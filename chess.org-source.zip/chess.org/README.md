# chess.org source code

Corresponding source of the chess.org web app published at https://chessorg.sebbrochet.com, licensed GPL-3.0-or-later (see LICENSE.txt).
Third-party components keep their own licenses: public/THIRD_PARTY_NOTICES.md and public/THIRD_PARTY_LICENSES.txt.

## Build

Requires Node.js 22 and network access for the first build.

    npm ci
    npm run build      # fetches and verifies Stockfish 18 assets and their source into public/engine, then builds dist/
    npm run preview    # serves dist/

## Develop and test

    npm run dev
    npm test                       # unit tests (Vitest)
    npx playwright install chromium
    npm run test:e2e               # browser tests against the built app
