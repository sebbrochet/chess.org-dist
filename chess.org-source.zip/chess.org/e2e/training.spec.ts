import { expect, test, type Page } from '@playwright/test';
import { legalContinuation } from '../src/chess/review';
import type { DomainSnapshot } from '../src/storage/library';

async function saved(page: Page): Promise<DomainSnapshot> {
  return page.evaluate(() => new Promise((resolve, reject) => {
    const request = indexedDB.open('keyval-store');
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const database = request.result;
      const transaction = database.transaction('keyval', 'readonly');
      const record = transaction.objectStore('keyval').get('chess.org:domain');
      record.onsuccess = () => resolve(record.result);
      transaction.oncomplete = () => database.close();
    };
  }));
}

test('recorded guessing saves assistance, preserves source and clears local progress', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Import PGN', exact: true }).first().click();
  await page.getByRole('textbox', { name: 'PGN', exact: true }).fill('[Title "Recall"]\n[White "Franzine_Echec"]\n[Black "sebbrochet"]\n1.e4 e5 2.Nf3 *');
  await page.getByRole('button', { name: 'Validate PGN' }).click();
  await page.getByRole('button', { name: 'Import 1 selected' }).click();
  const before = await saved(page);
  await page.getByRole('link', { name: 'Guess the Move', exact: true }).click();
  await page.getByRole('button', { name: 'Start practice' }).click();
  await expect(page.getByLabel('Target move')).toHaveCount(0);
  await expect(page.getByLabel('Training board').locator('.player-line strong')).toHaveText(['sebbrochet', 'Franzine_Echec']);
  await page.getByLabel('Your move', { exact: true }).fill('d4');
  await page.getByRole('button', { name: 'Submit answer', exact: true }).click();
  await expect(page.getByLabel('Exercise result')).toHaveText('Not the recorded move');
  await expect(page.getByLabel('Target move')).toHaveCount(0);
  await page.screenshot({ path: test.info().outputPath('concealed-guess.png'), fullPage: true });
  const failedGuess = await saved(page);
  await page.getByRole('button', { name: 'Show solution', exact: true }).click();
  await expect(page.getByLabel('Target move')).toHaveText('Target: e4');
  expect(await saved(page)).toEqual(failedGuess);
  await expect(page.getByLabel('Exercise result')).toHaveText('Not the recorded move');
  await page.getByRole('button', { name: 'Retry position', exact: true }).click();
  await expect(page.getByLabel('Target move')).toHaveCount(0);
  await page.getByRole('button', { name: 'Show hint', exact: true }).click();
  await expect(page.getByLabel('Move hint')).toHaveText('Move from e2.');
  await page.getByLabel('Your move', { exact: true }).fill('e4');
  await page.getByRole('button', { name: 'Submit answer', exact: true }).click();
  await expect(page.getByLabel('Exercise result')).toHaveText('Assisted result');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', before.games[0].positions[1]);
  await page.getByRole('button', { name: 'Next position', exact: true }).click();
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', before.games[0].positions[2]);
  await page.getByLabel('Your move', { exact: true }).fill('Nf3');
  await page.getByRole('button', { name: 'Submit answer', exact: true }).click();
  await expect(page.getByLabel('Exercise result')).toHaveText('Unaided success');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', before.games[0].positions[3]);
  expect((await saved(page)).games).toEqual(before.games);
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Progress', exact: true }).click();
  await expect(page.getByLabel('Guess the Move summary')).toContainText('3 attempts / 1 unaided successes / 1 assisted');
  await page.reload();
  await expect(page.getByLabel('Guess the Move summary')).toContainText('3 attempts');
  await page.getByRole('button', { name: 'Clear progress', exact: true }).click();
  await page.getByRole('button', { name: 'Clear attempt history', exact: true }).click();
  await expect(page.getByLabel('Guess the Move summary')).toContainText('0 attempts');
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Games', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Recall', exact: true })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('real review to mistake verification retains an offline unaided result', async ({ page, context }) => {
  test.setTimeout(60000);
  await page.addInitScript(() => {
    const state = { hold: false, pending: [] as { worker: Worker; event: MessageEvent }[],
      release() { this.hold = false; for (const item of this.pending.splice(0)) item.worker.dispatchEvent(new MessageEvent('message', { data: item.event.data })); },
      fail() { this.hold = false; for (const item of this.pending.splice(0)) item.worker.dispatchEvent(new ErrorEvent('error', { message: 'Injected engine failure' })); } };
    Object.assign(window, { trainerEngineGate: state });
    const NativeWorker = window.Worker;
    window.Worker = class extends NativeWorker {
      constructor(url: string | URL, options?: WorkerOptions) {
        super(url, options);
        this.addEventListener('message', event => {
          if (state.hold && String(event.data).startsWith('bestmove ')) { event.stopImmediatePropagation(); state.pending.push({ worker: this, event }); }
        });
      }
    };
  });
  await page.goto('/');
  await page.getByRole('button', { name: 'Import PGN', exact: true }).first().click();
  await page.getByRole('textbox', { name: 'PGN', exact: true }).fill('[Title "Training evidence"]\n[SetUp "1"]\n[FEN "r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3"]\n3.Nxe5 *');
  await page.getByRole('button', { name: 'Validate PGN' }).click();
  await page.getByRole('button', { name: 'Import 1 selected' }).click();
  const before = await saved(page);
  await page.getByRole('link', { name: 'Review game', exact: true }).click();
  await page.getByRole('button', { name: 'Review game', exact: true }).click();
  await expect(page.getByLabel('Review status', { exact: true })).toHaveText('Complete / 1 of 1 moves', { timeout: 20000 });
  await page.getByRole('link', { name: 'Practice mistakes', exact: true }).click();
  await page.getByRole('button', { name: 'Start practice', exact: true }).click();
  await expect(page.getByLabel('Target move')).toHaveCount(0);
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await context.setOffline(true);
  await page.evaluate(() => { (window as unknown as { trainerEngineGate: { hold: boolean } }).trainerEngineGate.hold = true; });
  await page.getByLabel('Your move', { exact: true }).fill('d4');
  await page.getByRole('button', { name: 'Submit answer', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as unknown as { trainerEngineGate: { pending: unknown[] } }).trainerEngineGate.pending.length)).toBeGreaterThan(0);
  await expect(page.getByLabel('Exercise result')).toHaveText('Checking and saving...');
  await expect(page.getByLabel('Your move', { exact: true })).toBeDisabled();
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', legalContinuation(before.games[0].startFen, ['d2d4'])[0].fen);
  expect((await saved(page)).mistakeAttempts[0]).toMatchObject({ status: 'Active', answers: [] });
  await page.evaluate(() => { (window as unknown as { trainerEngineGate: { release(): void } }).trainerEngineGate.release(); });
  await expect(page.getByLabel('Exercise result')).toHaveText('Unaided success', { timeout: 20000 });
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', legalContinuation(before.games[0].startFen, ['d2d4'])[0].fen);
  const retained = await saved(page);
  expect(retained.games).toEqual(before.games);
  expect(retained.mistakeAttempts[0].fen).toBe(before.games[0].startFen);
  await page.getByRole('button', { name: 'Retry position', exact: true }).click();
  await page.evaluate(() => { (window as unknown as { trainerEngineGate: { hold: boolean } }).trainerEngineGate.hold = true; });
  await page.getByLabel('Your move', { exact: true }).fill('Nxe5');
  await page.getByRole('button', { name: 'Submit answer', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as unknown as { trainerEngineGate: { pending: unknown[] } }).trainerEngineGate.pending.length)).toBeGreaterThan(0);
  await expect(page.getByLabel('Exercise result')).toHaveText('Checking and saving...');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', before.games[0].positions[1]);
  await page.evaluate(() => { (window as unknown as { trainerEngineGate: { release(): void } }).trainerEngineGate.release(); });
  await expect(page.getByLabel('Exercise result')).toHaveText('Outside the accepted engine result');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', before.games[0].startFen);
  await expect(page.getByLabel('Target move')).toHaveCount(0);
  const failedMistake = await saved(page);
  await page.getByRole('button', { name: 'Show solution', exact: true }).click();
  await expect(page.getByLabel('Target move')).toHaveText('Target: d4');
  expect(await saved(page)).toEqual(failedMistake);
  await expect(page.getByLabel('Exercise result')).toHaveText('Outside the accepted engine result');
  await page.getByRole('button', { name: 'Retry position', exact: true }).click();
  await expect(page.getByLabel('Target move')).toHaveCount(0);
  await page.evaluate(() => { (window as unknown as { trainerEngineGate: { hold: boolean } }).trainerEngineGate.hold = true; });
  await page.getByLabel('Your move', { exact: true }).fill('d4');
  await page.getByRole('button', { name: 'Submit answer', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as unknown as { trainerEngineGate: { pending: unknown[] } }).trainerEngineGate.pending.length)).toBeGreaterThan(0);
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', legalContinuation(before.games[0].startFen, ['d2d4'])[0].fen);
  await page.evaluate(() => { (window as unknown as { trainerEngineGate: { fail(): void } }).trainerEngineGate.fail(); });
  await expect(page.getByRole('alert')).toBeVisible();
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', before.games[0].startFen);
  await expect(page.getByLabel('Exercise result')).toHaveText('Your answer');
  expect((await saved(page)).mistakeAttempts.at(-1)).toMatchObject({ status: 'Active', answers: [] });
  expect((await saved(page)).games).toEqual(before.games);
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Progress', exact: true }).click();
  await expect(page.getByLabel('Practice Mistakes summary')).toContainText('3 attempts / 1 unaided successes');
  await page.reload();
  await expect(page.getByLabel('Practice Mistakes summary')).toContainText('3 attempts / 1 unaided successes');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('accepted Qc4 remains on the board after pointer input and retry restores the exercise', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Import PGN', exact: true }).first().click();
  await page.getByRole('textbox', { name: 'PGN', exact: true }).fill('[Title "Queen recall"]\n[White "Franzine_Echec"]\n[Black "sebbrochet"]\n[SetUp "1"]\n[FEN "4k3/8/2q5/8/8/8/8/6K1 b - - 0 1"]\n1...Qc4 *');
  await page.getByRole('button', { name: 'Validate PGN' }).click();
  await page.getByRole('button', { name: 'Import 1 selected' }).click();
  const before = await saved(page);
  await page.getByRole('link', { name: 'Guess the Move', exact: true }).click();
  await expect(page.getByLabel('Training board').locator('.player-line strong')).toHaveText(['sebbrochet', 'Franzine_Echec']);
  await page.getByRole('combobox', { name: /Practice side/ }).selectOption('black');
  await expect(page.getByLabel('Training board').locator('.player-line strong')).toHaveText(['Franzine_Echec', 'sebbrochet']);
  await page.getByRole('button', { name: 'Start practice', exact: true }).click();
  const board = page.locator('cg-board');
  await board.scrollIntoViewIfNeeded();
  const box = (await board.boundingBox())!;
  const origin = { position: { x: box.width * 5.5 / 8, y: box.height * 5.5 / 8 } };
  const destination = { position: { x: box.width * 5.5 / 8, y: box.height * 3.5 / 8 } };
  if (test.info().project.name === 'phone') await board.tap(origin); else await board.click(origin);
  await expect(page.locator('cg-board square.selected')).toHaveCount(1);
  if (test.info().project.name === 'phone') await board.tap(destination); else await board.click(destination);
  await expect(page.getByLabel('Exercise result')).toHaveText('Unaided success');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', before.games[0].positions[1]);
  await expect(page.locator('cg-board piece.anim')).toHaveCount(0);
  expect(await page.locator('cg-board piece.black.queen').evaluate(node => (node as HTMLElement & { cgKey: string }).cgKey)).toBe('c4');
  await page.screenshot({ path: test.info().outputPath('accepted-queen.png'), fullPage: true });
  const completed = await saved(page);
  expect(completed.games).toEqual(before.games);
  expect(completed.guessMoveAttempts[0]).toMatchObject({ status: 'Success', fen: before.games[0].startFen, answers: ['c6c4'] });
  await page.getByRole('button', { name: 'Retry position', exact: true }).click();
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', before.games[0].startFen);
  await expect(page.getByLabel('Target move')).toHaveCount(0);
  await page.getByRole('button', { name: 'Reveal answer', exact: true }).click();
  await expect(page.getByLabel('Exercise result')).toHaveText('Assisted result');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', before.games[0].startFen);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});