import { expect, test } from '@playwright/test';
import { lastRecordedMove, parseGames } from '../src/chess/pgn';

async function highlightedSquares(page: import('@playwright/test').Page, className: string) {
  return page.locator(`cg-board square.${className}`).evaluateAll(nodes => {
    const board = document.querySelector('cg-board')!.getBoundingClientRect();
    const black = document.querySelector('.board-frame')!.getAttribute('aria-label')!.includes('black at bottom');
    return nodes.map(node => {
      const box = node.getBoundingClientRect();
      const column = Math.floor((box.left - board.left + box.width / 2) / board.width * 8);
      const row = Math.floor((box.top - board.top + box.height / 2) / board.height * 8);
      return `${'abcdefgh'[black ? 7 - column : column]}${black ? row + 1 : 8 - row}`;
    }).sort();
  });
}

async function recordedHighlight(page: import('@playwright/test').Page) {
  const moves = await page.getByLabel('Saved moves').locator('li').allTextContents();
  const move = lastRecordedMove(parseGames(`1. ${moves.join(' ')} *`)[0])!;
  return [move.slice(0, 2), move.slice(2, 4)].sort();
}

async function openSetup(page: import('@playwright/test').Page) {
  await page.goto('/#/play');
  await expect(page.getByRole('heading', { name: 'Play Computer', exact: true })).toBeVisible();
}
async function start(page: import('@playwright/test').Page) {
  await page.getByRole('button', { name: 'Start game', exact: true }).click();
  await page.waitForURL(/#\/play\/[^/]+$/);
  await expect(page.getByRole('region', { name: 'Live game' })).toBeVisible();
}
async function square(page: import('@playwright/test').Page, file: number, rankFromTop: number) {
  const board = page.locator('cg-board');
  await board.scrollIntoViewIfNeeded();
  const box = (await board.boundingBox())!;
  const options = { position: { x: box.width * (file + 0.5) / 8, y: box.height * (rankFromTop + 0.5) / 8 } };
  if (test.info().project.name === 'phone') await board.tap(options);
  else await board.click(options);
}
test('reports verified bootstrap download failures promptly and reuses assets after a clean retry', async ({ page }) => {
  let fail = true;
  let scripts = 0;
  let wasm = 0;
  await page.route('**/engine/stockfish-18-lite-single.js', route => {
    scripts++;
    return fail ? route.fulfill({ status: 503, body: 'Unavailable' }) : route.continue();
  });
  await page.route('**/engine/stockfish-18-lite-single.wasm', route => { wasm++; return route.continue(); });
  const workers: string[] = [];
  page.on('worker', worker => workers.push(worker.url()));
  await openSetup(page);
  await page.getByRole('button', { name: 'Start game', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('Stockfish asset unavailable (503)');
  await expect(page.getByRole('region', { name: 'New game setup' })).toBeVisible();
  expect(workers).toHaveLength(0);
  fail = false;
  await start(page);
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  const fetched = { scripts, wasm };
  expect(fetched).toEqual({ scripts: 2, wasm: 2 });
  expect(workers[0]).toMatch(/^blob:.*?,stockfish$/);
  await page.getByLabel('Move (SAN)', { exact: true }).fill('e4');
  await page.getByRole('button', { name: 'Play move', exact: true }).click();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(2);
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  expect({ scripts, wasm }).toEqual(fetched);
  expect(workers).toHaveLength(1);
  await expect(page.getByRole('alert')).toHaveCount(0);
});

test('move sounds distinguish captures, obey mute and remain available offline', async ({ page, context }) => {
  await page.addInitScript(() => {
    Object.assign(window, { moveSoundCalls: [] as string[] });
    HTMLMediaElement.prototype.play = function () {
      (window as unknown as { moveSoundCalls: string[] }).moveSoundCalls.push(this.src);
      return Promise.resolve();
    };
  });
  const sounds = () => page.evaluate(() => (window as unknown as { moveSoundCalls: string[] }).moveSoundCalls.map(src => src.split('/').at(-1)));
  await page.goto('/');
  await page.getByRole('button', { name: 'Import PGN', exact: true }).first().click();
  await page.getByRole('textbox', { name: 'PGN', exact: true }).fill('[Title "Sound replay"]\n1.e4 d5 2.exd5 *');
  await page.getByRole('button', { name: 'Validate PGN' }).click();
  await page.getByRole('button', { name: 'Import 1 selected' }).click();
  expect(await sounds()).toEqual([]);
  await page.getByRole('button', { name: 'Next move', exact: true }).click();
  await expect.poll(sounds).toEqual(['move.mp3']);
  await page.getByRole('button', { name: 'Next move', exact: true }).click();
  await page.getByRole('button', { name: 'Next move', exact: true }).click();
  await expect.poll(sounds).toEqual(['move.mp3', 'move.mp3', 'capture.mp3']);
  await page.getByRole('button', { name: 'Flip board', exact: true }).click();
  expect(await sounds()).toHaveLength(3);
  await page.getByRole('button', { name: 'Mute move sounds', exact: true }).click();
  await page.getByRole('button', { name: 'Previous move', exact: true }).click();
  await page.getByRole('button', { name: 'Next move', exact: true }).click();
  expect(await sounds()).toHaveLength(3);
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload();
  await expect(page.getByRole('button', { name: 'Enable move sounds', exact: true })).toBeVisible();
  expect(await page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);
  await context.setOffline(true);
  const clips = await page.evaluate(async () => {
    const audio = new AudioContext();
    try {
      return await Promise.all(['move', 'capture'].map(async name => {
        const response = await fetch(`/sounds/${name}.mp3`);
        const buffer = await audio.decodeAudioData(await response.arrayBuffer());
        return { name, status: response.status, duration: buffer.duration };
      }));
    } finally { await audio.close(); }
  });
  expect(clips.every(clip => clip.status === 200 && clip.duration > 0)).toBe(true);
  await page.reload();
  await expect(page.getByRole('button', { name: 'Enable move sounds', exact: true })).toBeVisible();
  expect(await sounds()).toEqual([]);
  await page.getByRole('button', { name: 'Enable move sounds', exact: true }).click();
  await page.getByRole('button', { name: 'Next move', exact: true }).click();
  await expect.poll(sounds).toEqual(['move.mp3']);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('recovers a stalled initial startup and reuses the replacement for opponent replies', async ({ page }) => {
  await page.addInitScript(() => {
    const state = { workers: 0, blocked: false, bestmoves: 0, replyReady: false };
    let held: { worker: Worker; data: string } | undefined;
    Object.assign(window, { startupRecoveryProbe: state });
    Object.assign(window, { releaseEngineReply: () => { const reply = held; held = undefined; if (reply) reply.worker.dispatchEvent(new MessageEvent('message', { data: reply.data })); } });
    const NativeWorker = window.Worker;
    window.Worker = class extends NativeWorker {
      constructor(url: string | URL, options?: WorkerOptions) {
        super(url, options);
        const index = ++state.workers;
        this.addEventListener('message', event => {
          if (index === 1 && String(event.data) === 'chess.org:stockfish-worker-ready') { state.blocked = true; event.stopImmediatePropagation(); }
          if (index === 2 && String(event.data).startsWith('bestmove ') && ++state.bestmoves === 2) {
            held = { worker: this, data: String(event.data) }; state.replyReady = true; event.stopImmediatePropagation();
          }
        });
      }
    };
  });
  await openSetup(page);
  await page.getByRole('combobox', { name: 'Stockfish level', exact: true }).selectOption('0');
  await page.getByRole('button', { name: 'Start game', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as unknown as { startupRecoveryProbe: { blocked: boolean } }).startupRecoveryProbe.blocked)).toBe(true);
  await expect(page.getByRole('region', { name: 'New game setup' })).toBeVisible();
  await expect(page.getByRole('alert')).toHaveCount(0);
  await expect.poll(() => page.evaluate(() => (window as unknown as { startupRecoveryProbe: { workers: number } }).startupRecoveryProbe.workers), { timeout: 15000 }).toBe(2);
  await page.waitForURL(/#\/play\/[^/]+$/);
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  await page.getByLabel('Move (SAN)', { exact: true }).fill('e4');
  await page.getByRole('button', { name: 'Play move', exact: true }).click();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(1);
  await expect(page.getByLabel('Saved moves').locator('li').first()).toHaveText('e4');
  await expect(page.getByRole('alert')).toHaveCount(0);
  await expect.poll(() => page.evaluate(() => (window as unknown as { startupRecoveryProbe: { replyReady: boolean } }).startupRecoveryProbe.replyReady)).toBe(true);
  await page.evaluate(() => (window as unknown as { releaseEngineReply(): void }).releaseEngineReply());
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(2);
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  await expect(page.getByRole('alert')).toHaveCount(0);
  expect(await page.evaluate(() => (window as unknown as { startupRecoveryProbe: { workers: number } }).startupRecoveryProbe.workers)).toBe(2);
  const savedFen = await page.getByRole('img', { name: /^Chessboard/ }).getAttribute('data-fen');
  await page.reload();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(2);
  await expect(page.getByLabel('Saved moves').locator('li').first()).toHaveText('e4');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', savedFen!);
});

test('real engine, legal board/SAN, saved reply, takeback, resume and resignation', async ({ page }, testInfo) => {
  const workers: string[] = [];
  page.on('worker', worker => workers.push(worker.url()));
  await openSetup(page);
  await page.getByRole('combobox', { name: 'Stockfish level', exact: true }).selectOption('0');
  await page.getByLabel('Allow takebacks').check();
  await start(page);
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  await expect(page.getByRole('region', { name: 'Computer game board' }).locator('.player-line strong')).toHaveText(['Computer', 'You']);
  await expect(page.getByRole('region', { name: 'Computer game board' }).locator('.clock')).toHaveCount(0);
  await expect(page.getByText('Untimed', { exact: true })).toHaveCount(0);
  await expect(page.getByText('Time control', { exact: true })).toHaveCount(0);
  const boardNode = await page.locator('cg-board').elementHandle();
  const whiteKing = await page.locator('cg-board piece.white.king').elementHandle();
  await square(page, 4, 6);
  await expect(page.locator('cg-board square.selected')).toHaveCount(1);
  expect(await highlightedSquares(page, 'selected')).toEqual(['e2']);
  await expect(page.locator('cg-board square.selected')).not.toHaveCSS('background-color', 'rgba(0, 0, 0, 0)');
  expect(await highlightedSquares(page, 'move-dest')).toEqual(['e3', 'e4']);
  await expect(page.locator('cg-board square.move-dest').first()).toHaveCSS('background-image', /radial-gradient/);
  await page.screenshot({ path: testInfo.outputPath('selected-piece.png'), fullPage: true });
  await square(page, 4, 4);
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(2);
  await expect(page.getByLabel('Saved moves').locator('li').first()).toHaveText('e4');
  const replyHighlights = await recordedHighlight(page);
  await expect.poll(() => highlightedSquares(page, 'last-move')).toEqual(replyHighlights);
  await expect(page.locator('cg-board square.last-move').first()).not.toHaveCSS('background-color', 'rgba(0, 0, 0, 0)');
  expect(await page.locator('cg-board').evaluate((node, original) => node === original, boardNode)).toBe(true);
  expect(await page.locator('cg-board piece.white.king').evaluate((node, original) => node === original, whiteKing)).toBe(true);
  await page.getByRole('button', { name: 'Take back', exact: true }).click();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(0);
  await expect(page.locator('cg-board square.last-move')).toHaveCount(0);
  await expect(page.getByText('Enabled / 1 used')).toBeVisible();
  expect(await page.locator('cg-board').evaluate((node, original) => node === original, boardNode)).toBe(true);
  await page.getByLabel('Move (SAN)', { exact: true }).fill('d4');
  await page.getByRole('button', { name: 'Play move', exact: true }).click();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(2);
  const resumedHighlights = await recordedHighlight(page);
  expect(workers.filter(url => url.startsWith('blob:') && url.endsWith(',stockfish'))).toHaveLength(1);
  expect(await page.locator('cg-board').evaluate((node, original) => node === original, boardNode)).toBe(true);
  expect(await page.locator('cg-board piece.white.king').evaluate((node, original) => node === original, whiteKing)).toBe(true);
  const savedFen = await page.getByRole('img', { name: /^Chessboard/ }).getAttribute('data-fen');
  await page.getByRole('button', { name: 'Flip board', exact: true }).click();
  expect(await highlightedSquares(page, 'last-move')).toEqual(resumedHighlights);
  await page.getByRole('button', { name: 'Flip board', exact: true }).click();
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Games', exact: true }).click();
  await page.getByRole('link', { name: 'Resume game', exact: true }).click();
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', savedFen!);
  await page.reload();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(2);
  expect(await highlightedSquares(page, 'last-move')).toEqual(resumedHighlights);
  await expect(page.getByText('Enabled / 1 used')).toBeVisible();
  expect(workers.filter(url => url.startsWith('blob:') && url.endsWith(',stockfish'))).toHaveLength(1);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({ path: testInfo.outputPath('play-computer.png'), fullPage: true });
  await page.getByRole('button', { name: 'Resign', exact: true }).click();
  await page.getByRole('button', { name: 'Resign game', exact: true }).click();
  await expect(page.getByText('0-1 / Resignation')).toBeVisible();
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Games', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Resume game', exact: true })).toHaveCount(0);
});

test('developed pieces remain stationary during typed and pointer moves', async ({ page }) => {
  test.setTimeout(45000);
  await openSetup(page);
  await page.getByRole('combobox', { name: 'Starting position', exact: true }).selectOption('fen');
  await page.getByLabel('Starting FEN').fill('r1bqk2r/ppp2ppp/2np1n2/2b1p3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQkq - 2 6');
  await page.getByRole('combobox', { name: 'Stockfish level', exact: true }).selectOption('0');
  await start(page);
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  await expect(page.locator('cg-board piece.anim')).toHaveCount(0);
  await page.evaluate(() => {
    type Piece = HTMLElement & { cgKey: string; cgPiece: string; cgAnimating?: boolean };
    const root = document.querySelector('.board-frame')!;
    const initial = new Map(Array.from(root.querySelectorAll<Piece>('piece'), node => [node.cgKey, { piece: node.cgPiece, transform: node.style.transform }]));
    const stationaryMoved = new Set<string>();
    const animated = new Set<string>();
    const observer = new MutationObserver(() => {
      for (const node of root.querySelectorAll<Piece>('piece')) {
        if (node.cgAnimating || node.classList.contains('anim')) animated.add(`${node.cgKey}:${node.cgPiece}`);
        const before = initial.get(node.cgKey);
        if (before?.piece === node.cgPiece && before.transform !== node.style.transform) stationaryMoved.add(`${node.cgKey}:${node.cgPiece}`);
      }
    });
    observer.observe(root, { subtree: true, attributes: true, childList: true });
    Object.assign(window, { boardMotionProbe: { stationaryMoved, animated, stop: () => observer.disconnect() } });
  });
  await page.getByLabel('Move (SAN)', { exact: true }).fill('a3');
  await page.getByRole('button', { name: 'Play move', exact: true }).click();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(2, { timeout: 15000 });
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  await expect(page.locator('cg-board piece.anim')).toHaveCount(0);
  await square(page, 1, 6);
  await expect(page.locator('cg-board square.selected')).toHaveCount(1);
  await square(page, 1, 5);
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(4, { timeout: 15000 });
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  await expect(page.locator('cg-board piece.anim')).toHaveCount(0);
  const motion = await page.evaluate(() => {
    const probe = (window as unknown as { boardMotionProbe: { stationaryMoved: Set<string>; animated: Set<string>; stop(): void } }).boardMotionProbe;
    probe.stop();
    return { stationaryMoved: [...probe.stationaryMoved], animated: [...probe.animated] };
  });
  expect(motion.animated).toContain('a3:white pawn');
  expect(motion.stationaryMoved).toEqual([]);
});

test('retains the complete hashed engine set and obtains a real move after offline reload', async ({ page, context }) => {
  await page.goto('/');
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload();
  await expect(page.getByText('Offline shell ready')).toBeVisible();
  const retained = await page.evaluate(async () => {
    const manifest = await (await fetch('/engine/manifest.json')).json() as { assets: { path: string; bytes: number; sha256: string }[] };
    return Promise.all(manifest.assets.map(async asset => {
      const cached = await caches.match(asset.path, { ignoreVary: true });
      if (!cached) return { path: asset.path, valid: false };
      const data = await cached.arrayBuffer();
      const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', data)), value => value.toString(16).padStart(2, '0')).join('');
      return { path: asset.path, valid: data.byteLength === asset.bytes && hash === asset.sha256, bytes: data.byteLength, hash };
    }));
  });
  expect(retained, JSON.stringify(retained)).toEqual(expect.arrayContaining(retained.map(asset => expect.objectContaining({ path: asset.path, valid: true }))));
  expect(retained.map(asset => asset.path)).toContain('/engine/stockfish-18-lite-single.wasm');
  await context.setOffline(true);
  await page.reload();
  await page.getByRole('link', { name: 'Play Computer', exact: true }).click();
  await page.getByRole('combobox', { name: 'Your side', exact: true }).selectOption('black');
  await page.getByRole('combobox', { name: 'Stockfish level', exact: true }).selectOption('1');
  await start(page);
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(1);
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  const protocol = await page.evaluate(() => new Promise<{ engine: string; info: string; bestmove: string }>((resolve, reject) => {
    const worker = new Worker('/engine/stockfish-18-lite-single.js');
    let engine = '';
    let info = '';
    const timeout = setTimeout(() => { worker.terminate(); reject(new Error('Real offline engine did not finish')); }, 10000);
    worker.onerror = event => { clearTimeout(timeout); worker.terminate(); reject(new Error(event.message)); };
    worker.onmessage = event => {
      const line = String(event.data);
      if (line.startsWith('id name ')) engine = line;
      if (line === 'uciok') worker.postMessage('isready');
      if (line === 'readyok') { worker.postMessage('position startpos'); worker.postMessage('go depth 8'); }
      if (/score (cp|mate) /.test(line)) info = line;
      if (line.startsWith('bestmove ')) { clearTimeout(timeout); worker.terminate(); resolve({ engine, info, bestmove: line }); }
    };
    worker.postMessage('uci');
  }));
  expect(protocol.engine).toContain('Stockfish');
  expect(protocol.info).toContain('depth 8');
  expect(protocol.bestmove).toMatch(/^bestmove [a-h][1-8][a-h][1-8]/);
  console.log('REAL_OFFLINE_ENGINE', JSON.stringify({ project: test.info().project.name, retained, protocol }));
});

test('custom FEN intended draw, underpromotion and terminal starting position', async ({ page }) => {
  await openSetup(page);
  await page.getByRole('combobox', { name: 'Starting position', exact: true }).selectOption('fen');
  await page.getByLabel('Starting FEN').fill('7k/8/8/8/8/8/R7/K7 w - - 99 1');
  await start(page);
  await page.getByLabel('Intended move for draw claim').fill('Ra3');
  await page.getByRole('button', { name: 'Claim draw', exact: true }).click();
  await expect(page.getByText('1/2-1/2 / Fifty-move claim')).toBeVisible();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(0);
  await page.getByRole('link', { name: 'New game', exact: true }).click();
  await page.getByRole('combobox', { name: 'Starting position', exact: true }).selectOption('fen');
  await page.getByLabel('Starting FEN').fill('7k/P7/8/8/8/8/8/7K w - - 0 1');
  await start(page);
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  await square(page, 0, 1);
  await expect(page.locator('cg-board square.selected')).toHaveCount(1);
  await square(page, 0, 0);
  await page.getByRole('button', { name: 'Knight', exact: true }).click();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveText(['a8=N']);
  await expect(page.getByText('1/2-1/2 / Dead position')).toBeVisible();
  await page.getByRole('link', { name: 'New game', exact: true }).click();
  await page.getByRole('combobox', { name: 'Starting position', exact: true }).selectOption('fen');
  await page.getByLabel('Starting FEN').fill('7k/8/8/8/8/8/8/K7 w - - 0 1');
  await start(page);
  await expect(page.getByText('1/2-1/2 / Dead position')).toBeVisible();
});

test('selected position preserves its imported source and an absent timed game expires on resume', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Import PGN', exact: true }).first().click();
  await page.getByRole('textbox', { name: 'PGN', exact: true }).fill('1.e4 e5 *');
  await page.getByRole('button', { name: 'Validate PGN' }).click();
  await page.getByRole('button', { name: 'Import 1 selected' }).click();
  await expect(page.getByRole('link', { name: 'Resume game', exact: true })).toHaveCount(0);
  await page.getByRole('button', { name: 'Next move', exact: true }).click();
  const selectedFen = await page.getByRole('img', { name: /^Chessboard/ }).getAttribute('data-fen');
  await page.getByRole('link', { name: 'Play Computer', exact: true }).click();
  await page.getByRole('combobox', { name: 'Starting position', exact: true }).selectOption('selected');
  await page.getByRole('combobox', { name: 'Your side', exact: true }).selectOption('black');
  await start(page);
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', selectedFen!);
  await page.getByRole('link', { name: 'New game', exact: true }).click();
  await page.getByLabel('Timed game', { exact: true }).check();
  await page.getByLabel('Initial minutes').fill('0.1');
  await start(page);
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Games', exact: true }).click();
  await page.clock.install();
  await page.clock.fastForward(7000);
  await page.getByRole('link', { name: 'Resume game', exact: true }).click();
  await expect(page.getByText('0-1 / Timeout', { exact: true })).toBeVisible();
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(0);
});

test('board editor sets up a legal starting position kept in step with its FEN', async ({ page }) => {
  await openSetup(page);
  await page.getByRole('combobox', { name: 'Starting position', exact: true }).selectOption('fen');
  const fen = page.getByLabel('Starting FEN', { exact: true });
  await expect(fen).toHaveValue('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  const editor = page.locator('.position-editor-board cg-board');
  const place = async (file: number, rankFromTop: number) => {
    await editor.scrollIntoViewIfNeeded();
    const box = (await editor.boundingBox())!;
    const options = { position: { x: box.width * (file + 0.5) / 8, y: box.height * (rankFromTop + 0.5) / 8 } };
    if (test.info().project.name === 'phone') await editor.tap(options); else await editor.click(options);
  };
  const point = async (file: number, rankFromTop: number) => {
    const box = (await editor.boundingBox())!;
    return { x: box.x + box.width * (file + 0.5) / 8, y: box.y + box.height * (rankFromTop + 0.5) / 8 };
  };
  await editor.scrollIntoViewIfNeeded();
  await place(4, 4);
  await expect(fen).toHaveValue('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  if (test.info().project.name === 'phone') { await place(4, 6); await place(4, 4); }
  else {
    const from = await point(4, 6), to = await point(4, 4);
    await page.mouse.move(from.x, from.y); await page.mouse.down();
    await page.mouse.move(to.x, to.y, { steps: 8 }); await page.mouse.up();
  }
  await expect(fen).toHaveValue('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 1');
  await place(7, 7); await place(7, 4);
  await expect(fen).toHaveValue('rnbqkbnr/pppppppp/8/8/4P2R/8/PPPP1PPP/RNBQKBN1 w Qkq - 0 1');
  await page.getByRole('button', { name: 'Clear board', exact: true }).click();
  await expect(page.getByLabel('Position check')).toHaveText('The board is empty.');
  await expect(page.getByRole('button', { name: 'Start game', exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'white king', exact: true }).click(); await place(4, 7);
  await page.getByRole('button', { name: 'white rook', exact: true }).click(); await place(7, 7);
  await page.getByRole('button', { name: 'black king', exact: true }).click(); await place(4, 0);
  await page.getByLabel('White O-O', { exact: true }).check();
  await expect(fen).toHaveValue('4k3/8/8/8/8/8/8/4K2R w K - 0 1');
  await expect(page.getByLabel('Position check')).toHaveText('Legal position.');
  await page.getByRole('button', { name: 'Eraser', exact: true }).click(); await place(7, 7);
  await expect(fen).toHaveValue('4k3/8/8/8/8/8/8/4K3 w - - 0 1');
  await expect(page.getByLabel('White O-O', { exact: true })).toBeDisabled();
  await fen.fill('4k3/8/8/8/8/8/8/R3K3 w Q - 0 1');
  await expect(page.locator('.position-editor-board')).toHaveAttribute('data-fen', '4k3/8/8/8/8/8/8/R3K3 w Q - 0 1');
  await expect(page.getByLabel('White O-O-O', { exact: true })).toBeChecked();
  await page.screenshot({ path: test.info().outputPath('position-editor.png'), fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await start(page);
  await expect(page.locator('.replay .board-frame').first()).toHaveAttribute('data-fen', '4k3/8/8/8/8/8/8/R3K3 w Q - 0 1');
});

test('shows captured material, navigable moves and real-engine play aids that persist with the game', async ({ page }) => {
  test.setTimeout(120000);
  await openSetup(page);
  await page.getByRole('combobox', { name: 'Starting position', exact: true }).selectOption('fen');
  await page.getByLabel('Starting FEN', { exact: true }).fill('k7/8/8/3p4/4P3/8/8/K7 w - - 0 1');
  await page.getByLabel('Evaluation bar', { exact: true }).check();
  await page.getByLabel('Best-move arrow', { exact: true }).check();
  await page.getByLabel('Move assessments', { exact: true }).check();
  await start(page);
  await expect(page.getByRole('img', { name: /^Evaluation [+-]?#?-?\d/ })).toBeVisible({ timeout: 30000 });
  await expect(page.locator('.board-frame svg line')).toHaveCount(1, { timeout: 30000 });
  await expect(page.getByLabel('Captured by white: none')).toHaveCount(1);
  await page.getByLabel('Move (SAN)', { exact: true }).fill('exd5');
  await page.getByRole('button', { name: 'Play move', exact: true }).click();
  const moves = page.getByLabel('Saved moves').locator('li');
  await expect(moves).toHaveCount(2, { timeout: 15000 });
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  await expect(page.getByLabel('Saved moves').getByLabel('Assessment pending')).toHaveCount(0, { timeout: 60000 });
  await expect(page.getByLabel('Saved moves').getByLabel('Assessment unavailable')).toHaveCount(0);
  await page.getByRole('button', { name: 'First position', exact: true }).click();
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', 'k7/8/8/3p4/4P3/8/8/K7 w - - 0 1');
  await expect(page.getByLabel('Move (SAN)', { exact: true })).toBeDisabled();
  await expect(page.locator('.board-frame svg line')).toHaveCount(0);
  await expect(page.getByRole('status').filter({ hasText: 'Viewing start of 2' })).toBeVisible();
  await page.getByRole('button', { name: 'Next move', exact: true }).click();
  await expect(page.getByLabel('Captured by white: pawn; white ahead by 1')).toBeVisible();
  await page.getByRole('button', { name: 'Current position', exact: true }).click();
  await expect(page.getByLabel('Move (SAN)', { exact: true })).toBeEnabled();
  await page.getByLabel('Best-move arrow', { exact: true }).click();
  await expect(page.getByLabel('Best-move arrow', { exact: true })).not.toBeChecked();
  await expect(page.locator('.board-frame svg line')).toHaveCount(0);
  await page.reload();
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible();
  await expect(page.getByLabel('Best-move arrow', { exact: true })).not.toBeChecked();
  await expect(page.getByLabel('Evaluation bar', { exact: true })).toBeChecked();
  await expect(page.getByRole('img', { name: /^Evaluation / })).toBeVisible();
  await expect(page.getByLabel('Saved moves').getByLabel('Assessment pending')).toHaveCount(0);
  await expect(moves).toHaveCount(2);
});

test('resolves a Random side to a playable colour', async ({ page }) => {
  await openSetup(page);
  await page.getByRole('combobox', { name: 'Your side', exact: true }).selectOption('random');
  await start(page);
  await expect(page.getByRole('status').filter({ hasText: 'Your turn' })).toBeVisible({ timeout: 15000 });
  const side = await page.locator('.game-facts dd').first().textContent();
  expect(['white', 'black']).toContain(side);
  await expect(page.getByLabel('Saved moves').locator('li')).toHaveCount(side === 'white' ? 0 : 1);
});