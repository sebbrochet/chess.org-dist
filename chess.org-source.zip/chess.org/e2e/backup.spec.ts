import { readFile } from 'node:fs/promises';
import { expect, test } from '@playwright/test';

test('full backup preserves real review and all four training families through confirmed replacement', async ({ page }) => {
  test.setTimeout(90000);
  await page.goto('/');
  await page.getByRole('button', { name: 'Import PGN', exact: true }).first().click();
  await page.getByRole('textbox', { name: 'PGN', exact: true }).fill('[Title "Restore source"]\n[SetUp "1"]\n[FEN "r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3"]\n3.Nxe5 *');
  await page.getByRole('button', { name: 'Validate PGN', exact: true }).click(); await page.getByRole('button', { name: 'Import 1 selected', exact: true }).click();
  await page.getByRole('link', { name: 'Review game', exact: true }).click(); await page.getByRole('button', { name: 'Review game', exact: true }).click();
  await expect(page.getByLabel('Review status', { exact: true })).toHaveText('Complete / 1 of 1 moves', { timeout: 20000 });
  await page.getByRole('link', { name: 'Practice mistakes', exact: true }).click(); await page.getByRole('button', { name: 'Start practice', exact: true }).click();
  await page.getByLabel('Your move', { exact: true }).fill('d4'); await page.getByRole('button', { name: 'Submit answer', exact: true }).click();
  await expect(page.getByLabel('Exercise result')).toHaveText('Unaided success', { timeout: 20000 });
  const nav = page.getByRole('navigation', { name: 'Main' });
  await nav.getByRole('link', { name: 'Games', exact: true }).click(); await page.getByRole('link', { name: 'Guess the Move', exact: true }).click();
  await page.getByRole('button', { name: 'Start practice', exact: true }).click(); await page.getByLabel('Your move', { exact: true }).fill('Nxe5'); await page.getByRole('button', { name: 'Submit answer', exact: true }).click();
  await expect(page.getByLabel('Exercise result')).toHaveText('Unaided success');
  await nav.getByRole('link', { name: 'Repertoires', exact: true }).click(); await page.getByRole('button', { name: 'Import repertoire', exact: true }).click();
  await page.getByLabel('Repertoire name', { exact: true }).fill('Backup lines'); await page.getByLabel('Repertoire PGN', { exact: true }).fill('1.e4 e5 *'); await page.getByRole('button', { name: 'Save repertoire', exact: true }).click();
  await page.getByRole('link', { name: 'Practice selected lines', exact: true }).click(); await page.getByRole('button', { name: 'Start recall', exact: true }).click();
  await page.getByLabel('Recall move', { exact: true }).fill('e4'); await page.getByRole('button', { name: 'Submit recall', exact: true }).click(); await expect(page.getByLabel('Recall result')).toHaveText('Unaided success');
  await nav.getByRole('link', { name: 'Puzzles', exact: true }).click(); await page.getByRole('button', { name: 'Start puzzle', exact: true }).click();
  await page.getByLabel('Puzzle move', { exact: true }).fill('Qg7#'); await page.getByRole('button', { name: 'Submit puzzle move', exact: true }).click(); await expect(page.getByLabel('Puzzle result')).toHaveText('Unaided success');
  await nav.getByRole('link', { name: 'Backup', exact: true }).click();
  await expect(page.getByLabel('Current data counts')).toHaveText('1 games, 1 reviews, 1 repertoires, 3 puzzles, 4 attempts');
  const downloaded = page.waitForEvent('download'); await page.getByRole('button', { name: 'Export full backup', exact: true }).click();
  const backup = await downloaded; const text = await readFile((await backup.path())!, 'utf8');
  const parsed = JSON.parse(text); expect(parsed.data.mistakeAttempts).toHaveLength(1); expect(parsed.data.reviews[0].status).toBe('Complete');
  await nav.getByRole('link', { name: 'Games', exact: true }).click(); await page.getByRole('button', { name: 'Delete game', exact: true }).click(); await page.getByRole('button', { name: 'Delete permanently', exact: true }).click();
  await nav.getByRole('link', { name: 'Backup', exact: true }).click();
  await page.getByLabel('Full backup file', { exact: true }).setInputFiles({ name: 'all-personal-data.json', mimeType: 'application/json', buffer: Buffer.from(text) });
  await expect(page.getByLabel('Validated backup')).toContainText('all-personal-data.json');
  await page.getByRole('button', { name: 'Restore validated backup', exact: true }).click(); await page.getByRole('button', { name: 'Cancel', exact: true }).click();
  await expect(page.getByLabel('Current data counts')).toContainText('0 games, 0 reviews');
  await page.getByRole('button', { name: 'Restore validated backup', exact: true }).click(); await page.getByRole('button', { name: 'Replace local data', exact: true }).click();
  await expect(page.getByLabel('Backup status')).toContainText('Full backup restored.');
  await expect(page.getByLabel('Current data counts')).toHaveText('1 games, 1 reviews, 1 repertoires, 3 puzzles, 4 attempts');
  await page.reload(); await expect(page.getByLabel('Current data counts')).toHaveText('1 games, 1 reviews, 1 repertoires, 3 puzzles, 4 attempts');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('invalid backup cannot replace retained games', async ({ page }) => {
  await page.goto('/#/backup');
  await page.getByLabel('Full backup file', { exact: true }).setInputFiles({ name: 'corrupt.json', mimeType: 'application/json', buffer: Buffer.from('{"format":"wrong"}') });
  await expect(page.getByRole('alert')).toContainText('Backup rejected');
  await expect(page.getByRole('button', { name: 'Restore validated backup', exact: true })).toHaveCount(0);
  await expect(page.getByLabel('Current data counts')).toHaveText('0 games, 0 reviews, 0 repertoires, 0 puzzles, 0 attempts');
});