import { expect, test } from '@playwright/test';

if (process.env.RUN_LICHESS_LIVE === '1') test.use({ trace: 'off', screenshot: 'off', video: 'off' });
else test.beforeEach(async ({ page }) => { await page.route('https://lichess.org/api/cloud-eval?**', route => route.fulfill({ status: 404, body: '' })); });

async function square(page: import('@playwright/test').Page, file: number, rankFromTop: number) {
  const board = page.locator('.replay cg-board');
  await board.scrollIntoViewIfNeeded();
  const box = (await board.boundingBox())!;
  const options = { position: { x: box.width * (file + 0.5) / 8, y: box.height * (rankFromTop + 0.5) / 8 } };
  if (test.info().project.name === 'phone') await board.tap(options);
  else await board.click(options);
}

async function retainedGames(page: import('@playwright/test').Page) {
  return page.evaluate(async () => {
    const database = await new Promise<IDBDatabase>((resolve, reject) => { const request = indexedDB.open('keyval-store'); request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); });
    try {
      return await new Promise<{ games: { headers: Record<string, string>; pgn: string }[] }>((resolve, reject) => { const request = database.transaction('keyval').objectStore('keyval').get('chess.org:domain'); request.onsuccess = () => resolve(request.result ?? { games: [] }); request.onerror = () => reject(request.error); });
    } finally { database.close(); }
  });
}

test('public cadence filters Lichess before limiting and retains date/control metadata', async ({ page }) => {
  const rapid = '[GameId "RaPi1234"]\n[Event "Rated rapid game"]\n[White "Rapid Player"]\n[UTCDate "2026.11.06"]\n[UTCTime "12:34:56"]\n[TimeControl "600+5"]\n1.e4 *';
  const blitz = '[GameId "BlIt1234"]\n[Event "Rated blitz game"]\n[White "Blitz Player"]\n[Date "2026.11.05"]\n[TimeControl "180+2"]\n1.d4 *';
  await page.route('https://lichess.org/api/games/user/**', route => {
    const query = new URL(route.request().url()).searchParams;
    expect(query.get('until')).toBe(String(Date.parse('2026-11-07')));
    return route.fulfill({ contentType: 'application/x-chess-pgn', body: query.get('perfType') === 'rapid' ? rapid : query.get('perfType') === 'classical' ? '' : `${rapid}\n\n${blitz}` });
  });
  await page.goto('/#/online');
  await expect(page.getByLabel('Cadence', { exact: true })).toHaveValue('all');
  await page.getByLabel('Public username', { exact: true }).fill('club');
  await page.getByLabel('Before date (optional)', { exact: true }).fill('2026-11-07');
  await page.getByRole('button', { name: 'Fetch public games', exact: true }).click();
  await expect(page.locator('.preview-row')).toHaveCount(2);
  await expect(page.getByText('2026-11-06 / 12:34:56 (UTC)', { exact: true })).toBeVisible();
  await expect(page.getByText('Rapid / 10 min + 5 sec', { exact: true })).toBeVisible();
  await expect(page.getByText('2026-11-05 / Time unknown', { exact: true })).toBeVisible();
  await page.screenshot({ path: test.info().outputPath('public-games-cadence.png'), fullPage: true });
  expect((await retainedGames(page)).games).toHaveLength(0);
  await page.getByLabel('Cadence', { exact: true }).selectOption('rapid');
  await expect(page.getByRole('button', { name: 'Retain selected games', exact: true })).toBeDisabled();
  await page.getByRole('button', { name: 'Fetch public games', exact: true }).click();
  await expect(page.locator('.preview-row')).toHaveCount(1);
  await page.getByRole('button', { name: 'Retain selected games', exact: true }).click();
  await expect(page.getByLabel('Public import status')).toContainText('1 selected new records retained.');
  await page.getByLabel('Cadence', { exact: true }).selectOption('classical');
  await page.getByRole('button', { name: 'Fetch public games', exact: true }).click();
  await expect(page.getByText('No matching public games for this cadence and date or archive month.', { exact: true })).toBeVisible();
  await expect(page.getByRole('alert')).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Retain selected games', exact: true })).toBeDisabled();
  await page.reload();
  const saved = await retainedGames(page);
  expect(saved.games).toHaveLength(1);
  expect(saved.games[0].headers).toMatchObject({ TimeClass: 'rapid', TimeControl: '600+5', UTCDate: '2026.11.06', UTCTime: '12:34:56' });
  expect(saved.games[0].pgn).toContain('[TimeClass "rapid"]');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('public cadence filters chess.com within the chosen month and resets on provider change', async ({ page }) => {
  await page.route('https://api.chess.com/pub/player/club/games/archives', route => route.fulfill({ json: { archives: ['https://api.chess.com/pub/player/club/games/2026/10', 'https://api.chess.com/pub/player/club/games/2026/11'] } }));
  await page.route('https://api.chess.com/pub/player/club/games/2026/**', route => {
    const month = route.request().url().endsWith('/10') ? 'October' : 'November';
    return route.fulfill({ json: { games: ['rapid', 'blitz', 'daily', undefined].map((time_class, index) => ({ rules: 'chess', url: `https://www.chess.com/game/live/${month === 'October' ? 10 : 20}${index}`, pgn: `[White "${month} ${time_class ?? 'Unknown'}"]\n1.e4 *`, time_class, time_control: time_class === 'daily' ? '1/259200' : time_class ? '900+10' : undefined, end_time: time_class ? Date.parse('2026-11-06T12:34:56Z') / 1000 : undefined })) } });
  });
  await page.goto('/#/online');
  await page.getByLabel('Provider', { exact: true }).selectOption('chess.com');
  await page.getByLabel('Public username', { exact: true }).fill('club');
  await page.getByRole('button', { name: 'Fetch public games', exact: true }).click();
  await expect(page.locator('.preview-row')).toHaveCount(4);
  await expect(page.getByText('Cadence unknown / Time control unknown', { exact: true })).toBeVisible();
  await expect(page.getByText('Date unknown / Time unknown', { exact: true })).toBeVisible();
  await expect(page.getByText('Daily / 3 days/move', { exact: true })).toBeVisible();
  await page.getByLabel('Archive month', { exact: true }).selectOption('2026/10');
  await page.getByLabel('Cadence', { exact: true }).selectOption('rapid');
  await page.getByRole('button', { name: 'Fetch public games', exact: true }).click();
  await expect(page.locator('.preview-row')).toHaveCount(1);
  await expect(page.locator('.preview-row')).toContainText('October rapid');
  await expect(page.getByText('Ended 2026-11-06 / 12:34:56 (UTC)', { exact: true })).toBeVisible();
  await expect(page.getByText('Rapid / 15 min + 10 sec', { exact: true })).toBeVisible();
  expect((await retainedGames(page)).games).toHaveLength(0);
  await page.getByRole('button', { name: 'Retain selected games', exact: true }).click();
  await expect(page.getByLabel('Public import status')).toContainText('1 selected new records retained.');
  await page.reload();
  const saved = await retainedGames(page);
  expect(saved.games[0].headers).toMatchObject({ TimeClass: 'rapid', TimeControl: '900+10', EndUTCDate: '2026.11.06', EndUTCTime: '12:34:56' });
  await page.getByLabel('Cadence', { exact: true }).selectOption('classical');
  await page.getByLabel('Provider', { exact: true }).selectOption('chess.com');
  await expect(page.getByLabel('Cadence', { exact: true })).toHaveValue('all');
  await expect(page.getByLabel('Cadence', { exact: true }).locator('option[value="classical"]')).toHaveCount(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('public games preserve identity, deduplicate and survive provider refusal', async ({ page }) => {
  await page.route('https://lichess.org/api/games/user/**', route => route.fulfill({ contentType: 'application/x-chess-pgn', body: '[GameId "AbCd1234"]\n[White "Public White"]\n[Black "Public Black"]\n1.e4 e5 *' }));
  await page.goto('/#/online');
  await page.getByLabel('Public username', { exact: true }).fill('club-player');
  await page.getByRole('button', { name: 'Fetch public games', exact: true }).click();
  await expect(page.getByLabel('Public import status')).toContainText('1 public standard-chess records retrieved.');
  await page.getByRole('button', { name: 'Retain selected games', exact: true }).click();
  await expect(page.getByLabel('Public import status')).toContainText('1 selected new records retained.');
  await page.getByRole('button', { name: 'Retain selected games', exact: true }).click();
  await expect(page.getByLabel('Public import status')).toContainText('0 selected new records retained.');
  await page.route('https://lichess.org/api/games/user/**', route => route.fulfill({ status: 429, body: '' }));
  await page.getByRole('button', { name: 'Fetch public games', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('rate limit');
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Games', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Public White - Public Black', exact: true })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Library 1', exact: true })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('chess.com month selection and rating-filtered explorer distinguish empty and unavailable', async ({ page }) => {
  await page.route('https://api.chess.com/pub/player/club/games/archives', route => route.fulfill({ json: { archives: ['https://api.chess.com/pub/player/club/games/2026/10'] } }));
  await page.route('https://api.chess.com/pub/player/club/games/2026/10', route => route.fulfill({ json: { games: [{ rules: 'chess', url: 'https://www.chess.com/game/live/123', pgn: '[White "Club"]\n[Black "Opponent"]\n1.d4 d5 *' }] } }));
  await page.goto('/#/online');
  await page.getByLabel('Provider', { exact: true }).selectOption('chess.com');
  await page.getByLabel('Public username', { exact: true }).fill('club');
  await page.getByRole('button', { name: 'Fetch public games', exact: true }).click();
  await page.getByRole('button', { name: 'Retain selected games', exact: true }).click();
  await expect(page.getByLabel('Public import status')).toContainText('1 selected new records retained.');
  await page.route('https://explorer.lichess.ovh/lichess?**', route => {
    const query = new URL(route.request().url()).searchParams;
    expect(query.get('ratings')).toBe('1400,1600'); expect(query.get('speeds')).toBe('rapid,classical');
    return route.fulfill({ json: { white: 10, draws: 5, black: 5, moves: [{ uci: 'e2e4', white: 6, draws: 3, black: 1 }] } });
  });
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Openings', exact: true }).click();
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByLabel('Opening sample')).toHaveText('20 games / White 10 / Draws 5 / Black 5');
  await expect(page.getByText('Lichess ratings, not FIDE', { exact: true })).toBeVisible();
  await page.route('https://explorer.lichess.ovh/lichess?**', route => route.fulfill({ json: { white: 0, draws: 0, black: 0, moves: [] } }));
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByText('No games: no matching data for this position and filter.', { exact: true })).toBeVisible();
  await page.route('https://explorer.lichess.ovh/lichess?**', route => route.fulfill({ status: 401, body: '' }));
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('401');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('opening access is masked, session-only, provider-confined and cleared on reload', async ({ page }) => {
  const token = 'lip_browser_session_fixture';
  const headers: (string | undefined)[] = [];
  await page.route('https://explorer.lichess.ovh/lichess?**', route => {
    const authorization = route.request().headers().authorization; headers.push(authorization);
    return authorization ? route.fulfill({ json: { white: 10, draws: 5, black: 5, moves: [{ uci: 'e2e4', white: 6, draws: 3, black: 1 }] } }) : route.fulfill({ status: 401, body: '' });
  });
  await page.goto('/#/openings');
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('authentication refused (401)');
  await page.getByRole('button', { name: 'Lichess API access', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await expect(dialog.getByLabel('Lichess token', { exact: true })).toHaveAttribute('type', 'password');
  await expect(dialog.getByLabel('Remember on This Device', { exact: true })).not.toBeChecked();
  await dialog.getByLabel('Lichess token', { exact: true }).fill(token);
  await dialog.getByRole('button', { name: 'Validate and Use', exact: true }).click();
  await expect(dialog).toHaveCount(0);
  await expect(page.getByLabel('Lichess access status')).toHaveText('Accepted / Current Session');
  expect(await page.evaluate(() => localStorage.getItem('chess.org:lichess-access'))).toBeNull();
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByLabel('Opening sample')).toContainText('20 games');
  await page.route('https://lichess.org/api/games/user/**', route => {
    expect(route.request().headers().authorization).toBeUndefined();
    return route.fulfill({ body: '', contentType: 'application/x-chess-pgn' });
  });
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Public games', exact: true }).click();
  await page.getByLabel('Public username', { exact: true }).fill('club');
  await page.getByRole('button', { name: 'Fetch public games', exact: true }).click();
  await expect(page.getByText('No matching public games for this cadence and date or archive month.', { exact: true })).toBeVisible();
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Openings', exact: true }).click();
  await expect(page.getByLabel('Lichess access status')).toContainText('Current Session');
  expect(headers.slice(1)).toEqual([`Bearer ${token}`, `Bearer ${token}`]);
  expect(JSON.stringify(await retainedGames(page))).not.toContain(token);
  await page.reload();
  await expect(page.getByLabel('Lichess access status')).toHaveText('Anonymous access');
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('401');
  expect(headers.at(-1)).toBeUndefined();
});

test('remembered opening access preserves results on rejection, rate limits and network failure, then removes cleanly', async ({ page }) => {
  const token = 'lip_browser_device_fixture';
  let mode: 'ok' | 'refused' | 'limited' | 'network' = 'ok';
  const headers: (string | undefined)[] = [];
  await page.route('https://explorer.lichess.ovh/lichess?**', route => {
    headers.push(route.request().headers().authorization);
    if (mode === 'network') return route.abort('failed');
    return mode === 'ok' ? route.fulfill({ json: { white: 10, draws: 5, black: 5, moves: [{ uci: 'e2e4', white: 6, draws: 3, black: 1 }] } }) : route.fulfill({ status: mode === 'refused' ? 401 : 429, body: '' });
  });
  await page.goto('/#/openings');
  await page.getByRole('button', { name: 'Lichess API access', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByLabel('Lichess token', { exact: true }).fill(token);
  await dialog.getByLabel('Remember on This Device', { exact: true }).check();
  await expect(dialog.getByText(/not a secure vault/)).toBeVisible();
  await page.screenshot({ path: test.info().outputPath('lichess-access-consent.png'), fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await dialog.getByRole('button', { name: 'Validate and Use', exact: true }).click();
  await expect(dialog).toHaveCount(0);
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByLabel('Opening sample')).toContainText('20 games');
  mode = 'refused';
  await page.getByRole('button', { name: 'Lichess API access', exact: true }).click();
  await dialog.getByLabel('Lichess token', { exact: true }).fill('lip_rejected_fixture');
  await dialog.getByRole('button', { name: 'Validate and Use', exact: true }).click();
  await expect(dialog.getByRole('alert')).toContainText('authentication refused');
  expect(await page.evaluate(() => localStorage.getItem('chess.org:lichess-access'))).toBe(token);
  await dialog.getByRole('button', { name: 'Close dialog', exact: true }).click();
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByLabel('Lichess access status')).toContainText('Authentication refused');
  expect(headers.at(-1)).toBe(`Bearer ${token}`);
  mode = 'limited';
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('rate limit');
  await expect(page.getByLabel('Opening sample')).toContainText('20 games');
  mode = 'network';
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('network unavailable');
  await expect(page.getByLabel('Opening sample')).toContainText('20 games');
  mode = 'ok';
  await page.reload();
  await expect(page.getByLabel('Lichess access status')).toHaveText('Not checked / This Device');
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByLabel('Opening sample')).toContainText('20 games');
  await page.getByRole('button', { name: 'Lichess API access', exact: true }).click();
  await expect(dialog.getByLabel('Lichess token', { exact: true })).toHaveValue('');
  await dialog.getByRole('button', { name: 'Remove', exact: true }).click();
  await expect(page.getByLabel('Lichess access status')).toHaveText('Anonymous access');
  expect(await page.evaluate(() => localStorage.getItem('chess.org:lichess-access'))).toBeNull();
  await dialog.getByRole('button', { name: 'Close dialog', exact: true }).click();
  await expect(page.getByLabel('Opening sample')).toContainText('20 games');
  await page.reload();
  await expect(page.getByLabel('Lichess access status')).toHaveText('Anonymous access');
});

test('removing access during validation prevents a late browser response from remembering it', async ({ page }) => {
  let release!: () => void; let finish!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  const finished = new Promise<void>(resolve => { finish = resolve; });
  await page.route('https://explorer.lichess.ovh/lichess?**', async route => {
    await gate;
    try { await route.fulfill({ json: { white: 0, draws: 0, black: 0, moves: [] } }); }
    finally { finish(); }
  });
  await page.goto('/#/openings');
  await page.getByRole('button', { name: 'Lichess API access', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByLabel('Lichess token', { exact: true }).fill('lip_late_browser_fixture');
  await dialog.getByLabel('Remember on This Device', { exact: true }).check();
  const requested = page.waitForRequest('https://explorer.lichess.ovh/lichess?**');
  await dialog.getByRole('button', { name: 'Validate and Use', exact: true }).click();
  await requested;
  await dialog.getByRole('button', { name: 'Remove', exact: true }).click();
  release(); await finished;
  await expect(dialog.getByRole('status')).toHaveText('Access removed.');
  await expect(page.getByLabel('Lichess access status')).toHaveText('Anonymous access');
  expect(await page.evaluate(() => localStorage.getItem('chess.org:lichess-access'))).toBeNull();
  await page.reload();
  await expect(page.getByLabel('Lichess access status')).toHaveText('Anonymous access');
});

test('opening table shows names and percentages with pointer, keyboard and touch previews', async ({ page }, testInfo) => {
  const fen = 'rnbqkbnr/pppppppp/8/8/3P4/8/PPP1PPPP/RNBQKBNR b KQkq - 0 1';
  let requests = 0;
  await page.route('https://explorer.lichess.ovh/lichess?**', route => {
    requests++;
    return route.fulfill({ json: { white: 100, draws: 50, black: 50, opening: { eco: 'A40', name: "Queen's Pawn Game" }, moves: [
      { uci: 'd7d5', white: 60, draws: 30, black: 10, opening: { eco: 'D00', name: "Queen's Pawn Game" } },
      { uci: 'g8f6', white: 20, draws: 10, black: 10, opening: { eco: 'A45', name: 'Indian Defense' } },
      { uci: 'h7h6', white: 0, draws: 0, black: 0, opening: null },
    ] } });
  });
  await page.goto('/#/openings');
  await page.getByRole('textbox', { name: 'Position FEN', exact: true }).fill(fen);
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByLabel('Opening name')).toHaveText("A40 Queen's Pawn Game");
  const table = page.getByRole('table', { name: 'Opening continuations' });
  const row = table.getByRole('button', { name: 'd5', exact: true }).locator('xpath=ancestor::tr');
  await expect(row.getByRole('img', { name: 'White 60.0%, Draws 30.0%, Black 10.0%', exact: true })).toBeVisible();
  await expect(row).toContainText('50.0%');
  await expect(table.locator('tfoot').getByRole('img')).toHaveAttribute('aria-label', 'White 50.0%, Draws 25.0%, Black 25.0%');
  await expect(table.getByRole('img', { name: 'No games', exact: true })).toBeVisible();
  const board = page.locator('cg-board');
  await board.evaluate(element => element.setAttribute('data-preview-test', 'stable'));
  if (testInfo.project.name === 'phone') await page.getByRole('button', { name: 'Preview d5', exact: true }).tap();
  else await row.hover();
  await expect(page.locator('.cg-shapes line')).toHaveCount(1);
  await expect(page.getByLabel('Opening name')).toHaveText("D00 Queen's Pawn Game");
  await expect(page.locator('.board-frame')).toHaveAttribute('data-fen', fen);
  await expect(board).toHaveAttribute('data-preview-test', 'stable');
  expect(requests).toBe(1);
  await page.screenshot({ path: test.info().outputPath('opening-table-preview.png'), fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.getByRole('button', { name: 'Clear move preview', exact: true }).click();
  await expect(page.locator('.cg-shapes line')).toHaveCount(0);
  await expect(page.getByLabel('Opening name')).toHaveText("A40 Queen's Pawn Game");
  await page.getByRole('button', { name: 'Preview Nf6', exact: true }).focus();
  await expect(page.getByLabel('Opening name')).toHaveText('A45 Indian Defense');
  await expect(page.locator('.cg-shapes line')).toHaveCount(1);
  await page.getByRole('button', { name: 'Preview h6', exact: true }).focus();
  await expect(page.getByLabel('Opening name')).toHaveText('Opening unknown');
  expect(requests).toBe(1);
  expect((await retainedGames(page)).games).toHaveLength(0);
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.locator('.cg-shapes line')).toHaveCount(0);
  await expect(page.getByLabel('Opening name')).toHaveText("A40 Queen's Pawn Game");
});

test('selecting an opening continuation advances the board and clears its preview', async ({ page }) => {
  await page.route('https://explorer.lichess.ovh/lichess?**', route => {
    const fen = new URL(route.request().url()).searchParams.get('fen')!;
    const initial = fen.includes('PPPPPPPP/RNBQKBNR');
    return route.fulfill({ json: { white: 10, draws: 5, black: 5, opening: initial ? null : { eco: 'B00', name: "King's Pawn Game" }, moves: initial ? [{ uci: 'e2e4', white: 6, draws: 3, black: 1, opening: { eco: 'B00', name: "King's Pawn Game" } }] : [] } });
  });
  await page.goto('/#/openings');
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByLabel('Opening name')).toHaveText('Opening unknown');
  await page.getByRole('button', { name: 'Preview e4', exact: true }).click();
  await expect(page.locator('.cg-shapes line')).toHaveCount(1);
  await page.getByRole('button', { name: 'e4', exact: true }).click();
  await expect(page.locator('.board-frame')).toHaveAttribute('data-fen', /4P3/);
  await expect(page.locator('.cg-shapes line')).toHaveCount(0);
  await expect(page.getByLabel('Opening name')).toHaveText("B00 King's Pawn Game");
  await page.getByRole('button', { name: 'Previous move', exact: true }).click();
  await expect(page.getByLabel('Opening name')).toHaveText('Opening unknown');
  await expect(page.locator('.cg-shapes line')).toHaveCount(0);
});

test('explored lines form a navigable tree with evaluations, a flip control and a repertoire export', async ({ page }) => {
  const cloudHeaders: (string | undefined)[] = [];
  let explorerRequests = 0;
  await page.route('https://explorer.lichess.ovh/lichess?**', route => {
    explorerRequests++;
    const fen = new URL(route.request().url()).searchParams.get('fen')!;
    const initial = fen.startsWith('rnbqkbnr/pppppppp/8/8/8/8/');
    return route.fulfill({ json: initial ? { white: 60, draws: 20, black: 20, moves: [{ uci: 'e2e4', white: 30, draws: 10, black: 10 }, { uci: 'd2d4', white: 30, draws: 10, black: 10 }] } : { white: 0, draws: 0, black: 0, moves: [] } });
  });
  await page.route('https://lichess.org/api/cloud-eval?**', route => {
    cloudHeaders.push(route.request().headers().authorization);
    return route.fulfill({ json: { depth: 40, pvs: [{ moves: 'e2e4 e7e5', cp: 21 }, { moves: 'd2d4 d7d5', cp: 17 }] } });
  });
  await page.goto('/#/openings');
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect(page.getByLabel('Evaluation +0.2, Lichess cloud', { exact: true })).toHaveCount(2);
  await expect(page.getByLabel('Position evaluation +0.2, Lichess cloud', { exact: true })).toBeVisible();
  expect(cloudHeaders).toEqual([undefined]);
  await square(page, 4, 6); await square(page, 4, 4);
  await expect(page.locator('.replay .board-frame')).toHaveAttribute('data-fen', /4P3/);
  const tree = page.getByLabel('Explored moves');
  await expect(tree.getByRole('button', { name: '1. e4', exact: true })).toHaveAttribute('aria-current', 'step');
  await page.getByRole('button', { name: 'First position', exact: true }).click();
  await expect(page.getByRole('table', { name: 'Opening continuations' }).locator('tr[data-explored="true"]')).toHaveCount(1);
  await page.getByRole('button', { name: 'd4', exact: true }).click();
  await expect(tree.getByRole('button', { name: '1. d4', exact: true })).toHaveAttribute('aria-current', 'step');
  await expect(tree.getByRole('button', { name: '1. e4 (1 move)', exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Previous move', exact: true }).click();
  await expect.poll(() => explorerRequests).toBe(3);
  const before = await page.locator('.replay .board-frame').getAttribute('data-fen');
  await page.getByRole('button', { name: 'Preview position after 1. d4', exact: true }).click();
  const popup = page.getByRole('dialog', { name: 'Position after 1. d4' });
  await expect(popup).toBeVisible();
  await expect(page.locator('.replay .board-frame')).toHaveAttribute('data-fen', before!);
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'Flip board', exact: true }).click();
  await expect(page.locator('.replay .board-frame')).toHaveAttribute('aria-label', /black at bottom/);
  await expect(page.locator('.replay .board-frame')).toHaveAttribute('data-fen', before!);
  await page.screenshot({ path: test.info().outputPath('opening-exploration.png'), fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.getByRole('button', { name: 'Export as repertoire', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await expect(dialog.locator('select')).toHaveValue('black');
  await expect(dialog.getByLabel('Include statistics and evaluation comments', { exact: true })).toBeChecked();
  await dialog.getByLabel('Repertoire name', { exact: true }).fill('Explored starts');
  await dialog.getByRole('button', { name: 'Save repertoire', exact: true }).click();
  await expect(page.getByRole('status').filter({ hasText: 'Saved repertoire "Explored starts".' })).toBeVisible();
  await page.getByRole('link', { name: 'Open Repertoires', exact: true }).click();
  await expect(page.getByText('Explored starts').first()).toBeVisible();
});

test('the opening position can be set up with the board editor', async ({ page }) => {
  const requested: string[] = [];
  await page.route('https://explorer.lichess.ovh/lichess?**', route => {
    requested.push(new URL(route.request().url()).searchParams.get('fen')!);
    return route.fulfill({ json: { white: 0, draws: 0, black: 0, moves: [] } });
  });
  await page.goto('/#/openings');
  await page.getByText('Set up position', { exact: true }).click();
  const editor = page.locator('.position-editor-board cg-board');
  await editor.scrollIntoViewIfNeeded();
  const box = (await editor.boundingBox())!;
  const at = { position: { x: box.width * 4.5 / 8, y: box.height * 4.5 / 8 } };
  await page.getByRole('button', { name: 'white pawn', exact: true }).click();
  if (test.info().project.name === 'phone') await editor.tap(at); else await editor.click(at);
  await page.getByRole('button', { name: 'Eraser', exact: true }).click();
  const e2 = { position: { x: box.width * 4.5 / 8, y: box.height * 6.5 / 8 } };
  if (test.info().project.name === 'phone') await editor.tap(e2); else await editor.click(e2);
  await page.getByLabel('Black', { exact: true }).check();
  const fen = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1';
  await expect(page.getByRole('textbox', { name: 'Position FEN', exact: true })).toHaveValue(fen);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.getByRole('button', { name: 'Explore position', exact: true }).click();
  await expect.poll(() => requested).toEqual([fen]);
});

test.describe('live opening provider access', () => {
  test('live Lichess token validates and retrieves opening statistics without retention', async ({ page }) => {
    const token = process.env.LICHESS_OAUTH_TOKEN;
    test.skip(process.env.RUN_LICHESS_LIVE !== '1' || !token, 'Opt-in live provider check requires an environment token.');
    try {
      await page.goto('/#/openings');
      await page.getByRole('button', { name: 'Lichess API access', exact: true }).click();
      const dialog = page.getByRole('dialog');
      await dialog.getByLabel('Lichess token', { exact: true }).fill(token!);
      await dialog.getByRole('button', { name: 'Validate and Use', exact: true }).click();
      await expect(page.getByLabel('Lichess access status')).toHaveText('Accepted / Current Session', { timeout: 30000 });
      await page.getByRole('button', { name: 'Explore position', exact: true }).click();
      await expect(page.getByLabel('Opening sample')).toContainText('games / White', { timeout: 30000 });
      expect(await page.evaluate(() => localStorage.getItem('chess.org:lichess-access'))).toBeNull();
    } catch { throw new Error('Live Lichess opening workflow failed; credential details suppressed.'); }
    finally { await page.close(); }
  });
});