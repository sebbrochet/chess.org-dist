import { expect, test } from '@playwright/test';

async function square(page: import('@playwright/test').Page, file: number, rankFromTop: number) {
  const board = page.locator('.replay cg-board');
  await board.scrollIntoViewIfNeeded();
  const box = (await board.boundingBox())!;
  const options = { position: { x: box.width * (file + 0.5) / 8, y: box.height * (rankFromTop + 0.5) / 8 } };
  if (test.info().project.name === 'phone') await board.tap(options); else await board.click(options);
}
const move = async (page: import('@playwright/test').Page, from: [number, number], to: [number, number]) => { await square(page, ...from); await square(page, ...to); };

test('a game created on the board saves each move, keeps variations and reopens from Games', async ({ page }) => {
  await page.goto('/#/');
  await page.getByRole('link', { name: 'New game on board', exact: true }).click();
  const status = page.getByLabel('Save status');
  await expect(status).toContainText('Not created yet');
  await move(page, [4, 6], [4, 4]);
  await expect(status).toHaveText('Saved');
  await expect(page).toHaveURL(/#\/games\/[^/]+\/edit$/);
  await move(page, [4, 1], [4, 3]);
  await expect(status).toHaveText('Saved');
  await page.getByRole('button', { name: 'Previous move', exact: true }).click();
  await move(page, [2, 1], [2, 3]);
  const moves = page.getByLabel('Game moves');
  await expect(moves.getByRole('button', { name: '1... c5', exact: true })).toHaveAttribute('aria-current', 'step');
  await page.getByRole('button', { name: 'Make main line', exact: true }).click();
  await expect(status).toHaveText('Saved');
  const board = page.locator('.replay .board-frame');
  const before = await board.getAttribute('data-fen');
  await page.getByRole('button', { name: 'Preview position after 1. e4', exact: true }).click();
  await expect(page.getByRole('dialog', { name: 'Position after 1. e4' })).toBeVisible();
  await expect(board).toHaveAttribute('data-fen', before!);
  await page.keyboard.press('Escape');
  await page.screenshot({ path: test.info().outputPath('game-editor.png'), fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.reload();
  await expect(page.getByLabel('Game moves').getByRole('button', { name: 'c5', exact: true })).toBeVisible();
  await expect(page.getByLabel('Game moves').getByRole('button', { name: '1... e5', exact: true })).toBeVisible();
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Games', exact: true }).click();
  await expect(page.getByText('Created on board', { exact: true })).toBeVisible();
  await page.getByRole('link', { name: 'Edit moves', exact: true }).click();
  await expect(page.getByLabel('Save status')).toHaveText('Saved');
});

test('tags are edited in the editor and any game can be copied to an editable game', async ({ page }) => {
  await page.goto('/#/');
  await page.getByRole('button', { name: 'Import PGN', exact: true }).first().click();
  await page.getByRole('textbox', { name: 'PGN', exact: true }).fill('[Event "London"]\n[Site "London ENG"]\n[Date "1851.06.21"]\n[White "Anderssen"]\n[Black "Kieseritzky"]\n[WhiteTeam "Germany"]\n[BlackTitle "IM"]\n[WhiteElo "2600"]\n[Result "1-0"]\n\n1. e4 e5 (1... c5) 2. f4 { King\'s Gambit } 1-0');
  await page.getByRole('button', { name: 'Validate PGN', exact: true }).click();
  await page.getByRole('button', { name: 'Import 1 selected' }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  const bars = page.locator('.replay .player-bar');
  await expect(page.locator('.replay .event-line')).toHaveText('London · London ENG · 1851.06.21');
  await expect(bars.first()).toHaveAttribute('aria-label', 'Black, score 0, IM, Kieseritzky');
  await expect(bars.last()).toHaveAttribute('aria-label', 'White, score 1, Germany, Anderssen, rating 2600');
  await page.getByRole('button', { name: 'Flip board', exact: true }).click();
  await expect(bars.first()).toHaveAttribute('aria-label', /^White, score 1/);
  await page.screenshot({ path: test.info().outputPath('player-bars.png'), fullPage: true });
  await page.getByRole('button', { name: 'Copy to editable game', exact: true }).click();
  await expect(page).toHaveURL(/#\/games\/[^/]+\/edit$/);
  await expect(page.getByRole('button', { name: 'Rename game: Copy of Anderssen - Kieseritzky', exact: true })).toBeVisible();
  await expect(page.getByLabel('Game moves').getByText("King's Gambit", { exact: true })).toBeVisible();
  await page.getByText('Tags', { exact: true }).click();
  await page.getByRole('textbox', { name: 'Event', exact: true }).fill('London 1851');
  await page.getByRole('textbox', { name: 'New tag name', exact: true }).fill('ECO');
  await page.getByRole('textbox', { name: 'New tag value', exact: true }).fill('C33');
  await page.getByRole('button', { name: 'Add tag', exact: true }).click();
  await expect(page.getByRole('textbox', { name: 'ECO', exact: true })).toHaveValue('C33');
  await expect(page.locator('.replay .event-line')).toHaveText('London 1851 · London ENG · 1851.06.21');
  await expect(page.locator('.replay .player-bar').last()).toHaveAttribute('aria-label', 'White, score 1, Germany, Anderssen, rating 2600');
  await expect(page.getByLabel('Save status')).toHaveText('Saved');
  await page.screenshot({ path: test.info().outputPath('game-editor-tags.png'), fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Games', exact: true }).click();
  await expect(page.getByText('Created on board (copy of Anderssen - Kieseritzky)', { exact: true })).toBeVisible();
  await expect(page.locator('.game-list li')).toHaveCount(2);
});

test('comments, glyphs, right-click drawings and touch drawing are saved with the position', async ({ page }) => {
  await page.goto('/#/games/new');
  await move(page, [4, 6], [4, 4]);
  await expect(page.getByLabel('Save status')).toHaveText('Saved');
  await page.getByLabel('Comment after 1. e4', { exact: true }).fill('Best by test');
  await page.getByRole('group', { name: 'Move glyph' }).getByRole('button', { name: '!', exact: true }).click();
  await expect(page.getByLabel('Game moves').getByRole('button', { name: '1. e4!', exact: true })).toBeVisible();
  const board = page.locator('.replay cg-board');
  const box = (await board.boundingBox())!;
  const at = (file: number, rankFromTop: number) => ({ x: box.x + box.width * (file + 0.5) / 8, y: box.y + box.height * (rankFromTop + 0.5) / 8 });
  if (test.info().project.name !== 'phone') {
    await page.mouse.move(at(6, 7).x, at(6, 7).y); await page.mouse.down({ button: 'right' });
    await page.mouse.move(at(5, 5).x, at(5, 5).y, { steps: 6 }); await page.mouse.up({ button: 'right' });
    await expect(page.locator('.replay .cg-shapes line')).toHaveCount(1);
  }
  await page.getByRole('button', { name: 'Draw', exact: true }).click();
  await page.getByRole('button', { name: 'yellow', exact: true }).click();
  await square(page, 3, 4); await square(page, 3, 4);
  await expect(page.locator('.replay .cg-shapes circle')).toHaveCount(1);
  await expect(page.getByLabel('Save status')).toHaveText('Saved');
  await page.screenshot({ path: test.info().outputPath('game-editor-annotations.png'), fullPage: true });
  await page.reload();
  await page.getByLabel('Game moves').getByRole('button', { name: '1. e4!', exact: true }).click();
  await expect(page.getByLabel('Game moves').getByText('Best by test', { exact: true })).toBeVisible();
  await expect(page.locator('.replay .cg-shapes circle')).toHaveCount(1);
  await expect(page.locator('.replay .cg-shapes line')).toHaveCount(test.info().project.name === 'phone' ? 0 : 1);
});
