import { expect, test } from '@playwright/test';
import { readFile } from 'node:fs/promises';

const PGN = '[Event "Club"]\n[White "Alice"]\n[Black "Bob"]\n[Result "1-0"]\n\n1.e4 e5 2.Nf3 Nc6 1-0\n\n[White "Carol"]\n[Black "Dan"]\n\n1.d4 d5 *';

test('the Games footer links to the license notices and the source code download', async ({ page }) => {
  await page.goto('/');
  const footer = page.locator('.library-footer');
  await expect(footer.getByRole('link', { name: 'Licenses' })).toHaveAttribute('href', '/THIRD_PARTY_NOTICES.md');
  const source = footer.getByRole('link', { name: 'Source code (GPL)' });
  await expect(source).toHaveAttribute('href', '/chess.org-source.zip');
  await expect(source).toHaveAttribute('download', '');
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload();
  expect(await page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);
  const notices = page.waitForEvent('popup');
  await footer.getByRole('link', { name: 'Licenses' }).click();
  await expect((await notices).locator('body')).toContainText('Licenses And Source');
});

test('import, select, replay, edit, export, reload and delete', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('Your library is empty')).toBeVisible();
  await page.getByRole('button', { name: 'Import PGN', exact: true }).first().click();
  await page.getByRole('textbox', { name: 'PGN', exact: true }).fill(PGN);
  await page.getByRole('button', { name: 'Validate PGN' }).click();
  await expect(page.getByText('2 valid games')).toBeVisible();
  await page.getByRole('button', { name: 'Import 2 selected' }).click();
  await expect(page.getByRole('heading', { name: 'Alice - Bob' })).toBeVisible();
  const initialFen = await page.getByRole('img', { name: /^Chessboard/ }).getAttribute('data-fen');
  await page.getByRole('button', { name: 'Next move', exact: true }).click();
  await expect(page.getByLabel('Replay position')).toHaveText('1 / 4');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).not.toHaveAttribute('data-fen', initialFen!);
  await page.getByLabel('Recorded SAN', { exact: true }).fill('e5');
  await page.getByRole('button', { name: 'Replay SAN', exact: true }).click();
  await expect(page.getByLabel('Replay position')).toHaveText('2 / 4');
  await page.getByRole('button', { name: 'Flip board', exact: true }).click();
  await expect(page.locator('.cg-wrap')).toHaveClass(/orientation-black/);
  await page.getByRole('button', { name: 'Edit game details' }).click();
  await page.getByRole('textbox', { name: 'Title', exact: true }).fill('Club final');
  await page.getByRole('button', { name: 'Save details' }).click();
  await expect(page.getByRole('heading', { name: 'Club final' })).toBeVisible();
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export selected PGN' }).click();
  const download = await downloadPromise;
  const text = await readFile((await download.path())!, 'utf8');
  expect(text).toContain('[Title "Club final"]');
  expect(text).toContain('Nf3');
  expect(text).toContain('[White "Carol"]');
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Club final' })).toBeVisible();
  await page.getByRole('button', { name: 'Delete game', exact: true }).click();
  await page.getByRole('button', { name: 'Delete permanently' }).click();
  await expect(page.getByRole('heading', { name: 'Carol - Dan' })).toBeVisible();
  await page.getByRole('searchbox', { name: 'Search games' }).fill('No such game');
  await expect(page.getByText('No matching games')).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Library 1' })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test('coordinates sit outside the squares and remain aligned when flipped', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('coords.ranks coord')).toHaveCount(8);
  await expect(page.locator('coords.files coord')).toHaveCount(8);
  for (const flipped of [false, true]) {
    if (flipped) {
      await page.getByRole('button', { name: 'Flip board', exact: true }).click();
      await expect(page.locator('.cg-wrap')).toHaveClass(/orientation-black/);
    }
    const layout = await page.locator('.board-frame').evaluate(frame => {
      const board = frame.querySelector('cg-board')!.getBoundingClientRect();
      const outer = frame.getBoundingClientRect();
      const measure = (selector: string) => Array.from(frame.querySelectorAll(selector), element => {
        const rect = element.getBoundingClientRect();
        return { text: element.textContent, left: rect.left, right: rect.right, top: rect.top, bottom: rect.bottom, centerX: (rect.left + rect.right) / 2, centerY: (rect.top + rect.bottom) / 2 };
      });
      return { board: { left: board.left, right: board.right, top: board.top, bottom: board.bottom, width: board.width, height: board.height }, frame: { left: outer.left, bottom: outer.bottom }, ranks: measure('coords.ranks coord').sort((a, b) => a.centerY - b.centerY), files: measure('coords.files coord').sort((a, b) => a.centerX - b.centerX), overflow: document.documentElement.scrollWidth > innerWidth };
    });
    expect(layout.overflow).toBe(false);
    expect(Math.abs(layout.board.width - layout.board.height)).toBeLessThan(1);
    expect(layout.ranks.map(label => label.text)).toEqual(flipped ? ['1', '2', '3', '4', '5', '6', '7', '8'] : ['8', '7', '6', '5', '4', '3', '2', '1']);
    expect(layout.files.map(label => label.text)).toEqual(flipped ? ['h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'] : ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']);
    layout.ranks.forEach((label, index) => {
      expect(label.right).toBeLessThanOrEqual(layout.board.left + 1);
      expect(label.left).toBeGreaterThanOrEqual(layout.frame.left - 1);
      expect(Math.abs(label.centerY - (layout.board.top + layout.board.height * (index + 0.5) / 8))).toBeLessThan(1);
    });
    layout.files.forEach((label, index) => {
      expect(label.top).toBeGreaterThanOrEqual(layout.board.bottom - 1);
      expect(label.bottom).toBeLessThanOrEqual(layout.frame.bottom + 1);
      expect(Math.abs(label.centerX - (layout.board.left + layout.board.width * (index + 0.5) / 8))).toBeLessThan(1);
    });
  }
});

test('invalid file is rejected without changing retained games', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Import PGN', exact: true }).first().click();
  await page.getByLabel('PGN file').setInputFiles({ name: 'bad.pgn', mimeType: 'text/plain', buffer: Buffer.from('1.e4 e5 2.Bh6 *') });
  await expect(page.getByRole('textbox', { name: 'PGN', exact: true })).toHaveValue('1.e4 e5 2.Bh6 *');
  await page.getByRole('button', { name: 'Validate PGN' }).click();
  await expect(page.getByRole('alert')).toContainText('illegal move');
  await page.getByRole('button', { name: 'Close dialog' }).click();
  await expect(page.getByText('Your library is empty')).toBeVisible();
});

test('production shell reloads offline without inventing personal games', async ({ page, context }) => {
  await page.goto('/');
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload();
  await expect(page.getByText('Offline shell ready')).toBeVisible();
  await context.setOffline(true);
  await page.reload();
  await expect(page.getByText('Your library is empty')).toBeVisible();
  await expect(page.locator('cg-board piece')).toHaveCount(32);
});