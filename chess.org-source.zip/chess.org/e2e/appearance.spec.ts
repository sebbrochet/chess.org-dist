import { expect, test } from '@playwright/test';

test('appearance switches boards/pieces without rebuilding or changing games and persists offline', async ({ page, context }) => {
  await page.goto('/');
  const board = await page.locator('cg-board').elementHandle();
  const fen = await page.getByRole('img', { name: /^Chessboard/ }).getAttribute('data-fen');
  await page.getByRole('button', { name: 'Board appearance', exact: true }).click();
  await expect(page.getByRole('dialog', { name: 'Board appearance' })).toBeVisible();
  await page.getByRole('button', { name: 'Blue board', exact: true }).click();
  await page.getByRole('button', { name: 'Merida pieces', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Blue board' })).toHaveAttribute('aria-pressed', 'true');
  await expect(page.getByRole('button', { name: 'Merida pieces' })).toHaveAttribute('aria-pressed', 'true');
  await expect(page.getByRole('button', { name: 'Merida pieces' })).toHaveCSS('border-top-color', await page.getByRole('button', { name: 'Blue board' }).evaluate(node => getComputedStyle(node).borderTopColor));
  await expect(page.locator('cg-board piece.white.knight').first()).toHaveCSS('background-image', /pieces\/merida\/wN.svg/);
  await expect(page.getByRole('button', { name: 'Cburnett pieces' }).locator('piece')).toHaveCSS('background-image', /data:image\/svg/);
  await expect(page.locator('cg-board')).toHaveCSS('background-image', /140, 162, 173/);
  expect(await page.locator('cg-board').evaluate((node, original) => node === original, board)).toBe(true);
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', fen!);
  await page.screenshot({ path: test.info().outputPath('appearance-dialog.png'), fullPage: true });
  for (const [style, label] of [['letter', 'Letter'], ['mono', 'Mono']] as const) {
    await page.getByRole('button', { name: `${label} pieces`, exact: true }).click();
    const file = style === 'mono' ? 'N' : 'wN';
    await expect(page.getByRole('button', { name: `${label} pieces` }).locator('img')).toHaveAttribute('src', `/pieces/${style}/${file}.svg`);
    await expect(page.locator('cg-board piece.white.knight').first()).toHaveCSS('background-image', new RegExp(`pieces/${style}/${file}\\.svg`));
    expect(await page.locator('cg-board').evaluate((node, original) => node === original, board)).toBe(true);
    await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', fen!);
    await page.screenshot({ path: test.info().outputPath(`${style}-appearance.png`), fullPage: true });
  }
  expect(await page.locator('cg-board piece.white.king').evaluate(node => getComputedStyle(node).filter)).not.toBe(await page.locator('cg-board piece.black.king').evaluate(node => getComputedStyle(node).filter));
  await page.getByRole('button', { name: 'Letter pieces', exact: true }).click();
  await page.getByRole('button', { name: 'Close dialog', exact: true }).click();
  await page.screenshot({ path: test.info().outputPath('letter-board.png'), fullPage: true });
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Play Computer', exact: true }).click();
  await expect(page.locator('cg-board piece.black.king')).toHaveCSS('background-image', /pieces\/letter\/bK.svg/);
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload();
  await context.setOffline(true);
  const pieces = await page.evaluate(async () => Promise.all(['merida', 'letter', 'mono'].flatMap(style => (style === 'mono' ? [''] : ['w', 'b']).flatMap(color => ['K', 'Q', 'R', 'B', 'N', 'P'].map(async role => {
    const response = await fetch(`/pieces/${style}/${color}${role}.svg`);
    return response.ok && (await response.text()).includes('<svg');
  })))));
  expect(pieces.every(Boolean)).toBe(true);
  await page.reload();
  await expect(page.locator('cg-board piece.white.queen')).toHaveCSS('background-image', /pieces\/letter\/wQ.svg/);
  await page.getByRole('button', { name: 'Board appearance', exact: true }).click();
  await page.getByRole('button', { name: 'System board', exact: true }).click();
  await page.getByRole('button', { name: 'Cburnett pieces', exact: true }).click();
  await page.getByRole('button', { name: 'Close dialog', exact: true }).click();
  await expect(page.locator('cg-board piece.white.queen')).toHaveCSS('background-image', /data:image\/svg/);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});