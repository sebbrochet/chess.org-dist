import { expect, test } from '@playwright/test';
import { bundledPuzzles } from '../src/chess/puzzles';
import { legalContinuation } from '../src/chess/review';
import { positionFromFen } from '../src/chess/pgn';

test('starter solutions are verified by real Stockfish and solving persists offline', async ({ page, context }) => {
  await page.goto('/#/puzzles');
  await expect(page.getByRole('button', { name: 'Start puzzle', exact: true })).toBeVisible();
  for (const puzzle of bundledPuzzles().puzzles) {
    const best = await page.evaluate(fen => new Promise<string>((resolve, reject) => {
      const worker = new Worker('/engine/stockfish-18-lite-single.js');
      const timer = setTimeout(() => { worker.terminate(); reject(new Error('Engine did not finish puzzle proof')); }, 15000);
      worker.onmessage = event => {
        const line = String(event.data);
        if (line === 'uciok') worker.postMessage('isready');
        else if (line === 'readyok') { worker.postMessage(`position fen ${fen}`); worker.postMessage('go depth 8'); }
        else if (line.startsWith('bestmove ')) { clearTimeout(timer); worker.terminate(); resolve(line.split(' ')[1]); }
      };
      worker.onerror = () => { clearTimeout(timer); worker.terminate(); reject(new Error('Engine failed')); };
      worker.postMessage('uci');
    }), puzzle.fen);
    expect(positionFromFen(legalContinuation(puzzle.fen, [best])[0].fen).isCheckmate()).toBe(true);
    expect(puzzle.solutions.map(line => line[0])).toContain(best);
  }
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload();
  await context.setOffline(true);
  await page.reload();
  await page.getByRole('button', { name: 'Start puzzle', exact: true }).click();
  await expect(page.getByLabel('Puzzle solution')).toHaveCount(0);
  await page.getByLabel('Puzzle move', { exact: true }).fill('Qg7#');
  await page.getByRole('button', { name: 'Submit puzzle move', exact: true }).click();
  await expect(page.getByLabel('Puzzle result')).toHaveText('Unaided success');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', /^7k\/6Q1\/6K1\//);
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Progress', exact: true }).click();
  await expect(page.getByLabel('Puzzles summary')).toContainText('1 attempts / 1 unaided successes');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('explicit collection removal clears results and optional validated downloads need full solutions', async ({ page }) => {
  await page.route('https://lichess.org/api/puzzle/daily', route => route.fulfill({ json: { puzzle: { id: 'fixture', fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', solution: ['e2e4', 'e7e5', 'g1f3'], themes: ['fixture'], rating: 1500 } } }));
  await page.goto('/#/puzzles');
  await page.getByRole('button', { name: 'Remove collection', exact: true }).click();
  await page.getByRole('button', { name: 'Remove content and results', exact: true }).click();
  await page.reload();
  await expect(page.getByText('No puzzle content retained.', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Download Lichess collection', exact: true }).click();
  await page.getByRole('button', { name: 'Start puzzle', exact: true }).click();
  await page.getByLabel('Puzzle move', { exact: true }).fill('e4');
  await page.getByRole('button', { name: 'Submit puzzle move', exact: true }).click();
  await expect(page.getByLabel('Puzzle result')).toHaveText('Continue the solution');
  await expect(page.getByRole('img', { name: /^Chessboard/ })).toHaveAttribute('data-fen', /^rnbqkbnr\/pppp1ppp\/8\/4p3\/4P3\//);
  await expect(page.locator('cg-board square.last-move')).toHaveCount(2);
  await page.getByRole('button', { name: 'Show hint', exact: true }).click();
  await page.getByLabel('Puzzle move', { exact: true }).fill('Nf3');
  await page.getByRole('button', { name: 'Submit puzzle move', exact: true }).click();
  await expect(page.getByLabel('Puzzle result')).toHaveText('Assisted result');
  await page.getByRole('button', { name: 'Remove collection', exact: true }).click();
  await page.getByRole('button', { name: 'Remove content and results', exact: true }).click();
  await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: 'Progress', exact: true }).click();
  await expect(page.getByLabel('Puzzles summary')).toContainText('0 attempts');
});