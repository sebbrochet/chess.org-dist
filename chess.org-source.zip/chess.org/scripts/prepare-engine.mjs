import { copyFile, mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';

const root = new URL('../', import.meta.url);
const output = new URL('public/engine/', root);
const revision = 'fdc622346bd70cd6f65e9f711066426d1aa843c2';
const sourceName = 'stockfish.js-18.0.7-source.tar';
const sourceUrl = `https://codeload.github.com/nmrugg/stockfish.js/tar.gz/${revision}`;
const network = 'nn-9067e33176e8.nnue';
const networkUrl = `https://tests.stockfishchess.org/api/nn/${network}`;
await mkdir(output, { recursive: true });
const pkg = JSON.parse(await readFile(new URL('node_modules/stockfish/package.json', root), 'utf8'));
if (pkg.version !== '18.0.7') throw new Error('Engine package version changed; verify assets and matching source before shipping.');
const files = ['stockfish-18-lite-single.js', 'stockfish-18-lite-single.wasm'];
for (const name of files) await copyFile(new URL(`node_modules/stockfish/bin/${name}`, root), new URL(name, output));
await copyFile(new URL('node_modules/stockfish/Copying.txt', root), new URL('COPYING.txt', output));
try { await stat(new URL(sourceName, output)); }
catch {
  const response = await fetch(sourceUrl);
  if (!response.ok) throw new Error(`Cannot retain Stockfish corresponding source: HTTP ${response.status}`);
  await writeFile(new URL(sourceName, output), gunzipSync(new Uint8Array(await response.arrayBuffer())));
}
await rm(new URL('stockfish.js-18.0.7-source.tar.gz', output), { force: true });
try { await stat(new URL(network, output)); }
catch {
  const response = await fetch(networkUrl);
  if (!response.ok) throw new Error(`Cannot retain Stockfish NNUE build input: HTTP ${response.status}`);
  await writeFile(new URL(network, output), new Uint8Array(await response.arrayBuffer()));
}
const pinned = {
  'stockfish-18-lite-single.js': '2278005057f381491f1c9bb3e44c9f5920b3a00bef9759e33cc6582769a1f1fe',
  'stockfish-18-lite-single.wasm': 'a8fbc05ec6920b56d7485826dcb02c5ffd2826bcbf751cf973046f237a9096f1',
  [sourceName]: 'b8c818028a9d21c4f73c6725c6f45966977aef90bfd427c796598451a364033f',
};
const assets = await Promise.all([...files, 'COPYING.txt', sourceName, network, 'SOURCE.md'].map(async name => {
  const bytes = await readFile(new URL(name, output));
  const sha256 = createHash('sha256').update(bytes).digest('hex');
  if ((pinned[name] && pinned[name] !== sha256) || (name === network && !sha256.startsWith('9067e33176e8'))) throw new Error(`Engine asset integrity mismatch: ${name}`);
  return { path: `/engine/${name}`, bytes: bytes.length, sha256 };
}));
await writeFile(new URL('manifest.json', output), JSON.stringify({ version: pkg.version, sourceRevision: revision, sourceUrl, networkUrl, assets }, null, 2) + '\n');
console.log(`Prepared Stockfish ${pkg.version}: complete lite single-thread JS/WASM, GPL and matching source archive.`);