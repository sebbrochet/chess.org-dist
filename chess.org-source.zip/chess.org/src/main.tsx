import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './app/App';
import './app/styles.css';

ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);

if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').then(registration => {
    const worker = registration.active ?? registration.installing;
    if (worker?.state === 'activated') window.dispatchEvent(new Event('shell-ready'));
    worker?.addEventListener('statechange', () => {
      if (worker.state === 'activated') window.dispatchEvent(new Event('shell-ready'));
    });
  }).catch(() => window.dispatchEvent(new Event('shell-failed')));
}