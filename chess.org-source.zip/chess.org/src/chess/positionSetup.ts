import { Chess, IllegalSetup } from 'chessops/chess';
import { makeFen, parseFen } from 'chessops/fen';
import { SquareSet } from 'chessops/squareSet';
import type { Setup } from 'chessops/setup';
import type { Color, Piece, Square } from 'chessops/types';
import { parseSquare } from 'chessops/util';

export type CastlingRook = 'h1' | 'a1' | 'h8' | 'a8';
export const CASTLING_ROOKS: { rook: CastlingRook; label: string }[] = [{ rook: 'h1', label: 'White O-O' }, { rook: 'a1', label: 'White O-O-O' }, { rook: 'h8', label: 'Black O-O' }, { rook: 'a8', label: 'Black O-O-O' }];
export const STARTING_SETUP_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

export function readSetup(fen: string): Setup | undefined {
  const parsed = parseFen(fen.trim());
  return parsed.isOk ? parsed.value : undefined;
}

export function castlingAllowed(setup: Setup, rook: CastlingRook): boolean {
  const color: Color = rook.endsWith('1') ? 'white' : 'black';
  const king = setup.board.get(parseSquare(color === 'white' ? 'e1' : 'e8')!);
  const piece = setup.board.get(parseSquare(rook)!);
  return king?.role === 'king' && king.color === color && piece?.role === 'rook' && piece.color === color;
}

function withValidCastling(setup: Setup): Setup {
  let rights = setup.castlingRights;
  for (const { rook } of CASTLING_ROOKS) if (!castlingAllowed(setup, rook)) rights = rights.without(parseSquare(rook)!);
  return { ...setup, castlingRights: rights };
}

export function placePiece(setup: Setup, square: Square, piece: Piece | undefined): Setup {
  const board = setup.board.clone();
  if (piece) board.set(square, piece); else board.take(square);
  return withValidCastling({ ...setup, board, epSquare: undefined });
}

export function movePiece(setup: Setup, from: Square, to: Square): Setup {
  const piece = setup.board.get(from);
  if (!piece || from === to) return setup;
  const board = setup.board.clone();
  board.take(from); board.set(to, piece);
  return withValidCastling({ ...setup, board, epSquare: undefined });
}

export function setCastling(setup: Setup, rook: CastlingRook, on: boolean): Setup {
  if (on && !castlingAllowed(setup, rook)) return setup;
  const square = parseSquare(rook)!;
  return { ...setup, castlingRights: on ? setup.castlingRights.with(square) : setup.castlingRights.without(square) };
}

export const hasCastling = (setup: Setup, rook: CastlingRook) => setup.castlingRights.has(parseSquare(rook)!);
export const setTurn = (setup: Setup, turn: Color): Setup => ({ ...setup, turn, epSquare: undefined });
export const clearedSetup = (setup: Setup): Setup => ({ ...readSetup('8/8/8/8/8/8/8/8 w - - 0 1')!, turn: setup.turn, halfmoves: setup.halfmoves, fullmoves: setup.fullmoves, castlingRights: SquareSet.empty() });
export const setupFen = (setup: Setup) => makeFen(setup);

const PROBLEMS: Record<string, string> = {
  [IllegalSetup.Empty]: 'The board is empty.',
  [IllegalSetup.Kings]: 'Each side needs exactly one king.',
  [IllegalSetup.PawnsOnBackrank]: 'Pawns cannot stand on the first or last rank.',
  [IllegalSetup.OppositeCheck]: 'The side not to move is in check.',
};

export function setupProblem(setup: Setup): string | undefined {
  for (const color of ['white', 'black'] as const) {
    const pieces = setup.board[color];
    if (pieces.size() > 16 || pieces.intersect(setup.board.pawn).size() > 8) return 'Too many pieces for one side.';
  }
  const position = Chess.fromSetup(setup);
  return position.isErr ? PROBLEMS[position.error.message] ?? 'Illegal standard-chess position.' : undefined;
}
