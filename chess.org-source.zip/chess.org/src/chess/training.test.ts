import { describe, expect, it } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { acceptsCandidate, attemptDisplayFen, candidateUci, newAttempt } from './training';
import { parseGames } from './pgn';
import { legalContinuation } from './review';
import type { RetainedGame } from '../storage/library';

const cp = (value: number) => ({ kind: 'cp' as const, value, perspective: 'white' as const });
const mate = (winner: 'white' | 'black') => ({ kind: 'mate' as const, value: 3, perspective: 'white' as const, winner });
describe('training judgments', () => {
  it.each([
    ['black queen', '[SetUp "1"]\n[FEN "4k3/8/2q5/8/8/8/8/6K1 b - - 0 1"]\n1...Qc4 *', 'black'],
    ['castling', '[SetUp "1"]\n[FEN "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1"]\n1.O-O *', 'white'],
    ['underpromotion', '[SetUp "1"]\n[FEN "7k/P7/8/8/8/8/8/7K w - - 0 1"]\n1.a8=N *', 'white'],
  ] as const)('keeps the accepted %s move on the displayed board without mutating source or attempt', (_name, pgn, side) => {
    const game: RetainedGame = { ...parseGames(pgn)[0], id: 'game', source: { kind: 'pgn' }, createdAt: new Date().toISOString() };
    const attempt = { ...newAttempt(game, 'guess', side), status: 'Success' as const, answers: [candidateUci(game.startFen, game.moves[0])] };
    const original = structuredClone({ game, attempt });
    expect(attemptDisplayFen(attempt)).toBe(game.positions[1]);
    expect(attemptDisplayFen({ ...attempt, status: 'Assisted', assisted: true })).toBe(game.positions[1]);
    expect({ game, attempt }).toEqual(original);
  });
  it('shows the accepted submitted move rather than the target and does not preplay hints or failed answers', () => {
    const game: RetainedGame = { ...parseGames('1.e4 *')[0], id: 'game', source: { kind: 'pgn' }, createdAt: new Date().toISOString() };
    const attempt = newAttempt(game, 'guess', 'white');
    expect(attemptDisplayFen(attempt)).toBe(attempt.fen);
    expect(attemptDisplayFen({ ...attempt, status: 'Assisted', assisted: true })).toBe(attempt.fen);
    expect(attemptDisplayFen({ ...attempt, status: 'Incorrect', answers: ['d2d4'] })).toBe(attempt.fen);
    expect(attemptDisplayFen({ ...attempt, activity: 'mistake', status: 'Success', answers: ['d2d4'] })).toBe(legalContinuation(attempt.fen, ['d2d4'])[0].fen);
  });
  it('accepts the exact 30cp boundary from each movers perspective', () => {
    expect(acceptsCandidate(cp(100), cp(70), 'white')).toBe(true);
    expect(acceptsCandidate(cp(100), cp(69), 'white')).toBe(false);
    expect(acceptsCandidate(cp(-100), cp(-70), 'black')).toBe(true);
    expect(acceptsCandidate(cp(-100), cp(-69), 'black')).toBe(false);
  });
  it('does not apply numeric tolerance to mate or invent all-losing mate-distance rules', () => {
    expect(acceptsCandidate(mate('white'), mate('white'), 'white')).toBe(true);
    expect(acceptsCandidate(mate('white'), cp(1000), 'white')).toBe(false);
    expect(acceptsCandidate(cp(0), mate('black'), 'white')).toBe(false);
    expect(acceptsCandidate(mate('black'), mate('black'), 'white')).toBeUndefined();
  });
  it('normalizes legal SAN and rejects illegal answers', () => {
    expect(candidateUci(INITIAL_FEN, 'e4')).toBe('e2e4');
    expect(candidateUci('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1', 'e1h1')).toBe('e1g1');
    expect(() => candidateUci(INITIAL_FEN, 'e5')).toThrow('legal move');
  });
  it('selects recorded targets for either side without changing the saved game', () => {
    const game: RetainedGame = { ...parseGames('1.e4 e5 2.Nf3 *')[0], id: 'game', source: { kind: 'pgn' }, createdAt: new Date().toISOString() };
    const previous = structuredClone(game);
    expect(newAttempt(game, 'guess', 'black').target).toBe('e7e5');
    expect(newAttempt(game, 'guess', 'white', 2).target).toBe('g1f3');
    expect(game).toEqual(previous);
    expect(() => newAttempt(game, 'mistake', 'white')).toThrow('completed review');
  });
});