import { makeFen } from 'chessops/fen';
import { parsePgn, type PgnNodeData, type Node } from 'chessops/pgn';
import { makeSanAndPlay, parseSan } from 'chessops/san';
import type { Chess } from 'chessops/chess';
import { parseGames, positionFromFen } from './pgn';
import { candidateUci } from './training';
import { legalContinuation } from './review';

export interface RepertoireLine { id: string; moves: string[]; positions: string[] }
export interface Repertoire { id: string; name: string; side: 'white' | 'black'; generation: number; source: string; lines: RepertoireLine[]; createdAt: string }
export interface RecallAttempt {
  id: string; repertoireId: string; generation: number; selectedLines: string[]; side: 'white' | 'black';
  fen: string; targets: string[]; answers: string[]; assisted: boolean; status: 'Active' | 'Success' | 'Assisted' | 'Incorrect'; createdAt: string;
}
const identity = (fen: string) => fen.split(' ').slice(0, 4).join(' ');
export function recallDisplay(attempt: RecallAttempt): { fen: string; lastMove?: string } {
  const answer = attempt.answers.at(-1);
  return answer && (attempt.status === 'Success' || attempt.status === 'Assisted') && attempt.targets.includes(answer)
    ? { fen: legalContinuation(attempt.fen, [answer])[0].fen, lastMove: answer } : { fen: attempt.fen };
}
export function recallLeadMove(repertoire: Repertoire, selected: readonly string[], fen: string): { move: string; from: string } | undefined {
  const wanted = identity(fen);
  for (const line of repertoire.lines) {
    if (!selected.includes(line.id)) continue;
    const index = line.positions.findIndex(position => identity(position) === wanted);
    if (index > 0) return { move: candidateUci(line.positions[index - 1], line.moves[index - 1]), from: line.positions[index - 1] };
  }
  return undefined;
}
export interface RecallStep { label: string; uci: string; fen: string }
export function recallPath(repertoire: Repertoire, selected: readonly string[], fen: string): { text: string; otherOrders: number; lineIds: string[]; startFen: string; steps: RecallStep[] } | undefined {
  const wanted = identity(fen);
  const orders = new Map<string, { startFen: string; steps: RecallStep[] }>();
  const lineIds: string[] = [];
  for (const line of repertoire.lines) {
    if (!selected.includes(line.id)) continue;
    const index = line.positions.findIndex(position => identity(position) === wanted);
    if (index < 0) continue;
    lineIds.push(line.id);
    const key = `${line.positions[0]}|${line.moves.slice(0, index).join(' ')}`;
    if (index > 0 && !orders.has(key)) {
      const [, turn, , , , fullmove] = line.positions[0].split(' ');
      orders.set(key, { startFen: line.positions[0], steps: line.moves.slice(0, index).map((san, ply) => {
        const white = (turn === 'w') === (ply % 2 === 0);
        const number = Number(fullmove) + Math.floor((ply + (turn === 'w' ? 0 : 1)) / 2);
        return { label: white ? `${number}. ${san}` : ply === 0 ? `${number}... ${san}` : san, uci: candidateUci(line.positions[ply], san), fen: line.positions[ply + 1] };
      }) });
    }
  }
  const [first] = orders.values();
  if (first) return { text: first.steps.map(step => step.label).join(' '), otherOrders: orders.size - 1, lineIds, ...first };
  return lineIds.length ? { text: '', otherOrders: 0, lineIds, startFen: fen, steps: [] } : undefined;
}
export function importRepertoire(source: string, name: string, side: 'white' | 'black'): Repertoire {
  if (!name.trim() || name.trim().length > 200 || !['white', 'black'].includes(side)) throw new Error('Supply a name and a learned side.');
  const games = parseGames(source);
  const lines: RepertoireLine[] = [];
  for (const game of games) {
    const root = parsePgn(game.pgn)[0].moves;
    const walk = (node: Node<PgnNodeData>, position: Chess, moves: string[], positions: string[]) => {
      if (!node.children.length && moves.length) lines.push({ id: `line-${lines.length + 1}`, moves, positions });
      if (lines.length > 2000) throw new Error('Repertoire has too many lines. Import a smaller collection.');
      for (const child of node.children) {
        const next = position.clone(); const move = parseSan(next, child.data.san);
        if (!move) throw new Error('Illegal repertoire continuation.');
        const san = makeSanAndPlay(next, move);
        walk(child, next, [...moves, san], [...positions, makeFen(next.toSetup())]);
      }
    };
    walk(root, positionFromFen(game.startFen), [], [game.startFen]);
  }
  if (!lines.length) throw new Error('The repertoire contains no moves to practice.');
  return { id: crypto.randomUUID(), name: name.trim(), side, source, lines, generation: 1, createdAt: new Date().toISOString() };
}
export function recallPositions(repertoire: Repertoire, selected: string[]): string[] {
  const result = new Map<string, string>();
  for (const line of repertoire.lines.filter(line => selected.includes(line.id))) line.moves.forEach((_move, index) => {
    const fen = line.positions[index];
    if (positionFromFen(fen).turn === repertoire.side) result.set(identity(fen), fen);
  });
  return [...result.values()];
}
export function createRecall(repertoire: Repertoire, selected: string[], fen?: string): RecallAttempt {
  const choices = recallPositions(repertoire, selected);
  const position = fen ? choices.find(choice => identity(choice) === identity(fen)) : choices[0];
  if (!position) throw new Error('No recall positions in the selected lines.');
  const targets = new Set<string>();
  for (const line of repertoire.lines.filter(line => selected.includes(line.id))) line.moves.forEach((move, index) => {
    if (identity(line.positions[index]) === identity(position)) targets.add(candidateUci(position, move));
  });
  return { id: crypto.randomUUID(), repertoireId: repertoire.id, generation: repertoire.generation, selectedLines: [...selected], side: repertoire.side,
    fen: position, targets: [...targets], answers: [], assisted: false, status: 'Active', createdAt: new Date().toISOString() };
}