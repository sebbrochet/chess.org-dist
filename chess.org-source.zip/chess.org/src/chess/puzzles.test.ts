import { describe, expect, it } from 'vitest';
import { answerPuzzle, bundledPuzzles, lichessPuzzleSet, newPuzzleAttempt, puzzleDisplay, validatePuzzle } from './puzzles';
import { positionFromFen } from './pgn';
import { legalContinuation } from './review';

describe('retained tactical content', () => {
  it('enumerates legal mating alternatives for every original bundled position', () => {
    const set = bundledPuzzles(); expect(set.puzzles).toHaveLength(3);
    for (const puzzle of set.puzzles) {
      expect(puzzle.solutions.length).toBeGreaterThan(0);
      for (const line of puzzle.solutions) expect(positionFromFen(legalContinuation(puzzle.fen, line).at(-1)!.fen).isCheckmate()).toBe(true);
      expect(answerPuzzle(newPuzzleAttempt(puzzle), puzzle.solutions[0][0]).status).toBe('Success');
    }
  });
  it('rejects malformed or illegal supplied continuations', () => {
    const puzzle = bundledPuzzles().puzzles[0];
    expect(() => validatePuzzle({ ...puzzle, solutions: [['a1a8']] })).toThrow();
    expect(() => lichessPuzzleSet({ puzzle: { id: '../bad' } })).toThrow();
  });
  it('preserves assistance and requires the complete supplied sequence', () => {
    const set = lichessPuzzleSet({ puzzle: { id: 'test', fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', solution: ['e2e4', 'e7e5', 'g1f3'], themes: ['test'] } });
    const first = answerPuzzle({ ...newPuzzleAttempt(set.puzzles[0]), assisted: true }, 'e4');
    expect(first.status).toBe('Active'); expect(first.fen).toContain(' w KQkq');
    expect(answerPuzzle(first, 'Nf3').status).toBe('Assisted');
  });
  it('displays the accepted solving move but keeps the start for wrong, revealed or reply-ended attempts', () => {
    const puzzle = bundledPuzzles().puzzles[0];
    const move = puzzle.solutions[0][0];
    const solved = answerPuzzle(newPuzzleAttempt(puzzle), move);
    expect(puzzleDisplay(puzzle, solved)).toEqual({ fen: legalContinuation(puzzle.fen, [move])[0].fen, lastMove: move });
    const wrong = answerPuzzle(newPuzzleAttempt(puzzle), 'g6g5');
    expect(wrong.status).toBe('Incorrect');
    expect(puzzleDisplay(puzzle, wrong)).toEqual({ fen: puzzle.fen });
    expect(puzzleDisplay(puzzle, { ...newPuzzleAttempt(puzzle), assisted: true, status: 'Assisted' })).toEqual({ fen: puzzle.fen });
    const set = lichessPuzzleSet({ puzzle: { id: 'line', fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', solution: ['e2e4', 'e7e5', 'g1f3'], themes: [] } });
    const multi = set.puzzles[0];
    const done = answerPuzzle(answerPuzzle(newPuzzleAttempt(multi), 'e4'), 'Nf3');
    expect(puzzleDisplay(multi, done)).toEqual({ fen: legalContinuation(multi.fen, ['e2e4', 'e7e5', 'g1f3']).at(-1)!.fen, lastMove: 'g1f3' });
    const revealed = { ...answerPuzzle(newPuzzleAttempt(multi), 'e4'), assisted: true, status: 'Assisted' as const };
    const afterE4 = legalContinuation(multi.fen, ['e2e4'])[0].fen;
    expect(puzzleDisplay(multi, revealed)).toEqual({ fen: revealed.fen, lastMove: 'e7e5', lastMoveFrom: afterE4 });
    const midway = answerPuzzle(newPuzzleAttempt(multi), 'e4');
    expect(puzzleDisplay(multi, midway)).toEqual({ fen: midway.fen, lastMove: 'e7e5', lastMoveFrom: afterE4 });
  });
});