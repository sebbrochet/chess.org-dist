import { Chess, castlingSide } from 'chessops/chess';
import { INITIAL_FEN, makeFen, parseFen } from 'chessops/fen';
import { PgnParser, makePgn, parseComment, startingPosition, walk, type CommentShape, type Game, type PgnNodeData } from 'chessops/pgn';
import { makeSanAndPlay, parseSan } from 'chessops/san';
import { kingCastlesTo, makeUci } from 'chessops/util';

export const MAX_PGN_LENGTH = 2_000_000;
export const DETAIL_FIELDS = ['Title', 'White', 'Black', 'Event', 'Site', 'Date', 'Round', 'WhiteElo', 'BlackElo', 'Annotator'] as const;
export type DetailField = typeof DETAIL_FIELDS[number];
export type GameDetails = Partial<Record<DetailField, string>>;
export type GameResult = '*' | '1-0' | '0-1' | '1/2-1/2';
export interface ParsedGame {
  headers: Record<string, string>;
  startFen: string;
  moves: string[];
  positions: string[];
  result: GameResult;
  pgn: string;
}

export interface ImportedMoveAnalysis {
  comments: string[]; glyphs: string[]; markings: CommentShape[];
  evaluation?: { kind: 'cp'; value: number; perspective: 'white' } | { kind: 'mate'; value: number; perspective: 'white'; winner: 'white' | 'black' };
  depth?: number;
}
export interface ImportedGameAnalysis { entries: ImportedMoveAnalysis[]; evaluated: number; initialMarkings: CommentShape[] }

export function importedGameAnalysis(game: ParsedGame): ImportedGameAnalysis | undefined {
  try {
    let tree: Game<PgnNodeData> | undefined;
    new PgnParser((parsed, error) => { if (error || tree) throw new Error('Invalid imported annotation source.'); tree = parsed; }).parse(game.pgn);
    if (!tree) return;
    const recorded = validateGame(tree, 1);
    if (recorded.startFen !== game.startFen || JSON.stringify(recorded.moves) !== JSON.stringify(game.moves) || JSON.stringify(recorded.positions) !== JSON.stringify(game.positions)) return;
    let present = !!tree.comments?.length;
    walk(tree.moves, { clone() { return this; } }, (_, node, childIndex) => {
      if (node.comments?.length || node.startingComments?.length || node.nags?.length || childIndex > 0) present = true;
    });
    if (!present) return;
    const glyphs: Record<number, string> = { 1: '!', 2: '?', 3: '!!', 4: '??', 5: '!?', 6: '?!' };
    const entries = Array.from(tree.moves.mainline(), (node, index): ImportedMoveAnalysis => {
      const comments = node.comments ?? [];
      const tags = comments.flatMap(comment => comment.match(/\[%eval\b[^\]]*\]/g) ?? []);
      const parsed = tags.map(tag => {
        const result = parseComment(tag);
        return result.evaluation && !result.text.trim() ? result.evaluation : undefined;
      });
      const first = parsed[0];
      const supported = first && parsed.every(value => JSON.stringify(value) === JSON.stringify(first));
      let evaluation: ImportedMoveAnalysis['evaluation'];
      if (supported) {
        if ('pawns' in first && Number.isFinite(first.pawns)) evaluation = { kind: 'cp', value: Math.round(first.pawns * 100), perspective: 'white' };
        else if ('mate' in first && Number.isSafeInteger(first.mate)) {
          const winner = first.mate > 0 ? 'white' : first.mate < 0 ? 'black' : positionFromFen(game.positions[index + 1]).outcome()?.winner;
          if (winner) evaluation = { kind: 'mate', value: first.mate, perspective: 'white', winner };
        }
      }
      return { comments: comments.map(comment => parseComment(comment).text).filter(text => text.trim()), glyphs: (node.nags ?? []).map(nag => glyphs[nag] ?? `$${nag}`), markings: comments.flatMap(comment => parseComment(comment).shapes),
        evaluation, depth: evaluation ? first?.depth : undefined };
    });
    return { entries, evaluated: entries.filter(entry => entry.evaluation).length, initialMarkings: (tree.comments ?? []).flatMap(comment => parseComment(comment).shapes) };
  } catch { return; }
}

export function lastRecordedMove(game: Pick<ParsedGame, 'moves' | 'positions'>, ply = game.moves.length): string | undefined {
  if (ply < 1 || !game.moves[ply - 1] || !game.positions[ply - 1]) return;
  const position = positionFromFen(game.positions[ply - 1]);
  const move = parseSan(position, game.moves[ply - 1]);
  if (!move) return;
  const castle = castlingSide(position, move);
  return castle && 'from' in move ? makeUci({ from: move.from, to: kingCastlesTo(position.turn, castle) }) : makeUci(move);
}

export function positionFromFen(fen: string): Chess {
  const setup = parseFen(fen);
  if (setup.isErr) throw new Error('Invalid FEN syntax.');
  const position = Chess.fromSetup(setup.value);
  if (position.isErr) throw new Error('Illegal standard-chess starting position.');
  return position.value;
}

function checkedSource(source: string): { text: string; moves: number } {
  const token = /\s+|\[[A-Za-z0-9][A-Za-z0-9_+#=:-]*\s+"(?:[^"\\\r\n]|\\["\\])*"\]|\{[^}]*\}|;[^\r\n]*|%[^\r\n]*|\d+\.+|\.{3}|1\/2-1\/2|1-0|0-1|\*|\$\d{1,4}|[!?]{1,2}|[()]|(?:[NBKRQ]?[a-h]?[1-8]?x?[a-h][1-8](?:=?[NBRQnbrq])?|[O0o]-[O0o](?:-[O0o])?)[+#]?/y;
  let offset = 0;
  let depth = 0;
  let moves = 0;
  let text = '';
  let headerResult: string | undefined;
  let inMoves = false;
  while (offset < source.length) {
    token.lastIndex = offset;
    const match = token.exec(source);
    if (!match) throw new Error(`Unrecognized PGN text near "${source.slice(offset, offset + 24)}".`);
    const value = match[0];
    offset = token.lastIndex;
    if (value === '(') depth++;
    if (value === ')' && --depth < 0) throw new Error('Unbalanced PGN variation.');
    if (value.startsWith('[')) {
      if (inMoves || depth !== 0) throw new Error('PGN headers must precede the game moves.');
      const result = /^\[Result\s+"([^"]*)"\]$/.exec(value);
      if (result) {
        if (!['*', '1-0', '0-1', '1/2-1/2'].includes(result[1])) throw new Error('Invalid PGN result.');
        headerResult = result[1];
      }
    }
    const isResult = ['*', '1-0', '0-1', '1/2-1/2'].includes(value);
    if (isResult && depth === 0) {
      if (headerResult && headerResult !== value) throw new Error('PGN header and movetext results disagree.');
      headerResult = undefined;
      inMoves = false;
      text += `${value}\n\n`;
    } else {
      text += value;
      if (/^[a-hNBKRQO0o]/.test(value) && !isResult) { moves++; inMoves = true; }
    }
  }
  if (depth !== 0) throw new Error('Unbalanced PGN variation.');
  return { text, moves };
}

function validateGame(game: Game<PgnNodeData>, index: number): ParsedGame {
  const variant = game.headers.get('Variant')?.toLowerCase();
  if (variant && !['standard', 'chess', 'normal', 'from position'].includes(variant)) {
    throw new Error(`Game ${index}: only standard chess is supported.`);
  }
  const initial = startingPosition(game.headers);
  if (initial.isErr) throw new Error(`Game ${index}: invalid or illegal FEN.`);
  const position = initial.value;
  if (game.headers.get('SetUp') === '1' && !game.headers.has('FEN')) throw new Error(`Game ${index}: SetUp requires FEN.`);
  walk(game.moves, position.clone(), (current, node) => {
    const move = parseSan(current, node.san);
    if (!move) throw new Error(`Game ${index}: illegal move ${node.san}.`);
    node.san = makeSanAndPlay(current, move);
  });
  const startFen = makeFen(position.toSetup());
  const positions = [startFen];
  const moves: string[] = [];
  for (const node of game.moves.mainline()) {
    const move = parseSan(position, node.san);
    if (!move) throw new Error(`Game ${index}: illegal move ${node.san}.`);
    moves.push(makeSanAndPlay(position, move));
    positions.push(makeFen(position.toSetup()));
  }
  if (startFen !== INITIAL_FEN) {
    game.headers.set('SetUp', '1');
    game.headers.set('FEN', startFen);
  }
  return {
    headers: Object.fromEntries(game.headers), startFen, moves, positions,
    result: (game.headers.get('Result') ?? '*') as GameResult, pgn: makePgn(game),
  };
}

export function parseGames(source: string): ParsedGame[] {
  if (!source.trim()) throw new Error('Enter PGN or choose a PGN file.');
  if (source.length > MAX_PGN_LENGTH) throw new Error('PGN exceeds the 2 MB import limit.');
  const checked = checkedSource(source.replace(/^\uFEFF/, ''));
  const games: Game<PgnNodeData>[] = [];
  new PgnParser((game, error) => {
    if (error) throw new Error('PGN exceeds the parsing complexity limit.');
    games.push(game);
  }).parse(checked.text);
  let parsedMoves = 0;
  const parsed = games.map((game, index) => {
    walk(game.moves, { clone() { return this; } }, () => { parsedMoves++; });
    return validateGame(game, index + 1);
  });
  if (!parsed.length || parsedMoves !== checked.moves) throw new Error('PGN could not be parsed completely.');
  return parsed;
}

export function editDetails(game: ParsedGame, details: GameDetails): ParsedGame {
  const parsed = parseGames(game.pgn)[0];
  const headers = { ...parsed.headers };
  for (const field of DETAIL_FIELDS) {
    const value = details[field];
    if (value !== undefined) {
      if (value.length > 500 || Array.from(value).some(character => character.charCodeAt(0) < 32)) throw new Error(`${field} must be a single line of at most 500 characters.`);
      headers[field] = value.trim();
    }
  }
  const result: Game<PgnNodeData>[] = [];
  new PgnParser(game => result.push(game)).parse(parsed.pgn);
  result[0].headers = new Map(Object.entries(headers));
  return { ...parsed, headers, pgn: makePgn(result[0]) };
}

export function exportGames(games: readonly ParsedGame[]): string {
  if (!games.length) throw new Error('Select at least one game to export.');
  return games.map(game => game.pgn.trim()).join('\n\n') + '\n';
}

export function nextRecordedPly(game: ParsedGame, ply: number, san: string): number {
  const position = positionFromFen(game.positions[ply]);
  const move = parseSan(position, san.trim());
  if (!move) throw new Error('Enter a legal SAN move for the current position.');
  const canonical = makeSanAndPlay(position, move);
  if (canonical !== game.moves[ply]) throw new Error('That is not the next recorded move.');
  return ply + 1;
}