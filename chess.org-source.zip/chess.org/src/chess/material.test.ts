import { describe, expect, it } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { capturedMaterial } from './material';

describe('capturedMaterial', () => {
  it('records captures by the capturing side and the net advantage of the displayed ply', () => {
    const moves = ['e4', 'd5', 'exd5', 'Qxd5', 'Nc3'];
    expect(capturedMaterial(INITIAL_FEN, moves, 3)).toEqual({ captured: { white: ['pawn'], black: [] }, advantage: { side: 'white', points: 1 } });
    expect(capturedMaterial(INITIAL_FEN, moves)).toEqual({ captured: { white: ['pawn'], black: ['pawn'] }, advantage: null });
    expect(capturedMaterial(INITIAL_FEN, moves, 0)).toEqual({ captured: { white: [], black: [] }, advantage: null });
  });

  it('counts en passant and does not treat castling as capturing the own rook', () => {
    const enPassant = capturedMaterial(INITIAL_FEN, ['e4', 'a6', 'e5', 'd5', 'exd6']);
    expect(enPassant.captured.white).toEqual(['pawn']);
    const castled = capturedMaterial('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1', ['O-O', 'O-O-O']);
    expect(castled).toEqual({ captured: { white: [], black: [] }, advantage: null });
  });

  it('counts a captured promoted piece as the piece it had become and ignores pieces absent from a custom start', () => {
    const result = capturedMaterial('4k2r/P7/8/8/8/8/8/4K3 w - - 0 1', ['a8=Q+', 'Kf7', 'Qxh8']);
    expect(result.captured).toEqual({ white: ['rook'], black: [] });
    expect(result.advantage).toEqual({ side: 'white', points: 9 });
    const sorted = capturedMaterial('k7/8/8/8/8/8/8/K7 w - - 0 1', []);
    expect(sorted).toEqual({ captured: { white: [], black: [] }, advantage: null });
  });

  it('orders captured pieces by value', () => {
    const result = capturedMaterial('k7/8/8/3p4/2Q1n3/8/8/K7 w - - 0 1', ['Qxd5+', 'Kb8', 'Qxe4']);
    expect(result.captured.white).toEqual(['knight', 'pawn']);
  });
});
