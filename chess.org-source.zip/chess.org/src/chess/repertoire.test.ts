import { describe, expect, it } from 'vitest';
import { createRecall, importRepertoire, recallDisplay, recallLeadMove, recallPath, recallPositions } from './repertoire';
import { legalContinuation } from './review';

describe('recall path', () => {
  it('numbers the moves up to the position and counts other move orders', () => {
    const book = importRepertoire('1. e4 c6 2. d4 d5 3. Nc3 (3. Nd2 dxe4) dxe4 *\n\n1. d4 d5 2. e4 c6 3. Nc3 dxe4 *', 'Caro', 'black');
    const ids = book.lines.map(line => line.id);
    const afterNc3 = legalContinuation(book.lines[0].positions[0], ['e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3'])[4].fen;
    const path = recallPath(book, ids, afterNc3)!;
    expect(path.text).toBe('1. e4 c6 2. d4 d5 3. Nc3');
    expect(path.otherOrders).toBe(1);
    expect(path.lineIds).toHaveLength(2);
    const first = recallPositions(book, ids)[0];
    expect(recallPath(book, ids, first)!.text).toBe('1. e4');
    expect(recallPath(book, [ids[2]], afterNc3)).toMatchObject({ text: '1. d4 d5 2. e4 c6 3. Nc3', otherOrders: 0, lineIds: [ids[2]] });
    expect(path.steps.map(step => step.uci)).toEqual(['e2e4', 'c7c6', 'd2d4', 'd7d5', 'b1c3']);
    expect(path.steps.at(-1)!.fen).toBe(afterNc3);
    expect(path.startFen).toBe(book.lines[0].positions[0]);
  });

  it('starts black-to-move paths with an ellipsis and has no path at a line start', () => {
    const book = importRepertoire('[FEN "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1"]\n[SetUp "1"]\n\n1... c6 2. d4 d5 *', 'From e4', 'white');
    const ids = book.lines.map(line => line.id);
    const [atStart, afterC6] = [book.lines[0].positions[0], book.lines[0].positions[1]];
    expect(recallPath(book, ids, afterC6)!.text).toBe('1... c6');
    expect(recallPath(book, ids, atStart)!.text).toBe('');
    const deeper = importRepertoire('[FEN "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1"]\n[SetUp "1"]\n\n1... c6 2. d4 d5 *', 'From e4', 'black');
    expect(recallPath(deeper, deeper.lines.map(line => line.id), deeper.lines[0].positions[2])!.text).toBe('1... c6 2. d4');
  });
});

describe('recall lead move', () => {
  it('identifies the opponent move that reached the recall position, including castling, and nothing at the start', () => {
    const black = importRepertoire('1. e4 c6 2. d4 d5 *', 'Lines', 'black');
    const ids = black.lines.map(line => line.id);
    const [first, second] = recallPositions(black, ids);
    expect(recallLeadMove(black, ids, first)).toEqual({ move: 'e2e4', from: black.lines[0].positions[0] });
    expect(recallLeadMove(black, ids, second)?.move).toBe('d2d4');
    const white = importRepertoire('1. e4 e5 *', 'Lines', 'white');
    expect(recallLeadMove(white, white.lines.map(line => line.id), recallPositions(white, white.lines.map(line => line.id))[0])).toBeUndefined();
    const castle = importRepertoire('[FEN "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1"]\n[SetUp "1"]\n\n1. O-O O-O-O *', 'Castle', 'black');
    const castleIds = castle.lines.map(line => line.id);
    expect(recallLeadMove(castle, castleIds, recallPositions(castle, castleIds)[0])?.move).toBe('e1g1');
  });
});

describe('recall display', () => {
  it('keeps an accepted recall move on the board and reverts wrong or revealed attempts', () => {
    const book = importRepertoire('1.e4 e5 *', 'Lines', 'black');
    const attempt = createRecall(book, book.lines.map(line => line.id));
    expect(recallDisplay({ ...attempt, answers: ['e7e5'], status: 'Success' })).toEqual({ fen: legalContinuation(attempt.fen, ['e7e5'])[0].fen, lastMove: 'e7e5' });
    expect(recallDisplay({ ...attempt, answers: ['e7e5'], assisted: true, status: 'Assisted' }).lastMove).toBe('e7e5');
    expect(recallDisplay({ ...attempt, answers: ['c7c5'], status: 'Incorrect' })).toEqual({ fen: attempt.fen });
    expect(recallDisplay({ ...attempt, assisted: true, status: 'Assisted' })).toEqual({ fen: attempt.fen });
    expect(recallDisplay(attempt)).toEqual({ fen: attempt.fen });
  });
});

describe('PGN repertoires', () => {
  it('preserves branches and accepts any included selected continuation', () => {
    const book = importRepertoire('1.e4 (1.d4 d5) e5 2.Nf3 *', 'Club lines', 'white');
    expect(book.lines).toHaveLength(2);
    expect(createRecall(book, book.lines.map(line => line.id)).targets.sort()).toEqual(['d2d4', 'e2e4']);
    expect(recallPositions(book, book.lines.map(line => line.id))).toHaveLength(2);
  });
  it('limits targets to selected lines and the chosen side', () => {
    const book = importRepertoire('1.e4 (1.d4 d5) e5 *', 'Black lines', 'black');
    const selected = book.lines.find(line => line.moves[0] === 'd4')!;
    expect(createRecall(book, [selected.id]).targets).toEqual(['d7d5']);
    expect(() => createRecall(book, [])).toThrow('No recall');
  });
  it('rejects invalid PGN instead of silently installing partial content', () => {
    expect(() => importRepertoire('1.e4 e5 2.Bh6 *', 'Invalid', 'white')).toThrow();
    expect(() => importRepertoire('1.e4 *', '', 'white')).toThrow('name');
  });
});