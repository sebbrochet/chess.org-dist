import { parseUci } from 'chessops/util';
import { makeSan, parseSan } from 'chessops/san';
import { positionFromFen } from './pgn';
import { captureReviewSource, eligibleMistakes, engineUci, legalContinuation, sufficientSearchEffort, terminalEvidence, type Evidence, type MoveEvidence, type Review, type ReviewBasis } from './review';
import type { EngineScore, LocalEngine } from '../engine/stockfish';
import type { GameDependent, RetainedGame } from '../storage/library';

export interface TrainingAttempt extends GameDependent {
  activity: 'mistake' | 'guess';
  sourceIdentity: string;
  ply: number;
  side: 'white' | 'black';
  fen: string;
  target: string;
  assisted: boolean;
  status: 'Active' | 'Success' | 'Assisted' | 'Incorrect';
  answers: string[];
  createdAt: string;
  updatedAt: string;
  evidence?: { entry: MoveEvidence; basis: ReviewBasis; candidate?: Evidence };
}
export const isAttempt = (value: GameDependent): value is TrainingAttempt =>
  ['mistake', 'guess'].includes(String(value.activity)) && typeof value.fen === 'string' && typeof value.status === 'string';

export function attemptDisplayFen(attempt: TrainingAttempt): string {
  const answer = attempt.answers.at(-1);
  return answer && (attempt.status === 'Success' || attempt.status === 'Assisted')
    ? legalContinuation(attempt.fen, [answer])[0].fen : attempt.fen;
}

export function acceptsCandidate(best: EngineScore, candidate: EngineScore, mover: 'white' | 'black'): boolean | undefined {
  if (best.kind === 'cp' && candidate.kind === 'cp') return (best.value - candidate.value) * (mover === 'white' ? 1 : -1) <= 30;
  if (best.kind === 'mate' && best.winner === mover) return candidate.kind === 'mate' && candidate.winner === mover;
  if (candidate.kind === 'mate' && candidate.winner !== mover && (best.kind === 'cp' || best.winner === mover)) return false;
  return undefined;
}

export function candidateUci(fen: string, input: string): string {
  const position = positionFromFen(fen);
  const san = parseSan(position, input.trim());
  const move = san ?? parseUci(input.trim());
  if (!move || !position.isLegal(move)) throw new Error('Enter a legal move, including a promotion piece when required.');
  return san ? engineUci(fen, input.trim()) : engineUci(fen, makeSan(position, move));
}

export function newAttempt(game: RetainedGame, activity: TrainingAttempt['activity'], side: TrainingAttempt['side'], ply?: number, review?: Review): TrainingAttempt {
  const source = captureReviewSource(game);
  if (!['white', 'black'].includes(side)) throw new Error('Select White or Black.');
  let candidates: number[];
  if (activity === 'mistake') {
    if (!review || review.gameId !== game.id || review.source.identity !== source.identity) throw new Error('A current completed review or verified targeted preparation is required.');
    candidates = eligibleMistakes(review).filter(entry => entry.mover === side).map(entry => entry.ply);
  } else candidates = game.moves.flatMap((_move, index) => positionFromFen(game.positions[index]).turn === side ? [index] : []);
  const selected = ply === undefined ? candidates[0] : candidates.find(index => index === ply);
  if (selected === undefined) throw new Error('No eligible positions for the selected side.');
  const entry = eligibleMistakes(review).find(entry => entry.ply === selected);
  const now = new Date().toISOString();
  return { id: crypto.randomUUID(), gameId: game.id, activity, sourceIdentity: source.identity, ply: selected, side,
    fen: game.positions[selected], target: activity === 'mistake' ? entry!.best : engineUci(game.positions[selected], game.moves[selected]),
    assisted: false, status: 'Active', answers: [], createdAt: now, updatedAt: now,
    ...(activity === 'mistake' ? { evidence: { entry: structuredClone(entry!), basis: structuredClone(review!.basis) } } : {}) };
}

export async function verifyMistake(engine: LocalEngine, attempt: TrainingAttempt, input: string, signal: AbortSignal): Promise<{ answer: string; correct: boolean; evidence: Evidence }> {
  if (!attempt.evidence || attempt.activity !== 'mistake') throw new Error('Missing historical review evidence.');
  const answer = candidateUci(attempt.fen, input);
  const fen = legalContinuation(attempt.fen, [answer])[0].fen;
  let evidence = terminalEvidence(fen);
  if (!evidence) {
    const result = await engine.analyze({ gameId: attempt.gameId, generation: 1, fen, purpose: 'analysis', limits: attempt.evidence.basis.limits }, signal);
    if (signal.aborted) throw new DOMException('Exercise cancelled.', 'AbortError');
    if (!result.score || !Number.isFinite(result.score.value) || !result.jobId || result.depth < 1 || result.nodes < 1 || result.purpose !== 'analysis' || result.generation !== 1 || result.fen !== fen || result.gameId !== attempt.gameId || result.engineVersion !== attempt.evidence.basis.engineVersion ||
      JSON.stringify(result.limits) !== JSON.stringify(attempt.evidence.basis.limits) || !sufficientSearchEffort(result, attempt.evidence.basis)) throw new Error('Insufficient engine evidence; no result was awarded.');
    legalContinuation(fen, [result.bestmove]);
    legalContinuation(fen, result.pv);
    evidence = { kind: 'search', fen, score: result.score, result };
  }
  const correct = acceptsCandidate(attempt.evidence.entry.bestChild.score, evidence.score, attempt.side);
  if (correct === undefined) throw new Error('Mate outcomes are not comparable for this exercise; no success was awarded.');
  return { answer, correct, evidence };
}