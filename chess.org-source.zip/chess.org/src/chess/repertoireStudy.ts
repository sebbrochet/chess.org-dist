import { parseComment, parsePgn, type CommentShape, type Node, type PgnNodeData } from 'chessops/pgn';
import { makeFen } from 'chessops/fen';
import { makeSanAndPlay, parseSan } from 'chessops/san';
import type { Chess } from 'chessops/chess';
import { parseGames, positionFromFen } from './pgn';
import { engineUci } from './review';
import type { Repertoire } from './repertoire';

export interface StudyNode {
  id: number; parent: number; san: string; uci: string; fen: string;
  before: string[]; comments: string[]; shapes: CommentShape[]; children: number[]; lineIds: string[];
}
export interface StudyChapter { index: number; name: string; intro: string[]; introShapes: CommentShape[]; nodes: StudyNode[]; lineIds: string[] }

const texts = (comments?: string[]) => (comments ?? []).map(comment => parseComment(comment).text.trim()).filter(Boolean);
const shapes = (comments?: string[]) => (comments ?? []).flatMap(comment => parseComment(comment).shapes);
const lineKey = (startFen: string, moves: readonly string[]) => `${startFen}|${moves.join(' ')}`;

export function repertoireChapters(book: Repertoire): StudyChapter[] {
  const lineIds = new Map<string, string[]>();
  for (const line of book.lines) lineIds.set(lineKey(line.positions[0], line.moves), [...lineIds.get(lineKey(line.positions[0], line.moves)) ?? [], line.id]);
  return parseGames(book.source).map((game, index) => {
    const tree = parsePgn(game.pgn)[0];
    const name = [game.headers.ChapterName, game.headers.Event].find(value => value && value.trim() && value.trim() !== '?')?.trim() ?? `Chapter ${index + 1}`;
    const nodes: StudyNode[] = [{ id: 0, parent: -1, san: '', uci: '', fen: game.startFen, before: [], comments: [], shapes: [], children: [], lineIds: [] }];
    const visit = (source: Node<PgnNodeData>, parent: number, position: Chess, moves: string[]) => {
      if (!source.children.length && moves.length) {
        // Identical lines repeated across chapters keep their own ids, in import order.
        const id = lineIds.get(lineKey(game.startFen, moves))?.shift();
        // Propagate the leaf's line to every ancestor so "practice from here" can select it.
        for (let at = parent; id && at >= 0; at = nodes[at].parent) nodes[at].lineIds.push(id);
      }
      for (const child of source.children) {
        const next = position.clone();
        const move = parseSan(next, child.data.san);
        if (!move) throw new Error('Illegal repertoire continuation.');
        const before = makeFen(position.toSetup());
        const san = makeSanAndPlay(next, move);
        const node: StudyNode = { id: nodes.length, parent, san, uci: engineUci(before, san), fen: makeFen(next.toSetup()),
          before: texts(child.data.startingComments), comments: texts(child.data.comments), shapes: shapes(child.data.comments), children: [], lineIds: [] };
        nodes.push(node);
        nodes[parent].children.push(node.id);
        visit(child, node.id, next, [...moves, san]);
      }
    };
    visit(tree.moves, 0, positionFromFen(game.startFen), []);
    return { index, name, intro: texts(tree.comments), introShapes: shapes(tree.comments), nodes, lineIds: nodes[0].lineIds };
  });
}

let cached: { key: string; chapters: StudyChapter[] } | undefined;
export function cachedRepertoireChapters(book: Repertoire): StudyChapter[] {
  const key = `${book.id}:${book.generation}:${book.source.length}`;
  if (cached?.key !== key) cached = { key, chapters: repertoireChapters(book) };
  return cached.chapters;
}

export function studyPath(chapter: StudyChapter, id: number): number[] {
  const path: number[] = [];
  for (let at = id; at > 0; at = chapter.nodes[at].parent) path.unshift(at);
  return path;
}
export function lineEnd(chapter: StudyChapter, id: number): number {
  let at = id;
  while (chapter.nodes[at].children.length) at = chapter.nodes[at].children[0];
  return at;
}

export interface RecallExplanation { uci: string; san: string; comments: string[] }
export function recallExplanations(chapters: StudyChapter[], fen: string, targets: readonly string[], selected: readonly string[]): RecallExplanation[] {
  const identity = (value: string) => value.split(' ').slice(0, 4).join(' ');
  const wanted = identity(fen);
  const chosen = new Set(selected);
  return targets.map(uci => {
    const comments: string[] = [];
    let san = '';
    for (const chapter of chapters) for (const node of chapter.nodes) {
      if (node.uci !== uci || node.id === 0 || identity(chapter.nodes[node.parent].fen) !== wanted || !node.lineIds.some(id => chosen.has(id))) continue;
      san = node.san;
      for (const text of [...node.before, ...node.comments]) if (!comments.includes(text)) comments.push(text);
    }
    return { uci, san, comments };
  });
}
