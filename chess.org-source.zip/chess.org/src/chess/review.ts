import { makeFen } from 'chessops/fen';
import { castlingSide } from 'chessops/chess';
import { makeSanAndPlay, parseSan } from 'chessops/san';
import { kingCastlesTo, makeUci, parseUci } from 'chessops/util';
import { positionFromFen, type ParsedGame } from './pgn';
import { ENGINE_VERSION, type AnalysisResult, type EngineLimits, type EngineScore, type LocalEngine } from '../engine/stockfish';

export const REVIEW_BASIS = { version: 'equal-children-v1', engineVersion: ENGINE_VERSION, limits: { nodes: 12000 } } as const;
export interface ReviewBasis { version: typeof REVIEW_BASIS.version; engineVersion: typeof ENGINE_VERSION; limits: EngineLimits }
export interface ReviewSource { identity: string; startFen: string; moves: string[]; positions: string[] }
export type Evidence = { kind: 'terminal'; fen: string; score: EngineScore; reason: 'checkmate' | 'draw' }
  | { kind: 'search'; fen: string; score: EngineScore; result: AnalysisResult };
export interface MoveJudgment { mistake: boolean; lossCp?: number; mate?: 'surrendered' | 'avoidable' | 'retained' | 'unresolved' }
export interface MoveEvidence {
  ply: number; mover: 'white' | 'black'; played: string; best: string;
  parent: Evidence; bestChild: Evidence; actualChild: Evidence; judgment: MoveJudgment;
}
export interface PreparedCandidate { ply: number; status: 'Pending' | 'Verified eligible' | 'Rejected' | 'Unverifiable'; evidence?: MoveEvidence; error?: string }
export interface Review {
  id: string; gameId: string; generation: number; status: 'Analysing' | 'Complete' | 'Interrupted';
  source: ReviewSource; basis: ReviewBasis; entries: MoveEvidence[]; createdAt: string; updatedAt: string; interruption?: string;
  purpose?: 'comparison' | 'supplement'; task?: 'continuations' | 'practice';
  continuations?: { ply: number; evidence: Evidence }[];
  preparation?: { side: 'white' | 'black'; candidates: PreparedCandidate[] };
}

export function engineUci(fen: string, san: string): string {
  const position = positionFromFen(fen);
  const move = parseSan(position, san);
  if (!move) throw new Error('Review snapshot contains an illegal recorded move.');
  const castle = castlingSide(position, move);
  return castle && 'from' in move ? makeUci({ from: move.from, to: kingCastlesTo(position.turn, castle) }) : makeUci(move);
}

export function captureReviewSource(game: Pick<ParsedGame, 'startFen' | 'moves' | 'positions'>): ReviewSource {
  const { startFen, moves, positions } = structuredClone(game);
  return { identity: JSON.stringify([startFen, moves, positions]), startFen, moves, positions };
}

export function judgeMove(best: EngineScore, actual: EngineScore, mover: 'white' | 'black'): MoveJudgment {
  if (best.kind === 'cp' && actual.kind === 'cp') {
    const lossCp = Math.max(0, (best.value - actual.value) * (mover === 'white' ? 1 : -1));
    return { lossCp, mistake: lossCp >= 100 };
  }
  if (best.kind === 'mate' && best.winner === mover && (actual.kind !== 'mate' || actual.winner !== mover)) return { mistake: true, mate: 'surrendered' };
  if (actual.kind === 'mate' && actual.winner !== mover && (best.kind !== 'mate' || best.winner === mover)) return { mistake: true, mate: 'avoidable' };
  return { mistake: false, mate: best.kind === 'mate' && actual.kind === 'mate' && best.winner === actual.winner ? 'retained' : 'unresolved' };
}

export interface MoveAnnotation {
  glyph: '' | '?!' | '?' | '??'; label: 'Below annotation threshold' | 'Inaccuracy' | 'Mistake' | 'Blunder';
  winPercentLoss?: number; mate?: 'surrendered' | 'avoidable';
}

export function classifyWinningChanceLoss(loss: number): MoveAnnotation {
  return loss >= 15 ? { glyph: '??', label: 'Blunder' } : loss >= 10 ? { glyph: '?', label: 'Mistake' }
    : loss >= 5 ? { glyph: '?!', label: 'Inaccuracy' } : { glyph: '', label: 'Below annotation threshold' };
}

export function annotateMove(best: EngineScore, actual: EngineScore, mover: 'white' | 'black'): MoveAnnotation {
  const perspective = mover === 'white' ? 1 : -1;
  if (best.kind === 'cp' && actual.kind === 'cp') {
    const winningPercent = (value: number) => 100 / (1 + Math.exp(-0.00368208 * value * perspective));
    const winPercentLoss = Math.max(0, winningPercent(best.value) - winningPercent(actual.value));
    return { ...classifyWinningChanceLoss(winPercentLoss), winPercentLoss };
  }
  if (best.kind === 'mate' && best.winner === mover && (actual.kind !== 'mate' || actual.winner !== mover)) {
    const score = actual.kind === 'cp' ? actual.value * perspective : 0;
    return { ...classifyWinningChanceLoss(score > 999 ? 5 : score > 700 ? 10 : 15), mate: 'surrendered' };
  }
  if (best.kind === 'cp' && actual.kind === 'mate' && actual.winner !== mover) {
    const score = best.value * perspective;
    return { ...classifyWinningChanceLoss(score < -999 ? 5 : score < -700 ? 10 : 15), mate: 'avoidable' };
  }
  return classifyWinningChanceLoss(0);
}

export function terminalEvidence(fen: string): Evidence | undefined {
  const position = positionFromFen(fen);
  const outcome = position.outcome();
  if (!outcome) return;
  return outcome.winner
    ? { kind: 'terminal', fen, score: { kind: 'mate', value: 0, perspective: 'white', winner: outcome.winner }, reason: 'checkmate' }
    : { kind: 'terminal', fen, score: { kind: 'cp', value: 0, perspective: 'white' }, reason: 'draw' };
}

export function legalContinuation(fen: string, moves: readonly string[]): { san: string; uci: string; fen: string }[] {
  const position = positionFromFen(fen);
  return moves.map(uci => {
    const move = parseUci(uci);
    if (!move || !position.isLegal(move)) throw new Error('Engine continuation contains an illegal move.');
    const san = makeSanAndPlay(position, move);
    return { san, uci, fen: makeFen(position.toSetup()) };
  });
}

export function sufficientSearchEffort(result: AnalysisResult, basis: ReviewBasis): boolean {
  if ('depth' in basis.limits) return result.depth >= basis.limits.depth;
  if (!('nodes' in basis.limits) || (result.searchedNodes ?? result.nodes) >= basis.limits.nodes) return true;
  if (result.score?.kind !== 'mate' || result.depth < 1) return false;
  try {
    const line = legalContinuation(result.fen, result.pv);
    const terminal = line.length ? terminalEvidence(line.at(-1)!.fen) : undefined;
    return terminal?.score.kind === 'mate' && terminal.score.winner === result.score.winner;
  } catch { return false; }
}

export async function analyzeReviewPosition(engine: LocalEngine, target: string, gameId: string, generation: number, signal: AbortSignal, basis: ReviewBasis = REVIEW_BASIS): Promise<Evidence> {
    if (signal.aborted) throw new DOMException('Review cancelled.', 'AbortError');
    const terminal = terminalEvidence(target);
    if (terminal) return terminal;
    const result = await engine.analyze({ gameId, generation, fen: target, purpose: 'analysis', limits: basis.limits }, signal);
    if (signal.aborted) throw new DOMException('Review cancelled.', 'AbortError');
    if (result.gameId !== gameId || result.generation !== generation || result.purpose !== 'analysis' || result.fen !== target || result.engineVersion !== basis.engineVersion ||
      JSON.stringify(result.limits) !== JSON.stringify(basis.limits) || !result.score || result.depth < 1 || result.nodes < 1 ||
      !Number.isFinite(result.score.value) || !sufficientSearchEffort(result, basis)) throw new Error('Insufficient or mismatched engine evidence. Retry review.');
    legalContinuation(target, [result.bestmove]);
    legalContinuation(target, result.pv);
    return { kind: 'search', fen: target, score: result.score, result };
}

export async function analyzeRecordedMove(engine: LocalEngine, source: ReviewSource, ply: number, gameId: string, generation: number, signal: AbortSignal, basis: ReviewBasis = REVIEW_BASIS): Promise<MoveEvidence> {
  const fen = source.positions[ply];
  const position = positionFromFen(fen);
  const mover = position.turn;
  const playedMove = parseSan(position, source.moves[ply]);
  if (!playedMove) throw new Error('Review snapshot contains an illegal recorded move.');
  const played = engineUci(fen, source.moves[ply]);
  const analyze = (target: string) => analyzeReviewPosition(engine, target, gameId, generation, signal, basis);
  const parent = await analyze(fen);
  if (parent.kind !== 'search') throw new Error('Recorded move follows a terminal position.');
  const best = parent.result.bestmove;
  const bestFen = legalContinuation(fen, [best])[0].fen;
  const actualFen = legalContinuation(fen, [played])[0].fen;
  if (actualFen !== source.positions[ply + 1]) throw new Error('Review source snapshot does not match recorded moves.');
  const bestChild = await analyze(bestFen);
  const actualChild = bestFen === actualFen ? bestChild : await analyze(actualFen);
  return { ply, mover, played, best, parent, bestChild, actualChild, judgment: judgeMove(bestChild.score, actualChild.score, mover) };
}

export function hasValidPrefix(review: Review): boolean {
  try {
  const limits = Object.entries(review.basis.limits);
  const validSource = review.basis.version === REVIEW_BASIS.version && review.basis.engineVersion === ENGINE_VERSION && limits.length === 1 &&
    ['nodes', 'depth', 'movetime'].includes(limits[0][0]) && Number.isSafeInteger(limits[0][1]) && limits[0][1] > 0 &&
    review.source.identity === captureReviewSource(review.source).identity && review.source.positions.length === review.source.moves.length + 1 && review.source.positions[0] === review.source.startFen;
  if (!validSource || (review.purpose !== undefined && !['comparison', 'supplement'].includes(review.purpose))) return false;
  if (review.purpose === 'supplement') {
    const lines = review.continuations ?? [];
    const candidates = review.preparation?.candidates ?? [];
    if (!Array.isArray(lines) || (review.preparation && !Array.isArray(review.preparation.candidates))) return false;
    return review.entries.length === 0 && ['continuations', 'practice'].includes(review.task!) &&
      new Set(lines.map(line => line.ply)).size === lines.length && lines.every(line => Number.isSafeInteger(line.ply) && line.ply >= 0 && line.ply < review.source.moves.length && line.evidence.fen === review.source.positions[line.ply + 1] && validReviewEvidence(review, line.evidence) && (line.evidence.kind === 'terminal' || (line.evidence.result.pv.length > 0 && legalContinuation(line.evidence.fen, [line.evidence.result.pv[0]])[0].fen === legalContinuation(line.evidence.fen, [line.evidence.result.bestmove])[0].fen))) &&
      (!review.preparation || (['white', 'black'].includes(review.preparation.side) && new Set(candidates.map(candidate => candidate.ply)).size === candidates.length && candidates.every(candidate => {
        if (!Number.isSafeInteger(candidate.ply) || candidate.ply < 0 || candidate.ply >= review.source.moves.length) return false;
        if (candidate.status === 'Pending' || candidate.status === 'Unverifiable') return !candidate.evidence;
        if (!candidate.evidence || !['Verified eligible', 'Rejected'].includes(candidate.status) || candidate.evidence.ply !== candidate.ply) return false;
        const source = captureReviewSource({ startFen: review.source.positions[candidate.ply], moves: [review.source.moves[candidate.ply]], positions: review.source.positions.slice(candidate.ply, candidate.ply + 2) });
        return hasValidPrefix({ ...review, purpose: 'comparison', source, entries: [{ ...candidate.evidence, ply: 0 }] }) && candidate.evidence.judgment.mistake === (candidate.status === 'Verified eligible');
      }))) && (review.task !== 'practice' || !!review.preparation);
  }
  return review.entries.length <= review.source.moves.length && review.entries.every((entry, ply) => {
    try {
      const position = positionFromFen(review.source.positions[ply]);
      const validEvidence = (evidence: Evidence) => validReviewEvidence(review, evidence);
      return entry.ply === ply && entry.mover === position.turn && entry.played === engineUci(review.source.positions[ply], review.source.moves[ply]) && entry.parent.fen === review.source.positions[ply] &&
        entry.actualChild.fen === review.source.positions[ply + 1] && entry.bestChild.fen === legalContinuation(entry.parent.fen, [entry.best])[0].fen &&
        entry.parent.kind === 'search' && entry.best === entry.parent.result.bestmove && [entry.parent, entry.bestChild, entry.actualChild].every(validEvidence) &&
        JSON.stringify(entry.judgment) === JSON.stringify(judgeMove(entry.bestChild.score, entry.actualChild.score, entry.mover));
    } catch { return false; }
  });
  } catch { return false; }
}

export function validReviewEvidence(review: Review, evidence: Evidence): boolean {
  try {
    if (evidence.kind === 'terminal') return JSON.stringify(evidence) === JSON.stringify(terminalEvidence(evidence.fen));
    if (evidence.kind !== 'search') return false;
    const result = evidence.result;
    return evidence.score.perspective === 'white' && (evidence.score.kind === 'cp' || (evidence.score.kind === 'mate' && ['white', 'black'].includes(evidence.score.winner))) &&
      result.generation > 0 && result.generation <= review.generation && !!result.jobId && result.fen === evidence.fen && result.gameId === review.gameId && result.purpose === 'analysis' && result.engineVersion === review.basis.engineVersion &&
      JSON.stringify(result.limits) === JSON.stringify(review.basis.limits) && JSON.stringify(result.score) === JSON.stringify(evidence.score) && Number.isFinite(evidence.score.value) && result.depth > 0 && result.nodes > 0 && sufficientSearchEffort(result, review.basis) &&
      legalContinuation(evidence.fen, [result.bestmove]).length === 1 && legalContinuation(evidence.fen, result.pv).length === result.pv.length;
  } catch { return false; }
}

export function eligibleMistakes(review?: Review): MoveEvidence[] {
  if (!review || !hasValidPrefix(review)) return [];
  return review.purpose === 'supplement' ? (review.preparation?.candidates.filter(candidate => candidate.status === 'Verified eligible').map(candidate => candidate.evidence!) ?? [])
    : review.status === 'Complete' && hasCompleteCoverage(review) ? review.entries.filter(entry => entry.judgment.mistake) : [];
}

export function hasCompleteCoverage(review: Review): boolean {
  if (review.purpose === 'supplement') return hasValidPrefix(review) && (review.task === 'practice'
    ? !!review.preparation && review.preparation.candidates.filter(candidate => positionFromFen(review.source.positions[candidate.ply]).turn === review.preparation!.side).every(candidate => candidate.status !== 'Pending')
    : review.continuations?.length === review.source.moves.length);
  return review.entries.length === review.source.moves.length && hasValidPrefix(review);
}