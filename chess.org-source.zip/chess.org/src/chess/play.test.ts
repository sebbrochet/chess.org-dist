import { describe, expect, it } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { changePlayAids, currentFen, newComputerGame, playAids, resolveSide, transitionGame, type ComputerGame, type ComputerOptions } from './play';
import { positionFromFen } from './pgn';

const options: ComputerOptions = { side: 'white', level: 1, takebacks: true, time: { initialMs: 10000, incrementMs: 1000 } };
describe('computer-game transitions', () => {
  it('charges elapsed time, increments only legal pre-flag moves and expires after reopening', () => {
    const game = newComputerGame(INITIAL_FEN, options, 0);
    const moved = transitionGame(game, { type: 'move', move: 'e4', actor: 'player' }, 9000);
    expect(moved.computer.clock).toEqual({ white: 2000, black: 10000, running: 'black', at: 9000 });
    const expired = transitionGame(game, { type: 'move', move: 'e4', actor: 'player' }, 10000);
    expect(expired.result).toBe('0-1');
    expect(expired.moves).toEqual([]);
    expect(transitionGame(moved, { type: 'reconcile' }, 19000).result).toBe('1-0');
  });
  it('removes player move and reply without restoring time or removing earned increments', () => {
    let game = newComputerGame(INITIAL_FEN, options, 0);
    game = transitionGame(game, { type: 'move', move: 'e4', actor: 'player' }, 1000);
    game = transitionGame(game, { type: 'move', move: 'e5', actor: 'engine' }, 3000);
    game = transitionGame(game, { type: 'takeback' }, 4000);
    expect(game.moves).toEqual([]);
    expect(game.computer.clock).toEqual({ white: 9000, black: 9000, running: 'white', at: 4000 });
    expect(game.computer.takebacksUsed).toBe(1);
    expect(game.computer.options).toEqual(options);
  });
  it('delegates legality and insufficient material including timeout to chessops', () => {
    const game = newComputerGame(INITIAL_FEN, options, 0);
    expect(() => transitionGame(game, { type: 'move', move: 'e5', actor: 'player' }, 1)).toThrow('legal');
    expect(() => transitionGame(game, { type: 'move', move: 'e4', actor: 'engine' }, 1)).toThrow('turn');
    const bareKing = newComputerGame('7k/8/8/8/8/8/P7/K7 w - - 0 1', options, 0);
    expect(transitionGame(bareKing, { type: 'reconcile' }, 10000).result).toBe('1/2-1/2');
    expect(newComputerGame('7k/8/8/8/8/8/8/K7 w - - 0 1', options, 0).result).toBe('1/2-1/2');
  });
  it('keeps intended-claim moves out of recorded history and supports untimed play', () => {
    const game = newComputerGame('7k/8/8/8/8/8/R7/K7 w - - 99 1', { ...options, time: null }, 0);
    const claimed = transitionGame(game, { type: 'claim', intended: 'Ra3' }, 100000);
    expect(claimed.result).toBe('1/2-1/2');
    expect(claimed.moves).toEqual([]);
    expect(claimed.computer.clock).toBeNull();
    expect(() => transitionGame(claimed, { type: 'takeback' }, 100001)).toThrow('unfinished');
  });
  function move(game: ComputerGame, san: string) {
    return transitionGame(game, { type: 'move', move: san, actor: positionFromFen(currentFen(game)).turn === game.computer.options.side ? 'player' : 'engine' }, 0);
  }
  it('handles fivefold repetition and a threefold intended-move claim with exact position identity', () => {
    let game = newComputerGame(INITIAL_FEN, { ...options, side: 'black', time: null }, 0);
    for (const san of ['Nf3', 'Nf6', 'Ng1', 'Ng8', 'Nf3', 'Nf6', 'Ng1']) game = move(game, san);
    expect(() => transitionGame(game, { type: 'claim', intended: 'e5' }, 0)).toThrow('do not establish');
    const claimed = transitionGame(game, { type: 'claim', intended: 'Ng8' }, 0);
    expect(claimed.result).toBe('1/2-1/2');
    expect(claimed.moves).toHaveLength(7);
    for (const san of ['Ng8', 'Nf3', 'Nf6', 'Ng1', 'Ng8', 'Nf3', 'Nf6', 'Ng1', 'Ng8']) game = move(game, san);
    expect(game.computer.reason).toBe('Fivefold repetition');
  });
  it('prioritizes checkmate over 75 moves and resets the halfmove count on a pawn move', () => {
    let game = newComputerGame('7k/8/5KQ1/8/8/8/8/8 w - - 149 1', { ...options, time: null }, 0);
    game = move(game, 'Qg7#');
    expect(game.result).toBe('1-0');
    expect(game.computer.reason).toBe('Checkmate');
    game = newComputerGame('7k/8/8/8/8/8/R7/K7 w - - 149 1', { ...options, time: null }, 0);
    expect(move(game, 'Ra3').computer.reason).toBe('Seventy-five-move rule');
    game = newComputerGame('7k/8/8/8/8/8/RP6/K7 w - - 99 1', { ...options, time: null }, 0);
    expect(() => transitionGame(game, { type: 'claim', intended: 'b3' }, 0)).toThrow('do not establish');
  });
  it('uses standard castling, en passant and explicit underpromotion legality', () => {
    let game = newComputerGame('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1', { ...options, time: null }, 0);
    game = move(game, 'O-O');
    expect(currentFen(game)).toContain('R4RK1 b kq');
    game = newComputerGame(INITIAL_FEN, { ...options, time: null }, 0);
    for (const san of ['e4', 'a6', 'e5', 'd5', 'exd6']) game = move(game, san);
    expect(currentFen(game)).toContain('p2P4');
    game = newComputerGame('7k/P7/8/8/8/8/8/7K w - - 0 1', { ...options, time: null }, 0);
    expect(() => move(game, 'a7a8')).toThrow('legal');
    expect(move(game, 'a7a8n').moves).toEqual(['a8=N']);
  });
  it('does not equate inability to force mate with impossibility of mate', () => {
    const game = newComputerGame('7k/8/8/8/8/8/7r/KN6 b - - 0 1', { ...options, side: 'black' }, 0);
    expect(transitionGame(game, { type: 'reconcile' }, 10000).result).toBe('1-0');
  });
  it('refuses disabled takebacks, imported continuations and invalid draw claims without changing the source', () => {
    let game = newComputerGame(INITIAL_FEN, { ...options, takebacks: false }, 0);
    game = move(game, 'e4');
    expect(() => transitionGame(game, { type: 'takeback' }, 1)).toThrow('enabled');
    const imported = { ...game, source: { kind: 'pgn' as const }, computer: undefined };
    expect(() => transitionGame(imported, { type: 'reconcile' }, 1)).toThrow('unfinished');
    const original = newComputerGame(INITIAL_FEN, options, 0);
    expect(() => transitionGame(original, { type: 'claim', intended: 'e4' }, 1)).toThrow('do not establish');
    expect(original.computer.clock?.white).toBe(10000);
    expect(original.result).toBe('*');
  });
  it('resolves Random to a concrete side and keeps it', () => {
    expect(resolveSide('random', () => 0.2)).toBe('white');
    expect(resolveSide('random', () => 0.7)).toBe('black');
    expect(resolveSide('black', () => 0.2)).toBe('black');
  });
  it('starts play aids as chosen, changes them only during an unfinished game and preserves them through play', () => {
    const aids = { evaluation: true, bestMove: false, assessments: true };
    expect(playAids(newComputerGame(INITIAL_FEN, options, 0))).toEqual({ evaluation: false, bestMove: false, assessments: false });
    const legacy = newComputerGame(INITIAL_FEN, options, 0);
    delete (legacy.computer as { aids?: unknown }).aids;
    expect(playAids(legacy)).toEqual({ evaluation: false, bestMove: false, assessments: false });
    let game = newComputerGame(INITIAL_FEN, options, 0, aids);
    expect(playAids(game)).toEqual(aids);
    game = move(game, 'e4');
    expect(playAids(game)).toEqual(aids);
    const changed = changePlayAids(game, { ...aids, bestMove: true });
    expect(playAids(changed)).toEqual({ ...aids, bestMove: true });
    expect(changed.computer.version).toBe(game.computer.version);
    expect(changed.moves).toEqual(game.moves);
    expect(() => changePlayAids(game, { evaluation: 'yes' } as never)).toThrow('Invalid play aids');
    expect(() => newComputerGame(INITIAL_FEN, options, 0, { evaluation: true } as never)).toThrow('Invalid');
    expect(() => changePlayAids(transitionGame(game, { type: 'resign' }, 1), aids)).toThrow('unfinished');
  });
});