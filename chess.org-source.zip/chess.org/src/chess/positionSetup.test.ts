import { describe, expect, it } from 'vitest';
import { parseSquare } from 'chessops/util';
import { castlingAllowed, clearedSetup, movePiece, placePiece, readSetup, setCastling, setTurn, setupFen, setupProblem, STARTING_SETUP_FEN } from './positionSetup';

const square = (name: string) => parseSquare(name)!;

describe('position setup', () => {
  it('places and erases pieces, clearing en passant and castling rights that lose their king or rook', () => {
    const start = readSetup('rnbqkbnr/ppp1pppp/8/3pP3/8/8/PPPP1PPP/RNBQKBNR w KQkq d6 3 7')!;
    let setup = placePiece(start, square('h1'), undefined);
    expect(setupFen(setup)).toBe('rnbqkbnr/ppp1pppp/8/3pP3/8/8/PPPP1PPP/RNBQKBN1 w Qkq - 3 7');
    setup = placePiece(setup, square('e8'), { role: 'queen', color: 'black' });
    expect(setupFen(setup)).toContain(' w Q - 3 7');
    expect(castlingAllowed(setup, 'h1')).toBe(false);
    expect(setupFen(setCastling(setup, 'h1', true))).toBe(setupFen(setup));
    expect(setupFen(setCastling(setup, 'a1', false))).toContain(' w - - ');
  });

  it('moves a piece onto any square and re-checks castling', () => {
    const start = readSetup(STARTING_SETUP_FEN)!;
    expect(setupFen(movePiece(start, square('e2'), square('e4')))).toBe('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 1');
    expect(setupFen(movePiece(start, square('h1'), square('h7')))).toBe('rnbqkbnr/pppppppR/8/8/8/8/PPPPPPPP/RNBQKBN1 w Qkq - 0 1');
    expect(setupFen(movePiece(start, square('e4'), square('e5')))).toBe(STARTING_SETUP_FEN);
  });

  it('switches the side to move and clears the board while keeping move numbers', () => {
    const start = readSetup(STARTING_SETUP_FEN)!;
    expect(setupFen(setTurn(start, 'black'))).toBe('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b KQkq - 0 1');
    expect(setupFen(clearedSetup(readSetup('8/8/8/8/8/8/8/K6k b - - 4 30')!))).toBe('8/8/8/8/8/8/8/8 b - - 4 30');
    expect(readSetup('not a fen')).toBeUndefined();
  });

  it('names why a position is illegal', () => {
    const problem = (fen: string) => setupProblem(readSetup(fen)!);
    expect(problem(STARTING_SETUP_FEN)).toBeUndefined();
    expect(problem('8/8/8/8/8/8/8/8 w - - 0 1')).toBe('The board is empty.');
    expect(problem('8/8/8/8/8/8/8/K7 w - - 0 1')).toBe('Each side needs exactly one king.');
    expect(problem('k7/8/8/8/8/8/8/K6P w - - 0 1')).toBe('Pawns cannot stand on the first or last rank.');
    expect(problem('k6R/8/8/8/8/8/8/K7 w - - 0 1')).toBe('The side not to move is in check.');
    expect(problem('k7/pppppppp/p7/8/8/8/8/K7 w - - 0 1')).toBe('Too many pieces for one side.');
  });
});
