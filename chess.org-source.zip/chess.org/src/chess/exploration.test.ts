import { describe, expect, it } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { createExploration, explorationLineEnd, explorationPath, explorationPgn, nextExplorationNode, playExplorationMove, selectExplorationNode } from './exploration';
import { importRepertoire } from './repertoire';

describe('opening exploration tree', () => {
  it('adds each explored move once and follows the most recently visited child', () => {
    let tree = createExploration(INITIAL_FEN);
    tree = playExplorationMove(tree, 'e2e4');
    tree = playExplorationMove(tree, 'c7c6');
    tree = selectExplorationNode(tree, 1);
    tree = playExplorationMove(tree, 'e7e5');
    expect(tree.nodes.map(node => node.san)).toEqual(['', 'e4', 'c6', 'e5']);
    tree = selectExplorationNode(tree, 0);
    tree = playExplorationMove(tree, 'e2e4');
    expect(tree.nodes).toHaveLength(4);
    expect(tree.current).toBe(1);
    expect(nextExplorationNode(tree)).toBe(3);
    tree = selectExplorationNode(tree, 2);
    expect(explorationPath(tree)).toEqual([0, 1, 2]);
    expect(explorationLineEnd(selectExplorationNode(tree, 0))).toBe(2);
    expect(nextExplorationNode(tree)).toBeUndefined();
  });

  it('treats a castling move written either way as the same node and refuses illegal moves', () => {
    let tree = createExploration('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');
    tree = playExplorationMove(tree, 'e1g1');
    tree = playExplorationMove(selectExplorationNode(tree, 0), 'e1h1');
    expect(tree.nodes).toHaveLength(2);
    expect(tree.nodes[1].san).toBe('O-O');
    expect(() => playExplorationMove(tree, 'a1a8')).toThrow();
  });

  it('exports branching lines with comments that import back as a repertoire', () => {
    let tree = createExploration(INITIAL_FEN);
    for (const uci of ['e2e4', 'c7c6', 'd2d4']) tree = playExplorationMove(tree, uci);
    tree = selectExplorationNode(tree, 1);
    tree = playExplorationMove(tree, 'e7e5');
    const pgn = explorationPgn(tree, 'My "lines"', { intro: 'Lichess {sample}', move: node => node.san === 'c6' ? 'Eval +0.3 (Lichess cloud)' : undefined });
    expect(pgn).toBe('[Event "My \\"lines\\""]\n\n{ Lichess sample } 1. e4 c6 { Eval +0.3 (Lichess cloud) } (1... e5) 2. d4 *\n');
    const lines = importRepertoire(pgn, 'Mine', 'black').lines.map(line => line.moves);
    expect(lines).toHaveLength(2);
    expect(lines).toEqual(expect.arrayContaining([['e4', 'c6', 'd4'], ['e4', 'e5']]));
    expect(explorationPgn(tree, 'Plain')).toBe('[Event "Plain"]\n\n1. e4 c6 (1... e5) 2. d4 *\n');
  });

  it('keeps a non-standard start position as the initial position', () => {
    const fen = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1';
    const tree = playExplorationMove(createExploration(fen), 'c7c6');
    const pgn = explorationPgn(tree, 'From e4');
    expect(pgn).toContain(`[FEN "${fen}"]`);
    expect(pgn).toContain('1... c6 *');
    expect(importRepertoire(pgn, 'From e4', 'black').lines[0].positions[0]).toBe(fen);
  });
});
