import { parseSan } from 'chessops/san';
import type { Color, Role } from 'chessops/types';
import { positionFromFen } from './pgn';

const VALUES: Record<Role, number> = { pawn: 1, knight: 3, bishop: 3, rook: 5, queen: 9, king: 0 };
const ORDER: Role[] = ['queen', 'rook', 'bishop', 'knight', 'pawn'];

export interface CapturedMaterial {
  /** Opponent pieces each side has captured, most valuable first. */
  captured: Record<Color, Role[]>;
  advantage: { side: Color; points: number } | null;
}

export function capturedMaterial(startFen: string, moves: readonly string[], ply = moves.length): CapturedMaterial {
  const position = positionFromFen(startFen);
  const captured: Record<Color, Role[]> = { white: [], black: [] };
  for (const san of moves.slice(0, ply)) {
    const move = parseSan(position, san);
    if (!move) throw new Error('Recorded move is illegal.');
    if ('from' in move) {
      const target = position.board.get(move.to);
      // Castling is encoded as the king moving onto its own rook.
      if (target && target.color !== position.turn) captured[position.turn].push(target.role);
      else if (!target && position.board.get(move.from)?.role === 'pawn' && move.to === position.epSquare) captured[position.turn].push('pawn');
    }
    position.play(move);
  }
  let balance = 0;
  for (const square of position.board.occupied) {
    const piece = position.board.get(square)!;
    balance += VALUES[piece.role] * (piece.color === 'white' ? 1 : -1);
  }
  for (const side of ['white', 'black'] as const) captured[side].sort((a, b) => ORDER.indexOf(a) - ORDER.indexOf(b));
  return { captured, advantage: balance ? { side: balance > 0 ? 'white' : 'black', points: Math.abs(balance) } : null };
}
