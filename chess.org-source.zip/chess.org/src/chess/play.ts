import { makeFen } from 'chessops/fen';
import { ChildNode, Node, makePgn, type PgnNodeData } from 'chessops/pgn';
import { makeSanAndPlay, parseSan } from 'chessops/san';
import { opposite, parseUci } from 'chessops/util';
import type { Color } from 'chessops/types';
import { parseGames, positionFromFen, type GameResult } from './pgn';
import type { RetainedGame } from '../storage/library';

export interface ComputerOptions {
  readonly side: Color;
  readonly level: number;
  readonly takebacks: boolean;
  readonly time: { initialMs: number; incrementMs: number } | null;
}
export interface ClockState {
  white: number;
  black: number;
  running: Color | null;
  at: number;
}
export interface PlayAids { evaluation: boolean; bestMove: boolean; assessments: boolean }
export const NO_PLAY_AIDS: PlayAids = { evaluation: false, bestMove: false, assessments: false };
export interface ComputerState {
  readonly options: ComputerOptions;
  version: number;
  takebacksUsed: number;
  clock: ClockState | null;
  reason?: string;
  aids?: PlayAids;
}
export type ComputerGame = RetainedGame & { computer: ComputerState };
export type PlayCommand = { type: 'reconcile' } | { type: 'move'; move: string; actor: 'player' | 'engine' }
  | { type: 'takeback' } | { type: 'resign' } | { type: 'claim'; intended?: string };

export function isComputerGame(game: RetainedGame): game is ComputerGame {
  return game.source.kind === 'computer' && !!game.computer;
}
export function currentFen(game: RetainedGame): string { return game.positions[game.positions.length - 1]; }
export function playAids(game: ComputerGame): PlayAids { return { ...NO_PLAY_AIDS, ...game.computer.aids }; }
export function resolveSide(choice: Color | 'random', random: () => number = Math.random): Color {
  return choice === 'random' ? random() < 0.5 ? 'white' : 'black' : choice;
}
function validAids(aids: PlayAids): boolean {
  return Object.keys(aids).length === 3 && [aids.evaluation, aids.bestMove, aids.assessments].every(value => typeof value === 'boolean');
}
export function changePlayAids(original: RetainedGame, aids: PlayAids): ComputerGame {
  if (!isComputerGame(original) || original.result !== '*') throw new Error('Play aids can change only during an unfinished computer game.');
  if (!validAids(aids)) throw new Error('Invalid play aids.');
  return { ...original, computer: { ...original.computer, aids: { ...aids } } };
}
const win = (side: Color): GameResult => side === 'white' ? '1-0' : '0-1';
const identity = (fen: string) => makeFen(positionFromFen(fen).toSetup()).split(' ').slice(0, 4).join(' ');
function repetitions(positions: string[]): number {
  const last = identity(positions[positions.length - 1]);
  return positions.filter(fen => identity(fen) === last).length;
}

function finish(game: ComputerGame, result: GameResult, reason: string): void {
  game.result = result;
  game.computer.reason = reason;
  if (game.computer.clock) game.computer.clock.running = null;
}
function adjudicate(game: ComputerGame): void {
  const position = positionFromFen(currentFen(game));
  if (position.isCheckmate()) finish(game, win(opposite(position.turn)), 'Checkmate');
  else if (position.isStalemate()) finish(game, '1/2-1/2', 'Stalemate');
  else if (position.isInsufficientMaterial()) finish(game, '1/2-1/2', 'Dead position');
  else if (position.halfmoves >= 150) finish(game, '1/2-1/2', 'Seventy-five-move rule');
  else if (repetitions(game.positions) >= 5) finish(game, '1/2-1/2', 'Fivefold repetition');
}
function serialize(game: ComputerGame): ComputerGame {
  const headers = new Map(Object.entries(game.headers));
  headers.set('Result', game.result);
  if (game.computer.reason) headers.set('Termination', game.computer.reason);
  const root = new Node<PgnNodeData>();
  let node = root;
  for (const san of game.moves) {
    const child = new ChildNode({ san });
    node.children.push(child);
    node = child;
  }
  return { ...game, ...parseGames(makePgn({ headers, moves: root }))[0] };
}
export function newComputerGame(fen: string, options: ComputerOptions, now: number, aids: PlayAids = NO_PLAY_AIDS): ComputerGame {
  if (!['white', 'black'].includes(options.side) || !Number.isInteger(options.level) || options.level < 0 || options.level > 20 ||
    typeof options.takebacks !== 'boolean' || !validAids(aids)) throw new Error('Invalid computer-game options.');
  if (options.time && (!Number.isFinite(options.time.initialMs) || options.time.initialMs <= 0 ||
    !Number.isFinite(options.time.incrementMs) || options.time.incrementMs < 0)) throw new Error('Invalid time control.');
  const position = positionFromFen(fen);
  const startFen = makeFen(position.toSetup());
  const game: ComputerGame = {
    id: crypto.randomUUID(), createdAt: new Date(now).toISOString(), source: { kind: 'computer' },
    headers: { White: options.side === 'white' ? 'Player' : `Stockfish level ${options.level}`,
      Black: options.side === 'black' ? 'Player' : `Stockfish level ${options.level}`,
      Event: 'Computer game', Date: new Date(now).toISOString().slice(0, 10).replaceAll('-', '.'),
      SetUp: '1', FEN: startFen, TimeControl: options.time ? `${options.time.initialMs / 1000}+${options.time.incrementMs / 1000}` : '-' },
    startFen, positions: [startFen], moves: [], result: '*', pgn: '',
    computer: { options: structuredClone(options), version: 0, takebacksUsed: 0, aids: { ...aids },
      clock: options.time ? { white: options.time.initialMs, black: options.time.initialMs, running: position.turn, at: now } : null },
  };
  adjudicate(game);
  return serialize(game);
}

export function clockAt(game: ComputerGame, now: number): ClockState | null {
  const clock = game.computer.clock ? { ...game.computer.clock } : null;
  if (clock?.running) {
    clock[clock.running] = Math.max(0, clock[clock.running] - Math.max(0, now - clock.at));
    clock.at = Math.max(now, clock.at);
  }
  return clock;
}
export function canTakeBack(game: RetainedGame): boolean {
  return isComputerGame(game) && game.result === '*' && game.computer.options.takebacks &&
    game.positions.slice(0, -1).some(fen => positionFromFen(fen).turn === game.computer.options.side);
}
export function transitionGame(original: RetainedGame, command: PlayCommand, now: number): ComputerGame {
  if (!isComputerGame(original) || original.result !== '*') throw new Error('Only unfinished computer games can continue.');
  const game = structuredClone(original);
  const state = game.computer;
  const position = positionFromFen(currentFen(game));
  state.clock = clockAt(game, now);
  adjudicate(game);
  if (game.result === '*' && state.clock?.running && state.clock[state.clock.running] <= 0) {
    const opponent = opposite(state.clock.running);
    finish(game, position.hasInsufficientMaterial(opponent) ? '1/2-1/2' : win(opponent),
      position.hasInsufficientMaterial(opponent) ? 'Timeout; opponent cannot mate' : 'Timeout');
  }
  if (game.result === '*') {
    if (command.type === 'move') {
      if ((position.turn === state.options.side) !== (command.actor === 'player')) throw new Error('Not your turn.');
      const move = parseSan(position, command.move.trim()) ?? parseUci(command.move.trim());
      if (!move || !position.isLegal(move)) throw new Error('Enter a legal move, including a promotion piece when required.');
      game.moves.push(makeSanAndPlay(position, move));
      game.positions.push(makeFen(position.toSetup()));
      if (state.clock && state.options.time) {
        state.clock[opposite(position.turn)] += state.options.time.incrementMs;
        state.clock.running = position.turn;
      }
      adjudicate(game);
    } else if (command.type === 'resign') {
      finish(game, win(opposite(state.options.side)), 'Resignation');
    } else if (command.type === 'takeback') {
      if (!canTakeBack(game)) throw new Error('No enabled player move is available to take back.');
      let index = game.moves.length - 1;
      while (positionFromFen(game.positions[index]).turn !== state.options.side) index--;
      game.moves = game.moves.slice(0, index);
      game.positions = game.positions.slice(0, index + 1);
      state.takebacksUsed++;
      if (state.clock) state.clock.running = state.options.side;
    } else if (command.type === 'claim') {
      if (position.turn !== state.options.side) throw new Error('A draw claim requires your turn.');
      const positions = [...game.positions];
      if (command.intended?.trim()) {
        const move = parseSan(position, command.intended.trim()) ?? parseUci(command.intended.trim());
        if (!move || !position.isLegal(move)) throw new Error('The intended move must be legal.');
        position.play(move);
        positions.push(makeFen(position.toSetup()));
      }
      if (position.halfmoves >= 100) finish(game, '1/2-1/2', 'Fifty-move claim');
      else if (repetitions(positions) >= 3) finish(game, '1/2-1/2', 'Threefold repetition claim');
      else throw new Error('This position and intended move do not establish a draw claim.');
    }
  }
  state.version++;
  return serialize(game);
}