import { makeFen } from 'chessops/fen';
import { makeUci } from 'chessops/util';
import type { Move } from 'chessops/types';
import { parseGames, positionFromFen } from './pgn';
import { candidateUci } from './training';
import { legalContinuation } from './review';

export interface PuzzleCollection { id: string; name: string; source: string; puzzleIds: string[]; retainedAt: string }
export interface Puzzle { id: string; collectionId: string; fen: string; solutions: string[][]; themes: string[]; rating?: number }
export interface PuzzleAttempt {
  id: string; puzzleId: string; collectionId: string; side: 'white' | 'black'; fen: string;
  remaining: string[][]; answers: string[]; assisted: boolean; status: 'Active' | 'Success' | 'Assisted' | 'Incorrect'; createdAt: string;
}
export interface PuzzleSet { collection: PuzzleCollection; puzzles: Puzzle[] }
export function mateInOneMoves(fen: string): string[] {
  const position = positionFromFen(fen); const answers: string[] = [];
  for (const [from, destinations] of position.allDests()) for (const to of destinations) {
    const promotions = position.board.get(from)?.role === 'pawn' && (to < 8 || to >= 56) ? ['queen', 'rook', 'bishop', 'knight'] as const : [undefined];
    for (const promotion of promotions) {
      const move = { from, to, ...(promotion ? { promotion } : {}) } as Move;
      if (!position.isLegal(move)) continue;
      const child = position.clone(); child.play(move);
      if (child.isCheckmate()) answers.push(candidateUci(fen, makeUci(move)));
    }
  }
  return [...new Set(answers)];
}
export function validatePuzzle(puzzle: Puzzle): Puzzle {
  const fen = makeFen(positionFromFen(puzzle.fen).toSetup());
  if (!puzzle.id || !puzzle.collectionId || !Array.isArray(puzzle.solutions) || !puzzle.solutions.length || puzzle.solutions.length > 200) throw new Error('Invalid puzzle content.');
  const solutions = puzzle.solutions.map(line => {
    if (!Array.isArray(line) || !line.length || line.length > 100 || line.some(move => typeof move !== 'string')) throw new Error('Invalid puzzle continuation.');
    legalContinuation(fen, line); return [...line];
  });
  if (solutions.some(line => line.length === 1 && positionFromFen(legalContinuation(fen, line)[0].fen).isCheckmate())) {
    for (const move of mateInOneMoves(fen)) if (!solutions.some(line => line.length === 1 && line[0] === move)) solutions.push([move]);
  }
  return { ...puzzle, fen, solutions };
}
export function bundledPuzzles(): PuzzleSet {
  const id = 'chess-org-starter';
  const positions = ['7k/5Q2/6K1/8/8/8/8/8 w - - 0 1', 'k7/7R/1K6/8/8/8/8/8 w - - 0 1', '8/8/8/8/8/1k6/7r/K7 b - - 0 1'];
  const puzzles = positions.map((fen, index) => validatePuzzle({ id: `${id}-${index + 1}`, collectionId: id, fen,
    solutions: mateInOneMoves(fen).map(move => [move]), themes: ['mateIn1', 'original starter'] }));
  return { collection: { id, name: 'Checkmate essentials', source: 'chess.org original generated positions / CC0-1.0', puzzleIds: puzzles.map(puzzle => puzzle.id), retainedAt: new Date().toISOString() }, puzzles };
}
export function lichessPuzzleSet(value: unknown): PuzzleSet {
  if (!value || typeof value !== 'object') throw new Error('Invalid puzzle response.');
  const payload = value as { puzzle?: { id?: unknown; fen?: unknown; solution?: unknown; themes?: unknown; rating?: unknown }; game?: { pgn?: unknown } };
  const raw = payload.puzzle;
  if (!raw || typeof raw.id !== 'string' || !/^[a-zA-Z0-9]+$/.test(raw.id) || !Array.isArray(raw.solution) || raw.solution.some(move => typeof move !== 'string')) throw new Error('Invalid puzzle response.');
  const fen = typeof raw.fen === 'string' ? raw.fen : typeof payload.game?.pgn === 'string' ? parseGames(`${payload.game.pgn} *`)[0].positions.at(-1)! : '';
  const id = `lichess-${raw.id}`;
  const puzzle = validatePuzzle({ id: `${id}-position`, collectionId: id, fen, solutions: [raw.solution as string[]],
    themes: Array.isArray(raw.themes) ? raw.themes.filter((theme): theme is string => typeof theme === 'string') : [], ...(typeof raw.rating === 'number' ? { rating: raw.rating } : {}) });
  return { collection: { id, name: `Lichess tactics ${raw.id}`, source: `Lichess CC0 puzzle database / https://lichess.org/training/${raw.id}`, puzzleIds: [puzzle.id], retainedAt: new Date().toISOString() }, puzzles: [puzzle] };
}
export function newPuzzleAttempt(puzzle: Puzzle): PuzzleAttempt {
  return { id: crypto.randomUUID(), puzzleId: puzzle.id, collectionId: puzzle.collectionId, side: positionFromFen(puzzle.fen).turn, fen: puzzle.fen,
    remaining: structuredClone(puzzle.solutions), answers: [], assisted: false, status: 'Active', createdAt: new Date().toISOString() };
}
export function answerPuzzle(attempt: PuzzleAttempt, input: string): PuzzleAttempt {
  if (attempt.status !== 'Active') throw new Error('This solving attempt has ended.');
  const answer = candidateUci(attempt.fen, input);
  const matching = attempt.remaining.filter(line => line[0] === answer);
  const next = { ...attempt, answers: [...attempt.answers, answer] };
  if (!matching.length) return { ...next, status: 'Incorrect' };
  if (matching.some(line => line.length === 1)) return { ...next, status: attempt.assisted ? 'Assisted' : 'Success', remaining: [] };
  const reply = matching[0][1];
  const played = legalContinuation(attempt.fen, [answer, reply]);
  const remaining = matching.filter(line => line[1] === reply).map(line => line.slice(2));
  if (remaining.some(line => !line.length)) return { ...next, fen: played.at(-1)!.fen, remaining: [], status: attempt.assisted ? 'Assisted' : 'Success' };
  return { ...next, fen: played.at(-1)!.fen, remaining };
}
export function puzzleDisplay(puzzle: Puzzle, attempt: PuzzleAttempt): { fen: string; lastMove?: string; lastMoveFrom?: string } {
  const answer = attempt.answers.at(-1);
  if (!answer) return { fen: attempt.fen };
  try {
    let before = { ...newPuzzleAttempt(puzzle), assisted: attempt.assisted };
    let state = before;
    for (const move of attempt.answers) { before = state; state = answerPuzzle(state, move); }
    if (state.fen !== attempt.fen) return { fen: attempt.fen };
    // A solving move that ends the line is recorded without advancing the attempt position.
    if ((attempt.status === 'Success' || attempt.status === 'Assisted') && state.status === attempt.status && state.fen === before.fen) return { fen: legalContinuation(before.fen, [answer])[0].fen, lastMove: answer };
    const reply = state.fen !== before.fen ? before.remaining.find(line => line[0] === answer)?.[1] : undefined;
    return reply ? { fen: attempt.fen, lastMove: reply, lastMoveFrom: legalContinuation(before.fen, [answer])[0].fen } : { fen: attempt.fen };
  } catch { return { fen: attempt.fen }; }
}