import { describe, expect, it } from 'vitest';
import { editDetails, exportGames, importedGameAnalysis, lastRecordedMove, nextRecordedPly, parseGames, positionFromFen } from './pgn';

const PGN = '[Event "Club"]\n[White "Alice"]\n[Black "Bob"]\n[Result "1-0"]\n\n1.e4 e5 2.Nf3 Nc6 1-0';
const CUSTOM = '[SetUp "1"]\n[FEN "7k/8/8/8/8/8/4K3/8 b - - 0 42"]\n\n42...Kg7 *';

describe('PGN codec', () => {
  it('associates initial, mainline arrow and square markings without borrowing variation shapes', () => {
    const game = parseGames('{ [%csl Ye4] } 1.e4 { [%cal Ge2e4][%csl Rd4] } (1.d4 { [%cal Ba1a8] }) e5 *')[0];
    const imported = importedGameAnalysis(game)!;
    expect(imported.initialMarkings).toEqual([{ color: 'yellow', from: 28, to: 28 }]);
    expect(imported.entries[0].markings).toEqual([{ color: 'green', from: 12, to: 28 }, { color: 'red', from: 27, to: 27 }]);
    expect(imported.entries[1].markings).toEqual([]);
  });
  it('reuses supplied mainline scores, depth, glyphs and comments without borrowing variation evidence', () => {
    const game = parseGames('1.e4 $6 { [%eval 0.15,22] An idea. [%cal Ge2e4] } (1.d4 $4 { [%eval -8.0] }) e5 { [%eval -0.25] } *')[0];
    const original = game.pgn;
    expect(importedGameAnalysis(game)).toMatchObject({ evaluated: 2, entries: [
      { evaluation: { kind: 'cp', value: 15, perspective: 'white' }, depth: 22, glyphs: ['?!'], comments: ['An idea.'] },
      { evaluation: { kind: 'cp', value: -25, perspective: 'white' }, glyphs: [] },
    ] });
    expect(game.pgn).toBe(original);
    expect(exportGames([editDetails(game, { Title: 'Preserved' })])).toContain('[%cal Ge2e4]');
    expect(importedGameAnalysis(parseGames(exportGames([game]))[0])).toEqual(importedGameAnalysis(game));
  });
  it('does not fabricate missing, malformed, conflicting or wrong-source evaluations', () => {
    const game = parseGames('1.e4 { [%eval broken] } (1.d4 { [%eval 2.0] }) e5 { [%eval 0.2] [%eval -0.8] } *')[0];
    expect(importedGameAnalysis(game)).toMatchObject({ evaluated: 0 });
    expect(importedGameAnalysis(game)?.entries.every(entry => !entry.evaluation)).toBe(true);
    expect(importedGameAnalysis({ ...game, moves: ['d4', 'd5'] })).toBeUndefined();
    expect(importedGameAnalysis(parseGames('1.e4 e5 *')[0])).toBeUndefined();
  });
  it('keeps imported mate winners explicit, including terminal zero and unknown metadata', () => {
    const game = parseGames('1.f3 { [%eval #-2] } e5 2.g4 Qh4# { [%eval #0] } 0-1')[0];
    expect(importedGameAnalysis(game)).toMatchObject({ evaluated: 2, entries: [
      { evaluation: { kind: 'mate', value: -2, winner: 'black', perspective: 'white' } }, {}, {},
      { evaluation: { kind: 'mate', value: 0, winner: 'black', perspective: 'white' } },
    ] });
    expect(importedGameAnalysis(game)?.entries[0].depth).toBeUndefined();
  });
  it('identifies the previous recorded move at any replay position without guessing from FEN', () => {
    const game = parseGames('1.e4 e5 *')[0];
    expect(lastRecordedMove(game, 0)).toBeUndefined();
    expect(lastRecordedMove(game, 1)).toBe('e2e4');
    expect(lastRecordedMove(game)).toBe('e7e5');
    expect(lastRecordedMove(game, 3)).toBeUndefined();
  });
  it.each([
    ['[FEN "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1"]\n1.O-O *', 'e1g1'],
    ['[FEN "r3k2r/8/8/8/8/8/8/R3K2R b KQkq - 0 1"]\n1...O-O-O *', 'e8c8'],
    ['1.e4 a6 2.e5 d5 3.exd6 *', 'e5d6'],
    ['[FEN "7k/P7/8/8/8/8/4K3/8 w - - 0 1"]\n1.a8=N *', 'a7a8n'],
  ])('uses the played destination for special moves: %s', (pgn, expected) => {
    expect(lastRecordedMove(parseGames(pgn)[0])).toBe(expected);
  });
  it('imports multiple games including a black-to-move FEN', () => {
    const games = parseGames(`${PGN}\n\n${CUSTOM}`);
    expect(games).toHaveLength(2);
    expect(games[0].moves).toEqual(['e4', 'e5', 'Nf3', 'Nc6']);
    expect(games[1].positions[1]).toBe('8/6k1/8/8/8/8/4K3/8 w - - 1 43');
  });
  it('validates branches and preserves comments and variations', () => {
    const [game] = parseGames('1.e4 {A comment} (1.d4 d5) e5 *');
    expect(game.pgn).toContain('A comment');
    expect(game.pgn).toContain('d4');
    expect(game.moves).toEqual(['e4', 'e5']);
    expect(() => parseGames('1.e4 (1.e5) e5 *')).toThrow('illegal');
  });
  it.each(['', 'garbage', '1.e4 garbage e5 *', '1.e4 e5 2.Bh6 *', '1.e4 {unfinished', '1.e4 (1.d4 *', '[Result "1-0"]\n1.e4 0-1', '[FEN "bad"]\n*', '[FEN "8/8/8/8/8/8/8/8 w - - 0 1"]\n*', '[Variant "Atomic"]\n1.e4 *'])('rejects invalid input: %s', input => {
    expect(() => parseGames(input)).toThrow();
  });
  it('roundtrips selected games with escaped metadata, result, custom FEN and moves unchanged', () => {
    const games = parseGames(`${PGN}\n\n${CUSTOM}`);
    const edited = editDetails(games[0], { Title: 'A "quoted" title', White: 'Changed' });
    const roundtrip = parseGames(exportGames([edited, games[1]]));
    expect(roundtrip[0].headers.Title).toBe('A "quoted" title');
    expect(roundtrip.map(game => game.moves)).toEqual(games.map(game => game.moves));
    expect(roundtrip[0].result).toBe('1-0');
    expect(roundtrip[1].startFen).toBe(games[1].startFen);
    expect(roundtrip[1].pgn).toContain('42...');
  });
  it('only advances keyboard SAN through recorded moves', () => {
    const [game] = parseGames(PGN);
    expect(nextRecordedPly(game, 0, 'e4')).toBe(1);
    expect(() => nextRecordedPly(game, 0, 'd4')).toThrow('recorded');
    expect(() => nextRecordedPly(game, 0, 'e5')).toThrow('legal');
    expect(() => positionFromFen('bad')).toThrow();
  });
  it('rejects headers inside movetext rather than silently dropping metadata', () => {
    expect(() => parseGames('1.e4\n[White "Lost header"]\ne5 *')).toThrow('precede');
  });
  it('supports castling, en passant, and promotion through legal replay', () => {
    expect(parseGames('1.e4 e5 2.Nf3 Nc6 3.Bc4 Nf6 4.O-O *')[0].moves.at(-1)).toBe('O-O');
    expect(parseGames('1.e4 a6 2.e5 d5 3.exd6 *')[0].positions.at(-1)).toBe('rnbqkbnr/1pp1pppp/p2P4/8/8/8/PPPP1PPP/RNBQKBNR b KQkq - 0 3');
    const [promoted] = parseGames('[FEN "7k/P7/8/8/8/8/4K3/8 w - - 0 1"]\n1.a8=Q+ *');
    expect(promoted.moves).toEqual(['a8=Q+']);
    expect(promoted.positions[1]).toContain('Q6k');
  });
});