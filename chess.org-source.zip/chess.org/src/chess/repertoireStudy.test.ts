import { describe, expect, it } from 'vitest';
import { createRecall, importRepertoire } from './repertoire';
import { lineEnd, recallExplanations, repertoireChapters, studyPath } from './repertoireStudy';

const SOURCE = `[Event "Course"]
[ChapterName "Start Here"]

{ Welcome to the course. } *

[Event "Main event"]

{ Main ideas. } 1. e4 { King pawn [%cal Ge2e4] } c6 (1... e5 { Open game } 2. Nf3) 2. d4 { [%csl Rd4] } d5 *

[Event "?"]

1. e4 e5 2. Nf3 *
`;

describe('recall explanations', () => {
  const book = importRepertoire(`[ChapterName "A"]

1. e4 c6 { Solid. } 2. d4 d5 { Strike the centre. } *

[ChapterName "B"]

1. d4 d5 { Strike the centre. } 2. e4 (2. c4 c6 { Slav. }) c6 *

[ChapterName "C"]

1. e4 c6 { Other chapter. } *
`, 'Caro', 'black');
  const chapters = repertoireChapters(book);
  const all = book.lines.map(line => line.id);

  it('collects each expected move\'s comments from selected lines, de-duplicating transpositions', () => {
    const attempt = createRecall(book, all, 'rnbqkbnr/pppppppp/8/8/3P4/8/PPP1PPPP/RNBQKBNR b KQkq - 0 1');
    expect(recallExplanations(chapters, attempt.fen, attempt.targets, all)).toEqual([{ uci: 'd7d5', san: 'd5', comments: ['Strike the centre.'] }]);
    const after = createRecall(book, all, 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1');
    expect(recallExplanations(chapters, after.fen, after.targets, all)[0].comments).toEqual(['Solid.', 'Other chapter.']);
  });

  it('ignores comments from unselected lines and reports expected moves without comments', () => {
    const onlyA = chapters[0].lineIds;
    const attempt = createRecall(book, onlyA, 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1');
    expect(recallExplanations(chapters, attempt.fen, attempt.targets, onlyA)[0].comments).toEqual(['Solid.']);
    const quiet = importRepertoire('1. e4 c6 *', 'Quiet', 'black');
    const recall = createRecall(quiet, quiet.lines.map(line => line.id));
    expect(recallExplanations(repertoireChapters(quiet), recall.fen, recall.targets, recall.selectedLines)).toEqual([{ uci: 'c7c6', san: 'c6', comments: [] }]);
  });
});

describe('repertoire chapters', () => {
  const book = importRepertoire(SOURCE, 'Course', 'black');
  const chapters = repertoireChapters(book);

  it('keeps games as chapters in source order with name precedence and opening comments', () => {
    expect(chapters.map(chapter => chapter.name)).toEqual(['Start Here', 'Main event', 'Chapter 3']);
    expect(chapters[0].intro).toEqual(['Welcome to the course.']);
    expect(chapters[0].nodes).toHaveLength(1);
    expect(chapters[0].lineIds).toEqual([]);
    expect(chapters[1].intro).toEqual(['Main ideas.']);
  });

  it('attaches comments and supported markings to their moves and strips annotation commands from prose', () => {
    const [, e4] = chapters[1].nodes;
    expect(e4.san).toBe('e4');
    expect(e4.comments).toEqual(['King pawn']);
    expect(e4.shapes).toEqual([{ color: 'green', from: 12, to: 28 }]);
    const d4 = chapters[1].nodes.find(node => node.san === 'd4')!;
    expect(d4.comments).toEqual([]);
    expect(d4.shapes).toEqual([{ color: 'red', from: 27, to: 27 }]);
    const e5 = chapters[1].nodes.find(node => node.san === 'e5')!;
    expect(e5.comments).toEqual(['Open game']);
  });

  it('maps every imported line exactly once, including identical lines in different chapters', () => {
    const all = chapters.flatMap(chapter => chapter.lineIds);
    expect(all.sort()).toEqual(book.lines.map(line => line.id).sort());
    const byId = new Map(book.lines.map(line => [line.id, line.moves.join(' ')]));
    expect(chapters[2].lineIds.map(id => byId.get(id))).toEqual(['e4 e5 Nf3']);
    expect(chapters[1].lineIds.map(id => byId.get(id)).sort()).toEqual(['e4 c6 d4 d5', 'e4 e5 Nf3']);
  });

  it('selects the lines through a move and navigates paths and line ends', () => {
    const main = chapters[1];
    const e5 = main.nodes.find(node => node.san === 'e5')!;
    expect(e5.lineIds).toHaveLength(1);
    expect(main.nodes[1].lineIds).toHaveLength(2);
    expect(studyPath(main, e5.id).map(id => main.nodes[id].san)).toEqual(['e4', 'e5']);
    expect(main.nodes[lineEnd(main, 0)].san).toBe('d5');
    expect(main.nodes[lineEnd(main, e5.id)].san).toBe('Nf3');
  });
});
