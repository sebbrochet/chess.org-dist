import { describe, expect, it } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { addMove, addSan, automaticResult, createTree, deleteFrom, isMainline, mainline, makeMainline, promoteVariation, ROOT, treeFromPgn, treeToPgn, type GameTree } from './gameTree';
import { parseGames } from './pgn';

const play = (tree: GameTree, parent: number, ...ucis: string[]) => ucis.reduce((state, uci) => addMove(state.tree, state.id, uci), { tree, id: parent });
const sans = (tree: GameTree) => mainline(tree).map(id => tree.nodes[id].san);

describe('game tree', () => {
  it('adds moves, reuses existing ones and creates variations from the same position', () => {
    let { tree } = play(createTree(INITIAL_FEN), ROOT, 'e2e4', 'e7e5', 'g1f3');
    const e4 = tree.nodes[ROOT].children[0];
    const again = addMove(tree, e4, 'e7e5');
    expect(again.tree).toBe(tree);
    tree = play(tree, e4, 'c7c5', 'g1f3').tree;
    expect(sans(tree)).toEqual(['e4', 'e5', 'Nf3']);
    expect(tree.nodes[e4].children.map(id => tree.nodes[id].san)).toEqual(['e5', 'c5']);
    expect(() => addMove(tree, ROOT, 'e2e5')).toThrow('legal');
    expect(addSan(tree, ROOT, 'd4').tree.nodes[ROOT].children).toHaveLength(2);
    expect(() => addSan(tree, ROOT, 'Ke2')).toThrow('SAN');
  });

  it('promotes, makes main line and deletes from a move', () => {
    let { tree, id: nf3InSicilian } = play(createTree(INITIAL_FEN), ROOT, 'e2e4', 'e7e5');
    const e4 = tree.nodes[ROOT].children[0];
    ({ tree, id: nf3InSicilian } = play(tree, e4, 'c7c5', 'g1f3'));
    const d4 = play(tree, ROOT, 'd2d4');
    tree = play(d4.tree, d4.id, 'd7d5').tree;
    expect(isMainline(tree, nf3InSicilian)).toBe(false);
    const promoted = promoteVariation(tree, nf3InSicilian);
    expect(sans(promoted)).toEqual(['e4', 'c5', 'Nf3']);
    tree = makeMainline(tree, d4.id);
    expect(sans(tree)).toEqual(['d4', 'd5']);
    tree = deleteFrom(tree, e4);
    expect(Object.keys(tree.nodes)).toHaveLength(3);
    expect(deleteFrom(tree, ROOT)).toBe(tree);
  });

  it('writes and reads PGN with variations, comments, glyphs, markings and a set-up start', () => {
    const fen = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1';
    let { tree } = play(createTree(fen), ROOT, 'c7c6', 'd2d4');
    const id = mainline(tree)[1];
    const c6 = tree.nodes[ROOT].children[0];
    tree = play(tree, c6, 'g1f3').tree;
    tree = { ...tree, nodes: { ...tree.nodes, [id]: { ...tree.nodes[id], comment: 'Main', nag: 1, shapes: [{ color: 'green', from: 27, to: 35 }] }, [ROOT]: { ...tree.nodes[ROOT], comment: 'Intro' } } };
    const pgn = treeToPgn(tree, new Map([['White', 'Me']]), '*');
    expect(pgn).toContain('[FEN "' + fen + '"]');
    expect(pgn).toContain('{ Intro } 1... c6 2. d4 $1 { Main [%cal Gd4d5] } ( 2. Nf3 ) *');
    const [game] = parseGames(pgn);
    expect(game.moves).toEqual(['c6', 'd4']);
    const read = treeFromPgn(pgn);
    expect(read.headers.get('White')).toBe('Me');
    expect(treeToPgn(read.tree, read.headers, '*')).toBe(pgn);
  });

  it('sets the result when the main line ends in checkmate or stalemate', () => {
    const mate = play(createTree(INITIAL_FEN), ROOT, 'f2f3', 'e7e5', 'g2g4', 'd8h4').tree;
    expect(automaticResult(mate)).toBe('0-1');
    expect(automaticResult(createTree('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1'))).toBe('1/2-1/2');
    expect(automaticResult(createTree(INITIAL_FEN))).toBeUndefined();
  });
});
