import { describe, expect, it, vi } from 'vitest';
import { parseGames } from './pgn';
import { analyzeRecordedMove, analyzeReviewPosition, annotateMove, captureReviewSource, classifyWinningChanceLoss, engineUci, hasCompleteCoverage, hasValidPrefix, judgeMove, legalContinuation, REVIEW_BASIS, sufficientSearchEffort, terminalEvidence, type Review } from './review';
import { ENGINE_VERSION, type AnalysisRequest, type AnalysisResult, type EngineScore, type LocalEngine } from '../engine/stockfish';

const cp = (value: number): EngineScore => ({ kind: 'cp', value, perspective: 'white' });
const mate = (winner: 'white' | 'black', value = 2): EngineScore => ({ kind: 'mate', value, winner, perspective: 'white' });

describe('review judgments and evidence', () => {
  it('validates continuation-only coverage separately from full comparison and skips terminal searches', async () => {
    const source = captureReviewSource(parseGames('1.f3 e5 2.g4 Qh4# 0-1')[0]);
    const engine: LocalEngine = { cancelAll() {}, analyze: vi.fn() };
    const terminal = await analyzeReviewPosition(engine, source.positions[4], 'g', 1, new AbortController().signal);
    expect(engine.analyze).not.toHaveBeenCalled();
    const review: Review = { id: 'r', gameId: 'g', generation: 1, status: 'Interrupted', source, basis: REVIEW_BASIS, purpose: 'supplement', task: 'continuations', entries: [], continuations: [{ ply: 3, evidence: terminal }], createdAt: '2026-11-10', updatedAt: '2026-11-10' };
    expect(hasValidPrefix(review)).toBe(true); expect(hasCompleteCoverage(review)).toBe(false);
    expect(hasValidPrefix({ ...review, continuations: [{ ply: 2, evidence: terminal }] })).toBe(false);
  });
  it('classifies unrounded percentage-point losses at inclusive 5/10/15 boundaries', () => {
    for (const [loss, glyph] of [[-1, ''], [4.999999, ''], [5, '?!'], [9.999999, '?!'], [10, '?'], [14.999999, '?'], [15, '??'], [100, '??']] as const) {
      expect(classifyWinningChanceLoss(loss).glyph).toBe(glyph);
    }
  });
  it('uses position-sensitive child winning chances and preserves separate practice eligibility for both sides', () => {
    for (const mover of ['white', 'black'] as const) {
      const direction = mover === 'white' ? 1 : -1;
      expect(annotateMove(cp(0), cp(-100 * direction), mover)).toMatchObject({ glyph: '?!', label: 'Inaccuracy' });
      expect(annotateMove(cp(0), cp(-200 * direction), mover).glyph).toBe('??');
      expect(annotateMove(cp(1000 * direction), cp(700 * direction), mover).glyph).toBe('');
      expect(judgeMove(cp(1000 * direction), cp(700 * direction), mover).mistake).toBe(true);
      expect(annotateMove(cp(0), cp(100 * direction), mover).winPercentLoss).toBe(0);
    }
  });
  it('applies strict mate severity exceptions, terminal winners and no mate-delay penalty', () => {
    for (const mover of ['white', 'black'] as const) {
      const opponent = mover === 'white' ? 'black' : 'white';
      const direction = mover === 'white' ? 1 : -1;
      for (const [score, glyph] of [[700, '??'], [701, '?'], [999, '?'], [1000, '?!']] as const) {
        expect(annotateMove(mate(mover), cp(score * direction), mover)).toMatchObject({ glyph, mate: 'surrendered' });
        expect(annotateMove(cp(-score * direction), mate(opponent, 0), mover)).toMatchObject({ glyph, mate: 'avoidable' });
      }
      expect(annotateMove(mate(mover), mate(opponent, 0), mover)).toMatchObject({ glyph: '??', mate: 'surrendered' });
      expect(annotateMove(mate(mover, 1), mate(mover, 8), mover).glyph).toBe('');
      expect(annotateMove(mate(opponent), cp(-50 * direction), mover).glyph).toBe('');
      expect(annotateMove(cp(0), mate(mover, 0), mover).glyph).toBe('');
    }
  });
  it('accepts a legally verified mate PV longer than reported search depth without accepting incomplete evidence', () => {
    const result: AnalysisResult = {
      gameId: 'g', generation: 1, purpose: 'analysis', limits: REVIEW_BASIS.limits, jobId: 'verified-mate', engineVersion: ENGINE_VERSION,
      fen: '8/8/4p1p1/5p2/ppk1nP2/8/1K6/8 w - - 2 52',
      bestmove: 'b2c1', depth: 15, nodes: 11430, searchedNodes: 11430, score: mate('black', -10),
      pv: ['b2c1', 'c4c3', 'c1d1', 'b4b3', 'd1e2', 'a4a3', 'e2f1', 'a3a2', 'f1g2', 'b3b2', 'g2h3', 'a2a1q', 'h3g2', 'a1a5', 'g2h3', 'b2b1q', 'h3h2', 'a5a2', 'h2h3', 'b1h1'],
    };
    const line = legalContinuation(result.fen, result.pv);
    expect(terminalEvidence(line.at(-1)!.fen)?.score).toEqual(mate('black', 0));
    expect(sufficientSearchEffort(result, REVIEW_BASIS)).toBe(true);
    expect(sufficientSearchEffort({ ...result, pv: result.pv.slice(0, -1) }, REVIEW_BASIS)).toBe(false);
    expect(sufficientSearchEffort({ ...result, pv: ['b2b8'] }, REVIEW_BASIS)).toBe(false);
    expect(sufficientSearchEffort({ ...result, score: mate('white', 10) }, REVIEW_BASIS)).toBe(false);
    expect(sufficientSearchEffort({ ...result, score: cp(500) }, REVIEW_BASIS)).toBe(false);
    expect(sufficientSearchEffort({ ...result, depth: 0 }, REVIEW_BASIS)).toBe(false);
    expect(sufficientSearchEffort(result, { ...REVIEW_BASIS, limits: { depth: 20 } })).toBe(false);
  });
  it('uses mover-relative centipawns at the inclusive 100cp boundary', () => {
    expect(judgeMove(cp(120), cp(21), 'white')).toEqual({ lossCp: 99, mistake: false });
    expect(judgeMove(cp(120), cp(20), 'white')).toEqual({ lossCp: 100, mistake: true });
    expect(judgeMove(cp(-120), cp(-20), 'black')).toEqual({ lossCp: 100, mistake: true });
    expect(judgeMove(cp(0), cp(20), 'white').lossCp).toBe(0);
  });
  it('keeps surrendered, avoidable and retained mates separate from numeric losses', () => {
    expect(judgeMove(mate('white'), cp(500), 'white')).toEqual({ mistake: true, mate: 'surrendered' });
    expect(judgeMove(cp(-500), mate('white'), 'black')).toEqual({ mistake: true, mate: 'avoidable' });
    expect(judgeMove(mate('black', -2), mate('black', -1), 'white')).toEqual({ mistake: false, mate: 'retained' });
    expect(judgeMove(mate('white', 0), mate('white', 8), 'white')).toEqual({ mistake: false, mate: 'retained' });
  });
  it('recognizes checkmate zero with a winner and terminal draw without requesting a score', () => {
    const mated = parseGames('1.f3 e5 2.g4 Qh4# 0-1')[0];
    expect(terminalEvidence(mated.positions[4])?.score).toEqual(mate('black', 0));
    expect(terminalEvidence('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1')?.score).toEqual(cp(0));
    expect(terminalEvidence(mated.startFen)).toBeUndefined();
  });
  it('compares both children at equal limits, never ranks by the parent score', async () => {
    const source = captureReviewSource(parseGames('1.e4 *')[0]);
    const bestFen = legalContinuation(source.startFen, ['d2d4'])[0].fen;
    const analyze = vi.fn(async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request, jobId: 'job', engineVersion: ENGINE_VERSION,
      bestmove: request.fen === source.startFen ? 'd2d4' : 'e7e5', score: cp(request.fen === source.startFen ? 900 : request.fen === bestFen ? 120 : 20), depth: 8, nodes: 12000, pv: [] }));
    const entry = await analyzeRecordedMove({ analyze, cancelAll() {} }, source, 0, 'game', 3, new AbortController().signal);
    expect(entry.judgment).toEqual({ lossCp: 100, mistake: true });
    expect(analyze.mock.calls.map(([request]) => request.limits)).toEqual([REVIEW_BASIS.limits, REVIEW_BASIS.limits, REVIEW_BASIS.limits]);
    expect(analyze.mock.calls.map(([request]) => request.fen)).toEqual([source.startFen, bestFen, source.positions[1]]);
  });
  it('rejects missing scores, failures, cancellation and source mismatch instead of inventing zero', async () => {
    const source = captureReviewSource(parseGames('1.e4 *')[0]);
    const analyze = vi.fn(async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request, jobId: 'job', engineVersion: ENGINE_VERSION, bestmove: 'e2e4', depth: 8, nodes: 12000, pv: [] }));
    const engine: LocalEngine = { analyze, cancelAll() {} };
    await expect(analyzeRecordedMove(engine, source, 0, 'g', 1, new AbortController().signal)).rejects.toThrow('Insufficient');
    analyze.mockRejectedValueOnce(new Error('worker failed'));
    await expect(analyzeRecordedMove(engine, source, 0, 'g', 1, new AbortController().signal)).rejects.toThrow('worker failed');
    const controller = new AbortController(); controller.abort();
    await expect(analyzeRecordedMove(engine, source, 0, 'g', 1, controller.signal)).rejects.toMatchObject({ name: 'AbortError' });
  });
  it('uses exact terminal children without requiring a nonexistent engine score', async () => {
    const source = captureReviewSource(parseGames('[SetUp "1"]\n[FEN "7k/5Q2/6K1/8/8/8/8/8 w - - 0 1"]\n1.Qg7# 1-0')[0]);
    const analyze = vi.fn(async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request, jobId: 'job', engineVersion: ENGINE_VERSION,
      bestmove: 'f7g7', score: mate('white', 1), depth: 245, nodes: 7500, pv: ['f7g7'] }));
    const entry = await analyzeRecordedMove({ analyze, cancelAll() {} }, source, 0, 'g', 1, new AbortController().signal);
    expect(analyze).toHaveBeenCalledOnce();
    expect(entry.actualChild).toMatchObject({ kind: 'terminal', score: mate('white', 0) });
    expect(entry.judgment).toEqual({ mistake: false, mate: 'retained' });
    const result = await analyze({ gameId: 'g', generation: 1, fen: source.startFen, limits: REVIEW_BASIS.limits, purpose: 'analysis' });
    expect(sufficientSearchEffort(result, REVIEW_BASIS)).toBe(true);
    expect(sufficientSearchEffort({ ...result, score: cp(100) }, REVIEW_BASIS)).toBe(false);
    expect(sufficientSearchEffort({ ...result, score: mate('black') }, REVIEW_BASIS)).toBe(false);
    expect(sufficientSearchEffort({ ...result, pv: [] }, REVIEW_BASIS)).toBe(false);
  });
  it('uses standard UCI castling and legal SAN continuations, rejecting illegal PV and mismatched positions', async () => {
    const castle = parseGames('1.e4 e5 2.Nf3 Nc6 3.Bc4 Nf6 4.O-O *')[0];
    expect(engineUci(castle.positions[6], 'O-O')).toBe('e1g1');
    expect(legalContinuation(castle.positions[6], ['e1g1'])[0]).toMatchObject({ san: 'O-O', fen: castle.positions[7] });
    expect(() => legalContinuation(castle.startFen, ['e2e5'])).toThrow('illegal');
    const source = captureReviewSource(parseGames('1.e4 *')[0]);
    source.positions[1] = source.startFen;
    const analyze = async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request, jobId: 'job', engineVersion: ENGINE_VERSION,
      bestmove: 'e2e4', score: cp(0), depth: 8, nodes: 12000, pv: [] });
    await expect(analyzeRecordedMove({ analyze, cancelAll() {} }, source, 0, 'g', 1, new AbortController().signal)).rejects.toThrow('snapshot');
  });
  it('rejects stale tags, insufficient effort and illegal PV before retaining conclusions', async () => {
    const source = captureReviewSource(parseGames('1.e4 *')[0]);
    for (const override of [{ generation: 99 }, { gameId: 'other' }, { fen: source.positions[1] }, { nodes: 100 }, { depth: 0 }, { pv: ['e2e5'] }] satisfies Partial<AnalysisResult>[]) {
      const analyze = async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request, jobId: 'job', engineVersion: ENGINE_VERSION,
        bestmove: 'e2e4', score: cp(10), depth: 8, nodes: 12000, pv: ['e2e4'], ...override });
      await expect(analyzeRecordedMove({ analyze, cancelAll() {} }, source, 0, 'g', 1, new AbortController().signal)).rejects.toThrow();
    }
  });
  it('classifies a stalemate child as zero and surrender of the available mate', async () => {
    const source = captureReviewSource(parseGames('[SetUp "1"]\n[FEN "7k/5Q2/6K1/8/8/8/8/8 w - - 0 1"]\n1.Qe6 *')[0]);
    const analyze = vi.fn(async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request, jobId: 'job', engineVersion: ENGINE_VERSION,
      bestmove: 'f7g7', score: mate('white', 1), depth: 245, nodes: 7500, pv: ['f7g7'] }));
    const entry = await analyzeRecordedMove({ analyze, cancelAll() {} }, source, 0, 'g', 1, new AbortController().signal);
    expect(analyze).toHaveBeenCalledOnce();
    expect(entry.actualChild).toMatchObject({ kind: 'terminal', reason: 'draw', score: cp(0) });
    expect(entry.judgment).toEqual({ mistake: true, mate: 'surrendered' });
  });
});