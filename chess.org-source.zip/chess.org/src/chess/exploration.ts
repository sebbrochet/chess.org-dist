import { INITIAL_FEN } from 'chessops/fen';
import { positionFromFen } from './pgn';
import { legalContinuation } from './review';

export interface ExplorationNode { id: number; parent: number; uci: string; san: string; fen: string; children: number[] }
export interface Exploration { nodes: ExplorationNode[]; current: number; recent: Record<number, number> }

export function createExploration(fen: string): Exploration {
  positionFromFen(fen);
  return { nodes: [{ id: 0, parent: -1, uci: '', san: '', fen, children: [] }], current: 0, recent: {} };
}

export function selectExplorationNode(tree: Exploration, id: number): Exploration {
  const recent = { ...tree.recent };
  for (let at = id; tree.nodes[at].parent >= 0; at = tree.nodes[at].parent) recent[tree.nodes[at].parent] = at;
  return { ...tree, current: id, recent };
}

export function playExplorationMove(tree: Exploration, uci: string): Exploration {
  const from = tree.nodes[tree.current];
  const [move] = legalContinuation(from.fen, [uci]);
  const existing = from.children.find(id => tree.nodes[id].fen === move.fen);
  if (existing !== undefined) return selectExplorationNode(tree, existing);
  const id = tree.nodes.length;
  const nodes = tree.nodes.map(node => node.id === from.id ? { ...node, children: [...node.children, id] } : node);
  nodes.push({ id, parent: from.id, uci: move.uci, san: move.san, fen: move.fen, children: [] });
  return selectExplorationNode({ ...tree, nodes }, id);
}

export function nextExplorationNode(tree: Exploration, id = tree.current): number | undefined {
  const node = tree.nodes[id];
  return node.children.length ? tree.recent[id] ?? node.children[0] : undefined;
}

export function explorationLineEnd(tree: Exploration, id = tree.current): number {
  let at = id;
  for (let next = nextExplorationNode(tree, at); next !== undefined; next = nextExplorationNode(tree, at)) at = next;
  return at;
}

export function explorationPath(tree: Exploration, id = tree.current): number[] {
  const path: number[] = [];
  for (let at = id; at >= 0; at = tree.nodes[at].parent) path.unshift(at);
  return path;
}

export function explorationMoveLabel(tree: Exploration, id: number, numbered: boolean): string {
  const node = tree.nodes[id];
  const [, turn, , , , fullmove] = tree.nodes[node.parent].fen.split(' ');
  return turn === 'w' ? `${fullmove}. ${node.san}` : numbered ? `${fullmove}... ${node.san}` : node.san;
}

const header = (value: string) => value.replace(/[\\"]/g, '\\$&').replace(/[\r\n]+/g, ' ');
const comment = (value: string) => `{ ${value.replace(/[{}]/g, '').replace(/\s+/g, ' ').trim()} }`;

export function explorationPgn(tree: Exploration, name: string, annotate?: { intro?: string; move(node: ExplorationNode): string | undefined }): string {
  const root = tree.nodes[0];
  const headers = [`[Event "${header(name)}"]`, ...(root.fen === INITIAL_FEN ? [] : ['[SetUp "1"]', `[FEN "${root.fen}"]`])];
  const tokens: string[] = annotate?.intro ? [comment(annotate.intro)] : [];
  const emit = (id: number, numbered: boolean): boolean => {
    tokens.push(explorationMoveLabel(tree, id, numbered));
    const text = annotate?.move(tree.nodes[id]);
    if (text) tokens.push(comment(text));
    return !!text;
  };
  const line = (from: number, numbered: boolean) => {
    for (let at = from; tree.nodes[at].children.length;) {
      const [main, ...sides] = tree.nodes[at].children;
      const commented = emit(main, numbered);
      for (const side of sides) { tokens.push('('); line(side, emit(side, true)); tokens.push(')'); }
      numbered = commented || sides.length > 0;
      at = main;
    }
  };
  line(0, true);
  return `${headers.join('\n')}\n\n${tokens.join(' ').replace(/\( /g, '(').replace(/ \)/g, ')')} *\n`;
}
