import { INITIAL_FEN, makeFen } from 'chessops/fen';
import { ChildNode, Node, PgnParser, emptyHeaders, makeComment, makePgn, parseComment, type CommentShape, type Game, type PgnNodeData } from 'chessops/pgn';
import { makeSanAndPlay, parseSan } from 'chessops/san';
import { makeUci, parseUci } from 'chessops/util';
import { positionFromFen, type GameResult } from './pgn';

export interface TreeNode { id: number; parent: number; san: string; uci: string; fen: string; children: number[]; comment?: string; nag?: number; shapes?: CommentShape[] }
export interface GameTree { nodes: Record<number, TreeNode>; next: number }
export const ROOT = 0;

export function createTree(fen: string): GameTree {
  positionFromFen(fen);
  return { nodes: { [ROOT]: { id: ROOT, parent: -1, san: '', uci: '', fen, children: [] } }, next: 1 };
}

export function addMove(tree: GameTree, parentId: number, uci: string): { tree: GameTree; id: number } {
  const parent = tree.nodes[parentId];
  const position = positionFromFen(parent.fen);
  const move = parseUci(uci);
  if (!move || !position.isLegal(move)) throw new Error('Choose a legal move in this position.');
  const san = makeSanAndPlay(position, move);
  const fen = makeFen(position.toSetup());
  const existing = parent.children.find(id => tree.nodes[id].fen === fen);
  if (existing !== undefined) return { tree, id: existing };
  const id = tree.next;
  return { tree: { next: id + 1, nodes: { ...tree.nodes, [parentId]: { ...parent, children: [...parent.children, id] }, [id]: { id, parent: parentId, san, uci: makeUci(move), fen, children: [] } } }, id };
}

export function addSan(tree: GameTree, parentId: number, san: string): { tree: GameTree; id: number } {
  const position = positionFromFen(tree.nodes[parentId].fen);
  const move = parseSan(position, san.trim());
  if (!move) throw new Error('Enter a legal SAN move for this position.');
  return addMove(tree, parentId, makeUci(move));
}

export function deleteFrom(tree: GameTree, id: number): GameTree {
  if (id === ROOT) return tree;
  const nodes = { ...tree.nodes };
  const remove = (at: number) => { for (const child of nodes[at].children) remove(child); delete nodes[at]; };
  const parent = nodes[tree.nodes[id].parent];
  remove(id);
  nodes[parent.id] = { ...parent, children: parent.children.filter(child => child !== id) };
  return { ...tree, nodes };
}

function branchPoint(tree: GameTree, id: number): number | undefined {
  for (let at = id; at !== ROOT; at = tree.nodes[at].parent) if (tree.nodes[tree.nodes[at].parent].children[0] !== at) return at;
}

export const isMainline = (tree: GameTree, id: number) => branchPoint(tree, id) === undefined;

export function promoteVariation(tree: GameTree, id: number): GameTree {
  const at = branchPoint(tree, id);
  if (at === undefined) return tree;
  const parent = tree.nodes[tree.nodes[at].parent];
  return { ...tree, nodes: { ...tree.nodes, [parent.id]: { ...parent, children: [at, ...parent.children.filter(child => child !== at)] } } };
}

export function makeMainline(tree: GameTree, id: number): GameTree {
  let next = tree;
  while (!isMainline(next, id)) next = promoteVariation(next, id);
  return next;
}

export function mainline(tree: GameTree, from = ROOT): number[] {
  const ids: number[] = [];
  for (let at = tree.nodes[from].children[0]; at !== undefined; at = tree.nodes[at].children[0]) ids.push(at);
  return ids;
}

export function pathTo(tree: GameTree, id: number): number[] {
  const path: number[] = [];
  for (let at = id; at !== ROOT; at = tree.nodes[at].parent) path.unshift(at);
  return path;
}

export function moveLabel(tree: GameTree, id: number, numbered: boolean): string {
  const node = tree.nodes[id];
  const [, turn, , , , fullmove] = tree.nodes[node.parent].fen.split(' ');
  return turn === 'w' ? `${fullmove}. ${node.san}` : numbered ? `${fullmove}... ${node.san}` : node.san;
}

export function automaticResult(tree: GameTree): GameResult | undefined {
  const line = mainline(tree);
  const position = positionFromFen(tree.nodes[line.at(-1) ?? ROOT].fen);
  if (position.isCheckmate()) return position.turn === 'white' ? '0-1' : '1-0';
  if (position.isStalemate()) return '1/2-1/2';
}

const NAGS: Record<number, string> = { 1: '!', 2: '?', 3: '!!', 4: '??', 5: '!?', 6: '?!' };
export const GLYPHS = NAGS;

function readComments(comments: string[] | undefined): { comment?: string; shapes?: CommentShape[] } {
  if (!comments?.length) return {};
  const parsed = comments.map(text => parseComment(text));
  const comment = parsed.map(item => item.text.trim()).filter(Boolean).join(' ');
  const shapes = parsed.flatMap(item => item.shapes);
  return { ...(comment ? { comment } : {}), ...(shapes.length ? { shapes } : {}) };
}

export function treeFromPgn(pgn: string): { tree: GameTree; headers: Map<string, string> } {
  const games: Game<PgnNodeData>[] = [];
  new PgnParser(game => games.push(game), emptyHeaders).parse(pgn);
  if (games.length !== 1) throw new Error('A single game is required.');
  const game = games[0];
  const start = game.headers.get('FEN') ?? INITIAL_FEN;
  let tree = createTree(start);
  tree = { ...tree, nodes: { ...tree.nodes, [ROOT]: { ...tree.nodes[ROOT], ...readComments(game.comments) } } };
  const visit = (source: Node<PgnNodeData>, parentId: number) => {
    for (const child of source.children) {
      const position = positionFromFen(tree.nodes[parentId].fen);
      const move = parseSan(position, child.data.san);
      if (!move) throw new Error(`Illegal move ${child.data.san}.`);
      const added = addMove(tree, parentId, makeUci(move));
      const nag = child.data.nags?.find(value => NAGS[value]);
      tree = { ...added.tree, nodes: { ...added.tree.nodes, [added.id]: { ...added.tree.nodes[added.id], ...readComments(child.data.comments), ...(nag ? { nag } : {}) } } };
      visit(child, added.id);
    }
  };
  visit(game.moves, ROOT);
  return { tree, headers: game.headers };
}

const writeComments = (node: TreeNode) => node.comment || node.shapes?.length ? [makeComment({ text: node.comment, shapes: node.shapes })] : undefined;

export function treeToPgn(tree: GameTree, headers: Map<string, string>, result: GameResult): string {
  const start = tree.nodes[ROOT].fen;
  const out = new Map([...headers].filter(([key]) => !['Result', 'SetUp', 'FEN'].includes(key)));
  if (start !== INITIAL_FEN) { out.set('SetUp', '1'); out.set('FEN', start); }
  out.set('Result', result);
  const build = (id: number, target: Node<PgnNodeData>) => {
    for (const childId of tree.nodes[id].children) {
      const node = tree.nodes[childId];
      const child = new ChildNode<PgnNodeData>({ san: node.san, comments: writeComments(node), nags: node.nag ? [node.nag] : undefined });
      target.children.push(child);
      build(childId, child);
    }
  };
  const moves = new Node<PgnNodeData>();
  build(ROOT, moves);
  return makePgn({ headers: out, comments: writeComments(tree.nodes[ROOT]), moves });
}
