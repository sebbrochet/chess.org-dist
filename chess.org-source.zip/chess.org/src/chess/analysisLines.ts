import { makeFen } from 'chessops/fen';
import { ChildNode, Node, PgnParser, emptyHeaders, makePgn, type Game, type PgnNodeData } from 'chessops/pgn';
import { makeSanAndPlay, parseSan } from 'chessops/san';
import { makeUci, parseUci } from 'chessops/util';
import { addMove, createTree, mainline, ROOT, treeFromPgn, type GameTree } from './gameTree';
import { positionFromFen } from './pgn';

export interface LineMove { uci: string; children: LineMove[] }
export interface AnalysisBranch { ply: number; fen: string; moves: LineMove[] }
export interface AnalysisLines { id: string; gameId: string; branches: AnalysisBranch[] }
type Recorded = { positions: readonly string[]; moves: readonly string[] };

export function recordedUci(game: Recorded, ply: number): string | undefined {
  if (ply >= game.moves.length) return undefined;
  const move = parseSan(positionFromFen(game.positions[ply]), game.moves[ply]);
  return move && makeUci(move);
}

export function branchTree(branch: AnalysisBranch): GameTree {
  let tree = createTree(branch.fen);
  const visit = (moves: LineMove[], parent: number) => {
    for (const move of moves) {
      const added = addMove(tree, parent, move.uci);
      if (added.tree === tree) throw new Error('Duplicate analysis move.');
      tree = added.tree;
      visit(move.children, added.id);
    }
  };
  visit(branch.moves, ROOT);
  return tree;
}

export function branchFromTree(ply: number, tree: GameTree): AnalysisBranch {
  const moves = (id: number): LineMove[] => tree.nodes[id].children.map(child => ({ uci: tree.nodes[child].uci, children: moves(child) }));
  return { ply, fen: tree.nodes[ROOT].fen, moves: moves(ROOT) };
}

/** Throws unless every branch starts from its recorded position, is legal and never repeats the recorded move. */
export function validBranches(game: Recorded, branches: AnalysisBranch[]): AnalysisBranch[] {
  const plies = new Set<number>();
  return branches.map(branch => {
    if (!Number.isInteger(branch.ply) || branch.ply < 0 || branch.ply >= game.moves.length || plies.has(branch.ply)) throw new Error('Analysis line position is invalid.');
    if (branch.fen !== game.positions[branch.ply]) throw new Error('Analysis line no longer matches the recorded game.');
    if (!branch.moves.length) throw new Error('Analysis line is empty.');
    const recorded = recordedUci(game, branch.ply);
    if (branch.moves.some(move => move.uci === recorded)) throw new Error('Analysis line repeats the recorded move.');
    plies.add(branch.ply);
    return branchFromTree(branch.ply, branchTree(branch));
  });
}

/** Side lines supplied by the game's PGN, keyed by the ply they branch from. */
export function importedBranches(pgn: string): Record<number, GameTree> {
  const { tree: source } = treeFromPgn(pgn);
  const line = [ROOT, ...mainline(source)];
  const result: Record<number, GameTree> = {};
  line.forEach((at, ply) => {
    const alternatives = source.nodes[at].children.slice(1);
    if (!alternatives.length) return;
    let tree = createTree(source.nodes[at].fen);
    const copy = (from: number, to: number) => { for (const child of source.nodes[from].children) { const added = addMove(tree, to, source.nodes[child].uci); tree = added.tree; copy(child, added.id); } };
    for (const alternative of alternatives) { const added = addMove(tree, ROOT, source.nodes[alternative].uci); tree = added.tree; copy(alternative, added.id); }
    result[ply] = tree;
  });
  return result;
}

export function mergeIntoTree(tree: GameTree, branches: AnalysisBranch[]): GameTree {
  const line = [ROOT, ...mainline(tree)];
  let next = tree;
  const visit = (moves: LineMove[], parent: number) => { for (const move of moves) { const added = addMove(next, parent, move.uci); next = added.tree; visit(move.children, added.id); } };
  for (const branch of branches) if (line[branch.ply] !== undefined && next.nodes[line[branch.ply]].fen === branch.fen) visit(branch.moves, line[branch.ply]);
  return next;
}

/** Adds the Player's lines as PGN variations after the original content, keeping everything else verbatim. */
export function mergeIntoPgn(pgn: string, branches: AnalysisBranch[]): string {
  if (!branches.length) return pgn;
  const games: Game<PgnNodeData>[] = [];
  new PgnParser(game => games.push(game), emptyHeaders).parse(pgn);
  const game = games[0];
  const parents: Node<PgnNodeData>[] = [game.moves];
  for (let at: Node<PgnNodeData> | undefined = game.moves.children[0]; at; at = at.children[0]) parents.push(at);
  const append = (target: Node<PgnNodeData>, fen: string, moves: LineMove[]) => {
    for (const move of moves) {
      const position = positionFromFen(fen);
      const san = makeSanAndPlay(position, parseUci(move.uci)!);
      let child = target.children.find(existing => existing.data.san === san);
      if (!child) { child = new ChildNode<PgnNodeData>({ san }); target.children.push(child); }
      append(child, makeFen(position.toSetup()), move.children);
    }
  };
  for (const branch of branches) if (parents[branch.ply]) append(parents[branch.ply], branch.fen, branch.moves);
  return makePgn(game);
}

