import { describe, expect, it } from 'vitest';
import { parseGames } from './pgn';
import { branchFromTree, branchTree, importedBranches, mergeIntoPgn, mergeIntoTree, validBranches, type AnalysisBranch } from './analysisLines';
import { addMove, mainline, ROOT, treeFromPgn } from './gameTree';

const [game] = parseGames('[Event "Club"]\n1.e4 { [%eval 0.3] Main comment } e5 2.Nf3 *');
const afterE4: AnalysisBranch = { ply: 1, fen: game.positions[1], moves: [{ uci: 'c7c5', children: [{ uci: 'g1f3', children: [] }, { uci: 'b1c3', children: [] }] }] };

describe('analysis lines', () => {
  it('round-trips a branch through its tree and keeps variation order', () => {
    const tree = branchTree(afterE4);
    expect(branchFromTree(1, tree)).toEqual(afterE4);
    const extended = addMove(tree, ROOT, 'e7e6').tree;
    expect(branchFromTree(1, extended).moves.map(move => move.uci)).toEqual(['c7c5', 'e7e6']);
  });

  it('rejects stale, illegal, empty or recorded-move branches', () => {
    expect(validBranches(game, [afterE4])).toEqual([afterE4]);
    expect(() => validBranches(game, [{ ...afterE4, fen: game.positions[0] }])).toThrow('no longer matches');
    expect(() => validBranches(game, [{ ...afterE4, moves: [{ uci: 'e7e5', children: [] }] }])).toThrow('repeats the recorded move');
    expect(() => validBranches(game, [{ ...afterE4, moves: [{ uci: 'e2e4', children: [] }] }])).toThrow();
    expect(() => validBranches(game, [{ ...afterE4, moves: [] }])).toThrow('empty');
    expect(() => validBranches(game, [{ ...afterE4, ply: 3, fen: game.positions[3] }])).toThrow('position is invalid');
    expect(() => validBranches(game, [afterE4, afterE4])).toThrow('position is invalid');
  });

  it('reads imported side lines by branch ply', () => {
    const trees = importedBranches('1.e4 (1.d4 d5) e5 (1...c5 2.Nf3) *');
    expect(Object.keys(trees)).toEqual(['0', '1']);
    expect(mainline(trees[0]).map(id => trees[0].nodes[id].san)).toEqual(['d4', 'd5']);
    expect(mainline(trees[1]).map(id => trees[1].nodes[id].san)).toEqual(['c5', 'Nf3']);
  });

  it('adds lines to PGN as variations after the original content without losing comments', () => {
    const pgn = mergeIntoPgn(game.pgn, [afterE4]);
    expect(pgn).toContain('[%eval 0.3]');
    expect(pgn).toContain('Main comment');
    expect(pgn.replace(/\s+/g, ' ')).toContain('} e5 ( 1... c5 2. Nf3 ( 2. Nc3 ) ) 2. Nf3');
    expect(parseGames(pgn)[0].moves).toEqual(game.moves);
    expect(mergeIntoPgn(game.pgn, [])).toBe(game.pgn);
  });

  it('merges lines into an editable tree as ordinary variations', () => {
    const { tree } = treeFromPgn(game.pgn);
    const merged = mergeIntoTree(tree, [afterE4]);
    const e4 = mainline(merged)[0];
    expect(merged.nodes[e4].children.map(id => merged.nodes[id].san)).toEqual(['e5', 'c5']);
  });
});
