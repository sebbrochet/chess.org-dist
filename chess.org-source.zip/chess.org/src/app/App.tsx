import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowDownToLine, ArrowUpFromLine, Check, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Copy, FilePlus2, FlipVertical2, FolderOpen, Pencil, Plus, Search, Trash2, Volume2, VolumeX, Settings2 } from 'lucide-react';
import { INITIAL_FEN } from 'chessops/fen';
import { Board } from '../components/Board';
import { MovePreviewProvider, PreviewableMove } from '../components/MovePreview';
import { Modal } from '../components/Modal';
import { EventLine, PlayerBar } from '../components/PlayerBar';
import { AppearancePanel } from '../components/AppearancePanel';
import { applyAppearance, readAppearance, saveAppearance } from '../utils/appearance';
import { DETAIL_FIELDS, MAX_PGN_LENGTH, exportGames, lastRecordedMove, nextRecordedPly, parseGames, type GameDetails, type ParsedGame } from '../chess/pgn';
import { createLibrary, emptySnapshot, type DomainSnapshot, type RetainedGame } from '../storage/library';
import { mergeIntoPgn } from '../chess/analysisLines';
import { PlayComputer } from '../features/play/PlayComputer';
import { isComputerGame } from '../chess/play';
import { GameReview } from '../features/review/GameReview';
import { Training } from '../features/training/Training';
import { Progress } from '../features/training/Progress';
import { Repertoires } from '../features/repertoires/Repertoires';
import { LearnRepertoire } from '../features/repertoires/LearnRepertoire';
import { Puzzles } from '../features/puzzles/Puzzles';
import { OnlineGames } from '../features/services/OnlineGames';
import { OpeningExplorer } from '../features/services/OpeningExplorer';
import { Backup } from '../features/backup/Backup';
import { GameEditor } from '../features/games/GameEditor';
import { moveSoundsEnabled, setMoveSoundsEnabled } from '../utils/moveSound';

const defaultLibrary = createLibrary();
const message = (error: unknown) => error instanceof Error ? error.message : 'The operation failed. Existing games have not been changed.';
const display = (value: string | undefined, fallback: string) => value && value !== '?' ? value : fallback;
export const gameTitle = (game: ParsedGame) => game.headers.Title || `${display(game.headers.White, 'Unknown White')} - ${display(game.headers.Black, 'Unknown Black')}`;

function Tool({ label, children, ...props }: { label: string; children: ReactNode } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button type="button" className="icon" title={label} aria-label={label} {...props}>{children}</button>;
}

export function App({ library = defaultLibrary }: { library?: ReturnType<typeof createLibrary> }) {
  const [snapshot, setSnapshot] = useState<DomainSnapshot>(emptySnapshot);
  const [route, setRoute] = useState(window.location.hash);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');
  const [shell, setShell] = useState(import.meta.env.DEV ? 'Development' : 'Shell caching');
  const [selectedId, setSelectedId] = useState('');
  const [exportIds, setExportIds] = useState<Set<string>>(new Set());
  const [exportLines, setExportLines] = useState(false);
  const [search, setSearch] = useState('');
  const [ply, setPly] = useState(0);
  const [orientation, setOrientation] = useState<'white' | 'black'>('white');
  const [soundEnabled, setSoundEnabled] = useState(moveSoundsEnabled);
  const [san, setSan] = useState('');
  const [modal, setModal] = useState<'import' | 'edit' | 'delete' | 'appearance' | null>(null);
  const [appearance, setAppearance] = useState(readAppearance);
  const [source, setSource] = useState('');
  const [preview, setPreview] = useState<ParsedGame[]>([]);
  const [chosen, setChosen] = useState<Set<number>>(new Set());
  const [details, setDetails] = useState<GameDetails>({});
  const [loadVersion, setLoadVersion] = useState(0);
  const operationLock = useRef(false);
  const importButton = useRef<HTMLButtonElement>(null);
  const fileVersion = useRef(0);
  const pendingReview = useRef<{ gameId: string; requestId: string }>();
  const game = snapshot.games.find(candidate => candidate.id === selectedId) ?? snapshot.games[0];
  const cursor = Math.min(ply, game?.moves.length ?? 0);
  const fen = game?.positions[cursor] ?? INITIAL_FEN;
  const playing = route.startsWith('#/play');
  const playId = route.split('/')[2];
  const reviewing = route === '#/review' || /^#\/games\/[^/]+\/review$/.test(route);
  const reviewId = reviewing && route.startsWith('#/games/') ? route.split('/')[2] : undefined;
  const reviewTargetId = playing && snapshot.games.some(record => record.id === playId) ? playId : game?.id;
  const reviewRequest = pendingReview.current?.gameId === reviewId ? pendingReview.current?.requestId : undefined;
  function requestPostGameReview(gameId: string) {
    pendingReview.current = { gameId, requestId: crypto.randomUUID() };
    window.location.hash = `/games/${gameId}/review`;
  }
  function consumeReviewRequest(requestId: string) { if (pendingReview.current?.requestId === requestId) pendingReview.current = undefined; }
  const practiceHandoff = route.startsWith('#/practice/');
  const progressView = route === '#/progress';
  const repertoireView = route.startsWith('#/repertoires') || route.startsWith('#/practice/repertoire/') || route.startsWith('#/learn/repertoire/');
  const puzzleView = route === '#/puzzles';
  const onlineView = route === '#/online';
  const openingsView = route === '#/openings';
  const backupView = route === '#/backup';
  const editorView = /^#\/games\/(new|[^/]+\/edit)$/.test(route);
  useEffect(() => { applyAppearance(appearance); }, [appearance]);

  useEffect(() => { if (playId) { setSelectedId(playId); setPly(0); } }, [playId]);
  useEffect(() => {
    const changed = () => {
      if (pendingReview.current && window.location.hash !== `#/games/${pendingReview.current.gameId}/review`) pendingReview.current = undefined;
      setRoute(window.location.hash); setError('');
    };
    window.addEventListener('hashchange', changed);
    return () => window.removeEventListener('hashchange', changed);
  }, []);

  useEffect(() => {
    let active = true;
    setReady(false);
    library.load().then(value => {
      if (active) { setSnapshot(value); setReady(true); setError(''); }
    }).catch(reason => { if (active) setError(`Library unavailable: ${message(reason)}`); });
    return () => { active = false; };
  }, [library, loadVersion]);

  useEffect(() => {
    const ready = () => setShell('Offline shell ready');
    const failed = () => setShell('Offline shell unavailable');
    window.addEventListener('shell-ready', ready);
    window.addEventListener('shell-failed', failed);
    if (import.meta.env.PROD && 'serviceWorker' in navigator) {
      void navigator.serviceWorker.ready.then(ready);
    }
    return () => { window.removeEventListener('shell-ready', ready); window.removeEventListener('shell-failed', failed); };
  }, []);

  async function commit(operation: () => Promise<DomainSnapshot>, success: string, after?: (value: DomainSnapshot) => void) {
    if (operationLock.current) return;
    operationLock.current = true;
    setBusy(true); setError(''); setStatus('');
    try {
      const next = await operation();
      setSnapshot(next);
      after?.(next);
      setStatus(success);
      setModal(null);
    } catch (reason) { setError(`Not saved: ${message(reason)}`); }
    finally { setBusy(false); operationLock.current = false; }
  }

  function openModal(value: 'import' | 'edit' | 'delete') {
    setError(''); setStatus('');
    if (value === 'edit' && game) setDetails(Object.fromEntries(DETAIL_FIELDS.map(field => [field, game.headers[field] ?? ''])));
    setModal(value);
  }

  function closeModal() {
    fileVersion.current++;
    setModal(null); setError('');
  }

  function updateSource(value: string) {
    setSource(value); setPreview([]); setChosen(new Set()); setError('');
  }

  async function readFile(file: File | undefined) {
    if (!file) return;
    const version = ++fileVersion.current;
    try {
      if (file.size > MAX_PGN_LENGTH) throw new Error('PGN exceeds the 2 MB import limit.');
      const text = await file.text();
      if (version === fileVersion.current) updateSource(text);
    } catch (reason) { if (version === fileVersion.current) { setPreview([]); setError(message(reason)); } }
  }

  function validateImport(event: FormEvent) {
    event.preventDefault(); setError('');
    try {
      const parsed = parseGames(source);
      setPreview(parsed); setChosen(new Set(parsed.map((_, index) => index)));
    } catch (reason) { setPreview([]); setError(message(reason)); }
  }

  function select(game: RetainedGame) { setSelectedId(game.id); setPly(0); setSan(''); setError(''); }
  function moveTo(value: number) { setPly(Math.max(0, Math.min(value, game?.moves.length ?? 0))); setError(''); }

  function download() {
    try {
      const chosen = snapshot.games.filter(record => exportIds.has(record.id));
      const text = exportGames(exportLines ? chosen.map(record => ({ ...record, pgn: mergeIntoPgn(record.pgn, snapshot.analysisLines.find(lines => lines.gameId === record.id)?.branches ?? []) })) : chosen);
      const url = URL.createObjectURL(new Blob([text], { type: 'application/x-chess-pgn;charset=utf-8' }));
      const link = document.createElement('a');
      link.href = url; link.download = 'chess-org-games.pgn'; link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setStatus('PGN file prepared.'); setError('');
    } catch (reason) { setError(message(reason)); }
  }

  const visibleGames = snapshot.games.filter(record => `${gameTitle(record)} ${record.headers.Event} ${record.headers.Date} ${record.result}`.toLowerCase().includes(search.toLowerCase()));
  const outcome = game?.result === '*' ? 'Unfinished' : game?.result;
  const errorBlock = error ? <p className="error" role="alert">{error}</p> : null;

  return <>
    <header className="app-header">
      <a className="brand" href="#/" aria-label="chess.org Games"><span className="brand-mark" aria-hidden="true">c.</span>chess.org</a>
      <nav className="app-nav" aria-label="Main"><a href="#/" aria-current={!playing && !reviewing && !practiceHandoff && !progressView && !repertoireView && !puzzleView && !onlineView && !openingsView && !backupView ? 'page' : undefined}>Games</a><a href="#/play" aria-current={playing ? 'page' : undefined}>Play Computer</a><a href={reviewTargetId ? `#/games/${reviewTargetId}/review` : '#/review'} aria-current={reviewing ? 'page' : undefined}>Review</a><a href="#/practice/mistakes" aria-current={practiceHandoff && !repertoireView ? 'page' : undefined}>Trainer</a><a href="#/repertoires" aria-current={repertoireView ? 'page' : undefined}>Repertoires</a><a href="#/puzzles" aria-current={puzzleView ? 'page' : undefined}>Puzzles</a><a href="#/online" aria-current={onlineView ? 'page' : undefined}>Public games</a><a href="#/openings" aria-current={openingsView ? 'page' : undefined}>Openings</a><a href="#/progress" aria-current={progressView ? 'page' : undefined}>Progress</a><a href="#/backup" aria-current={backupView ? 'page' : undefined}>Backup</a></nav>
      <span className="storage-state">{busy ? 'Saving...' : ready ? 'Local library' : 'Opening library...'}</span>
      <button type="button" className="icon" title="Board appearance" aria-label="Board appearance" disabled={busy || !!modal} onClick={() => setModal('appearance')}><Settings2 size={19} /></button>
      <button type="button" className="icon" title={soundEnabled ? 'Mute move sounds' : 'Enable move sounds'} aria-label={soundEnabled ? 'Mute move sounds' : 'Enable move sounds'} aria-pressed={soundEnabled} onClick={() => { const next = !soundEnabled; setMoveSoundsEnabled(next); setSoundEnabled(next); }}>{soundEnabled ? <Volume2 size={19} /> : <VolumeX size={19} />}</button>
      <button ref={importButton} type="button" className="primary" disabled={!ready || busy} onClick={() => openModal('import')}><FilePlus2 size={17} />Import PGN</button>
    </header>
    <div className="notification" aria-live="polite" role="status">{status}</div>
    {!modal && errorBlock}
    {!ready && error && <button className="retry" onClick={() => setLoadVersion(value => value + 1)}>Retry opening library</button>}
    {backupView ? ready && <Backup library={library} snapshot={snapshot} onSnapshot={setSnapshot} /> : editorView ? ready && <GameEditor key={route} library={library} snapshot={snapshot} onSnapshot={setSnapshot} route={route} /> : onlineView ? ready && <OnlineGames library={library} snapshot={snapshot} onSnapshot={setSnapshot} /> : openingsView ? <OpeningExplorer initialFen={fen} library={library} onSnapshot={setSnapshot} ready={ready} /> : puzzleView ? ready && <Puzzles library={library} snapshot={snapshot} onSnapshot={setSnapshot} /> : repertoireView ? ready && (route.startsWith('#/learn/repertoire/') ? <LearnRepertoire key={route} snapshot={snapshot} route={route} /> : <Repertoires key={route} library={library} snapshot={snapshot} onSnapshot={setSnapshot} route={route} />) : progressView ? ready && <Progress library={library} snapshot={snapshot} onSnapshot={setSnapshot} /> : practiceHandoff ? ready && <Training key={route} library={library} snapshot={snapshot} onSnapshot={setSnapshot} route={route} /> : reviewing ? ready && <GameReview key={reviewId ?? 'picker'} library={library} snapshot={snapshot} onSnapshot={setSnapshot} gameId={reviewId} reviewRequest={reviewRequest} onReviewRequestConsumed={consumeReviewRequest} /> : playing ? ready && <PlayComputer key={playId ?? 'new'} library={library} snapshot={snapshot} onSnapshot={setSnapshot} gameId={playId} selectedFen={fen} onReview={requestPostGameReview} /> : <main className="workspace" aria-busy={busy}>
      <section className="replay" aria-label="Game replay">
        {game && <EventLine headers={game.headers} />}
        {game ? <PlayerBar headers={game.headers} result={game.result} side={orientation === 'white' ? 'black' : 'white'} /> : <div className="player-line"><strong>Black</strong></div>}
        <div tabIndex={0} className="board-keyboard" aria-label="Board replay" onKeyDown={event => {
          if (!game) return;
          if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {
            event.preventDefault();
            moveTo(event.key === 'Home' ? 0 : event.key === 'End' ? game.moves.length : cursor + (event.key === 'ArrowRight' ? 1 : -1));
          }
        }}><Board fen={fen} orientation={orientation} lastMove={game ? lastRecordedMove(game, cursor) : undefined} /></div>
        {game ? <PlayerBar headers={game.headers} result={game.result} side={orientation}>{game.headers.TimeControl ? `Time control: ${game.headers.TimeControl}` : 'Time control unknown'}</PlayerBar> : <div className="player-line"><strong>White</strong></div>}
        <div className="replay-toolbar">
          <Tool label="First position" disabled={!game || cursor === 0} onClick={() => moveTo(0)}><ChevronsLeft /></Tool>
          <Tool label="Previous move" disabled={!game || cursor === 0} onClick={() => moveTo(cursor - 1)}><ChevronLeft /></Tool>
          <output aria-label="Replay position">{game ? `${cursor} / ${game.moves.length}` : '0 / 0'}</output>
          <Tool label="Next move" disabled={!game || cursor === game.moves.length} onClick={() => moveTo(cursor + 1)}><ChevronRight /></Tool>
          <Tool label="Last position" disabled={!game || cursor === game.moves.length} onClick={() => moveTo(game.moves.length)}><ChevronsRight /></Tool>
          <Tool label="Flip board" onClick={() => setOrientation(value => value === 'white' ? 'black' : 'white')}><FlipVertical2 size={19} /></Tool>
        </div>
        <form className="san-entry" onSubmit={event => {
          event.preventDefault();
          if (!game) return;
          try { setPly(nextRecordedPly(game, cursor, san)); setSan(''); setError(''); }
          catch (reason) { setError(message(reason)); }
        }}>
          <label htmlFor="san">Recorded SAN</label><input id="san" autoComplete="off" spellCheck={false} value={san} disabled={!game || cursor === game.moves.length} onChange={event => setSan(event.target.value)} />
          <Tool label="Replay SAN" disabled={!game || !san.trim() || cursor === game.moves.length} type="submit"><ChevronRight size={20} /></Tool>
        </form>
        <details className="fen"><summary>Position (FEN)</summary><code>{fen}</code></details>
      </section>

      <section className="game-panel" aria-label="Selected game">
        <header className="panel-heading"><div><span className="eyebrow">Recorded game</span><h1>{game ? gameTitle(game) : 'No game selected'}</h1></div>
          <div className="tools"><Tool label="Edit game details" disabled={!game || busy} onClick={() => openModal('edit')}><Pencil size={18} /></Tool><Tool label="Delete game" disabled={!game || busy} onClick={() => openModal('delete')}><Trash2 size={18} /></Tool></div>
        </header>
        {game ? <>
          <dl className="game-facts"><div><dt>Event</dt><dd>{display(game.headers.Event, 'Unknown event')}</dd></div><div><dt>Date</dt><dd>{display(game.headers.Date, 'Unknown date')}</dd></div><div><dt>Result</dt><dd>{outcome}{game.computer?.reason ? ` / ${game.computer.reason}` : ''}</dd></div><div><dt>Source</dt><dd>{game.source.kind === 'computer' ? 'Computer' : game.source.kind === 'online' ? `${game.source.provider} / ${game.source.originalId}` : game.source.kind === 'board' ? `Created on board${game.source.copiedFrom ? ` (copy of ${game.source.copiedFrom})` : ''}` : 'PGN'}</dd></div></dl>
          {game.source.kind === 'board' && <a className="resume-link" href={`#/games/${game.id}/edit`}>Edit moves</a>}
          <button type="button" className="resume-link" disabled={busy} onClick={() => { const id = crypto.randomUUID(); void commit(() => library.copyToEditable(game.id, id), 'Editable copy created.', () => { window.location.hash = `/games/${id}/edit`; }); }}><Copy size={16} />Copy to editable game</button>
          {isComputerGame(game) && game.result === '*' && <a className="resume-link" href={`#/play/${game.id}`}>Resume game</a>}
          <a className="resume-link review-link" href={`#/games/${game.id}/review`}>Review game</a>
          <a className="resume-link" href={`#/practice/guess/${game.id}`}>Guess the Move</a>
          <MovePreviewProvider key={`${game.id}:${game.pgn}`} orientation={orientation}><div className="moves" aria-label="Recorded moves"><button className={cursor === 0 ? 'current' : ''} aria-current={cursor === 0 ? 'step' : undefined} onClick={() => moveTo(0)}>Start</button>{game.moves.map((move, index) => {
            const fields = game.startFen.split(' ');
            const absolutePly = (Number(fields[5]) - 1) * 2 + (fields[1] === 'b' ? 1 : 0) + index;
            const label = `${Math.floor(absolutePly / 2) + 1}${absolutePly % 2 ? '...' : '.'} ${move}`;
            return <PreviewableMove key={index} fen={game.positions[index + 1]} label={label} move={lastRecordedMove(game, index + 1)}><button aria-label={`Replay ${Math.floor(absolutePly / 2) + 1}${absolutePly % 2 ? ' black' : ' white'} ${move}`} aria-current={cursor === index + 1 ? 'step' : undefined} className={cursor === index + 1 ? 'current' : ''} onClick={() => moveTo(index + 1)}><span>{Math.floor(absolutePly / 2) + 1}{absolutePly % 2 ? '...' : '.'}</span>{move}</button></PreviewableMove>;
          })}</div></MovePreviewProvider>
        </> : <div className="empty selected-empty"><FolderOpen size={30} strokeWidth={1.3} /><p>No recorded moves</p></div>}
      </section>

      <section className="library" aria-labelledby="library-heading">
        <header className="panel-heading"><h2 id="library-heading">Library <span className="count">{snapshot.games.length}</span></h2><a className="button-link" href="#/games/new"><Plus size={16} />New game on board</a><Tool label="Export selected PGN" disabled={busy || !snapshot.games.some(record => exportIds.has(record.id))} onClick={download}><ArrowDownToLine size={19} /></Tool></header>
        <label className="search"><Search size={16} /><span className="sr-only">Search games</span><input type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search games" /></label>
        {snapshot.games.length === 0 ? <div className="empty"><FolderOpen size={28} strokeWidth={1.3} /><h3>Your library is empty</h3><button disabled={!ready || busy} onClick={() => openModal('import')}><ArrowUpFromLine size={16} />Import PGN</button></div> : <>
          <label className="select-all"><input type="checkbox" aria-label="Select all games for export" checked={snapshot.games.length > 0 && snapshot.games.every(record => exportIds.has(record.id))} onChange={event => setExportIds(event.target.checked ? new Set(snapshot.games.map(record => record.id)) : new Set())} />Select all <span>{snapshot.games.filter(record => exportIds.has(record.id)).length} selected</span></label>
          <label className="select-all"><input type="checkbox" checked={exportLines} onChange={event => setExportLines(event.target.checked)} />Include my analysis lines</label>
          <ul className="game-list">{visibleGames.map(record => <li key={record.id} className={game?.id === record.id ? 'active' : ''}>
            <input type="checkbox" aria-label={`Select ${gameTitle(record)} for export`} checked={exportIds.has(record.id)} onChange={event => setExportIds(previous => { const next = new Set(previous); if (event.target.checked) next.add(record.id); else next.delete(record.id); return next; })} />
            <button className="game-row" aria-current={game?.id === record.id ? 'true' : undefined} onClick={() => select(record)}><strong>{gameTitle(record)}</strong><span>{display(record.headers.Event, 'Unknown event')}<b>{record.result}</b></span><small>{display(record.headers.Date, 'Unknown date')} / {record.moves.length} plies</small></button>
            <a className="row-review" aria-label={`Review ${gameTitle(record)}`} href={`#/games/${record.id}/review`}>Review</a>
          </li>)}</ul>{!visibleGames.length && <p className="no-match">No matching games</p>}
        </>}
        <footer className="library-footer"><span>{shell}</span><a href="/THIRD_PARTY_NOTICES.md" target="_blank" rel="noreferrer">Licenses</a><a href="/chess.org-source.zip" download>Source code (GPL)</a></footer>
      </section>
    </main>}

    {modal && <Modal title={modal === 'appearance' ? 'Board appearance' : modal === 'import' ? 'Import PGN' : modal === 'edit' ? 'Edit game details' : 'Delete game?'} busy={busy} onClose={closeModal}>
      {modal === 'appearance' && <AppearancePanel value={appearance} onChange={next => { saveAppearance(next); setAppearance(next); }} />}
      {errorBlock}
      {modal === 'import' && <>
        <form onSubmit={validateImport}>
          <label className="field">PGN file<input type="file" accept=".pgn,.txt,application/x-chess-pgn,text/plain" disabled={busy} onChange={event => void readFile(event.target.files?.[0])} /></label>
          <label className="field">PGN<textarea aria-label="PGN" value={source} disabled={busy} rows={8} spellCheck={false} onChange={event => { fileVersion.current++; updateSource(event.target.value); }} /></label>
          <div className="dialog-actions"><button type="submit" disabled={busy}><Check size={17} />Validate PGN</button></div>
        </form>
        {preview.length > 0 && <div className="import-preview"><h3>{preview.length} valid {preview.length === 1 ? 'game' : 'games'}</h3>{preview.map((record, index) => <label key={index} className="preview-row"><input type="checkbox" aria-label={`Import ${gameTitle(record)}`} checked={chosen.has(index)} disabled={busy} onChange={event => setChosen(previous => { const next = new Set(previous); if (event.target.checked) next.add(index); else next.delete(index); return next; })} /><span>{gameTitle(record)}<small>{record.moves.length} plies / {record.result === '*' ? 'Unfinished' : record.result}</small></span></label>)}
          <div className="dialog-actions"><button className="primary" disabled={busy || chosen.size === 0} onClick={() => void commit(() => library.importGames(preview.filter((_, index) => chosen.has(index))), `${chosen.size} ${chosen.size === 1 ? 'game' : 'games'} saved.`, next => {
            const added = next.games.slice(-chosen.size);
            setSelectedId(added[0].id); setExportIds(new Set(added.map(record => record.id))); setPly(0); setSource(''); setPreview([]); setChosen(new Set());
          })}><ArrowUpFromLine size={17} />{busy ? 'Saving...' : `Import ${chosen.size} selected`}</button></div>
        </div>}
      </>}
      {modal === 'edit' && game && <form onSubmit={event => { event.preventDefault(); void commit(() => library.editGame(game.id, details), 'Game details saved.'); }}>
        <div className="details-grid">{DETAIL_FIELDS.map(field => <label key={field} className="field">{field}<input value={details[field] ?? ''} maxLength={500} disabled={busy} onChange={event => setDetails(previous => ({ ...previous, [field]: event.target.value }))} /></label>)}</div>
        <div className="dialog-actions"><button disabled={busy} type="button" onClick={closeModal}>Cancel</button><button className="primary" disabled={busy} type="submit"><Check size={17} />{busy ? 'Saving...' : 'Save details'}</button></div>
      </form>}
      {modal === 'delete' && game && <>
        <p>Delete <strong>{gameTitle(game)}</strong> and its associated review and practice records?</p>
        <div className="dialog-actions"><button disabled={busy} onClick={closeModal}>Cancel</button><button className="danger" disabled={busy} onClick={() => void commit(() => library.deleteGame(game.id), 'Game deleted.', () => { setPly(0); setSan(''); })}><Trash2 size={17} />{busy ? 'Deleting...' : 'Delete permanently'}</button></div>
      </>}
    </Modal>}
  </>;
}