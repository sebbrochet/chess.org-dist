import { expect, it } from 'vitest';
import { buildServiceWorker } from './serviceWorker';

it('preloads the complete versioned shell and never touches IndexedDB or forces activation', () => {
  const script = buildServiceWorker(['/', '/assets/index-abc.js', '/assets/index-def.css'], 'test');
  expect(script).toContain('chess-org-shell-test');
  expect(script).toContain('/assets/index-abc.js');
  expect(script).toContain('cache.addAll(ASSETS)');
  expect(script).toContain('await caches.delete(CACHE)');
  expect(script).not.toContain('indexedDB');
  expect(script).not.toContain('skipWaiting');
  expect(script).not.toContain('clients.claim');
});

it('answers only app navigations with the shell so linked documents open themselves', () => {
  const script = buildServiceWorker(['/'], 'test');
  expect(script).toContain("pathname === '/' || pathname === '/index.html'");
  expect(script).toContain("cache.match(shell ? '/' : event.request");
});