export function buildServiceWorker(assets: string[], version: string): string {
  return `
const CACHE = ${JSON.stringify(`chess-org-shell-${version}`)};
const ASSETS = ${JSON.stringify(assets)};
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)).catch(async error => {
    await caches.delete(CACHE);
    throw error;
  }));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('chess-org-shell-') && key !== CACHE).map(key => caches.delete(key)))));
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  const { pathname } = new URL(event.request.url);
  const shell = event.request.mode === 'navigate' && (pathname === '/' || pathname === '/index.html');
  event.respondWith(caches.open(CACHE).then(async cache => {
    const saved = await cache.match(shell ? '/' : event.request, { ignoreVary: true, ignoreSearch: shell });
    return saved || fetch(event.request);
  }));
});
`;
}