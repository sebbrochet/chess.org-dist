// @vitest-environment jsdom
import React from 'react';
import { act } from 'react';
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { afterEach, beforeAll, expect, it, vi } from 'vitest';
import { App } from './App';
import { createLibrary, emptySnapshot, type DomainSnapshot, type SnapshotDriver } from '../storage/library';
import { parseGames } from '../chess/pgn';
import { newComputerGame, transitionGame } from '../chess/play';
import { INITIAL_FEN } from 'chessops/fen';

vi.mock('../components/Board', () => ({ Board: ({ fen }: { fen: string }) => <div data-testid="board">{fen}</div> }));

beforeAll(() => {
  HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
  HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); };
});
afterEach(() => { cleanup(); localStorage.clear(); });

it('hands the exact completed game to first review once and ordinary reopening does not regenerate it', async () => {
  const game = transitionGame(newComputerGame(INITIAL_FEN, { side: 'white', level: 4, takebacks: false, time: null }, 0), { type: 'resign' }, 1);
  let durable = emptySnapshot();
  durable.games = [{ ...parseGames('[Title "Unrelated selected game"]\n1.e4 *')[0], id: 'other-game', createdAt: new Date().toISOString(), source: { kind: 'pgn' } }, game];
  const library = createLibrary({ read: async () => structuredClone(durable), update: async change => { durable = change(structuredClone(durable)); } });
  const begin = vi.spyOn(library, 'beginFirstReview');
  window.location.hash = `#/play/${game.id}`;
  const mounted = render(<React.StrictMode><App library={library} /></React.StrictMode>);
  await act(async () => { await Promise.resolve(); });
  expect(within(screen.getByRole('navigation', { name: 'Main' })).getByRole('link', { name: 'Review' }).getAttribute('href')).toBe(`#/games/${game.id}/review`);
  expect(durable.reviews).toHaveLength(0);
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Review game' })); });
  await screen.findByText('Complete / 0 of 0 moves');
  expect(durable.reviews[0].gameId).toBe(game.id); expect(begin).toHaveBeenCalledOnce();
  const retained = structuredClone(durable.reviews);
  mounted.unmount();
  render(<App library={library} />);
  await screen.findByText('Complete / 0 of 0 moves');
  expect(begin).toHaveBeenCalledOnce(); expect(durable.reviews).toEqual(retained);
});

it('previews a recorded after-move position without changing replay selection or a SAN draft', async () => {
  const parsed = parseGames('1.e4 e5 *')[0];
  const snapshot = emptySnapshot();
  snapshot.games.push({ ...parsed, id: 'preview-game', createdAt: new Date().toISOString(), source: { kind: 'pgn' } });
  const update = vi.fn(); const library = createLibrary({ read: async () => structuredClone(snapshot), update });
  window.location.hash = '#/';
  render(<App library={library} />);
  await act(async () => { await Promise.resolve(); });
  fireEvent.change(screen.getByRole('textbox', { name: 'Recorded SAN' }), { target: { value: 'e4' } });
  const position = screen.getByTestId('board').textContent;
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after 1. e4' }));
  const popup = screen.getByRole('dialog', { name: 'Position after 1. e4' });
  expect(popup.querySelector('.mini-board-frame')?.getAttribute('data-fen')).toBe(parsed.positions[1]);
  expect(screen.getByTestId('board').textContent).toBe(position);
  expect(screen.getByLabelText('Replay position').textContent).toBe('0 / 2');
  expect((screen.getByRole('textbox', { name: 'Recorded SAN' }) as HTMLInputElement).value).toBe('e4');
  fireEvent.click(within(popup).getByRole('button', { name: 'Dismiss move preview' }));
  expect(update).not.toHaveBeenCalled();
});

it('applies and persists board appearance without mutating the library', async () => {
  const update = vi.fn();
  const library = createLibrary({ read: async () => emptySnapshot(), update });
  const view = render(<App library={library} />);
  fireEvent.click(screen.getByRole('button', { name: 'Board appearance' }));
  fireEvent.click(screen.getByRole('button', { name: 'Blue board' }));
  fireEvent.click(screen.getByRole('button', { name: 'Merida pieces' }));
  await act(async () => { await Promise.resolve(); });
  expect(document.documentElement.dataset.pieceStyle).toBe('merida');
  expect(document.documentElement.style.getPropertyValue('--cp-board-dark')).toBe('#8ca2ad');
  expect(update).not.toHaveBeenCalled();
  view.unmount();
  render(<App library={library} />);
  await act(async () => { await Promise.resolve(); });
  expect(document.documentElement.dataset.pieceStyle).toBe('merida');
});

it('provides an accessible move-sound toggle and retains the preference after remounting', async () => {
  const library = createLibrary({ read: async () => emptySnapshot(), update: async () => {} });
  const view = render(<App library={library} />);
  fireEvent.click(screen.getByRole('button', { name: 'Mute move sounds' }));
  expect(screen.getByRole('button', { name: 'Enable move sounds' }).getAttribute('aria-pressed')).toBe('false');
  expect(localStorage.getItem('chess.org:move-sounds')).toBe('false');
  view.unmount();
  render(<App library={library} />);
  expect(screen.getByRole('button', { name: 'Enable move sounds' })).toBeTruthy();
  fireEvent.click(screen.getByRole('button', { name: 'Enable move sounds' }));
  expect(localStorage.getItem('chess.org:move-sounds')).toBe('true');
  await act(async () => { await Promise.resolve(); });
});

it('keeps unsaved selections visible after a failed storage mutation and only displays games after durable success', async () => {
  let durable = emptySnapshot();
  let rejectWrite = true;
  let finish: (() => void) | undefined;
  const driver: SnapshotDriver = {
    read: async () => structuredClone(durable),
    update: async change => {
      const candidate = change(structuredClone(durable));
      if (rejectWrite) throw new Error('Disk full');
      await new Promise<void>(resolve => { finish = resolve; });
      durable = candidate;
    },
  };
  render(<App library={createLibrary(driver)} />);
  await act(async () => { await Promise.resolve(); });
  fireEvent.click(screen.getAllByRole('button', { name: 'Import PGN' })[0]);
  fireEvent.change(screen.getByRole('textbox', { name: 'PGN' }), { target: { value: '[White "Test"]\n1.e4 e5 *' } });
  fireEvent.click(screen.getByRole('button', { name: 'Validate PGN' }));
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Import 1 selected' })); });
  expect(screen.getByRole('alert').textContent).toContain('Not saved: Disk full');
  expect((within(screen.getByRole('dialog')).getByRole('checkbox') as HTMLInputElement).checked).toBe(true);
  expect(screen.getByText('Your library is empty')).toBeTruthy();
  expect(durable.games).toHaveLength(0);
  rejectWrite = false;
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Import 1 selected' })); });
  expect(durable.games).toHaveLength(0);
  expect(screen.getByText('Your library is empty')).toBeTruthy();
  await act(async () => { finish?.(); });
  expect(durable.games).toHaveLength(1);
  expect(screen.getByRole('heading', { name: 'Test - Unknown Black' })).toBeTruthy();
  expect(screen.queryByRole('dialog')).toBeNull();
});

it('does not replace saved descriptions after a failed edit', async () => {
  const { parseGames } = await import('../chess/pgn');
  const seed = createLibrary();
  const durable: DomainSnapshot = { ...emptySnapshot(), games: [{ ...parseGames('[White "Original"]\n1.d4 d5 *')[0], id: 'existing', createdAt: '2026-10-30', source: { kind: 'pgn' } }] };
  const library = { ...seed, load: async () => durable, editGame: vi.fn().mockRejectedValue(new Error('Quota')) };
  render(<App library={library} />);
  await act(async () => { await Promise.resolve(); });
  fireEvent.click(screen.getByRole('button', { name: 'Edit game details' }));
  fireEvent.change(screen.getByRole('textbox', { name: 'White' }), { target: { value: 'Not saved' } });
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Save details' })); });
  expect(screen.getByRole('heading', { name: 'Original - Unknown Black' })).toBeTruthy();
  expect(screen.getByRole('alert').textContent).toContain('Not saved');
  expect(durable.games[0].headers.White).toBe('Original');
});