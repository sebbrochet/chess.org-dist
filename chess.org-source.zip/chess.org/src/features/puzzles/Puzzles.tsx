import { useEffect, useRef, useState } from 'react';
import { ArrowDownToLine, ArrowRight, Eye, Lightbulb, RotateCcw, Trash2 } from 'lucide-react';
import { parseSquare } from 'chessops/util';
import { Board } from '../../components/Board';
import { Modal } from '../../components/Modal';
import { positionFromFen } from '../../chess/pgn';
import { bundledPuzzles, lichessPuzzleSet, puzzleDisplay } from '../../chess/puzzles';
import { legalContinuation } from '../../chess/review';
import { candidateUci } from '../../chess/training';
import type { createLibrary, DomainSnapshot } from '../../storage/library';

export function Puzzles({ library, snapshot, onSnapshot }: { library: ReturnType<typeof createLibrary>; snapshot: DomainSnapshot; onSnapshot: (value: DomainSnapshot) => void }) {
  const [selectedId, setSelectedId] = useState(''); const [attemptId, setAttemptId] = useState('');
  const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [status, setStatus] = useState('');
  const [hint, setHint] = useState(false); const [answer, setAnswer] = useState(''); const [promotion, setPromotion] = useState(''); const [removing, setRemoving] = useState('');
  const [pending, setPending] = useState<{ attemptId: string; fen: string; move: string }>();
  const lock = useRef(false);
  const initialized = !!snapshot.extensions.bundledPuzzlesInitialized;
  useEffect(() => { if (!initialized) void library.initializePuzzles().then(onSnapshot).catch(reason => setError(reason instanceof Error ? reason.message : 'Starter retention failed.')); }, [initialized, library, onSnapshot]);
  const puzzle = snapshot.puzzles.find(record => record.id === selectedId) ?? snapshot.puzzles[0];
  const attempt = snapshot.puzzleAttempts.find(record => record.id === attemptId && record.puzzleId === puzzle?.id);
  const collection = snapshot.puzzleCollections.find(record => record.id === puzzle?.collectionId);
  const ended = !!attempt && attempt.status !== 'Active';
  const shown = attempt && puzzle ? busy && pending?.attemptId === attempt.id ? { fen: pending.fen, lastMove: pending.move } : puzzleDisplay(puzzle, attempt) : undefined;
  const fen = shown?.fen ?? puzzle?.fen;
  async function save(run: () => Promise<DomainSnapshot>) {
    if (lock.current) return; lock.current = true; setBusy(true); setError(''); setStatus('');
    try { const next = await run(); onSnapshot(next); return next; } catch (reason) { setError(reason instanceof Error ? reason.message : 'Not saved.'); } finally { lock.current = false; setBusy(false); }
  }
  async function start() {
    if (!puzzle) return;
    const next = await save(() => library.startPuzzle(puzzle.id));
    if (next) { setAttemptId(next.puzzleAttempts.at(-1)!.id); setHint(false); setAnswer(''); }
  }
  async function action(value: { type: 'answer'; input: string } | { type: 'hint' | 'reveal' }) {
    if (!attempt) return;
    if (value.type === 'answer') {
      try { const move = candidateUci(attempt.fen, value.input); setPending({ attemptId: attempt.id, fen: legalContinuation(attempt.fen, [move])[0].fen, move }); } catch { /* the save reports illegal input */ }
    }
    const next = await save(() => library.puzzleAction(attempt.id, value));
    setPending(undefined);
    if (next) { setAnswer(''); if (value.type === 'hint') setHint(true); }
  }
  function boardMove(uci: string) {
    if (!attempt) return;
    const square = parseSquare(uci.slice(0, 2));
    if (square !== undefined && positionFromFen(attempt.fen).board.get(square)?.role === 'pawn' && /[18]$/.test(uci)) setPromotion(uci);
    else void action({ type: 'answer', input: uci });
  }
  async function download() {
    const next = await save(async () => {
      const response = await fetch('https://lichess.org/api/puzzle/daily', { signal: AbortSignal.timeout(15000) });
      if (!response.ok) throw new Error(`Lichess puzzle retrieval unavailable (${response.status}). Retained content is unchanged.`);
      const text = await response.text(); if (text.length > 2000000) throw new Error('Puzzle response is too large.');
      const set = lichessPuzzleSet(JSON.parse(text));
      return library.retainPuzzleSet(set);
    });
    if (next) { setSelectedId(next.puzzles.at(-1)?.id ?? ''); setAttemptId(''); setStatus('Collection retained for offline solving.'); }
  }
  return <main className={puzzle && fen ? 'workspace review-workspace' : 'progress-workspace'}>
    {fen && puzzle && <section className="replay" aria-label="Puzzle board"><Board fen={fen} orientation={positionFromFen(puzzle.fen).turn} lastMove={shown?.lastMove} lastMoveFrom={shown && 'lastMoveFrom' in shown ? shown.lastMoveFrom : undefined} deferMoveReset onMove={attempt && !ended && !busy ? boardMove : undefined} />
      {attempt && <form className="san-entry" onSubmit={event => { event.preventDefault(); void action({ type: 'answer', input: answer }); }}><label htmlFor="puzzle-san">Puzzle move</label><input id="puzzle-san" value={answer} disabled={busy || ended} onChange={event => setAnswer(event.target.value)} /><button className="icon" title="Submit puzzle move" aria-label="Submit puzzle move" disabled={busy || ended || !answer.trim()}><ArrowRight /></button></form>}</section>}
    <section className="game-panel"><h1>Puzzles</h1>{error && <p className="error" role="alert">{error}</p>}{status && <p role="status">{status}</p>}
      <div className="play-actions"><button disabled={busy} onClick={() => void download()}><ArrowDownToLine size={17} />Download Lichess collection</button>{!snapshot.puzzleCollections.some(record => record.id === 'chess-org-starter') && initialized && <button disabled={busy} onClick={() => void save(() => library.retainPuzzleSet(bundledPuzzles()))}><RotateCcw size={17} />Restore starter set</button>}</div>
      <ul className="review-picker">{snapshot.puzzleCollections.map(record => <li key={record.id}><strong>{record.name}</strong><p>{record.source}</p><button disabled={busy} onClick={() => setRemoving(record.id)}><Trash2 size={16} />Remove collection</button><ul>{snapshot.puzzles.filter(p => p.collectionId === record.id).map((p, index) => <li key={p.id}><button aria-current={puzzle?.id === p.id ? 'true' : undefined} onClick={() => { setSelectedId(p.id); setAttemptId(''); setHint(false); }}>Puzzle {index + 1}{p.rating ? ` / Lichess ${p.rating}` : ''}</button></li>)}</ul></li>)}</ul>
      {puzzle ? <><h2>{collection?.name}</h2><p>{puzzle.themes.join(', ')}</p>{!attempt ? <button className="primary" disabled={busy} onClick={() => void start()}>Start puzzle</button> : <>
        <p role="status" aria-label="Puzzle result">{busy ? 'Saving...' : attempt.status === 'Success' ? 'Unaided success' : attempt.status === 'Assisted' ? 'Assisted result' : attempt.status === 'Incorrect' ? 'Not the supplied solution' : 'Continue the solution'}</p>
        {hint && !ended && <p aria-label="Puzzle hint">Move from {attempt.remaining[0][0].slice(0, 2)}.</p>}
        {ended && <p aria-label="Puzzle solution">Solutions: {puzzle.solutions.map(line => legalContinuation(puzzle.fen, line).map(step => step.san).join(' ')).join(' / ')}</p>}
        <div className="play-actions">{!ended ? <><button disabled={busy} onClick={() => void action({ type: 'hint' })}><Lightbulb size={17} />Show hint</button><button disabled={busy} onClick={() => void action({ type: 'reveal' })}><Eye size={17} />Reveal answer</button></> : <button disabled={busy} onClick={() => void start()}><RotateCcw size={17} />Retry puzzle</button>}</div></>}
      </> : <p>No puzzle content retained.</p>}<footer className="library-footer"><a href="#/progress">Progress</a><a href="https://database.lichess.org/#puzzles" target="_blank" rel="noreferrer">Lichess CC0 source</a></footer>
    </section>
    {removing && <Modal title="Remove puzzle collection?" busy={busy} onClose={() => setRemoving('')}><p>Remove retained positions and all their solving results?</p>{error && <p className="error" role="alert">{error}</p>}<div className="dialog-actions"><button disabled={busy} onClick={() => setRemoving('')}>Cancel</button><button className="danger" disabled={busy} onClick={() => void save(async () => { const next = await library.removePuzzleCollection(removing); setRemoving(''); setAttemptId(''); return next; })}>Remove content and results</button></div></Modal>}
    {promotion && <Modal title="Promote puzzle pawn" busy={busy} onClose={() => setPromotion('')}><div className="play-actions">{['q', 'r', 'b', 'n'].map((piece, index) => <button key={piece} onClick={() => { const input = promotion + piece; setPromotion(''); void action({ type: 'answer', input }); }}>{['Queen', 'Rook', 'Bishop', 'Knight'][index]}</button>)}</div></Modal>}
  </main>;
}