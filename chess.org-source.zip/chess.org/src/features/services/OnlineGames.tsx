import { useEffect, useRef, useState } from 'react';
import { ArrowDownToLine, Search } from 'lucide-react';
import { cadenceOptions, fetchPublicGames, publicGameDetails, type Cadence, type GameProvider, type PublicGame } from '../../providers/chessServices';
import type { createLibrary, DomainSnapshot } from '../../storage/library';

export function OnlineGames({ library, snapshot, onSnapshot }: { library: ReturnType<typeof createLibrary>; snapshot: DomainSnapshot; onSnapshot: (value: DomainSnapshot) => void }) {
  const [provider, setProvider] = useState<GameProvider>('lichess'); const [username, setUsername] = useState('');
  const [cadence, setCadence] = useState<Cadence>('all'); const [retrieved, setRetrieved] = useState(false);
  const [before, setBefore] = useState(''); const [month, setMonth] = useState(''); const [archives, setArchives] = useState<string[]>([]);
  const [records, setRecords] = useState<PublicGame[]>([]); const [selected, setSelected] = useState<Set<number>>(new Set());
  const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [status, setStatus] = useState('');
  const controller = useRef<AbortController>(); const saving = useRef(false);
  useEffect(() => () => controller.current?.abort(), []);
  function reset() { controller.current?.abort(); setRecords([]); setSelected(new Set()); setRetrieved(false); setError(''); setStatus(''); setBusy(false); }
  async function load() {
    controller.current?.abort(); const current = new AbortController(); controller.current = current; setBusy(true); setError(''); setStatus('');
    try {
      const result = await fetchPublicGames(provider, username, month, before, fetch, current.signal, cadence);
      if (current.signal.aborted) return;
      setRecords(result.games); setRetrieved(true); setArchives(result.archives); if (provider === 'chess.com' && !month) setMonth(result.archives.at(-1) ?? '');
      setSelected(new Set(result.games.map((_game, index) => index))); setStatus(`${result.games.length} public standard-chess records retrieved.`);
    } catch (reason) { if (!current.signal.aborted) setError(reason instanceof Error ? reason.message : 'Provider request failed. Retained games are unchanged.'); }
    finally { if (controller.current === current) setBusy(false); }
  }
  async function retain() {
    if (saving.current) return; saving.current = true; setBusy(true); setError('');
    try {
      const chosen = records.filter((_record, index) => selected.has(index));
      const next = await library.importPublicGames(chosen);
      const keys = new Set(snapshot.games.flatMap(game => game.source.kind === 'online' ? [`${game.source.provider}:${game.source.originalId}`] : []));
      const count = chosen.filter(record => !keys.has(`${record.provider}:${record.originalId}`)).length;
      onSnapshot(next); setStatus(`${count} selected new records retained. Existing provider identities were skipped.`);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Not saved. Retained games are unchanged.'); }
    finally { saving.current = false; setBusy(false); }
  }
  return <main className="progress-workspace"><h1>Public Games</h1>{error && <p className="error" role="alert">{error}</p>}{status && <p role="status" aria-label="Public import status">{status}</p>}
    <form className="service-form" onSubmit={event => { event.preventDefault(); void load(); }}><label className="field">Provider<select aria-label="Provider" value={provider} disabled={busy} onChange={event => { reset(); setProvider(event.target.value as GameProvider); setCadence('all'); setMonth(''); setArchives([]); }}><option value="lichess">Lichess</option><option value="chess.com">chess.com</option></select></label>
      <label className="field">Public username<input value={username} required disabled={saving.current} onChange={event => { reset(); setUsername(event.target.value); setMonth(''); setArchives([]); }} /></label>
      <label className="field">Cadence<select aria-label="Cadence" value={cadence} disabled={saving.current} onChange={event => { reset(); setCadence(event.target.value as Cadence); }}>{cadenceOptions(provider).map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
      {provider === 'lichess' ? <label className="field">Before date (optional)<input type="date" value={before} disabled={saving.current} onChange={event => { reset(); setBefore(event.target.value); }} /></label> : archives.length > 0 && <label className="field">Archive month<select aria-label="Archive month" value={month} disabled={saving.current} onChange={event => { reset(); setMonth(event.target.value); }}>{archives.slice().reverse().map(archive => <option key={archive} value={archive}>{archive}</option>)}</select></label>}
      <button className="primary" disabled={busy}><Search size={17} />{busy ? 'Working...' : 'Fetch public games'}</button></form>
    <section><header className="panel-heading"><h2>Retrieved records</h2><button disabled={busy || !selected.size} onClick={() => void retain()}><ArrowDownToLine size={17} />Retain selected games</button></header>
      {retrieved && !records.length && !busy && !error && <p>No matching public games for this cadence and date or archive month.</p>}
      <ul className="review-picker">{records.map((record, index) => {
        const details = publicGameDetails(record);
        return <li key={`${record.provider}:${record.originalId}`}><label className="preview-row"><input type="checkbox" checked={selected.has(index)} disabled={busy} onChange={event => setSelected(previous => { const next = new Set(previous); if (event.target.checked) next.add(index); else next.delete(index); return next; })} /><span>{record.game.headers.White || 'White'} - {record.game.headers.Black || 'Black'} / {record.game.result}<small>{details.date}</small><small>{details.cadence} / {details.timeControl}</small><small>{record.provider} / {record.originalId} / {record.game.moves.length} plies</small></span></label></li>;
      })}</ul>
      <a href="#/">Retained games</a></section></main>;
}