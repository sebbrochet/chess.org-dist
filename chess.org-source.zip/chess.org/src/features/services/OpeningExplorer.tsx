import { useEffect, useMemo, useRef, useState, useSyncExternalStore, type ReactNode } from 'react';
import { Check, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Download, Eye, FlipVertical2, KeyRound, Minus, Plus, Search, Trash2, X } from 'lucide-react';
import { INITIAL_FEN } from 'chessops/fen';
import { parseSquare } from 'chessops/util';
import { Board } from '../../components/Board';
import { Modal } from '../../components/Modal';
import { MovePreviewProvider, PreviewableMove } from '../../components/MovePreview';
import { PositionEditor } from '../../components/PositionEditor';
import { fetchCloudEvaluation, fetchOpenings, openingToken, OpeningServiceError, type CloudLine, type OpeningInfo, type OpeningSample } from '../../providers/chessServices';
import { lichessAccess, type AccessStatus } from '../../providers/lichessAccess';
import { analyzeReviewPosition, legalContinuation } from '../../chess/review';
import { positionFromFen } from '../../chess/pgn';
import { createExploration, explorationLineEnd, explorationMoveLabel, explorationPath, explorationPgn, nextExplorationNode, playExplorationMove, selectExplorationNode, type ExplorationNode } from '../../chess/exploration';
import { localEngine, type LocalEngine } from '../../engine/stockfish';
import { evaluationLabel, scoreLabel } from '../play/PlayComputer';
import type { createLibrary, DomainSnapshot } from '../../storage/library';

const RATING_OPTIONS = [{ value: '1000,1200', label: '1000-1399' }, { value: '1400,1600', label: '1400-1799' }, { value: '1800,2000', label: '1800-2199' }, { value: '2200,2500', label: '2200+' }, { value: '0,1000,1200,1400,1600,1800,2000,2200,2500', label: 'All ratings' }];
const SPEED_OPTIONS = [{ value: 'rapid,classical', label: 'Rapid and classical' }, { value: 'rapid', label: 'Rapid' }, { value: 'classical', label: 'Classical' }, { value: 'blitz', label: 'Blitz' }];
type CandidateEvaluation = { label: string; source: 'Lichess cloud' | 'Stockfish' } | 'unavailable';
const sampleKey = (fen: string, ratings: string, speeds: string) => `${ratings}|${speeds}|${fen}`;
const childFen = (fen: string, uci: string) => { try { return legalContinuation(fen, [uci])[0].fen; } catch { return undefined; } };
const percent = (count: number, total: number) => `${(100 * count / total).toFixed(1)}%`;
function EvaluationCell({ value }: { value?: CandidateEvaluation }) {
  if (!value) return <span className="opening-eval" aria-label="Evaluation pending" title="Evaluation pending">...</span>;
  if (value === 'unavailable') return <span className="opening-eval" aria-label="Evaluation unavailable" title="Evaluation unavailable">n/a</span>;
  const label = `${value.label}, ${value.source}`;
  return <span className="opening-eval" aria-label={`Evaluation ${label}`} title={`${label} (White's point of view)`}>{value.label}<small>{value.source === 'Lichess cloud' ? 'cloud' : 'SF'}</small></span>;
}

const compactGames = new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 });
function PositionEvaluation({ value }: { value?: CandidateEvaluation }) {
  const known = value && value !== 'unavailable' ? value : undefined;
  const label = !value ? 'pending' : known ? `${known.label}, ${known.source}` : 'unavailable';
  return <output className="opening-position-eval" aria-label={`Position evaluation ${label}`} title="Evaluation of the current position from White's point of view">Eval {known ? known.label : value ? 'n/a' : '...'}{known && <small>{known.source === 'Lichess cloud' ? 'cloud' : 'SF'}</small>}</output>;
}
const openingLabel = (opening?: OpeningInfo) => opening ? `${opening.eco ? `${opening.eco} ` : ''}${opening.name}` : 'Opening unknown';
function OutcomeBar({ white, draws, black }: { white: number; draws: number; black: number }) {
  const total = white + draws + black;
  if (!total) return <div className="opening-outcome" role="img" aria-label="No games" title="No games"><div className="opening-outcome-bar" aria-hidden="true" /><span className="opening-empty-outcome">No games</span></div>;
  const values = [white, draws, black].map(count => 100 * count / total);
  const label = `White ${values[0].toFixed(1)}%, Draws ${values[1].toFixed(1)}%, Black ${values[2].toFixed(1)}%`;
  return <div className="opening-outcome" role="img" aria-label={label} title={label}>
    <div className="opening-outcome-bar" aria-hidden="true">{values.map((value, index) => <span key={index} className={['opening-white', 'opening-draw', 'opening-black'][index]} style={{ width: `${value}%` }} />)}</div>
    <div className="opening-outcome-labels" aria-hidden="true">{values.map((value, index) => <span key={index}>{value.toFixed(1)}%</span>)}</div>
  </div>;
}

export function OpeningExplorer({ initialFen = INITIAL_FEN, library, onSnapshot, ready = true, engine = localEngine }: {
  initialFen?: string; library?: ReturnType<typeof createLibrary>; onSnapshot?: (snapshot: DomainSnapshot) => void; ready?: boolean; engine?: LocalEngine;
}) {
  const [tree, setTree] = useState(() => { try { return createExploration(initialFen); } catch { return createExploration(INITIAL_FEN); } });
  const node = tree.nodes[tree.current]; const fen = node.fen;
  const [draft, setDraft] = useState(fen);
  const [ratings, setRatings] = useState('1400,1600'); const [speeds, setSpeeds] = useState('rapid,classical');
  const [samples, setSamples] = useState<Record<string, OpeningSample>>({});
  const samplesRef = useRef(samples); samplesRef.current = samples;
  const sample = samples[sampleKey(fen, ratings, speeds)];
  const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const [preview, setPreview] = useState<string>();
  const previewMove = sample?.moves.find(move => move.uci === preview);
  const [evaluations, setEvaluations] = useState<Record<string, CandidateEvaluation>>({});
  const evaluationsRef = useRef(evaluations); evaluationsRef.current = evaluations;
  const cloudRequests = useRef(new Map<string, Promise<CloudLine[]>>());
  const explored = useRef(false);
  const [flipped, setFlipped] = useState(false); const orientation = flipped ? 'black' : 'white';
  const [promotion, setPromotion] = useState('');
  const [setupOpen, setSetupOpen] = useState(false);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());
  const [exportOpen, setExportOpen] = useState(false); const [exportName, setExportName] = useState('Opening exploration');
  const [exportSide, setExportSide] = useState<'white' | 'black'>('white'); const [exportComments, setExportComments] = useState(true);
  const [exporting, setExporting] = useState(false); const [exportError, setExportError] = useState(''); const [notice, setNotice] = useState('');
  const access = useSyncExternalStore(lichessAccess.subscribe, lichessAccess.getSnapshot);
  const [accessOpen, setAccessOpen] = useState(false); const [tokenDraft, setTokenDraft] = useState(''); const [remember, setRemember] = useState(false);
  const [validating, setValidating] = useState(false); const [accessError, setAccessError] = useState(''); const [accessMessage, setAccessMessage] = useState('');
  const controller = useRef<AbortController>();
  const validation = useRef<AbortController>();
  useEffect(() => () => { controller.current?.abort(); validation.current?.abort(); lichessAccess.cancelValidation(); }, []);
  useEffect(() => { setDraft(fen); setPreview(undefined); }, [fen]);
  useEffect(() => { if (explored.current) void load(fen, ratings, speeds); }, [fen, ratings, speeds]);
  const candidateFens = useMemo(() => new Map(sample?.moves.map(move => [move.uci, childFen(sample.fen, move.uci)]) ?? []), [sample]);
  useEffect(() => {
    if (!explored.current) return;
    const position = fen;
    const targets = [...new Set([position, ...[...candidateFens.values()].filter((child): child is string => !!child)])];
    const known = (target: string) => { const value = evaluationsRef.current[target]; return !!value && value !== 'unavailable'; };
    const record = (values: Record<string, CandidateEvaluation>) => { evaluationsRef.current = { ...evaluationsRef.current, ...values }; setEvaluations(previous => ({ ...previous, ...values })); };
    if (targets.every(known)) return;
    const current = new AbortController(); const { signal } = current;
    void (async () => {
      let cloud = cloudRequests.current.get(position);
      if (!cloud) { cloud = fetchCloudEvaluation(position).catch(() => []); cloudRequests.current.set(position, cloud); }
      const lines = await cloud;
      if (signal.aborted) return;
      const found: Record<string, CandidateEvaluation> = {};
      if (lines.length && childFen(position, lines[0].uci) && !known(position)) found[position] = { label: scoreLabel(lines[0].score), source: 'Lichess cloud' };
      for (const line of lines) { const child = childFen(position, line.uci); if (child && targets.includes(child) && !known(child)) found[child] = { label: scoreLabel(line.score), source: 'Lichess cloud' }; }
      record(found);
      for (const target of targets) {
        if (signal.aborted) return;
        if (known(target)) continue;
        let value: CandidateEvaluation;
        try { value = { label: evaluationLabel(await analyzeReviewPosition(engine, target, 'opening-explorer', 0, signal)), source: 'Stockfish' }; }
        catch { if (signal.aborted) return; value = 'unavailable'; }
        record({ [target]: value });
      }
    })();
    return () => current.abort();
  }, [fen, candidateFens, engine]);
  function closeAccess() {
    validation.current?.abort(); lichessAccess.cancelValidation(); setValidating(false); setTokenDraft(''); setAccessError(''); setAccessMessage(''); setAccessOpen(false);
  }
  async function validateAccess() {
    validation.current?.abort(); const current = new AbortController(); validation.current = current;
    const generation = lichessAccess.beginValidation(); setValidating(true); setAccessError(''); setAccessMessage('');
    try {
      const token = openingToken(tokenDraft || lichessAccess.getToken() || '');
      await fetchOpenings(INITIAL_FEN, ratings, speeds, fetch, current.signal, token);
      if (current.signal.aborted) return;
      controller.current?.abort(); setBusy(false);
      if (lichessAccess.configure(token, remember, generation)) { setError(''); closeAccess(); }
    } catch (reason) {
      if (!current.signal.aborted) setAccessError(reason instanceof Error ? reason.message : 'Opening access could not be configured.');
    } finally { if (validation.current === current) setValidating(false); }
  }
  function removeAccess() {
    validation.current?.abort(); controller.current?.abort(); setValidating(false); setBusy(false); setTokenDraft(''); setRemember(false); setAccessError(''); setAccessMessage('');
    try { lichessAccess.remove(); setAccessMessage('Access removed.'); }
    catch (reason) { setAccessError(reason instanceof Error ? reason.message : 'Access could not be removed.'); }
  }
  async function load(position: string, ratingBands: string, timeControls: string, force = false): Promise<boolean> {
    const key = sampleKey(position, ratingBands, timeControls);
    if (!force && samplesRef.current[key]) { controller.current?.abort(); setBusy(false); setError(''); return true; }
    controller.current?.abort(); const current = new AbortController(); controller.current = current; setBusy(true); setError('');
    const token = lichessAccess.getToken();
    try {
      positionFromFen(position);
      const result = await fetchOpenings(position, ratingBands, timeControls, fetch, current.signal, token);
      if (current.signal.aborted) return false;
      lichessAccess.recordStatus(token, 'Accepted');
      setPreview(undefined); setSamples(previous => ({ ...previous, [key]: result }));
      return true;
    } catch (reason) {
      if (!current.signal.aborted) {
        if (reason instanceof OpeningServiceError) {
          const statuses: Record<typeof reason.kind, AccessStatus> = { authentication: 'Authentication refused', 'rate-limit': 'Rate limited', network: 'Network unavailable', provider: 'Provider unavailable' };
          lichessAccess.recordStatus(token, statuses[reason.kind]);
        }
        setError(reason instanceof Error ? reason.message : 'Opening statistics are unavailable.');
      }
      return false;
    }
    finally { if (controller.current === current) setBusy(false); }
  }
  async function explorePosition() {
    explored.current = true;
    if (draft === fen) { await load(fen, ratings, speeds, true); return; }
    if (await load(draft, ratings, speeds, true)) { setTree(createExploration(draft)); setExpanded(new Set()); }
  }
  function go(id: number) { explored.current = true; setPromotion(''); setTree(previous => selectExplorationNode(previous, id)); }
  function play(uci: string) {
    try { const next = playExplorationMove(tree, uci); explored.current = true; setPromotion(''); setError(''); setTree(next); }
    catch { setError('Choose a legal move in this position.'); }
  }
  function boardMove(uci: string) {
    const from = parseSquare(uci.slice(0, 2));
    if (from !== undefined && positionFromFen(fen).board.get(from)?.role === 'pawn' && /[18]$/.test(uci)) setPromotion(uci);
    else play(uci);
  }
  function annotation(item: ExplorationNode): string | undefined {
    const parent = tree.nodes[item.parent];
    const parentSample = samplesRef.current[sampleKey(parent.fen, ratings, speeds)];
    const stats = parentSample?.moves.find(move => childFen(parent.fen, move.uci) === item.fen);
    const value = evaluationsRef.current[item.fen];
    const parts = [
      ...(parentSample ? [stats?.total ? `${stats.total} games: White ${percent(stats.white, stats.total)} / Draws ${percent(stats.draws, stats.total)} / Black ${percent(stats.black, stats.total)}` : 'No games'] : []),
      ...(value && value !== 'unavailable' ? [`Eval ${value.label} (${value.source})`] : []),
    ];
    return parts.length ? parts.join('; ') : undefined;
  }
  async function exportExploration() {
    const name = exportName.trim();
    if (tree.nodes.length < 2) { setExportError('Explore at least one move before exporting.'); return; }
    if (!name) { setExportError('Supply a repertoire name.'); return; }
    if (!library || !onSnapshot) return;
    const intro = `Lichess opening explorer, ratings ${RATING_OPTIONS.find(option => option.value === ratings)?.label ?? ratings}, ${SPEED_OPTIONS.find(option => option.value === speeds)?.label.toLowerCase() ?? speeds} (Lichess ratings, not FIDE). Evaluations from White's point of view.`;
    const pgn = explorationPgn(tree, name, exportComments ? { intro, move: annotation } : undefined);
    setExporting(true); setExportError('');
    try { onSnapshot(await library.importRepertoire(pgn, name, exportSide)); setExportOpen(false); setNotice(`Saved repertoire "${name}".`); }
    catch (reason) { setExportError(reason instanceof Error ? reason.message : 'The repertoire could not be saved.'); }
    finally { setExporting(false); }
  }

  const onPath = new Set(explorationPath(tree));
  const subtreeSize = (id: number): number => 1 + tree.nodes[id].children.reduce((total, child) => total + subtreeSize(child), 0);
  const treeMove = (id: number, numbered: boolean) => <PreviewableMove key={id} fen={tree.nodes[id].fen} label={explorationMoveLabel(tree, id, true)} move={tree.nodes[id].uci}>
    <button type="button" className="study-move" aria-current={tree.current === id ? 'step' : undefined} onClick={() => go(id)}>{explorationMoveLabel(tree, id, numbered)}</button>
  </PreviewableMove>;
  const treeLine = (from: number): ReactNode[] => {
    const out: ReactNode[] = [];
    let numbered = true;
    for (let at = from, main = nextExplorationNode(tree, at); main !== undefined; at = main, main = nextExplorationNode(tree, at)) {
      const sides = tree.nodes[at].children.filter(id => id !== main);
      out.push(treeMove(main, numbered));
      for (const side of sides) out.push(variation(side));
      numbered = sides.length > 0;
    }
    return out;
  };
  const toggle = (id: number) => setExpanded(previous => { const next = new Set(previous); if (next.has(id)) next.delete(id); else next.add(id); return next; });
  const variation = (id: number): ReactNode => {
    const open = expanded.has(id) || onPath.has(id); const size = subtreeSize(id);
    return <div key={`v${id}`} className="study-variation">
      {open ? <>
        {!onPath.has(id) && <button type="button" className="icon study-toggle" title="Collapse variation" aria-label={`Collapse variation ${explorationMoveLabel(tree, id, true)}`} onClick={() => toggle(id)}><Minus size={14} /></button>}
        {treeMove(id, true)}{treeLine(id)}
      </> : <button type="button" className="study-collapsed" aria-expanded="false" onClick={() => toggle(id)}><Plus size={14} />{explorationMoveLabel(tree, id, true)} ({size} {size === 1 ? 'move' : 'moves'})</button>}
    </div>;
  };
  const exploredChildren = new Set(node.children.map(id => tree.nodes[id].fen));
  const next = nextExplorationNode(tree);

  return <main className="workspace review-workspace"><section className="replay" aria-label="Opening position"><Board fen={fen} orientation={orientation} lastMove={node.uci || undefined} previewMove={previewMove?.uci} onMove={boardMove} />
      <div className="replay-toolbar">
        <button className="icon" title="First position" aria-label="First position" disabled={tree.current === 0} onClick={() => go(0)}><ChevronsLeft /></button>
        <button className="icon" title="Previous move" aria-label="Previous move" disabled={tree.current === 0} onClick={() => go(node.parent)}><ChevronLeft /></button>
        <button className="icon" title="Next move" aria-label="Next move" disabled={next === undefined} onClick={() => go(next!)}><ChevronRight /></button>
        <button className="icon" title="End of line" aria-label="End of line" disabled={next === undefined} onClick={() => go(explorationLineEnd(tree))}><ChevronsRight /></button>
        <button className="icon" title="Flip board" aria-label="Flip board" aria-pressed={flipped} onClick={() => setFlipped(value => !value)}><FlipVertical2 /></button>
        {explored.current && <PositionEvaluation value={evaluations[fen]} />}
      </div>
      <MovePreviewProvider orientation={orientation} resetKey={`${tree.current}:${tree.nodes.length}`}><div className="study-tree exploration-tree" aria-label="Explored moves">
        <button type="button" className="study-move" aria-current={tree.current === 0 ? 'step' : undefined} onClick={() => go(0)}>Start</button>
        {treeLine(0)}
        {tree.nodes.length === 1 && <p className="review-note">Play a move on the board or select one in the table to start exploring.</p>}
      </div></MovePreviewProvider>
      <div className="play-actions"><button type="button" disabled={!library || !ready} onClick={() => { setExportSide(orientation); setExportError(''); setNotice(''); setExportOpen(true); }}><Download size={17} />Export as repertoire</button></div>
      {notice && <p role="status">{notice} <a href="#/repertoires">Open Repertoires</a></p>}
    </section>
    <section className="game-panel"><header className="panel-heading"><h1>Opening Explorer</h1><button type="button" className="icon" title="Lichess API access" aria-label="Lichess API access" onClick={() => { setTokenDraft(''); setRemember(false); setAccessError(''); setAccessMessage(''); setAccessOpen(true); }}><KeyRound size={19} /></button></header>
      <p aria-label="Lichess access status">{access ? `${access.status} / ${access.retention === 'device' ? 'This Device' : 'Current Session'}` : 'Anonymous access'}</p>
      {error && <p className="error" role="alert">{error}</p>}<form onSubmit={event => { event.preventDefault(); void explorePosition(); }}>
      <details className="position-setup" onToggle={event => setSetupOpen(event.currentTarget.open)}><summary>Set up position</summary>{setupOpen && <PositionEditor fen={draft} onChange={setDraft} fenField={false} />}</details>
      <label className="field">Position FEN<textarea rows={3} value={draft} onChange={event => setDraft(event.target.value)} /></label><label className="field">Lichess rating bands<select value={ratings} onChange={event => setRatings(event.target.value)}>{RATING_OPTIONS.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
      <label className="field">Time controls<select value={speeds} onChange={event => setSpeeds(event.target.value)}>{SPEED_OPTIONS.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label><button className="primary" disabled={busy}><Search size={17} />{busy ? 'Fetching statistics...' : 'Explore position'}</button></form>
      {sample && <section className="opening-results"><p className="opening-source">{sample.source} / <span>{sample.ratingSystem}</span></p><p className="opening-filters" aria-label="Applied filters">Applied bands: {sample.ratings}; speeds: {sample.speeds}</p><p className="sr-only" aria-label="Opening sample">{sample.total} games / White {sample.white} / Draws {sample.draws} / Black {sample.black}</p>
        <div className="opening-context"><h2 aria-label="Opening name" aria-live="polite">{openingLabel(previewMove ? previewMove.opening : sample.opening)}</h2><button type="button" className="icon" title="Clear move preview" aria-label="Clear move preview" onClick={() => setPreview(undefined)}><X size={16} /></button></div>
        {!sample.total ? <p>No games: no matching data for this position and filter.</p> : <div className="history-table"><table className="opening-table" aria-label="Opening continuations"><thead><tr><th scope="col">Move</th><th scope="col">Frequency</th><th scope="col">Games</th><th scope="col" title="Evaluation from White's point of view">Eval</th><th scope="col">White / Draw / Black</th></tr></thead><tbody>{sample.moves.map(move => {
          const child = candidateFens.get(move.uci);
          return <tr key={move.uci} data-preview={preview === move.uci} data-explored={!!child && exploredChildren.has(child)} onPointerEnter={event => { if (event.pointerType !== 'touch') setPreview(move.uci); }} onPointerLeave={event => { if (!event.currentTarget.contains(document.activeElement)) setPreview(value => value === move.uci ? undefined : value); }} onFocus={() => setPreview(move.uci)} onBlur={event => { if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setPreview(value => value === move.uci ? undefined : value); }}>
          <td><div className="opening-move"><button className="opening-play" title={child && exploredChildren.has(child) ? 'Explored' : undefined} onClick={() => play(move.uci)}>{move.san}</button><button type="button" className="opening-preview" aria-label={`Preview ${move.san}`} title={`Preview ${move.san}`} aria-pressed={preview === move.uci} onClick={() => setPreview(move.uci)}><Eye size={15} /></button></div></td>
          <td>{(100 * move.total / sample.total).toFixed(1)}%</td><td title={`${move.total} games`}>{compactGames.format(move.total)}</td><td><EvaluationCell value={child ? evaluations[child] : 'unavailable'} /></td><td><OutcomeBar white={move.white} draws={move.draws} black={move.black} /></td>
        </tr>; })}</tbody><tfoot><tr><th scope="row">Total</th><td>100%</td><td title={`${sample.total} games`}>{compactGames.format(sample.total)}</td><td /><td><OutcomeBar white={sample.white} draws={sample.draws} black={sample.black} /></td></tr></tfoot></table></div>}</section>}
    </section>
    {promotion && <Modal title="Promote pawn" busy={false} onClose={() => setPromotion('')}><div className="play-actions">{['q', 'r', 'b', 'n'].map((piece, index) => <button key={piece} onClick={() => play(promotion + piece)}>{['Queen', 'Rook', 'Bishop', 'Knight'][index]}</button>)}</div></Modal>}
    {exportOpen && <Modal title="Export as repertoire" busy={exporting} onClose={() => setExportOpen(false)}>
      <form onSubmit={event => { event.preventDefault(); void exportExploration(); }}>
        <label className="field">Repertoire name<input value={exportName} maxLength={200} disabled={exporting} onChange={event => setExportName(event.target.value)} /></label>
        <label className="field">Side to learn<select value={exportSide} disabled={exporting} onChange={event => setExportSide(event.target.value as 'white' | 'black')}><option value="white">White</option><option value="black">Black</option></select></label>
        <label className="check-field"><input type="checkbox" checked={exportComments} disabled={exporting} onChange={event => setExportComments(event.target.checked)} />Include statistics and evaluation comments</label>
        {exportError && <p className="error" role="alert">{exportError}</p>}
        <div className="dialog-actions"><button type="button" disabled={exporting} onClick={() => setExportOpen(false)}>Cancel</button><button type="submit" className="primary" disabled={exporting}><Download size={17} />{exporting ? 'Saving...' : 'Save repertoire'}</button></div>
      </form>
    </Modal>}
    {accessOpen && <Modal title="Lichess API Access" busy={false} onClose={closeAccess}>
      <form onSubmit={event => { event.preventDefault(); void validateAccess(); }}>
        <label className="field">Lichess token<input type="password" autoComplete="off" autoCapitalize="none" spellCheck={false} value={tokenDraft} disabled={validating} onChange={event => setTokenDraft(event.target.value)} /></label>
        <label className="check-field"><input type="checkbox" checked={remember} disabled={validating} onChange={event => setRemember(event.target.checked)} />Remember on This Device</label>
        {remember && <p className="error">Browser storage is not a secure vault. Anyone with access to this browser may access this token.</p>}
        {accessError && <p className="error" role="alert">{accessError}</p>}
        {accessMessage && <p role="status">{accessMessage}</p>}
        <div className="dialog-actions"><button type="button" onClick={removeAccess}><Trash2 size={17} />Remove</button><button type="submit" className="primary" disabled={validating || (!tokenDraft && !access)}><Check size={17} />{validating ? 'Validating...' : 'Validate and Use'}</button></div>
      </form>
    </Modal>}
  </main>;
}