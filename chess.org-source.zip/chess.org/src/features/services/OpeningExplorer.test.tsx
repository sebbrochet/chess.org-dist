// @vitest-environment jsdom
import React, { act } from 'react';
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { afterEach, beforeAll, expect, it, vi } from 'vitest';
import { OpeningExplorer } from './OpeningExplorer';
import { lichessAccess, LICHESS_ACCESS_KEY } from '../../providers/lichessAccess';
import { exportBackup, parseBackup, prepareRestoration } from '../../storage/backup';
import { createLibrary, emptySnapshot, type DomainSnapshot } from '../../storage/library';
import { INITIAL_FEN } from 'chessops/fen';
import { makeUci } from 'chessops/util';
import { positionFromFen } from '../../chess/pgn';
import { ENGINE_VERSION, type AnalysisRequest, type LocalEngine } from '../../engine/stockfish';

vi.mock('../../components/Board', () => ({ Board: ({ fen, orientation, previewMove, onMove }: { fen: string; orientation: string; previewMove?: string; onMove?: (uci: string) => void }) => <div data-testid="opening-board" data-fen={fen} data-orientation={orientation} data-preview={previewMove}>Board<input aria-label="Board move" onChange={event => onMove?.(event.target.value)} /></div> }));
beforeAll(() => {
  HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
  HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); };
});
afterEach(() => { cleanup(); lichessAccess.remove(); localStorage.clear(); vi.unstubAllGlobals(); });
const sample = { white: 10, draws: 5, black: 5, moves: [{ uci: 'e2e4', white: 6, draws: 3, black: 1 }] };
function openAccess() { fireEvent.click(screen.getByRole('button', { name: 'Lichess API access' })); return within(screen.getByRole('dialog')); }
async function submit(token: string) {
  const dialog = openAccess(); fireEvent.change(dialog.getByLabelText('Lichess token'), { target: { value: token } });
  await act(async () => { fireEvent.click(dialog.getByRole('button', { name: 'Validate and Use' })); });
}
const explorerCalls = (fetcher: { mock: { calls: Parameters<typeof fetch>[] } }) => fetcher.mock.calls.filter(([url]) => String(url).startsWith('https://explorer.lichess.ovh/'));
const cloudCalls = (fetcher: { mock: { calls: Parameters<typeof fetch>[] } }) => fetcher.mock.calls.filter(([url]) => String(url).startsWith('https://lichess.org/api/cloud-eval'));
function anyMove(fen: string): string {
  for (const [from, dests] of positionFromFen(fen).allDests()) for (const to of dests) return makeUci({ from, to });
  throw new Error('No legal move.');
}
function fakeEngine(score: (fen: string) => number | undefined) {
  const analyze = vi.fn(async (request: AnalysisRequest) => {
    const value = score(request.fen);
    if (value === undefined) throw new Error('Engine unavailable.');
    const move = anyMove(request.fen);
    return { ...request, jobId: 'job', engineVersion: ENGINE_VERSION, bestmove: move, pv: [move], depth: 12, nodes: 12000, score: { kind: 'cp' as const, value, perspective: 'white' as const } };
  });
  return { engine: { analyze, cancelAll: vi.fn() } as unknown as LocalEngine, analyze };
}
const E4 = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1';
function explorerFetch(byFen: (fen: string) => object, cloud: (fen: string) => Response = () => new Response('', { status: 404 })) {
  return vi.fn<typeof fetch>().mockImplementation(async input => {
    const url = new URL(String(input)); const fen = url.searchParams.get('fen')!;
    return url.origin === 'https://lichess.org' ? cloud(fen) : new Response(JSON.stringify(byFen(fen)));
  });
}
const stats = (uci: string, white = 6, draws = 3, black = 1) => ({ uci, white, draws, black });

it('validates a masked session token, returns to the prepared query and survives view remounting', async () => {
  const fetcher = vi.fn<typeof fetch>().mockImplementation(async () => new Response(JSON.stringify(sample))); vi.stubGlobal('fetch', fetcher);
  const view = render(<OpeningExplorer />);
  const dialog = openAccess();
  expect(dialog.getByLabelText('Lichess token').getAttribute('type')).toBe('password');
  expect((dialog.getByLabelText('Remember on This Device') as HTMLInputElement).checked).toBe(false);
  fireEvent.change(dialog.getByLabelText('Lichess token'), { target: { value: 'lip_session_fixture' } });
  await act(async () => { fireEvent.click(dialog.getByRole('button', { name: 'Validate and Use' })); });
  expect(screen.queryByRole('dialog')).toBeNull();
  expect(screen.getByLabelText('Lichess access status').textContent).toBe('Accepted / Current Session');
  expect(localStorage.getItem(LICHESS_ACCESS_KEY)).toBeNull();
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  expect(screen.getByLabelText('Opening sample').textContent).toContain('20 games');
  expect(fetcher.mock.calls[1][1]?.headers).toEqual({ Authorization: 'Bearer lip_session_fixture' });
  view.unmount(); render(<OpeningExplorer />);
  expect(screen.getByLabelText('Lichess access status').textContent).toContain('Current Session');
});

it('preserves working access and previous results when replacement validation is refused', async () => {
  const fetcher = vi.fn<typeof fetch>().mockImplementation(async () => new Response(JSON.stringify(sample))); vi.stubGlobal('fetch', fetcher);
  render(<OpeningExplorer />); await submit('lip_working_fixture');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  fetcher.mockResolvedValue(new Response('private provider text', { status: 401 }));
  await submit('lip_rejected_fixture');
  expect(screen.getByRole('alert').textContent).toContain('authentication refused');
  expect(lichessAccess.getToken()).toBe('lip_working_fixture');
  expect(screen.getByLabelText('Opening sample').textContent).toContain('20 games');
  expect(screen.getByRole('alert').textContent).not.toContain('private provider text');
});

it('removes access during pending validation and rejects the late result', async () => {
  let resolve!: (response: Response) => void;
  vi.stubGlobal('fetch', vi.fn(() => new Promise<Response>(done => { resolve = done; })));
  render(<OpeningExplorer />); const dialog = openAccess();
  fireEvent.change(dialog.getByLabelText('Lichess token'), { target: { value: 'lip_late_fixture' } });
  fireEvent.click(dialog.getByRole('button', { name: 'Validate and Use' }));
  fireEvent.click(dialog.getByRole('button', { name: 'Remove' }));
  await act(async () => { resolve(new Response(JSON.stringify(sample))); });
  expect(lichessAccess.getToken()).toBeUndefined();
  expect(screen.getByLabelText('Lichess access status').textContent).toBe('Anonymous access');
  expect(localStorage.getItem(LICHESS_ACCESS_KEY)).toBeNull();
});

it('cancels validation on dialog closure without configuring access', async () => {
  let resolve!: (response: Response) => void;
  vi.stubGlobal('fetch', vi.fn(() => new Promise<Response>(done => { resolve = done; })));
  render(<OpeningExplorer />); const dialog = openAccess();
  fireEvent.change(dialog.getByLabelText('Lichess token'), { target: { value: 'lip_cancelled_fixture' } });
  fireEvent.click(dialog.getByRole('button', { name: 'Validate and Use' }));
  fireEvent.click(dialog.getByRole('button', { name: 'Close dialog' }));
  await act(async () => { resolve(new Response(JSON.stringify(sample))); });
  expect(lichessAccess.getToken()).toBeUndefined();
  expect(screen.queryByRole('dialog')).toBeNull();
});

it('retains explicit consent, keeps secrets out of backups and leaves access unchanged by restoration', async () => {
  vi.stubGlobal('fetch', vi.fn<typeof fetch>().mockImplementation(async () => new Response(JSON.stringify(sample))));
  render(<OpeningExplorer />); const dialog = openAccess();
  fireEvent.change(dialog.getByLabelText('Lichess token'), { target: { value: 'lip_device_fixture' } });
  fireEvent.click(dialog.getByLabelText('Remember on This Device'));
  expect(dialog.getByText(/not a secure vault/)).toBeTruthy();
  await act(async () => { fireEvent.click(dialog.getByRole('button', { name: 'Validate and Use' })); });
  expect(localStorage.getItem(LICHESS_ACCESS_KEY)).toBe('lip_device_fixture');
  const backup = exportBackup(emptySnapshot());
  expect(backup).not.toContain('lip_device_fixture');
  prepareRestoration(parseBackup(backup), emptySnapshot());
  expect(lichessAccess.getToken()).toBe('lip_device_fixture');
  fireEvent.click(openAccess().getByRole('button', { name: 'Remove' }));
  expect(localStorage.getItem(LICHESS_ACCESS_KEY)).toBeNull();
});

it('reports query refusal without replacing the last sample or hiding applied source context', async () => {
  const fetcher = vi.fn<typeof fetch>().mockImplementation(async () => new Response(JSON.stringify(sample))); vi.stubGlobal('fetch', fetcher);
  render(<OpeningExplorer />); await submit('lip_query_fixture');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  fetcher.mockResolvedValue(new Response('', { status: 429 }));
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  expect(screen.getByRole('alert').textContent).toContain('rate limit');
  expect(screen.getByLabelText('Lichess access status').textContent).toContain('Rate limited');
  expect(screen.getByLabelText('Opening sample').textContent).toContain('20 games');
  expect(screen.getByLabelText('Applied filters').textContent).toContain('1400,1600');
});

it('shows correctly based percentages and previews independent opening names without playing or requesting', async () => {
  const fetcher = vi.fn<typeof fetch>().mockImplementation(async () => new Response(JSON.stringify({ ...sample, opening: { eco: 'A00', name: 'Current opening' }, moves: [
    { ...sample.moves[0], opening: { eco: 'B00', name: "King's Pawn Game" } },
    { uci: 'd2d4', white: 0, draws: 0, black: 0, opening: null },
  ] }))); vi.stubGlobal('fetch', fetcher);
  render(<OpeningExplorer />);
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  expect(screen.getByLabelText('Opening name').textContent).toBe('A00 Current opening');
  expect(screen.getByRole('img', { name: 'White 60.0%, Draws 30.0%, Black 10.0%' })).toBeTruthy();
  expect(screen.getByRole('img', { name: 'White 50.0%, Draws 25.0%, Black 25.0%' })).toBeTruthy();
  expect(screen.getByRole('img', { name: 'No games' })).toBeTruthy();
  const board = screen.getByTestId('opening-board'); const fen = board.getAttribute('data-fen');
  const row = screen.getByRole('button', { name: 'e4' }).closest('tr')!;
  fireEvent.pointerEnter(row, { pointerType: 'mouse' });
  expect(board.getAttribute('data-preview')).toBe('e2e4');
  expect(screen.getByLabelText('Opening name').textContent).toBe("B00 King's Pawn Game");
  expect(board.getAttribute('data-fen')).toBe(fen);
  expect(explorerCalls(fetcher)).toHaveLength(1);
  fireEvent.pointerLeave(row);
  expect(board.getAttribute('data-preview')).toBeNull();
  expect(screen.getByLabelText('Opening name').textContent).toBe('A00 Current opening');
  fireEvent.focus(screen.getByRole('button', { name: 'Preview d4' }));
  expect(screen.getByLabelText('Opening name').textContent).toBe('Opening unknown');
  fireEvent.click(screen.getByRole('button', { name: 'Clear move preview' }));
  expect(screen.getByLabelText('Opening name').textContent).toBe('A00 Current opening');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  expect(board.getAttribute('data-preview')).toBeNull();
});

it('builds a navigable exploration tree from board and table moves, reusing fetched statistics', async () => {
  const fetcher = explorerFetch(fen => fen === INITIAL_FEN ? { white: 10, draws: 5, black: 5, moves: [stats('e2e4'), stats('d2d4', 0, 0, 0)] } : fen === E4 ? { white: 6, draws: 3, black: 1, moves: [stats('c7c6', 3, 1, 1)] } : { white: 0, draws: 0, black: 0, moves: [] });
  vi.stubGlobal('fetch', fetcher);
  render(<OpeningExplorer engine={fakeEngine(() => 0).engine} />);
  const board = screen.getByTestId('opening-board');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  expect((screen.getByRole('button', { name: 'Previous move' }) as HTMLButtonElement).disabled).toBe(true);
  await act(async () => { fireEvent.change(screen.getByLabelText('Board move'), { target: { value: 'e2e4' } }); });
  expect(board.getAttribute('data-fen')).toBe(E4);
  expect(await screen.findByLabelText('Position evaluation +0.0, Stockfish')).toBeTruthy();
  expect(within(screen.getByLabelText('Explored moves')).getByRole('button', { name: '1. e4' }).getAttribute('aria-current')).toBe('step');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'c6' })); });
  expect(within(screen.getByLabelText('Explored moves')).getByRole('button', { name: 'c6' }).getAttribute('aria-current')).toBe('step');
  expect(screen.getByText(/^No games/)).toBeTruthy();
  expect(explorerCalls(fetcher)).toHaveLength(3);
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'First position' })); });
  expect(board.getAttribute('data-fen')).toBe(INITIAL_FEN);
  expect(explorerCalls(fetcher)).toHaveLength(3);
  expect(screen.getByRole('button', { name: 'e4' }).closest('tr')!.getAttribute('data-explored')).toBe('true');
  expect(screen.getByRole('button', { name: 'd4' }).closest('tr')!.getAttribute('data-explored')).toBe('false');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'End of line' })); });
  expect(board.getAttribute('data-fen')).toContain('pp1ppppp/2p5');
  expect((screen.getByRole('button', { name: 'Next move' }) as HTMLButtonElement).disabled).toBe(true);
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'First position' })); });
  await act(async () => { fireEvent.change(screen.getByLabelText('Board move'), { target: { value: 'a2a3' } }); });
  expect(screen.getByRole('button', { name: '1. e4 (2 moves)' }).getAttribute('aria-expanded')).toBe('false');
  await act(async () => { fireEvent.change(screen.getByLabelText('Board move'), { target: { value: 'a2a5' } }); });
  expect(screen.getByRole('alert').textContent).toContain('legal move');
  fireEvent.click(screen.getByRole('button', { name: 'Flip board' }));
  expect(board.getAttribute('data-orientation')).toBe('black');
  expect(board.getAttribute('data-fen')).toContain('/P7/');
  expect(explorerCalls(fetcher)).toHaveLength(4);
  fireEvent.change(screen.getByLabelText('Position FEN'), { target: { value: E4 } });
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  expect(within(screen.getByLabelText('Explored moves')).getAllByRole('button')).toHaveLength(1);
});

it('evaluates candidates anonymously from the cloud first, then with Stockfish, and marks failures', async () => {
  const D4 = 'rnbqkbnr/pppppppp/8/8/3P4/8/PPP1PPPP/RNBQKBNR b KQkq - 0 1';
  const fetcher = explorerFetch(() => ({ white: 10, draws: 5, black: 5, moves: [stats('e2e4'), stats('d2d4'), stats('g1f3')] }), () => new Response(JSON.stringify({ depth: 50, pvs: [{ moves: 'e2e4 e7e5', cp: 20 }] })));
  vi.stubGlobal('fetch', fetcher);
  const { engine, analyze } = fakeEngine(fen => fen === D4 ? 31 : undefined);
  render(<OpeningExplorer engine={engine} />);
  await submit('lip_eval_fixture');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  expect(await screen.findByLabelText('Evaluation +0.2, Lichess cloud')).toBeTruthy();
  expect(await screen.findByLabelText('Evaluation +0.3, Stockfish')).toBeTruthy();
  expect(await screen.findByLabelText('Evaluation unavailable')).toBeTruthy();
  expect(screen.getByLabelText('Evaluation unavailable').textContent).toBe('n/a');
  expect(screen.getByLabelText('Position evaluation +0.2, Lichess cloud').textContent).toBe('Eval +0.2cloud');
  expect(analyze.mock.calls.map(([request]) => request.fen)).not.toContain(E4);
  expect(cloudCalls(fetcher)).toHaveLength(1);
  expect(cloudCalls(fetcher)[0][1]?.headers).toBeUndefined();
  expect(explorerCalls(fetcher).at(-1)![1]?.headers).toEqual({ Authorization: 'Bearer lip_eval_fixture' });
});

it('exports the explored tree as a repertoire with statistics and evaluation comments', async () => {
  let durable: DomainSnapshot = emptySnapshot();
  const library = createLibrary({ read: async () => structuredClone(durable), update: async change => { durable = change(structuredClone(durable)); } });
  const onSnapshot = vi.fn();
  vi.stubGlobal('fetch', explorerFetch(fen => fen === INITIAL_FEN ? { white: 10, draws: 5, black: 5, moves: [stats('e2e4')] } : { white: 0, draws: 0, black: 0, moves: [] }));
  render(<OpeningExplorer library={library} onSnapshot={onSnapshot} engine={fakeEngine(() => 31).engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Export as repertoire' }));
  let dialog = within(screen.getByRole('dialog'));
  await act(async () => { fireEvent.click(dialog.getByRole('button', { name: 'Save repertoire' })); });
  expect(dialog.getByRole('alert').textContent).toContain('Explore at least one move');
  expect(durable.repertoires).toHaveLength(0);
  fireEvent.click(dialog.getByRole('button', { name: 'Cancel' }));
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Explore position' })); });
  await screen.findByLabelText('Evaluation +0.3, Stockfish');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'e4' })); });
  await act(async () => { fireEvent.change(screen.getByLabelText('Board move'), { target: { value: 'c7c6' } }); });
  fireEvent.click(screen.getByRole('button', { name: 'Flip board' }));
  fireEvent.click(screen.getByRole('button', { name: 'Export as repertoire' }));
  dialog = within(screen.getByRole('dialog'));
  expect((dialog.getByLabelText('Side to learn') as HTMLSelectElement).value).toBe('black');
  expect((dialog.getByLabelText('Include statistics and evaluation comments') as HTMLInputElement).checked).toBe(true);
  fireEvent.change(dialog.getByLabelText('Repertoire name'), { target: { value: '' } });
  await act(async () => { fireEvent.click(dialog.getByRole('button', { name: 'Save repertoire' })); });
  expect(dialog.getByRole('alert').textContent).toContain('name');
  fireEvent.change(dialog.getByLabelText('Repertoire name'), { target: { value: 'Caro try' } });
  await act(async () => { fireEvent.click(dialog.getByRole('button', { name: 'Save repertoire' })); });
  expect(screen.queryByRole('dialog')).toBeNull();
  expect(screen.getByText(/Saved repertoire "Caro try"/)).toBeTruthy();
  const [book] = durable.repertoires;
  expect(book).toMatchObject({ name: 'Caro try', side: 'black' });
  expect(book.lines.map(line => line.moves)).toEqual([['e4', 'c6']]);
  expect(book.source).toContain('{ 10 games: White 60.0% / Draws 30.0% / Black 10.0%; Eval +0.3 (Stockfish) }');
  expect(book.source).toContain('Lichess ratings, not FIDE');
  expect(onSnapshot).toHaveBeenCalledOnce();
});