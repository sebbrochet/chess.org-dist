import { useRef, useState } from 'react';
import { ArrowDownToLine, ArrowUpFromLine, ShieldCheck } from 'lucide-react';
import { Modal } from '../../components/Modal';
import { exportBackup, MAX_BACKUP_SIZE, parseBackup } from '../../storage/backup';
import { localEngine } from '../../engine/stockfish';
import type { createLibrary, DomainSnapshot } from '../../storage/library';

export function Backup({ library, snapshot, onSnapshot }: { library: ReturnType<typeof createLibrary>; snapshot: DomainSnapshot; onSnapshot: (value: DomainSnapshot) => void }) {
  const [candidate, setCandidate] = useState<DomainSnapshot>(); const [filename, setFilename] = useState('');
  const [confirm, setConfirm] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [status, setStatus] = useState('');
  const lock = useRef(false); const readVersion = useRef(0);
  const counts = (data: DomainSnapshot) => `${data.games.length} games, ${data.reviews.length} reviews, ${data.repertoires.length} repertoires, ${data.puzzles.length} puzzles, ${data.mistakeAttempts.length + data.guessMoveAttempts.length + data.repertoireAttempts.length + data.puzzleAttempts.length} attempts`;
  async function download() {
    if (lock.current) return; lock.current = true; setBusy(true); setError(''); setStatus('');
    try {
      const latest = await library.load();
      const text = exportBackup(latest); const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
      const anchor = document.createElement('a'); anchor.href = url; anchor.download = `chess-org-backup-${new Date().toISOString().slice(0, 10)}.json`; anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000); setStatus('Full backup prepared.');
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Backup could not be prepared.'); }
    finally { lock.current = false; setBusy(false); }
  }
  async function read(file?: File) {
    const version = ++readVersion.current; setCandidate(undefined); setFilename(''); setError(''); setStatus('');
    if (!file) return;
    setBusy(true);
    try {
      if (file.size > MAX_BACKUP_SIZE) throw new Error('Backup exceeds the supported 100 MB size.');
      const parsed = parseBackup(await file.text());
      if (version === readVersion.current) { setCandidate(parsed); setFilename(file.name); }
    } catch (reason) { if (version === readVersion.current) setError(`Backup rejected: ${reason instanceof Error ? reason.message : 'Invalid input.'}`); }
    finally { if (version === readVersion.current) setBusy(false); }
  }
  async function restore() {
    if (!candidate || lock.current) return; lock.current = true; setBusy(true); setError(''); setStatus('');
    try {
      localEngine.cancelAll();
      const next = await library.restoreData(candidate); onSnapshot(next); setConfirm(false); setCandidate(undefined); setFilename(''); setStatus('Full backup restored. Previous local data was replaced.');
    } catch (reason) { setError(`Not restored: ${reason instanceof Error ? reason.message : 'Storage failure. Existing data is intact.'}`); }
    finally { lock.current = false; setBusy(false); }
  }
  return <main className="progress-workspace"><h1>Backup</h1>{error && <p className="error" role="alert">{error}</p>}{status && <p role="status" aria-label="Backup status">{status}</p>}
    <section><h2>Retained personal data</h2><p aria-label="Current data counts">{counts(snapshot)}</p><button className="primary" disabled={busy} onClick={() => void download()}><ArrowDownToLine size={17} />Export full backup</button></section>
    <section><h2>Restore personal data</h2><label className="field">Full backup file<input type="file" accept=".json,application/json" disabled={busy} onChange={event => void read(event.target.files?.[0])} /></label>
      {candidate && <><p aria-label="Validated backup"><ShieldCheck size={17} /> Validated: {filename}</p><p aria-label="Backup data counts">{counts(candidate)}</p><button disabled={busy} onClick={() => setConfirm(true)}><ArrowUpFromLine size={17} />Restore validated backup</button></>}
    </section>{confirm && candidate && <Modal title="Replace all local data?" busy={busy} onClose={() => setConfirm(false)}><p>Replace {counts(snapshot)} with {counts(candidate)} from {filename}?</p><p>Existing local records and history will be replaced. Running clocks keep their original time bases.</p>{error && <p className="error" role="alert">{error}</p>}<div className="dialog-actions"><button disabled={busy} onClick={() => setConfirm(false)}>Cancel</button><button className="danger" disabled={busy} onClick={() => void restore()}>Replace local data</button></div></Modal>}
  </main>;
}