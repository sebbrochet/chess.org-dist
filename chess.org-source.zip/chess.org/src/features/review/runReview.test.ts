import { describe, expect, it } from 'vitest';
import { createLibrary, emptySnapshot, migrateSnapshot } from '../../storage/library';
import { parseGames } from '../../chess/pgn';
import { captureReviewSource, REVIEW_BASIS } from '../../chess/review';
import { ENGINE_VERSION, type AnalysisRequest, type AnalysisResult, type LocalEngine } from '../../engine/stockfish';
import { runReview } from './runReview';
import { exportBackup, parseBackup } from '../../storage/backup';

function fixture(pgn = '1.e4 *') {
  let durable = emptySnapshot();
  let fail = false;
  const library = createLibrary({ read: async () => structuredClone(durable), update: async change => {
    const next = change(structuredClone(durable));
    if (fail) throw new Error('Quota');
    durable = next;
  } });
  const engine: LocalEngine = { cancelAll() {}, analyze: async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request,
    jobId: crypto.randomUUID(), engineVersion: ENGINE_VERSION, score: { kind: 'cp', value: 20, perspective: 'white' }, depth: 8, nodes: 12000, pv: [],
    bestmove: request.fen.split(' ')[1] === 'w' ? request.fen.includes('/4P3/') ? 'g1f3' : 'e2e4' : 'e7e5' }) };
  return { library, engine, read: () => structuredClone(durable), fail: (value: boolean) => { fail = value; }, start: async () => {
    const game = (await library.importGames(parseGames(pgn))).games[0];
    return (await library.beginReview(game.id)).reviews[0];
  } };
}

describe('durable review orchestration', () => {
  it('retains one search per missing after-move position and reuses completed continuation work', async () => {
    const test = fixture('1.e4 { [%eval 0.25] } *');
    const game = (await test.library.importGames(parseGames('1.e4 { [%eval 0.25] } *'))).games[0];
    const review = (await test.library.beginSupplement(game.id, 'continuations', 'white')).reviews[0];
    let searches = 0;
    const engine: LocalEngine = { cancelAll() {}, analyze: async request => { searches++; return { ...await test.engine.analyze(request), pv: ['e7e5'] }; } };
    await runReview(test.library, review, new AbortController().signal, () => {}, engine);
    expect(searches).toBe(1); expect(test.read().reviews[0]).toMatchObject({ purpose: 'supplement', status: 'Complete', entries: [], continuations: [{ ply: 0 }] });
    const resumed = (await test.library.beginSupplement(game.id, 'continuations', 'white')).reviews[0];
    await runReview(test.library, resumed, new AbortController().signal, () => {}, engine);
    expect(searches).toBe(1); expect(test.read().games[0]).toEqual(game);
    const forged = test.read(); const line = forged.reviews[0].continuations![0].evidence;
    if (line.kind !== 'search') throw new Error('Expected retained search');
    line.result.pv = ['c7c5'];
    expect(() => exportBackup(forged)).toThrow('inconsistent review');
  });
  it('makes a verified targeted mistake trainable while another candidate is pending, preserving original annotations and backup evidence', async () => {
    const test = fixture();
    const game = (await test.library.importGames(parseGames('1.d4 $4 { [%eval 0.1] Keep me } d5 2.e4 $2 *'))).games[0];
    const review = (await test.library.beginSupplement(game.id, 'practice', 'white')).reviews[0];
    const controller = new AbortController();
    const engine: LocalEngine = { cancelAll() {}, analyze: async request => ({ ...await test.engine.analyze(request), score: { kind: 'cp', value: request.fen === game.positions[1] ? -200 : 20, perspective: 'white' } }) };
    await expect(runReview(test.library, review, controller.signal, snapshot => {
      if (snapshot.reviews[0].preparation?.candidates[0].status === 'Verified eligible') controller.abort();
    }, engine)).rejects.toMatchObject({ name: 'AbortError' });
    expect(test.read().reviews[0]).toMatchObject({ status: 'Interrupted', preparation: { candidates: [{ ply: 0, status: 'Verified eligible' }, { ply: 2, status: 'Pending' }] } });
    const started = await test.library.startAttempt(game.id, 'mistake', 'white', 0);
    expect(started.mistakeAttempts[0]).toMatchObject({ fen: game.startFen, target: 'e2e4', status: 'Active' });
    expect(started.games[0]).toEqual(game);
    expect(parseBackup(exportBackup(started)).reviews[0].preparation).toEqual(started.reviews[0].preparation);
    const malformed = structuredClone(started); Reflect.deleteProperty(malformed.reviews[0].preparation!, 'candidates');
    expect(() => exportBackup(malformed)).toThrow('inconsistent review');
    const forged = structuredClone(started); forged.reviews[0].preparation!.candidates[1].status = 'Verified eligible';
    expect(() => exportBackup(forged)).toThrow('inconsistent review');
    await expect(test.library.startAttempt(game.id, 'mistake', 'white', 2)).rejects.toThrow('No eligible');
    const deleted = await test.library.deleteReview(review.id);
    expect(parseBackup(exportBackup(deleted)).mistakeAttempts).toEqual(started.mistakeAttempts);
  });
  it('resumes only missing continuation searches after interruption and backup restoration', async () => {
    const test = fixture();
    const game = (await test.library.importGames(parseGames('1.e4 { [%eval 0.25] } e5 *'))).games[0];
    const review = (await test.library.beginSupplement(game.id, 'continuations', 'white')).reviews[0];
    const controller = new AbortController(); let searches = 0;
    const engine: LocalEngine = { cancelAll() {}, analyze: async request => { searches++; const result = await test.engine.analyze(request); return { ...result, pv: [result.bestmove] }; } };
    await expect(runReview(test.library, review, controller.signal, next => { if (next.reviews[0].continuations?.length === 1) controller.abort(); }, engine)).rejects.toMatchObject({ name: 'AbortError' });
    const original = test.read().reviews[0].continuations![0];
    await test.library.restoreData(parseBackup(exportBackup(test.read())));
    const resumed = (await test.library.beginSupplement(game.id, 'continuations', 'white')).reviews[0];
    await runReview(test.library, resumed, new AbortController().signal, () => {}, engine);
    expect(searches).toBe(2); expect(test.read().reviews[0].continuations![0]).toEqual(original);
    expect(test.read().reviews[0].status).toBe('Complete');
  });
  it('rejects a supplied mistake annotation when completed local evidence does not meet eligibility', async () => {
    const test = fixture();
    const game = (await test.library.importGames(parseGames('1.e4 $4 { [%eval -8.0] } *'))).games[0];
    const review = (await test.library.beginSupplement(game.id, 'practice', 'white')).reviews[0];
    await runReview(test.library, review, new AbortController().signal, () => {}, test.engine);
    expect(test.read().reviews[0].preparation?.candidates[0].status).toBe('Rejected');
    await expect(test.library.startAttempt(game.id, 'mistake', 'white')).rejects.toThrow('No eligible');
    expect(test.read().games[0]).toEqual(game);
  });
  it('keeps failed targeted checks unverifiable and retries them without fabricating eligibility', async () => {
    const test = fixture();
    const game = (await test.library.importGames(parseGames('1.e4 $4 { [%eval -8.0] } *'))).games[0];
    const review = (await test.library.beginSupplement(game.id, 'practice', 'white')).reviews[0];
    await expect(runReview(test.library, review, new AbortController().signal, () => {}, { cancelAll() {}, analyze: async () => { throw new Error('Offline engine failure'); } })).rejects.toThrow('Offline engine failure');
    expect(test.read().reviews[0]).toMatchObject({ status: 'Interrupted', preparation: { candidates: [{ status: 'Unverifiable' }] } });
    expect(() => exportBackup(test.read())).not.toThrow();
    const retried = (await test.library.beginSupplement(game.id, 'practice', 'white')).reviews[0];
    expect(retried.preparation?.candidates[0].status).toBe('Pending');
    await runReview(test.library, retried, new AbortController().signal, () => {}, test.engine);
    expect(test.read().reviews[0].preparation?.candidates[0].status).toBe('Rejected');
    await expect(test.library.startAttempt(game.id, 'mistake', 'white')).rejects.toThrow('No eligible');
    expect(test.read().games[0]).toEqual(game);
  });
  it('only completes exhaustive evidence for the actual saved snapshot and never edits source moves', async () => {
    const test = fixture(); const review = await test.start();
    await expect(test.library.completeReview(review.id, review.generation, review.source.identity)).rejects.toThrow('incomplete');
    await runReview(test.library, review, new AbortController().signal, () => {}, test.engine);
    const saved = await test.library.load();
    expect(saved.reviews[0].status).toBe('Complete');
    expect(saved.reviews[0].entries).toHaveLength(1);
    expect(saved.reviews[0].basis).toEqual(REVIEW_BASIS);
    expect(saved.reviews[0].source).toEqual(captureReviewSource(saved.games[0]));
    expect(saved.games[0].pgn).toBe(parseGames('1.e4 *')[0].pgn);
  });
  it('recovers unfinished work as Interrupted on next load, retries and preserves training history on regenerate/delete', async () => {
    const test = fixture(); const review = await test.start();
    expect((await test.library.load()).reviews[0].status).toBe('Interrupted');
    const retried = (await test.library.retryReview(review.id)).reviews[0];
    expect(retried.generation).toBe(2);
    await runReview(test.library, retried, new AbortController().signal, () => {}, test.engine);
    await test.library.mutate(snapshot => ({ ...snapshot, mistakeAttempts: [{ id: 'attempt', gameId: review.gameId, reviewId: review.id, evidence: 'historical' }] }));
    const regenerated = await test.library.beginReview(review.gameId);
    expect(regenerated.reviews[0].generation).toBe(3);
    expect(regenerated.mistakeAttempts).toHaveLength(1);
    const deleted = await test.library.deleteReview(review.id);
    expect(deleted.reviews).toHaveLength(0); expect(deleted.games).toHaveLength(1); expect(deleted.mistakeAttempts).toHaveLength(1);
  });
  it('ignores late generation, navigation, review deletion and game deletion results', async () => {
    for (const action of ['generation', 'navigation', 'review', 'game'] as const) {
      const test = fixture(); const review = await test.start(); const controller = new AbortController();
      const engine: LocalEngine = { ...test.engine, analyze: async request => {
        if (action === 'generation') await test.library.beginReview(review.gameId);
        if (action === 'navigation') controller.abort();
        if (action === 'review') await test.library.deleteReview(review.id);
        if (action === 'game') await test.library.deleteGame(review.gameId);
        return test.engine.analyze(request);
      } };
      await expect(runReview(test.library, review, controller.signal, () => {}, engine)).rejects.toThrow();
      expect(test.read().reviews.some(record => record.status === 'Complete')).toBe(false);
      expect(test.read().reviews.every(record => record.entries.length === 0)).toBe(true);
    }
  });
  it('interrupts on worker failure or missing scores, retaining source and existing prefix', async () => {
    const test = fixture(); const review = await test.start();
    await expect(runReview(test.library, review, new AbortController().signal, () => {}, { ...test.engine, analyze: async () => { throw new Error('worker failed'); } })).rejects.toThrow('worker failed');
    expect(test.read().reviews[0]).toMatchObject({ status: 'Interrupted', entries: [], interruption: 'worker failed' });
    const retried = (await test.library.retryReview(review.id)).reviews[0];
    await expect(runReview(test.library, retried, new AbortController().signal, () => {}, { ...test.engine, analyze: async request => ({ ...await test.engine.analyze(request), score: undefined }) })).rejects.toThrow('Insufficient');
    expect(test.read().reviews[0].status).toBe('Interrupted');
  });
  it('rejects source mismatch and failed retention without declaring completion', async () => {
    const test = fixture(); const review = await test.start();
    await test.library.mutate(snapshot => ({ ...snapshot, games: snapshot.games.map(game => ({ ...game, ...parseGames('1.d4 *')[0] })) }));
    await expect(runReview(test.library, review, new AbortController().signal, () => {}, test.engine)).rejects.toThrow('source snapshot changed');
    await expect(test.library.retryReview(review.id)).rejects.toThrow('changed');
    const next = (await test.library.beginReview(review.gameId)).reviews[0];
    test.fail(true);
    await expect(test.library.completeReview(next.id, next.generation, next.source.identity)).rejects.toThrow();
    expect(test.read().reviews[0].status).toBe('Analysing');
    test.fail(false);
    expect((await test.library.load()).reviews[0].status).toBe('Interrupted');
  });
  it('migrates schema-1 cascade fixtures without erasing any personal records or extensions', () => {
    const game = { ...parseGames('1.e4 *')[0], id: 'g', createdAt: '2026-10-30', source: { kind: 'pgn' } };
    const legacy = { ...emptySnapshot(), schemaVersion: 1, games: [game], reviews: [{ id: 'r', gameId: 'g', legacy: 'preserved' }], extensions: { custom: 3 } };
    expect(migrateSnapshot(legacy)).toMatchObject({ schemaVersion: emptySnapshot().schemaVersion, games: [game], reviews: [{ id: 'r', gameId: 'g', status: 'Interrupted', legacy: 'preserved' }], extensions: { custom: 3 } });
    expect(legacy.schemaVersion).toBe(1);
  });
  it('retains a valid completed prefix through interruption and retries only unfinished moves', async () => {
    const test = fixture('1.e4 e5 *'); const review = await test.start(); const controller = new AbortController();
    await expect(runReview(test.library, review, controller.signal, snapshot => {
      if (snapshot.reviews[0].entries.length === 1) controller.abort();
    }, test.engine)).rejects.toMatchObject({ name: 'AbortError' });
    const interrupted = test.read().reviews[0];
    expect(interrupted.status).toBe('Interrupted'); expect(interrupted.entries).toHaveLength(1);
    const retried = (await test.library.retryReview(review.id)).reviews[0];
    await runReview(test.library, retried, new AbortController().signal, () => {}, test.engine);
    const completed = test.read().reviews[0];
    expect(completed.status).toBe('Complete'); expect(completed.entries).toHaveLength(2);
    expect(completed.entries[0]).toEqual(interrupted.entries[0]);
    expect(completed.entries[1].parent).toMatchObject({ kind: 'search', result: { generation: 2 } });
  });
  it('retains no invented entry when quota failure rejects an engine result and interruption write', async () => {
    const test = fixture(); const review = await test.start();
    const engine: LocalEngine = { ...test.engine, analyze: async request => { test.fail(true); return test.engine.analyze(request); } };
    await expect(runReview(test.library, review, new AbortController().signal, () => {}, engine)).rejects.toThrow('Quota');
    expect(test.read().reviews[0]).toMatchObject({ status: 'Analysing', entries: [] });
    test.fail(false);
    expect((await test.library.load()).reviews[0]).toMatchObject({ status: 'Interrupted', entries: [] });
  });
});