// @vitest-environment jsdom
import React, { useState } from 'react';
import { act, cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { afterEach, beforeAll, expect, it, vi } from 'vitest';
import { parseGames } from '../../chess/pgn';
import { captureReviewSource } from '../../chess/review';
import { GameReview, mistakePracticeHref, scoreLabel } from './GameReview';
import { runReview } from './runReview';
import { createLibrary, emptySnapshot, type DomainSnapshot } from '../../storage/library';
import { ENGINE_VERSION, type AnalysisRequest, type AnalysisResult, type LocalEngine } from '../../engine/stockfish';

vi.mock('../../components/Board', () => ({ Board: ({ fen, orientation, lastMove, moveGlyph, previewMove }: { fen: string; orientation: string; lastMove?: string; moveGlyph?: { text: string; label: string }; previewMove?: string }) => <div data-testid="board" data-orientation={orientation} data-last-move={lastMove} data-move-glyph={moveGlyph?.text} data-best-arrow={previewMove}>{fen}</div> }));
beforeAll(() => {
  HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
  HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); };
});
afterEach(cleanup);
async function fixture(pgn = '[White "Reviewer"]\n1.e4 *') {
  let durable = emptySnapshot(); let fail = false;
  const library = createLibrary({ read: async () => structuredClone(durable), update: async change => {
    const next = change(structuredClone(durable)); if (fail) throw new Error('Quota'); durable = next;
  } });
  const snapshot = await library.importGames(parseGames(pgn));
  const engine: LocalEngine = { cancelAll() {}, analyze: vi.fn(async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request, jobId: 'job',
    engineVersion: ENGINE_VERSION, score: { kind: 'cp', value: 30, perspective: 'white' }, depth: 8, nodes: 12000,
    bestmove: request.fen.split(' ')[1] === 'w' ? 'e2e4' : 'e7e5', pv: request.fen.split(' ')[1] === 'w' ? ['e2e4', 'e7e5'] : ['e7e5'] })) };
  return { library, snapshot, engine, read: () => structuredClone(durable), fail: () => { fail = true; } };
}
function Harness({ library, initial, engine, gameId = initial.games[0].id, request, consumed }: { library: ReturnType<typeof createLibrary>; initial: DomainSnapshot; engine: LocalEngine; gameId?: string; request?: string; consumed?: (requestId: string) => void }) {
  const [snapshot, setSnapshot] = useState(initial);
  return <GameReview library={library} snapshot={snapshot} onSnapshot={setSnapshot} gameId={gameId} engine={engine} reviewRequest={request} onReviewRequestConsumed={consumed} />;
}

async function finishedFixture() {
  const test = await fixture();
  const started = await test.library.startComputer(test.snapshot.games[0].startFen, { side: 'white', level: 4, takebacks: false, time: null }, 0);
  const game = started.games.at(-1)!;
  const moved = await test.library.play(game.id, { version: game.computer!.version, fen: game.startFen }, { type: 'move', move: 'd2d4', actor: 'player' }, 1);
  const latest = moved.games.at(-1)!;
  await test.library.play(game.id, { version: latest.computer!.version, fen: latest.positions.at(-1)! }, { type: 'resign' }, 2);
  return { ...test, snapshot: test.read(), gameId: game.id };
}

it('browses original imported evaluations and glyphs without local analysis and cancels replacement without changes', async () => {
  const test = await fixture('1.e4 $4 { [%eval -1.25,24] Blunder. d4 was best. } (1.d4 d5) *');
  const original = test.read();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  expect(screen.getByLabelText('Review status').textContent).toContain('Imported PGN analysis / 1 of 1');
  expect(screen.getByLabelText('Imported annotation ??').textContent).toBe('??');
  const continuationAction = screen.getByRole('button', { name: 'Review game' });
  const fullAction = screen.getByRole('button', { name: 'Full local review' });
  const preparationAction = screen.getByRole('button', { name: 'Prepare mistakes' });
  expect(continuationAction.getAttribute('title')).toContain('only missing local continuations');
  expect(fullAction.getAttribute('title')).toContain('After confirmation and completion');
  expect(preparationAction.getAttribute('title')).toContain("selected side's imported ? and ??");
  expect(continuationAction.querySelector('.lucide-git-branch')).toBeTruthy();
  expect(fullAction.querySelector('.lucide-microscope')).toBeTruthy();
  expect(preparationAction.querySelector('.lucide-target')).toBeTruthy();
  expect(screen.getByTestId('board').getAttribute('data-move-glyph')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByTestId('board').getAttribute('data-move-glyph')).toBe('??');
  fireEvent.click(screen.getByRole('button', { name: 'Flip board' }));
  expect(screen.getByTestId('board').getAttribute('data-move-glyph')).toBe('??');
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'c5' } });
  fireEvent.click(screen.getByRole('button', { name: 'Explore move' }));
  expect(screen.getByTestId('board').getAttribute('data-move-glyph')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Undo exploration' }));
  expect(screen.getByTestId('board').getAttribute('data-move-glyph')).toBe('??');
  expect(screen.getByLabelText('Recorded position evaluation').textContent).toBe('-1.25');
  expect(screen.getByLabelText('Imported move annotations').textContent).toContain('Blunder. d4 was best.');
  expect(screen.getByText('Imported continuation unavailable.')).toBeTruthy();
  expect(screen.queryByRole('link', { name: 'Practice mistakes' })).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Full local review' }));
  expect(screen.getByRole('dialog').textContent).toContain('original PGN');
  fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
  expect(test.read()).toEqual(original); expect(test.engine.analyze).not.toHaveBeenCalled();
});

it('switches from imported evidence only after confirmed completion and reveals it again on local deletion', async () => {
  const test = await fixture('1.e4 $6 { [%eval -1.25] Original annotation } *');
  const original = test.read().games;
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Full local review' }));
  expect(test.engine.analyze).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('button', { name: 'Start local review' }));
  await waitFor(() => expect(screen.getByLabelText('Review status').textContent).toContain('Complete / 1 of 1'));
  expect(screen.queryByLabelText('Imported annotation ?!')).toBeNull();
  expect(test.read().games).toEqual(original);
  fireEvent.click(screen.getByRole('button', { name: 'Delete review' }));
  fireEvent.click(screen.getByRole('button', { name: 'Delete analysis' }));
  await waitFor(() => expect(screen.getByLabelText('Review status').textContent).toContain('Imported PGN analysis'));
  expect(screen.getByLabelText('Imported annotation ?!')).toBeTruthy();
  expect(test.read().games).toEqual(original);
});

it('keeps imported evidence active during a confirmed run, cancellation and a late engine result', async () => {
  const test = await fixture('1.e4 $4 { [%eval -1.25] Original evidence } *');
  const original = test.read().games; const baseAnalyze = test.engine.analyze;
  let release: ((result: AnalysisResult) => void) | undefined; let pending: AnalysisRequest | undefined;
  const engine: LocalEngine = { cancelAll() {}, analyze: vi.fn(request => { pending = request; return new Promise<AnalysisResult>(resolve => { release = resolve; }); }) };
  render(<Harness library={test.library} initial={test.snapshot} engine={engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Full local review' }));
  fireEvent.click(screen.getByRole('button', { name: 'Start local review' }));
  await waitFor(() => expect(engine.analyze).toHaveBeenCalledOnce());
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Recorded position evaluation').textContent).toBe('-1.25');
  expect(screen.getByLabelText('Local review status').textContent).toContain('Analysing / 0 of 1');
  fireEvent.click(screen.getByRole('button', { name: 'Cancel analysis' }));
  await waitFor(() => expect(screen.getByLabelText('Local review status').textContent).toContain('Interrupted'));
  await act(async () => { release?.(await baseAnalyze(pending!)); });
  expect(screen.getByLabelText('Review status').textContent).toContain('Imported PGN analysis');
  expect(screen.getByLabelText('Recorded position evaluation').textContent).toBe('-1.25');
  expect(test.read().reviews[0]).toMatchObject({ status: 'Interrupted', entries: [] });
  expect(test.read().games).toEqual(original);
});

it.each(['engine', 'storage'] as const)('preserves imported display on %s failure after confirmation', async failure => {
  const test = await fixture('1.e4 $6 { [%eval 0.25] Preserved } *');
  const original = test.read().games;
  if (failure === 'engine') vi.mocked(test.engine.analyze).mockRejectedValue(new Error('Engine unavailable'));
  else test.fail();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Full local review' }));
  fireEvent.click(screen.getByRole('button', { name: 'Start local review' }));
  await waitFor(() => expect(screen.getByRole('alert').textContent).toContain(failure === 'engine' ? 'Engine unavailable' : 'Quota'));
  expect(screen.getByLabelText('Review status').textContent).toContain('Imported PGN analysis');
  expect(screen.getByLabelText('Imported annotation ?!')).toBeTruthy();
  expect(test.read().games).toEqual(original);
});

it('rejects a confirmation after the displayed recorded source changes without starting an engine', async () => {
  const test = await fixture('1.e4 { [%eval 0.25] } *');
  const changed = structuredClone(test.snapshot);
  const view = render(<GameReview library={test.library} snapshot={test.snapshot} onSnapshot={() => {}} gameId={test.snapshot.games[0].id} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Full local review' }));
  changed.games[0] = { ...changed.games[0], ...parseGames('1.d4 { [%eval 0.15] } *')[0] };
  view.rerender(<GameReview library={test.library} snapshot={changed} onSnapshot={() => {}} gameId={changed.games[0].id} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Start local review' }));
  expect(screen.getByRole('alert').textContent).toContain('source changed');
  expect(test.engine.analyze).not.toHaveBeenCalled(); expect(test.read().reviews).toHaveLength(0);
});

it('marks a recorded move matching the engine first choice as Best move and its predecessor continuation as Played next', async () => {
  const test = await fixture('1.d4 e5 *');
  const analyze = test.engine.analyze;
  vi.mocked(analyze).mockImplementation(async request => {
    const best = request.fen.split(' ')[1] === 'w' ? 'e2e4' : 'e7e5';
    return { ...request, jobId: 'job', engineVersion: ENGINE_VERSION, score: { kind: 'cp', value: 30, perspective: 'white' }, depth: 8, nodes: 12000, bestmove: best, pv: [best] };
  });
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Review game' })); });
  await waitFor(() => expect(screen.getByLabelText('Review status').textContent).toContain('Complete / 2 of 2'));
  expect(screen.getAllByLabelText('Best move')).toHaveLength(1);
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByTestId('board').getAttribute('data-move-glyph')).toBeNull();
  const first = screen.getByLabelText('Engine continuation').querySelector('button')!;
  expect(first.className).toBe('played-next');
  expect(first.textContent).toBe('e5 Played next');
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByTestId('board').getAttribute('data-move-glyph')).toBe('\u2605');
  expect(screen.getByLabelText('Best move', { selector: 'p' }).textContent).toContain("matched Stockfish's first choice");
});

it('consumes an explicit post-game request once under Strict Mode and retains the exact completed source', async () => {
  const test = await finishedFixture(); const original = test.read().games;
  const consumed = vi.fn(); const begin = vi.spyOn(test.library, 'beginFirstReview');
  render(<React.StrictMode><Harness library={test.library} initial={test.snapshot} engine={test.engine} gameId={test.gameId} request="post-game-once" consumed={consumed} /></React.StrictMode>);
  await waitFor(() => expect(screen.getByLabelText('Review status').textContent).toContain('Complete / 1 of 1'));
  expect(begin).toHaveBeenCalledOnce(); expect(consumed).toHaveBeenCalledExactlyOnceWith('post-game-once');
  expect(test.read().reviews).toHaveLength(1);
  expect(test.read().reviews[0]).toMatchObject({ gameId: test.gameId, generation: 1, source: { moves: ['d4'] } });
  expect(test.read().games).toEqual(original);
});

it('defaults an annotated post-game handoff to a non-destructive continuation supplement', async () => {
  const test = await finishedFixture();
  const annotated = await test.library.mutate(snapshot => ({ ...snapshot, games: snapshot.games.map(game => game.id === test.gameId ? { ...game, pgn: game.pgn.replace('d4', 'd4 { [%eval 0.15] }') } : game) }));
  const first = vi.spyOn(test.library, 'beginFirstReview');
  render(<Harness library={test.library} initial={annotated} engine={test.engine} gameId={test.gameId} request="annotated-post-game" />);
  await waitFor(() => expect(screen.getByLabelText('Local review status').textContent).toContain('Complete'));
  expect(screen.queryByRole('dialog')).toBeNull(); expect(first).not.toHaveBeenCalled();
  expect(test.read().reviews[0]).toMatchObject({ purpose: 'supplement', entries: [], continuations: [{ ply: 0 }] });
  expect(screen.getByLabelText('Review status').textContent).toContain('Imported PGN analysis');
  expect(test.read().games).toEqual(annotated.games);
});

it('adds local continuations without replacing imported scores or original glyphs', async () => {
  const test = await fixture('1.e4 $4 { [%eval -1.25] Still supplied } *');
  const original = test.read().games;
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Review game' }));
  await waitFor(() => expect(screen.getByLabelText('Local review status').textContent).toContain('Complete'));
  expect(screen.queryByRole('dialog')).toBeNull(); expect(test.engine.analyze).toHaveBeenCalledOnce();
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Recorded position evaluation').textContent).toBe('-1.25');
  expect(screen.getByLabelText('Continuation source').textContent).toContain('Locally generated');
  expect(within(screen.getByLabelText('Engine continuation')).getByRole('button', { name: 'e5' })).toBeTruthy();
  expect(screen.queryByRole('link', { name: 'Practice mistakes' })).toBeNull();
  expect(test.read().games).toEqual(original);
});

it('prepares an imported candidate independently and offers practice without replacing the study display', async () => {
  const test = await fixture('1.d4 $4 { [%eval 0.15] Original study explanation } *');
  const original = test.read().games;
  const analyze = vi.mocked(test.engine.analyze).getMockImplementation()!;
  vi.mocked(test.engine.analyze).mockImplementation(async (request, signal) => ({ ...await analyze(request, signal), score: { kind: 'cp', value: request.fen === original[0].positions[1] ? -200 : 30, perspective: 'white' } }));
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Prepare mistakes' }));
  await waitFor(() => expect(screen.getByLabelText('Practice preparation').textContent).toContain('Verified eligible'));
  expect(screen.getByRole('link', { name: 'Practice mistakes' }).getAttribute('href')).toContain('side=white');
  expect(screen.getByLabelText('Review status').textContent).toContain('Imported PGN analysis');
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Recorded position evaluation').textContent).toBe('+0.15');
  expect(screen.getByLabelText('Imported move annotations').textContent).toContain('Original study explanation');
  expect(test.read().games).toEqual(original);
});

it.each(['Analysing', 'Interrupted', 'Complete'] as const)('opens a retained %s review without implicit analysis or regeneration', async status => {
  const test = await finishedFixture();
  const begun = await test.library.beginReview(test.gameId); const review = begun.reviews[0];
  if (status === 'Complete') await runReview(test.library, review, new AbortController().signal, () => {}, test.engine);
  else if (status === 'Interrupted') await test.library.interruptReview(review.id, review.generation, 'Fixture interruption');
  const initial = test.read(); vi.mocked(test.engine.analyze).mockClear();
  const begin = vi.spyOn(test.library, 'beginFirstReview'); const consumed = vi.fn();
  render(<Harness library={test.library} initial={initial} engine={test.engine} gameId={test.gameId} request={`reuse-${status}`} consumed={consumed} />);
  await waitFor(() => expect(consumed).toHaveBeenCalledOnce());
  expect(begin).not.toHaveBeenCalled(); expect(test.engine.analyze).not.toHaveBeenCalled();
  expect(test.read()).toEqual(initial);
});

it('reports failed post-game storage without losing the completed game or claiming a retained review', async () => {
  const test = await finishedFixture(); const original = test.read(); test.fail();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} gameId={test.gameId} request="storage-failure" />);
  await waitFor(() => expect(screen.getByRole('alert').textContent).toContain('Quota'));
  expect(test.read()).toEqual(original); expect(test.read().reviews).toHaveLength(0);
  expect(test.engine.analyze).not.toHaveBeenCalled();
});

it('retains a failed post-game engine run as incomplete and never automatically retries it', async () => {
  const test = await finishedFixture(); const original = test.read().games;
  const engine: LocalEngine = { cancelAll: vi.fn(), analyze: vi.fn().mockRejectedValue(new Error('Engine unavailable')) };
  const begin = vi.spyOn(test.library, 'beginFirstReview');
  render(<Harness library={test.library} initial={test.snapshot} engine={engine} gameId={test.gameId} request="engine-failure" />);
  await waitFor(() => expect(screen.getByLabelText('Review status').textContent).toContain('Interrupted'));
  expect(begin).toHaveBeenCalledOnce(); expect(engine.analyze).toHaveBeenCalledOnce();
  expect(test.read().reviews[0]).toMatchObject({ status: 'Interrupted', generation: 1 });
  expect(test.read().games).toEqual(original);
});

it('previews the retained after-move snapshot without changing exploration, drafts or requesting engine work', async () => {
  const test = await fixture('1.e4 e5 *');
  const reviewed = await test.library.beginReview(test.snapshot.games[0].id);
  const original = structuredClone(reviewed);
  const changed = parseGames('1.d4 d5 *')[0];
  reviewed.games[0] = { ...reviewed.games[0], ...changed };
  render(<Harness library={test.library} initial={reviewed} engine={test.engine} />);
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'd4' } });
  fireEvent.click(screen.getByRole('button', { name: 'Explore move' }));
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'd5' } });
  const position = screen.getByTestId('board').textContent;
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after 1. e4' }));
  const popup = screen.getByRole('dialog', { name: 'Position after 1. e4' });
  expect(popup.querySelector('.mini-board-frame')?.getAttribute('data-fen')).toBe(original.games[0].positions[1]);
  expect(screen.getByTestId('board').textContent).toBe(position);
  expect(screen.getByLabelText('Exploration moves').textContent).toBe('d4');
  expect((screen.getByLabelText('Explore SAN') as HTMLInputElement).value).toBe('d5');
  fireEvent.click(within(popup).getByRole('button', { name: 'Dismiss move preview' }));
  expect(test.engine.analyze).not.toHaveBeenCalled();
  expect(test.read()).toEqual(original);
});

it('shows recorded player names on the correct sides through flipping without changing saved data', async () => {
  const test = await fixture('[White "Franzine_Echec"]\n[Black "selbrochet"]\n1.e4 c6 *');
  const original = test.read();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  const names = () => Array.from(screen.getByLabelText('Review board').querySelectorAll('.player-line strong')).map(label => label.textContent);
  expect(names()).toEqual(['selbrochet', 'Franzine_Echec']);
  expect(screen.getByTestId('board').getAttribute('data-orientation')).toBe('white');
  fireEvent.click(screen.getByRole('button', { name: 'Flip board' }));
  expect(names()).toEqual(['Franzine_Echec', 'selbrochet']);
  expect(screen.getByTestId('board').getAttribute('data-orientation')).toBe('black');
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(names()).toEqual(['Franzine_Echec', 'selbrochet']);
  expect(test.read()).toEqual(original);
  expect(test.engine.analyze).not.toHaveBeenCalled();
});

it.each(['1.e4 *', '[White "?"]\n[Black " "]\n1.e4 *'])('falls back to color names for unavailable player headers: %s', async pgn => {
  const test = await fixture(pgn);
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  const names = () => Array.from(screen.getByLabelText('Review board').querySelectorAll('.player-line strong')).map(label => label.textContent);
  expect(names()).toEqual(['Black', 'White']);
  fireEvent.click(screen.getByRole('button', { name: 'Flip board' }));
  expect(names()).toEqual(['White', 'Black']);
});

it('retains a completed review, reopens without engine work and explores SAN/PV without editing source', async () => {
  const test = await fixture();
  const review = (await test.library.beginReview(test.snapshot.games[0].id)).reviews[0];
  await runReview(test.library, review, new AbortController().signal, () => {}, test.engine);
  const saved = test.read(); vi.mocked(test.engine.analyze).mockClear();
  render(<Harness library={test.library} initial={saved} engine={test.engine} />);
  expect(screen.getByLabelText('Review status').textContent).toContain('Complete / 1 of 1');
  expect(test.engine.analyze).not.toHaveBeenCalled();
  expect(screen.queryByLabelText('Selected move evidence')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  fireEvent.click(within(screen.getByLabelText('Engine continuation')).getByRole('button', { name: 'e5' }));
  expect(screen.getByTestId('board').textContent).toBe(parseGames('1.e4 e5 *')[0].positions[2]);
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'Nc3' } });
  fireEvent.click(screen.getByRole('button', { name: 'Explore move' }));
  expect(screen.getByLabelText('Exploration moves').textContent).toBe('e5 Nc3');
  expect(test.read().games).toEqual(saved.games);
  fireEvent.click(screen.getByRole('button', { name: 'Undo exploration' }));
  expect(screen.getByTestId('board').textContent).toBe(parseGames('1.e4 e5 *')[0].positions[2]);
  expect(mistakePracticeHref(saved.reviews[0], 'black')).toContain(`?side=black&source=${review.id}&generation=1`);
});

it('distinguishes unmarked analyzed moves from pending coverage and explains retained evidence without mutations', async () => {
  const test = await fixture();
  const retained = (await test.library.beginReview(test.snapshot.games[0].id)).reviews[0];
  await runReview(test.library, retained, new AbortController().signal, () => {}, test.engine);
  const saved = test.read(); const extended = parseGames('1.e4 e5 *')[0];
  saved.games[0] = { ...saved.games[0], ...extended };
  saved.reviews[0].source = captureReviewSource(extended); saved.reviews[0].status = 'Interrupted';
  const original = structuredClone(saved); vi.mocked(test.engine.analyze).mockClear();
  render(<Harness library={test.library} initial={saved} engine={test.engine} />);
  const moves = within(screen.getByLabelText('Reviewed moves'));
  expect(moves.getByRole('button', { name: /^1\. e4/ }).textContent).toContain('Analysed');
  expect(moves.getByRole('button', { name: /^1\.\.\. e5/ }).textContent).toContain('Not analysed');
  expect(screen.queryByLabelText('Move assessment')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Move assessment').textContent).toContain('Below annotation threshold');
  expect(screen.getByLabelText('Move assessment').textContent).toContain('estimated winning-chance loss: 0.00 percentage points');
  expect(screen.getByLabelText('Move assessment').textContent).toContain('Not a mistake-practice candidate');
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Move assessment').textContent).toBe('Not analysed');
  expect(saved).toEqual(original); expect(test.engine.analyze).not.toHaveBeenCalled();
});

it.each([
  { best: 0, actual: -200, label: 'Blunder', glyph: '??', loss: '2.00', practice: true },
  { best: 0, actual: -120, label: 'Mistake', glyph: '?', loss: '1.20', practice: true },
  { best: 0, actual: -60, label: 'Inaccuracy', glyph: '?!', loss: '0.60', practice: false },
  { best: 1000, actual: 700, label: 'Below annotation threshold', glyph: '', loss: '3.00', practice: true },
])('explains $label independently of practice eligibility using the children, not the parent', async ({ best, actual, label, glyph, loss, practice }) => {
  const test = await fixture('1.d4 *');
  vi.mocked(test.engine.analyze).mockImplementation(async request => ({ ...request, jobId: 'annotation-test', engineVersion: ENGINE_VERSION, depth: 8, nodes: 12000,
    bestmove: request.fen.split(' ')[1] === 'w' ? 'e2e4' : 'e7e5', pv: request.fen.split(' ')[1] === 'w' ? ['e2e4', 'e7e5'] : ['e7e5'],
    score: { kind: 'cp', value: request.fen === test.snapshot.games[0].startFen ? -900 : request.fen === parseGames('1.e4 *')[0].positions[1] ? best : actual, perspective: 'white' } }));
  const retained = (await test.library.beginReview(test.snapshot.games[0].id)).reviews[0];
  await runReview(test.library, retained, new AbortController().signal, () => {}, test.engine);
  const original = test.read(); vi.mocked(test.engine.analyze).mockClear();
  render(<Harness library={test.library} initial={original} engine={test.engine} />);
  if (glyph) expect(screen.getByLabelText(label).textContent).toBe(glyph);
  else expect(screen.getByLabelText('Reviewed moves').querySelector('.review-glyph')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Move assessment').textContent).toContain(label);
  expect(screen.getByTestId('board').getAttribute('data-move-glyph')).toBe(glyph || null);
  expect(screen.getByLabelText('Move assessment').textContent).toContain(`${loss} pawns lost`);
  expect(screen.getByLabelText('Move assessment').textContent).toContain(practice ? 'Eligible for mistake practice' : 'Not a mistake-practice candidate');
  const disclosure = screen.getByLabelText('Move assessment').closest('details');
  if (glyph) expect(disclosure).toBeNull();
  else {
    expect(disclosure).toBe(screen.getByText('Analysis details').closest('details'));
    expect(disclosure!.open).toBe(false);
    fireEvent.click(screen.getByText('Analysis details'));
    expect(disclosure!.open).toBe(true);
    expect(screen.getByLabelText('Move assessment').textContent).toContain(label);
  }
  expect(test.read()).toEqual(original); expect(test.engine.analyze).not.toHaveBeenCalled();
});

it('withholds grades for incomparable evidence instead of treating absent support as a zero loss', async () => {
  const test = await fixture();
  const retained = (await test.library.beginReview(test.snapshot.games[0].id)).reviews[0];
  await runReview(test.library, retained, new AbortController().signal, () => {}, test.engine);
  const saved = test.read(); const child = saved.reviews[0].entries[0].actualChild;
  if (child.kind !== 'search') throw new Error('Expected search fixture');
  child.result.limits = { nodes: 1 };
  vi.mocked(test.engine.analyze).mockClear();
  render(<Harness library={test.library} initial={saved} engine={test.engine} />);
  expect(within(screen.getByLabelText('Reviewed moves')).getByTitle('Evidence unavailable')).toBeTruthy();
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Move assessment').textContent).toBe('Evidence unavailable');
  expect(screen.queryByText('Below annotation threshold')).toBeNull();
  expect(test.engine.analyze).not.toHaveBeenCalled();
});

it('shows only the recorded-position score prominently and keeps diagnostics in collapsed Analysis details', async () => {
  const test = await fixture();
  const retained = (await test.library.beginReview(test.snapshot.games[0].id)).reviews[0];
  await runReview(test.library, retained, new AbortController().signal, () => {}, test.engine);
  const original = test.read(); vi.mocked(test.engine.analyze).mockClear();
  render(<Harness library={test.library} initial={original} engine={test.engine} />);
  const details = screen.getByText('Analysis details').closest('details')!;
  expect(details.open).toBe(false);
  expect(screen.queryByLabelText('Recorded position evaluation')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Recorded position evaluation').textContent).toBe(scoreLabel(original.reviews[0].entries[0].actualChild.score));
  expect(screen.getByLabelText('Recorded position evaluation').closest('details')).toBeNull();
  expect(screen.getByLabelText('Selected move evidence').compareDocumentPosition(screen.getByLabelText('Reviewed moves')) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
  expect(screen.getByLabelText('Engine continuation').compareDocumentPosition(screen.getByLabelText('Reviewed moves')) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
  expect(screen.getByLabelText('Reviewed moves').compareDocumentPosition(details) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
  for (const label of ['Analysis basis', 'Equal child effort', 'Protocol', 'Score perspective', 'Before recorded move / White', 'After best move / White', 'After recorded move / White']) {
    expect(within(details).getByText(label)).toBeTruthy();
  }
  expect(details.open).toBe(false);
  fireEvent.click(screen.getByText('Analysis details'));
  expect(details.open).toBe(true);
  expect(screen.getByLabelText('Engine continuation').closest('details')).toBeNull();
  expect(test.read()).toEqual(original);
  expect(test.engine.analyze).not.toHaveBeenCalled();
});

it('jumps to first and last recorded positions and clears exploration without changing source', async () => {
  const test = await fixture('1.e4 e5 2.Nf3 Nc6 *');
  const original = test.read();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  expect((screen.getByRole('button', { name: 'First position' }) as HTMLButtonElement).disabled).toBe(true);
  expect((screen.getByRole('button', { name: 'Last position' }) as HTMLButtonElement).disabled).toBe(false);
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'c5' } });
  fireEvent.click(screen.getByRole('button', { name: 'Explore move' }));
  expect(screen.getByLabelText('Exploration moves').textContent).toBe('c5');
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'Nc3' } });
  fireEvent.click(screen.getByRole('button', { name: 'First position' }));
  expect(screen.getByTestId('board').textContent).toBe(original.games[0].positions[0]);
  expect(screen.queryByLabelText('Exploration moves')).toBeNull();
  expect((screen.getByLabelText('Explore SAN') as HTMLInputElement).value).toBe('');
  fireEvent.click(screen.getByRole('button', { name: 'Last position' }));
  expect(screen.getByTestId('board').textContent).toBe(original.games[0].positions[4]);
  expect((screen.getByRole('button', { name: 'Last position' }) as HTMLButtonElement).disabled).toBe(true);
  expect((screen.getByRole('button', { name: 'Next recorded move' }) as HTMLButtonElement).disabled).toBe(true);
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'Bc4' } });
  fireEvent.click(screen.getByRole('button', { name: 'Explore move' }));
  expect((screen.getByRole('button', { name: 'Last position' }) as HTMLButtonElement).disabled).toBe(false);
  fireEvent.click(screen.getByRole('button', { name: 'Last position' }));
  expect(screen.getByTestId('board').textContent).toBe(original.games[0].positions[4]);
  expect(screen.queryByLabelText('Exploration moves')).toBeNull();
  expect(test.read()).toEqual(original);
  expect(test.engine.analyze).not.toHaveBeenCalled();
});

it('reveals navigated move rows by scrolling only the list without stealing control focus', async () => {
  const test = await fixture('1.e4 e5 2.Nf3 Nc6 *');
  const original = test.read();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  const list = screen.getByLabelText('Reviewed moves');
  const bounds = (top: number, bottom: number) => ({ top, bottom, left: 0, right: 200, width: 200, height: bottom - top, x: 0, y: top, toJSON() {} });
  vi.spyOn(list, 'getBoundingClientRect').mockReturnValue(bounds(100, 200));
  Object.defineProperty(list, 'clientHeight', { configurable: true, value: 100 });
  const rows = Array.from(list.children);
  vi.spyOn(rows[1], 'getBoundingClientRect').mockReturnValue(bounds(180, 220));
  vi.spyOn(rows[2], 'getBoundingClientRect').mockReturnValue(bounds(140, 180));
  vi.spyOn(rows[3], 'getBoundingClientRect').mockReturnValue(bounds(80, 120));
  vi.spyOn(rows[4], 'getBoundingClientRect').mockReturnValue(bounds(280, 320));
  vi.spyOn(rows[0], 'getBoundingClientRect').mockReturnValue(bounds(20, 60));
  const next = screen.getByRole('button', { name: 'Next recorded move' });
  next.focus(); fireEvent.click(next);
  expect(list.scrollTop).toBe(20); expect(document.activeElement).toBe(next);
  fireEvent.click(next);
  expect(list.scrollTop).toBe(20);
  fireEvent.click(next);
  expect(list.scrollTop).toBe(0);
  fireEvent.click(screen.getByRole('button', { name: 'Last position' }));
  expect(list.scrollTop).toBe(120);
  fireEvent.click(screen.getByRole('button', { name: 'First position' }));
  expect(list.scrollTop).toBe(40);
  expect(screen.getByRole('button', { name: 'Start' }).getAttribute('aria-current')).toBe('step');
  expect(test.read()).toEqual(original); expect(test.engine.analyze).not.toHaveBeenCalled();
});

it('disables both endpoint jumps for an empty recorded game', async () => {
  const test = await fixture('*');
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  expect((screen.getByRole('button', { name: 'First position' }) as HTMLButtonElement).disabled).toBe(true);
  expect((screen.getByRole('button', { name: 'Last position' }) as HTMLButtonElement).disabled).toBe(true);
  expect(screen.getByRole('button', { name: 'Start' }).getAttribute('aria-current')).toBe('step');
  expect(screen.queryByLabelText('Selected move evidence')).toBeNull();
});

it('selects Start and after-move positions consistently with previews without modifying recorded sources', async () => {
  const test = await fixture('1.e4 e5 2.Nf3 *'); const original = test.read();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  const moves = within(screen.getByLabelText('Reviewed moves'));
  expect(moves.getByRole('button', { name: 'Start' }).getAttribute('aria-current')).toBe('step');
  fireEvent.click(moves.getByRole('button', { name: /^1\. e4/ }));
  expect(screen.getByTestId('board').textContent).toBe(original.games[0].positions[1]);
  expect(moves.getByRole('button', { name: /^1\. e4/ }).getAttribute('aria-current')).toBe('step');
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after 1. e4' }));
  expect(screen.getByRole('dialog').querySelector('.mini-board-frame')?.getAttribute('data-fen')).toBe(screen.getByTestId('board').textContent);
  fireEvent.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Dismiss move preview' }));
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByTestId('board').textContent).toBe(original.games[0].positions[2]);
  fireEvent.click(moves.getByRole('button', { name: 'Start' }));
  expect(screen.getByTestId('board').textContent).toBe(original.games[0].startFen);
  expect(test.read()).toEqual(original);
  expect(test.engine.analyze).not.toHaveBeenCalled();
});

it('uses the played move child continuation instead of the pre-move best alternative', async () => {
  const test = await fixture('1.d4 *');
  const retained = (await test.library.beginReview(test.snapshot.games[0].id)).reviews[0];
  await runReview(test.library, retained, new AbortController().signal, () => {}, test.engine);
  const original = test.read(); vi.mocked(test.engine.analyze).mockClear();
  render(<Harness library={test.library} initial={original} engine={test.engine} />);
  expect(screen.queryByLabelText('Selected move evidence')).toBeNull();
  fireEvent.click(within(screen.getByLabelText('Reviewed moves')).getByRole('button', { name: /^1\. d4/ }));
  expect(screen.getByTestId('board').textContent).toBe(original.games[0].positions[1]);
  expect(screen.getByTestId('board').getAttribute('data-last-move')).toBe('d2d4');
  expect(within(screen.getByLabelText('Selected move evidence')).getByRole('heading', { name: 'd4 / white' })).toBeTruthy();
  expect(within(screen.getByLabelText('Engine continuation')).queryByRole('button', { name: 'e4' })).toBeNull();
  fireEvent.click(within(screen.getByLabelText('Engine continuation')).getByRole('button', { name: 'e5' }));
  expect(screen.getByTestId('board').textContent).toBe(parseGames('1.d4 e5 *')[0].positions[2]);
  expect(screen.getByTestId('board').getAttribute('data-last-move')).toBe('e7e5');
  expect(screen.getByLabelText('Exploration moves').textContent).toBe('e5');
  fireEvent.click(screen.getByRole('button', { name: 'Undo exploration' }));
  expect(screen.getByTestId('board').textContent).toBe(original.games[0].positions[1]);
  fireEvent.click(within(screen.getByLabelText('Reviewed moves')).getByRole('button', { name: 'Start' }));
  expect(screen.queryByLabelText('Selected move evidence')).toBeNull();
  expect(test.read()).toEqual(original);
  expect(test.engine.analyze).not.toHaveBeenCalled();
});

it('previews continuation positions and arrows without changing recorded selection, drafts, exploration or evidence', async () => {
  const test = await fixture('1.d4 *');
  const retained = (await test.library.beginReview(test.snapshot.games[0].id)).reviews[0];
  await runReview(test.library, retained, new AbortController().signal, () => {}, test.engine);
  const original = test.read(); vi.mocked(test.engine.analyze).mockClear();
  render(<Harness library={test.library} initial={original} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'e5' } });
  const before = screen.getByTestId('board').textContent;
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after continuation 1: e5' }));
  const popup = screen.getByRole('dialog', { name: 'Position after continuation 1: e5' });
  expect(popup.querySelector('.mini-board-frame')?.getAttribute('data-fen')).toBe(parseGames('1.d4 e5 *')[0].positions[2]);
  await waitFor(() => expect(popup.querySelectorAll('.cg-shapes line')).toHaveLength(1));
  expect(screen.getByTestId('board').textContent).toBe(before);
  expect((screen.getByLabelText('Explore SAN') as HTMLInputElement).value).toBe('e5');
  expect(screen.queryByLabelText('Exploration moves')).toBeNull();
  fireEvent.click(within(popup).getByRole('button', { name: 'Dismiss move preview' }));
  expect(test.read()).toEqual(original); expect(test.engine.analyze).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after continuation 1: e5' }));
  fireEvent.click(within(screen.getByLabelText('Reviewed moves')).getByRole('button', { name: 'Start' }));
  expect(screen.queryByRole('dialog')).toBeNull();
});

it('reports missing retained continuation without borrowing the parent line', async () => {
  const test = await fixture('1.d4 *');
  const retained = (await test.library.beginReview(test.snapshot.games[0].id)).reviews[0];
  await runReview(test.library, retained, new AbortController().signal, () => {}, test.engine);
  const saved = test.read();
  const child = saved.reviews[0].entries[0].actualChild;
  if (child.kind !== 'search') throw new Error('Expected retained search fixture');
  child.result.pv = [];
  render(<Harness library={test.library} initial={saved} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByText('Retained continuation unavailable.')).toBeTruthy();
  expect(within(screen.getByLabelText('Engine continuation')).queryByRole('button')).toBeNull();
});

it('shows no continuation for a terminal recorded child and makes no preview engine requests', async () => {
  const test = await fixture('[SetUp "1"]\n[FEN "7k/5Q2/6K1/8/8/8/8/8 w - - 0 1"]\n1.Qg7# 1-0');
  const engine: LocalEngine = { cancelAll: vi.fn(), analyze: vi.fn(async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request, jobId: 'mate-fixture', engineVersion: ENGINE_VERSION, score: { kind: 'cp', value: 30, perspective: 'white' }, depth: 8, nodes: 12000, bestmove: 'f7g7', pv: ['f7g7'] })) };
  const retained = (await test.library.beginReview(test.snapshot.games[0].id)).reviews[0];
  await runReview(test.library, retained, new AbortController().signal, () => {}, engine);
  const original = test.read(); vi.mocked(engine.analyze).mockClear();
  render(<Harness library={test.library} initial={original} engine={engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByText('No continuation: the recorded position is terminal.')).toBeTruthy();
  expect(screen.getByLabelText('Move assessment').textContent).toContain('Retained mate outcome: white wins');
  expect(within(screen.getByLabelText('Engine continuation')).queryByRole('button')).toBeNull();
  expect(engine.analyze).not.toHaveBeenCalled(); expect(test.read()).toEqual(original);
});

it('generates with real orchestration and confirms independent removal in a native dialog', async () => {
  const test = await fixture();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Review game' }));
  await waitFor(() => expect(screen.getByLabelText('Review status').textContent).toContain('Complete'));
  fireEvent.click(screen.getByRole('button', { name: 'Delete review' }));
  expect(screen.getByRole('dialog')).toBeInstanceOf(HTMLDialogElement);
  expect(test.read().reviews).toHaveLength(1);
  fireEvent.click(screen.getByRole('button', { name: 'Delete analysis' }));
  await waitFor(() => expect(screen.getByLabelText('Review status').textContent).toBe('Not analysed'));
  expect(test.read().games).toEqual(test.snapshot.games);
  expect(test.read().reviews).toHaveLength(0);
});

it('cancels on navigation and never accepts a late reply from an engine ignoring abort', async () => {
  const test = await fixture();
  let release: ((value: AnalysisResult) => void) | undefined; let request: AnalysisRequest | undefined; let signal: AbortSignal | undefined;
  const engine: LocalEngine = { cancelAll() {}, analyze: vi.fn((next: AnalysisRequest, abort?: AbortSignal) => { request = next; signal = abort; return new Promise<AnalysisResult>(resolve => { release = resolve; }); }) };
  const view = render(<Harness library={test.library} initial={test.snapshot} engine={engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Review game' }));
  await waitFor(() => expect(engine.analyze).toHaveBeenCalledOnce());
  view.unmount();
  await waitFor(() => expect(test.read().reviews[0].status).toBe('Interrupted'));
  expect(signal?.aborted).toBe(true);
  await act(async () => { release?.(await test.engine.analyze(request!)); });
  expect(test.read().reviews[0].entries).toHaveLength(0);
  expect(test.read().games).toEqual(test.snapshot.games);
});

it('does not claim retained analysis on storage failure, and exposes worker failure as retryable', async () => {
  const test = await fixture(); test.fail();
  const first = render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Review game' }));
  await waitFor(() => expect(screen.getByRole('alert').textContent).toContain('Quota'));
  expect(test.read().reviews).toHaveLength(0); first.unmount();
  const second = await fixture();
  render(<Harness library={second.library} initial={second.snapshot} engine={{ cancelAll() {}, analyze: vi.fn().mockRejectedValue(new Error('Worker failed')) }} />);
  fireEvent.click(screen.getByRole('button', { name: 'Review game' }));
  await waitFor(() => expect(screen.getByLabelText('Review status').textContent).toContain('Interrupted'));
  expect(screen.getByRole('button', { name: 'Retry review' })).toBeTruthy();
  expect(second.read().reviews[0].entries).toHaveLength(0);
});

it('keeps explored variations inline, reorganises them and never changes the recorded game', async () => {
  const test = await fixture('1.e4 e5 2.Nf3 *');
  const first = render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  const play = (move: string) => { fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: move } }); fireEvent.click(screen.getByRole('button', { name: 'Explore move' })); };
  const branchMoves = () => test.read().analysisLines[0]?.branches[0].moves.map(move => move.uci);
  play('e4');
  expect(screen.getByRole('button', { name: /^1\. e4/ }).getAttribute('aria-current')).toBe('step');
  expect(test.read().analysisLines).toEqual([]);
  play('c5');
  await waitFor(() => expect(branchMoves()).toEqual(['c7c5']));
  expect(screen.getByRole('button', { name: 'Variation 1... c5' }).getAttribute('aria-current')).toBe('step');
  expect(screen.getByLabelText('Exploration moves').textContent).toBe('c5');
  play('Nf3');
  await waitFor(() => expect(test.read().analysisLines[0].branches[0].moves[0].children.map(move => move.uci)).toEqual(['g1f3']));
  fireEvent.click(screen.getByRole('button', { name: 'Previous variation move' }));
  expect(screen.getByRole('button', { name: 'Variation 1... c5' }).getAttribute('aria-current')).toBe('step');
  fireEvent.click(screen.getByRole('button', { name: /^1\. e4/ }));
  play('e6');
  await waitFor(() => expect(branchMoves()).toEqual(['c7c5', 'e7e6']));
  fireEvent.click(screen.getByRole('button', { name: 'Promote variation' }));
  await waitFor(() => expect(branchMoves()).toEqual(['e7e6', 'c7c5']));
  expect((screen.getByRole('button', { name: 'Promote variation' }) as HTMLButtonElement).disabled).toBe(true);
  fireEvent.click(screen.getByRole('button', { name: 'Variation 1... c5' }));
  fireEvent.click(screen.getByRole('button', { name: 'Delete from here' }));
  await waitFor(() => expect(branchMoves()).toEqual(['e7e6']));
  expect(screen.queryByRole('button', { name: 'Variation 2. Nf3' })).toBeNull();
  expect(screen.getByRole('button', { name: /^1\. e4/ }).getAttribute('aria-current')).toBe('step');
  const revision = test.read().revision;
  play('e6');
  expect(screen.getByRole('button', { name: 'Variation 1... e6' }).getAttribute('aria-current')).toBe('step');
  expect(test.read().revision).toBe(revision);
  expect(test.read().games).toEqual(test.snapshot.games);
  expect(test.read().reviews).toHaveLength(0);
  expect(test.engine.analyze).not.toHaveBeenCalled();
  first.unmount();
  render(<Harness library={test.library} initial={test.read()} engine={test.engine} />);
  expect(screen.getByRole('button', { name: 'Variation 1... e6' })).toBeTruthy();
});

it('keeps a variation on the board when it cannot be saved', async () => {
  const test = await fixture('1.e4 e5 *');
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  test.fail();
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'c5' } });
  fireEvent.click(screen.getByRole('button', { name: 'Explore move' }));
  await waitFor(() => expect(screen.getByRole('alert').textContent).toContain('Not saved'));
  expect(screen.getByRole('button', { name: 'Variation 1... c5' }).getAttribute('aria-current')).toBe('step');
  expect(screen.getByTestId('board').textContent).toContain('2p5');
  expect(test.read().analysisLines).toEqual([]);
});

it('shows imported side lines read-only and keeps moves played from them as the Player\'s own line', async () => {
  const test = await fixture('1.e4 e5 (1...c5 2.Nf3) *');
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Imported variation 1... c5' }));
  expect(screen.getByRole('group', { name: 'Selected variation' }).textContent).toContain('read-only');
  expect(screen.queryByRole('button', { name: 'Delete from here' })).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Next variation move' }));
  expect(screen.getByRole('button', { name: 'Imported variation 2. Nf3' }).getAttribute('aria-current')).toBe('step');
  fireEvent.change(screen.getByLabelText('Explore SAN'), { target: { value: 'd6' } });
  fireEvent.click(screen.getByRole('button', { name: 'Explore move' }));
  await waitFor(() => expect(test.read().analysisLines[0]?.branches).toEqual([{ ply: 1, fen: test.snapshot.games[0].positions[1], moves: [{ uci: 'c7c5', children: [{ uci: 'g1f3', children: [{ uci: 'd7d6', children: [] }] }] }] }]));
  expect(screen.getByRole('button', { name: 'Variation 2... d6' }).getAttribute('aria-current')).toBe('step');
  expect(test.read().games).toEqual(test.snapshot.games);
});

it('evaluates displayed positions only with the Live engine on, once per position, and keeps the choice', async () => {
  const test = await fixture();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  const live = screen.getByRole('switch', { name: 'Live engine' }) as HTMLInputElement;
  expect(live.checked).toBe(false);
  expect(screen.queryByLabelText('Position evaluation')).toBeNull();
  expect(test.engine.analyze).not.toHaveBeenCalled();
  fireEvent.click(live);
  await waitFor(() => expect(test.read().extensions.reviewLiveEngine).toBe(true));
  await waitFor(() => expect(screen.getByLabelText('Position evaluation').textContent).toBe('+0.3 Stockfish / White'));
  expect(screen.getByTestId('board').getAttribute('data-best-arrow')).toBe('e2e4');
  expect(test.engine.analyze).toHaveBeenCalledTimes(1);
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  await waitFor(() => expect(test.engine.analyze).toHaveBeenCalledTimes(2));
  await waitFor(() => expect(within(screen.getByRole('list', { name: 'Reviewed moves' })).getByRole('button', { name: /^1\. e4/ }).textContent).toContain('+0.3'));
  fireEvent.click(screen.getByRole('button', { name: 'First position' }));
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Position evaluation').textContent).toContain('+0.3');
  expect(test.engine.analyze).toHaveBeenCalledTimes(2);
  expect(test.read().reviews).toHaveLength(0);
  fireEvent.click(live);
  await waitFor(() => expect(test.read().extensions.reviewLiveEngine).toBe(false));
  expect(screen.queryByLabelText('Position evaluation')).toBeNull();
  expect(screen.getByTestId('board').getAttribute('data-best-arrow')).toBeNull();
  expect(within(screen.getByRole('list', { name: 'Reviewed moves' })).getByRole('button', { name: /^1\. e4/ }).textContent).not.toContain('+0.3');
});

it('reuses retained Review evaluations and shows n/a when the live engine fails', async () => {
  const test = await fixture();
  render(<Harness library={test.library} initial={test.snapshot} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Review game' }));
  await waitFor(() => expect(screen.getByLabelText('Review status').textContent).toContain('Complete'));
  const calls = vi.mocked(test.engine.analyze).mock.calls.length;
  expect(screen.getByLabelText('Position evaluation').textContent).toBe('+0.3 Review / White');
  expect(screen.getByTestId('board').getAttribute('data-best-arrow')).toBeNull();
  fireEvent.click(screen.getByRole('switch', { name: 'Live engine' }));
  await waitFor(() => expect(test.read().extensions.reviewLiveEngine).toBe(true));
  expect(screen.getByTestId('board').getAttribute('data-best-arrow')).toBe('e2e4');
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Position evaluation').textContent).toContain('Review');
  expect(screen.getByTestId('board').getAttribute('data-best-arrow')).toBe('e7e5');
  expect(test.engine.analyze).toHaveBeenCalledTimes(calls);
  cleanup();
  const failing = await fixture();
  const broken = await failing.library.changeReviewSettings({ liveEngine: true });
  render(<Harness library={failing.library} initial={broken} engine={{ cancelAll() {}, analyze: vi.fn().mockRejectedValue(new Error('Worker failed')) }} />);
  await waitFor(() => expect(screen.getByLabelText('Position evaluation').textContent).toBe('n/a Stockfish / White'));
  expect(screen.getByTestId('board').getAttribute('data-best-arrow')).toBeNull();
  expect(failing.read().games).toEqual(failing.snapshot.games);
});

it('shows no best-move arrow for an imported evaluation without a retained local continuation', async () => {
  const test = await fixture('1.e4 { [%eval 0.25] } *');
  const live = await test.library.changeReviewSettings({ liveEngine: true });
  render(<Harness library={test.library} initial={live} engine={test.engine} />);
  fireEvent.click(screen.getByRole('button', { name: 'Next recorded move' }));
  expect(screen.getByLabelText('Position evaluation').textContent).toBe('+0.3 Imported PGN / White');
  expect(screen.getByTestId('board').getAttribute('data-best-arrow')).toBeNull();
  expect(test.engine.analyze).toHaveBeenCalledTimes(1);
});