import { analyzeRecordedMove, analyzeReviewPosition, type Review } from '../../chess/review';
import { positionFromFen } from '../../chess/pgn';
import { localEngine, type LocalEngine } from '../../engine/stockfish';
import type { createLibrary, DomainSnapshot } from '../../storage/library';

export async function runReview(library: ReturnType<typeof createLibrary>, review: Review, signal: AbortSignal,
  onSnapshot: (snapshot: DomainSnapshot) => void, engine: LocalEngine = localEngine): Promise<void> {
  const current = () => !signal.aborted;
  try {
    if (review.purpose === 'supplement') {
      if (review.task === 'continuations') {
        for (let ply = 0; ply < review.source.moves.length; ply++) {
          if (review.continuations?.some(line => line.ply === ply)) continue;
          const evidence = await analyzeReviewPosition(engine, review.source.positions[ply + 1], review.gameId, review.generation, signal, review.basis);
          const next = await library.retainContinuation(review.id, review.generation, review.source.identity, ply, evidence, current);
          if (current()) onSnapshot(next);
        }
      } else {
        for (const candidate of review.preparation?.candidates ?? []) {
          if (candidate.status !== 'Pending' || positionFromFen(review.source.positions[candidate.ply]).turn !== review.preparation!.side) continue;
          try {
            const evidence = await analyzeRecordedMove(engine, review.source, candidate.ply, review.gameId, review.generation, signal, review.basis);
            const next = await library.retainPreparation(review.id, review.generation, review.source.identity, { ply: candidate.ply, status: evidence.judgment.mistake ? 'Verified eligible' : 'Rejected', evidence }, current);
            if (current()) onSnapshot(next);
          } catch (reason) {
            if (current()) {
              const next = await library.retainPreparation(review.id, review.generation, review.source.identity, { ply: candidate.ply, status: 'Unverifiable', error: reason instanceof Error ? reason.message : 'Verification unavailable.' }, current);
              onSnapshot(next);
            }
            throw reason;
          }
        }
      }
      const next = await library.completeReview(review.id, review.generation, review.source.identity, current);
      if (current()) onSnapshot(next);
      return;
    }
    for (let ply = review.entries.length; ply < review.source.moves.length; ply++) {
      const entry = await analyzeRecordedMove(engine, review.source, ply, review.gameId, review.generation, signal, review.basis);
      const next = await library.appendReview(review.id, review.generation, review.source.identity, entry, current);
      if (current()) onSnapshot(next);
    }
    const next = await library.completeReview(review.id, review.generation, review.source.identity, current);
    if (current()) onSnapshot(next);
  } catch (reason) {
    const next = await library.interruptReview(review.id, review.generation, reason instanceof Error ? reason.message : 'Engine analysis interrupted.');
    if (current()) onSnapshot(next);
    throw reason;
  }
}