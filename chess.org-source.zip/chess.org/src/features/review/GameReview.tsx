import { useEffect, useMemo, useRef, useState, type ReactElement } from 'react';
import { ArrowUp, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, FlipVertical2, GitBranch, Microscope, RotateCcw, Square, Target, Trash2 } from 'lucide-react';
import { makeFen } from 'chessops/fen';
import { makeSanAndPlay, parseSan } from 'chessops/san';
import { makeUci, parseSquare, parseUci } from 'chessops/util';
import { Board } from '../../components/Board';
import { MovePreviewProvider, PreviewableMove } from '../../components/MovePreview';
import { Modal } from '../../components/Modal';
import { EventLine, PlayerBar } from '../../components/PlayerBar';
import { importedGameAnalysis, lastRecordedMove, positionFromFen } from '../../chess/pgn';
import { analyzeReviewPosition, annotateMove, captureReviewSource, eligibleMistakes, hasValidPrefix, legalContinuation, REVIEW_BASIS, type Evidence, type Review } from '../../chess/review';
import { localEngine, type EngineScore, type LocalEngine } from '../../engine/stockfish';
import { reviewLiveEngine, type createLibrary, type DomainSnapshot } from '../../storage/library';
import { evaluationLabel, scoreLabel as compactScoreLabel } from '../play/PlayComputer';
import { addMove, createTree, deleteFrom, isMainline, mainline, moveLabel, pathTo, promoteVariation, ROOT, type GameTree } from '../../chess/gameTree';
import { branchFromTree, branchTree, importedBranches, recordedUci } from '../../chess/analysisLines';

type Owner = 'mine' | 'imported';
const uciOf = (fen: string, san: string) => makeUci(parseSan(positionFromFen(fen), san)!);
import { runReview } from './runReview';

const message = (reason: unknown) => reason instanceof Error ? reason.message : 'Review operation failed.';
export const scoreLabel = (score: EngineScore) => score.kind === 'cp' ? `${score.value >= 0 ? '+' : ''}${(score.value / 100).toFixed(2)}` : `Mate ${Math.abs(score.value)} / ${score.winner} wins`;
export const mistakePracticeHref = (review: Review, side: 'white' | 'black') => `#/practice/mistakes/${encodeURIComponent(review.gameId)}?side=${side}&source=${encodeURIComponent(review.id)}&generation=${review.generation}`;
const evidenceLabel = (evidence: Evidence) => `${scoreLabel(evidence.score)}${evidence.kind === 'terminal' ? ` (${evidence.reason})` : ` / depth ${evidence.result.depth}, ${evidence.result.searchedNodes ?? evidence.result.nodes} searched nodes`}`;

export function GameReview({ library, snapshot, onSnapshot, gameId, reviewRequest, onReviewRequestConsumed, engine = localEngine }: {
  library: ReturnType<typeof createLibrary>; snapshot: DomainSnapshot; onSnapshot: (snapshot: DomainSnapshot) => void; gameId?: string; reviewRequest?: string; onReviewRequestConsumed?: (requestId: string) => void; engine?: LocalEngine;
}) {
  const game = snapshot.games.find(record => record.id === gameId);
  const review = snapshot.reviews.find(record => record.gameId === gameId);
  const imported = game ? importedGameAnalysis(game) : undefined;
  const mismatch = !!game && !!review && review.source.identity !== captureReviewSource(game).identity;
  const validPrefix = !!review && hasValidPrefix(review);
  const complete = !!review && review.purpose !== 'supplement' && review.status === 'Complete' && review.entries.length === review.source.moves.length && validPrefix;
  const usingImported = !!imported && (!complete || mismatch);
  const source = usingImported && game ? captureReviewSource(game) : review?.source ?? (game ? captureReviewSource(game) : undefined);
  const [ply, setPly] = useState(0);
  const [path, setPath] = useState<{ san: string; fen: string; beforeFen: string }[]>([]);
  const [san, setSan] = useState('');
  const [side, setSide] = useState<'white' | 'black'>(game?.computer?.options.side ?? 'white');
  const [flipped, setFlipped] = useState(false);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [promotion, setPromotion] = useState('');
  const [replacementIdentity, setReplacementIdentity] = useState<string>();
  const alive = useRef(true);
  const lock = useRef(false);
  const active = useRef<{ controller: AbortController; review?: Review }>();
  const handledRequest = useRef<string>();
  const handoff = useRef<() => void>();
  const movesRef = useRef<HTMLOListElement>(null);
  const liveCache = useRef(new Map<string, { label: string; best?: string }>());
  const [, setLiveVersion] = useState(0);
  const liveOn = reviewLiveEngine(snapshot);
  useEffect(() => { liveCache.current.clear(); }, [gameId]);

  useEffect(() => {
    alive.current = true;
    const stop = () => {
      const run = active.current;
      run?.controller.abort();
      if (run?.review) void library.interruptReview(run.review.id, run.review.generation, 'Analysis stopped on navigation, hiding or closure. Retry to continue.').then(onSnapshot).catch(() => {});
    };
    const visibility = () => { if (document.hidden) stop(); };
    document.addEventListener('visibilitychange', visibility);
    window.addEventListener('pagehide', stop);
    return () => { alive.current = false; stop(); document.removeEventListener('visibilitychange', visibility); window.removeEventListener('pagehide', stop); };
  }, [library, onSnapshot]);

  async function start(retry: boolean, firstOnly = false, confirmedSource?: string, task?: 'continuations' | 'practice') {
    if (!game || lock.current) return;
    if (usingImported && !confirmedSource && !task && (!retry || review?.purpose === 'supplement')) task = retry && review?.purpose === 'supplement' ? review.task : 'continuations';
    const taskSide = retry && task === 'practice' ? review?.preparation?.side ?? side : side;
    if (confirmedSource && confirmedSource !== captureReviewSource(game).identity) { setReplacementIdentity(undefined); setError('Review source changed. Request replacement again.'); return; }
    lock.current = true; setSaving(true); setError('');
    active.current?.controller.abort();
    const controller = new AbortController();
    const run: { controller: AbortController; review?: Review } = { controller };
    active.current = run;
    try {
      const first = firstOnly && !task ? await library.beginFirstReview(game.id, REVIEW_BASIS, () => !controller.signal.aborted, confirmedSource) : undefined;
      if (first && !first.started) { if (alive.current) onSnapshot(first.snapshot); return; }
      const next = task ? await library.beginSupplement(game.id, task, taskSide, () => !controller.signal.aborted) : first?.snapshot ?? (retry && review ? await library.retryReview(review.id, () => !controller.signal.aborted)
        : await library.beginReview(game.id, REVIEW_BASIS, () => !controller.signal.aborted, confirmedSource));
      const retained = next.reviews.find(record => record.gameId === game.id)!;
      run.review = retained;
      if (alive.current) { onSnapshot(next); setPly(0); setPath([]); setSaving(false); if (task === 'practice') setSide(taskSide); }
      await runReview(library, retained, controller.signal, onSnapshot, engine);
    } catch (reason) { if (alive.current && !controller.signal.aborted) setError(message(reason)); }
    finally { if (active.current === run) { active.current = undefined; lock.current = false; if (alive.current) setSaving(false); } }
  }

  handoff.current = () => {
    if (!reviewRequest || handledRequest.current === reviewRequest) return;
    handledRequest.current = reviewRequest; onReviewRequestConsumed?.(reviewRequest);
    if (game?.computer && game.result !== '*' && !review) void start(false, true);
  };
  useEffect(() => {
    if (!reviewRequest) return;
    const timer = window.setTimeout(() => handoff.current?.(), 0);
    return () => window.clearTimeout(timer);
  }, [reviewRequest]);

  async function cancel() {
    active.current?.controller.abort();
    if (!review) return;
    setSaving(true); setError('');
    try { onSnapshot(await library.interruptReview(review.id, review.generation, 'Cancelled by Player. Partial analysis retained.')); }
    catch (reason) { setError(`Not saved: ${message(reason)}`); }
    finally { if (alive.current) setSaving(false); }
  }

  async function remove() {
    if (!review) return;
    active.current?.controller.abort();
    setSaving(true); setError('');
    try { onSnapshot(await library.deleteReview(review.id)); setDeleting(false); setPly(0); setPath([]); }
    catch (reason) { setError(`Not saved: ${message(reason)}`); }
    finally { if (alive.current) setSaving(false); }
  }

  const cursor = Math.min(ply, source?.moves.length ?? 0);
  const editable = !!game && !!source && source.identity === captureReviewSource(game).identity;
  const storedLines = snapshot.analysisLines.find(record => record.gameId === gameId);
  const [localLines, setLocalLines] = useState<{ gameId: string; trees: Record<number, GameTree> }>();
  const myTrees = useMemo(() => {
    if (localLines && localLines.gameId === gameId) return localLines.trees;
    const trees: Record<number, GameTree> = {};
    for (const branch of storedLines?.branches ?? []) { try { trees[branch.ply] = branchTree(branch); } catch { /* stale line: not shown */ } }
    return trees;
  }, [localLines, gameId, storedLines]);
  const gamePgn = game?.pgn;
  const importedTrees = useMemo(() => { try { return gamePgn ? importedBranches(gamePgn) : {}; } catch { return {}; } }, [gamePgn]);
  const [selected, setSelected] = useState<{ owner: Owner; id: number }>();
  const treeAt = (owner: Owner, at: number): GameTree | undefined => {
    const tree = (owner === 'mine' ? myTrees : importedTrees)[at];
    return tree && tree.nodes[ROOT].children.length && tree.nodes[ROOT].fen === source?.positions[at] ? tree : undefined;
  };
  const selectedTree = selected ? treeAt(selected.owner, cursor) : undefined;
  const selectedNode = selected ? selectedTree?.nodes[selected.id] : undefined;
  const inVariation = !!selectedNode && !path.length;
  const offRecord = path.length > 0 || !!selectedNode;
  useEffect(() => { setPly(0); setPath([]); setSan(''); setSelected(undefined); }, [source?.identity, usingImported]);
  useEffect(() => {
    const list = movesRef.current;
    const selected = list?.querySelector('[aria-current="step"]')?.closest('li');
    if (!list || !selected) return;
    const bounds = list.getBoundingClientRect();
    const row = selected.getBoundingClientRect();
    const top = bounds.top + list.clientTop;
    const bottom = top + list.clientHeight;
    if (row.top < top) list.scrollTop -= top - row.top;
    else if (row.bottom > bottom) list.scrollTop += row.bottom - bottom;
  }, [cursor, source?.identity, selected]);
  const baseFen = source?.positions[cursor];
  const fen = path.at(-1)?.fen ?? selectedNode?.fen ?? baseFen;
  const entry = cursor > 0 && !usingImported ? review?.entries[cursor - 1] : undefined;
  const importedEntry = cursor > 0 && usingImported ? imported?.entries[cursor - 1] : undefined;
  const running = review?.status === 'Analysing';
  const annotations = source?.moves.map((_, index) => {
    const evidence = !usingImported ? review?.entries[index] : undefined;
    return evidence && (validPrefix || hasValidPrefix({ ...review!, entries: review!.entries.slice(0, index + 1) }))
      ? annotateMove(evidence.bestChild.score, evidence.actualChild.score, evidence.mover) : undefined;
  }) ?? [];
  const annotation = annotations[cursor - 1];
  const bestMoves = annotations.map((value, index) => !!value && review!.entries[index].best === review!.entries[index].played);
  const isBest = bestMoves[cursor - 1];
  const mistakes = !mismatch ? eligibleMistakes(review).filter(record => record.mover === side) : [];
  const preparedForSide = review?.preparation?.candidates.filter(candidate => positionFromFen(review.source.positions[candidate.ply]).turn === side) ?? [];
  const activeCandidates = review?.preparation?.candidates.filter(candidate => positionFromFen(review.source.positions[candidate.ply]).turn === review.preparation!.side) ?? [];
  const continuationEvidence = usingImported ? !mismatch && validPrefix ? review?.continuations?.find(line => line.ply === cursor - 1)?.evidence : undefined : entry?.actualChild;
  let continuation: ReturnType<typeof legalContinuation> = [];
  if (continuationEvidence?.kind === 'search' && continuationEvidence.fen === baseFen) {
    try { continuation = legalContinuation(continuationEvidence.fen, continuationEvidence.result.pv); } catch { continuation = []; }
  }
  function select(index: number) { setPly(index); setPath([]); setSelected(undefined); setSan(''); setError(''); }
  function choose(owner: Owner, id: number, at: number) { setPly(at); setPath([]); setSelected({ owner, id }); setSan(''); setError(''); }
  function persist(trees: Record<number, GameTree>) {
    if (!game) return;
    setLocalLines({ gameId: game.id, trees });
    const branches = Object.entries(trees).filter(([, tree]) => tree.nodes[ROOT].children.length).map(([at, tree]) => branchFromTree(Number(at), tree)).sort((left, right) => left.ply - right.ply);
    library.saveAnalysisLines(game.id, branches).then(saved => { if (alive.current) onSnapshot(saved); },
      reason => { if (alive.current) setError(`Not saved: ${message(reason)} The variation stays on the board and is saved with your next change.`); });
  }
  function keep(from: number, sequence: string[]): boolean {
    if (!editable || !source) return false;
    let at = from, moves = sequence;
    while (moves.length && moves[0] === recordedUci(source, at)) { at++; moves = moves.slice(1); }
    if (!moves.length) { select(at); return true; }
    if (at >= source.moves.length) return false;
    const supplied = treeAt('imported', at);
    if (supplied) {
      let node: number | undefined = ROOT;
      for (const uci of moves) node = node === undefined ? undefined : supplied.nodes[node].children.find(child => supplied.nodes[child].uci === uci);
      if (node !== undefined) { choose('imported', node, at); return true; }
    }
    const existing = treeAt('mine', at);
    let tree = existing ?? createTree(source.positions[at]), node = ROOT;
    for (const uci of moves) ({ tree, id: node } = addMove(tree, node, uci));
    choose('mine', node, at);
    if (tree !== existing) persist({ ...myTrees, [at]: tree });
    return true;
  }
  function previousMove() {
    if (!inVariation) { select(cursor - 1); return; }
    if (selectedNode!.parent === ROOT) setSelected(undefined); else choose(selected!.owner, selectedNode!.parent, cursor);
  }
  function deleteHere() {
    if (!selected || !selectedTree || !selectedNode) return;
    persist({ ...myTrees, [cursor]: deleteFrom(selectedTree, selected.id) });
    if (selectedNode.parent === ROOT) setSelected(undefined); else setSelected({ owner: 'mine', id: selectedNode.parent });
  }
  const retainedLabel = (index: number): { label: string; source: string } | undefined => {
    if (usingImported) { const score = index > 0 ? imported?.entries[index - 1]?.evaluation : undefined; return score ? { label: compactScoreLabel(score), source: 'Imported PGN' } : undefined; }
    const evidence = index > 0 ? review?.entries[index - 1]?.actualChild : review?.entries[0]?.parent;
    return evidence && review!.source.identity === source?.identity ? { label: evaluationLabel(evidence), source: 'Review' } : undefined;
  };
  const retained = offRecord ? undefined : retainedLabel(cursor);
  const hasRetained = !!retained;
  const retainedEvidence = retained && (cursor === 0 && !usingImported ? review?.entries[0]?.parent : continuationEvidence);
  const retainedBest = retainedEvidence?.kind === 'search' && retainedEvidence.fen === baseFen ? retainedEvidence.result.bestmove : undefined;
  const liveLabel = (target: string) => liveOn ? liveCache.current.get(target)?.label : undefined;
  const bestArrow = liveOn && fen ? retained ? retainedBest : liveCache.current.get(fen)?.best : undefined;
  useEffect(() => {
    if (!liveOn || !fen || hasRetained || liveCache.current.has(fen)) return;
    const controller = new AbortController();
    const target = fen;
    analyzeReviewPosition(engine, target, `live:${gameId ?? ''}`, 0, controller.signal)
      .then(evidence => ({ label: evaluationLabel(evidence), best: evidence.kind === 'search' ? evidence.result.bestmove : undefined }), () => controller.signal.aborted ? undefined : { label: 'n/a' })
      .then(value => { if (value !== undefined && !controller.signal.aborted && alive.current) { liveCache.current.set(target, value); setLiveVersion(version => version + 1); } });
    return () => controller.abort();
  }, [liveOn, fen, hasRetained, engine, gameId]);
  async function toggleLive(next: boolean) {
    setError('');
    try { const saved = await library.changeReviewSettings({ liveEngine: next }); if (alive.current) onSnapshot(saved); }
    catch (reason) { if (alive.current) setError(`Not saved: ${message(reason)}`); }
  }
  function explore(moveText: string, uci = false) {
    if (!fen) return;
    try {
      const position = positionFromFen(fen);
      const move = uci ? parseUci(moveText) : parseSan(position, moveText.trim());
      if (!move || !position.isLegal(move)) throw new Error('Choose a legal move in this analysis position.');
      const playedSan = makeSanAndPlay(position, move);
      const prefix = [...(selectedNode && selectedTree ? pathTo(selectedTree, selected!.id).map(id => selectedTree.nodes[id].uci) : []), ...path.map(step => uciOf(step.beforeFen, step.san))];
      if (!keep(cursor, [...prefix, makeUci(move)])) setPath(previous => [...previous, { san: playedSan, fen: makeFen(position.toSetup()), beforeFen: fen }]);
      setSan(''); setError(''); setPromotion('');
    } catch (reason) { setError(message(reason)); }
  }
  function boardMove(uci: string) {
    if (!fen) return;
    const position = positionFromFen(fen);
    const from = parseSquare(uci.slice(0, 2));
    if (from !== undefined && position.board.get(from)?.role === 'pawn' && /[18]$/.test(uci)) setPromotion(uci);
    else explore(uci, true);
  }

  if (!game || !source || !fen) return <main className="play-unavailable"><h1>Game Review</h1>{gameId && <p role="alert">This source game is unavailable.</p>}
    <ul className="review-picker">{snapshot.games.map(record => <li key={record.id}><a href={`#/games/${record.id}/review`}>{record.headers.Title || `${record.headers.White || 'White'} - ${record.headers.Black || 'Black'}`}</a></li>)}</ul><a href="#/">Games</a></main>;

  const lastMove = path.length ? lastRecordedMove({ moves: [path.at(-1)!.san], positions: [path.at(-1)!.beforeFen, fen] })
    : selectedNode && selectedTree ? lastRecordedMove({ moves: [selectedNode.san], positions: [selectedTree.nodes[selectedNode.parent].fen, selectedNode.fen] }) : lastRecordedMove(source, cursor);
  const sourceMarkings = source.identity === captureReviewSource(game).identity ? imported : undefined;
  const markings = !offRecord ? cursor ? sourceMarkings?.entries[cursor - 1]?.markings : sourceMarkings?.initialMarkings : undefined;
  const importedGlyph = importedEntry?.glyphs.find(glyph => /^[!?]{1,2}$/.test(glyph));
  const glyphText = importedGlyph ?? (annotation?.glyph || (isBest ? '★' : undefined));
  const moveGlyph = !offRecord && glyphText ? { text: glyphText, label: usingImported ? 'Imported annotation' : annotation?.glyph ? annotation.label : 'Best move' } : undefined;
  const lineMoves = path.length ? path.map(step => step.san) : selectedNode && selectedTree ? pathTo(selectedTree, selected!.id).map(id => selectedTree.nodes[id].san) : [];
  const variationMove = (owner: Owner, tree: GameTree, id: number, at: number, numbered: boolean) => {
    const node = tree.nodes[id];
    const value = liveLabel(node.fen);
    const name = `${owner === 'imported' ? 'Imported variation' : 'Variation'} ${moveLabel(tree, id, true)}`;
    return <PreviewableMove key={`${owner}-${id}`} fen={node.fen} label={name} move={lastRecordedMove({ moves: [node.san], positions: [tree.nodes[node.parent].fen, node.fen] })}>
      <button className="variation-move" aria-label={value ? `${name}, ${value}` : name} aria-current={!path.length && cursor === at && selected?.owner === owner && selected.id === id ? 'step' : undefined} onClick={() => choose(owner, id, at)}>{moveLabel(tree, id, numbered)}{value && <small className="review-move-eval" aria-hidden="true">{value}</small>}</button></PreviewableMove>;
  };
  const continueLine = (owner: Owner, tree: GameTree, parent: number, at: number, numbered: boolean): ReactElement[] => {
    const [main, ...alternatives] = tree.nodes[parent].children;
    if (main === undefined) return [];
    return [variationMove(owner, tree, main, at, numbered),
      ...alternatives.map(alternative => <span key={`(${owner}-${alternative}`} className="variation-nested">({variationMove(owner, tree, alternative, at, true)}{continueLine(owner, tree, alternative, at, false)})</span>),
      ...continueLine(owner, tree, main, at, alternatives.length > 0)];
  };
  const variations = (at: number) => {
    const blocks = (['imported', 'mine'] as const).flatMap(owner => { const tree = treeAt(owner, at); return tree ? tree.nodes[ROOT].children.map(first => ({ owner, tree, first })) : []; });
    if (!blocks.length) return null;
    return <li key={`variations-${at}`} className="review-variations"><details open><summary>{blocks.length} {blocks.length === 1 ? 'variation' : 'variations'}</summary>
      {blocks.map(({ owner, tree, first }) => <div key={`${owner}-${first}`} className={`review-variation${owner === 'imported' ? ' imported' : ''}`}>{owner === 'imported' && <span className="variation-source">Imported</span>}
        {variationMove(owner, tree, first, at, true)}{continueLine(owner, tree, first, at, false)}</div>)}</details></li>;
  };
  const moveAssessment = entry && <div className="review-assessment" aria-label="Move assessment">{annotation ? <><strong>{annotation.label}</strong><p>Analysed / {entry.mover} / finite local search</p>
    {annotation.winPercentLoss !== undefined ? <p>{(entry.judgment.lossCp! / 100).toFixed(2)} pawns lost / estimated winning-chance loss: {annotation.winPercentLoss.toFixed(2)} percentage points</p>
      : <p>{annotation.mate === 'surrendered' ? 'Available forced mate surrendered' : annotation.mate === 'avoidable' ? 'Avoidable forced mate allowed' : entry.actualChild.score.kind === 'mate' ? `Retained mate outcome: ${entry.actualChild.score.winner} wins` : 'No forced mate reported after recorded move'}</p>}
    <p>{entry.judgment.mistake ? 'Eligible for mistake practice' : 'Not a mistake-practice candidate'}</p></> : <strong>Evidence unavailable</strong>}</div>;
  const continuationPanel = <><h3>Best continuation</h3>{usingImported && continuation.length > 0 && <p className="review-note" aria-label="Continuation source">Locally generated continuation / {review?.basis.engineVersion}</p>}<div className="pv-moves" aria-label="Engine continuation">{continuation.length ? continuation.map((step, index) => {
    const beforeFen = index ? continuation[index - 1].fen : baseFen!;
    const playedNext = index === 0 && !usingImported && !offRecord && step.san === source.moves[cursor];
    return <PreviewableMove key={index} fen={step.fen} label={`continuation ${index + 1}: ${step.san}`} move={lastRecordedMove({ moves: [step.san], positions: [beforeFen, step.fen] })}><button className={playedNext ? 'played-next' : undefined} title={playedNext ? 'Played next in the game' : undefined} onClick={() => { setSelected(undefined); setPath(continuation.slice(0, index + 1).map((value, stepIndex) => ({ ...value, beforeFen: stepIndex ? continuation[stepIndex - 1].fen : baseFen! }))); setSan(''); }}>{step.san}{playedNext && <small className="played-next-label" aria-hidden="true"> Played next</small>}</button></PreviewableMove>;
  }) : <p className="review-note">{positionFromFen(baseFen!).isEnd() ? 'No continuation: the recorded position is terminal.' : usingImported ? 'Imported continuation unavailable.' : 'Retained continuation unavailable.'}</p>}</div></>;

  return <main className="workspace review-workspace" aria-busy={saving}>
    <section className="replay" aria-label="Review board">
      <EventLine headers={game.headers} />
      <PlayerBar headers={game.headers} result={game.result} side={flipped ? 'white' : 'black'}>{offRecord ? 'Exploration' : 'Recorded snapshot'}</PlayerBar>
      <Board fen={fen} orientation={flipped ? 'black' : 'white'} lastMove={lastMove} previewMove={bestArrow} moveGlyph={moveGlyph} markings={markings} onMove={boardMove} />
      <PlayerBar headers={game.headers} result={game.result} side={flipped ? 'black' : 'white'}>{cursor} / {source.moves.length} plies</PlayerBar>
      <div className="replay-toolbar">
        <button className="icon" title="First position" aria-label="First position" disabled={cursor === 0 && !offRecord} onClick={() => select(0)}><ChevronsLeft /></button>
        <button className="icon" title={inVariation ? 'Previous variation move' : 'Previous recorded move'} aria-label={inVariation ? 'Previous variation move' : 'Previous recorded move'} disabled={!inVariation && cursor === 0} onClick={previousMove}><ChevronLeft /></button>
        <button className="icon" title={inVariation ? 'Next variation move' : 'Next recorded move'} aria-label={inVariation ? 'Next variation move' : 'Next recorded move'} disabled={inVariation ? !selectedNode!.children.length : cursor === source.moves.length} onClick={() => inVariation ? choose(selected!.owner, selectedNode!.children[0], cursor) : select(cursor + 1)}><ChevronRight /></button>
        <button className="icon" title="Last position" aria-label="Last position" disabled={inVariation ? !selectedNode!.children.length : cursor === source.moves.length && !path.length} onClick={() => inVariation ? choose(selected!.owner, mainline(selectedTree!, selected!.id).at(-1)!, cursor) : select(source.moves.length)}><ChevronsRight /></button>
        <button className="icon" title="Undo exploration" aria-label="Undo exploration" disabled={!offRecord} onClick={() => path.length ? setPath(previous => previous.slice(0, -1)) : previousMove()}><RotateCcw /></button>
        <button className="icon" title="Flip board" aria-label="Flip board" onClick={() => setFlipped(value => !value)}><FlipVertical2 /></button>
      </div>
      <div className="live-engine">
        <label className="live-switch"><input type="checkbox" role="switch" checked={liveOn} onChange={event => void toggleLive(event.target.checked)} />Live engine</label>
        {(retained || liveOn) && <output aria-label="Position evaluation" title="Evaluation (White's point of view)"><strong>{retained?.label ?? liveLabel(fen) ?? '...'}</strong> <span>{retained?.source ?? 'Stockfish'} / White</span></output>}
      </div>
      <form className="san-entry" onSubmit={event => { event.preventDefault(); explore(san); }}><label htmlFor="review-san">Explore SAN</label><input id="review-san" value={san} autoComplete="off" onChange={event => setSan(event.target.value)} /><button className="icon" title="Explore move" aria-label="Explore move" disabled={!san.trim()}><ChevronRight /></button></form>
      {lineMoves.length > 0 && <p className="exploration-path" aria-label="Exploration moves">{lineMoves.join(' ')}</p>}
      <details className="fen"><summary>Position (FEN)</summary><code>{fen}</code></details>
    </section>
    <MovePreviewProvider key={`${game.id}:${source.identity}`} orientation={flipped ? 'black' : 'white'} resetKey={`${usingImported}:${cursor}:${review?.generation ?? 0}:${JSON.stringify(continuation)}`}><section className="game-panel" aria-label="Game review">
      <header className="panel-heading"><div><span className="eyebrow">Game Review</span><h1>{game.headers.Title || `${game.headers.White || 'White'} - ${game.headers.Black || 'Black'}`}</h1></div>
        <button className="icon" title="Delete review" aria-label="Delete review" disabled={!review || saving} onClick={() => setDeleting(true)}><Trash2 size={18} /></button></header>
      {error && <p role="alert" className="error">{error}</p>}
      <p className="review-status" role="status" aria-label="Review status">{usingImported ? `Imported PGN analysis / ${imported!.evaluated} of ${source.moves.length} moves with evaluations` : <>{review ? mismatch ? 'Source changed / retained snapshot' : review.status === 'Complete' && !complete ? 'Interrupted / insufficient coverage' : review.status : 'Not analysed'}{review ? ` / ${review.entries.length} of ${source.moves.length} moves` : ''}</>}</p>
      {usingImported && review && <p className="review-note" aria-label="Local review status">{review.purpose === 'supplement' ? `Local supplement / ${review.task === 'practice' ? 'practice preparation' : 'continuations'}` : 'Local review'}: {mismatch ? 'Source changed' : review.status} / {review.purpose === 'supplement' && review.task === 'practice' ? `${activeCandidates.filter(candidate => candidate.status !== 'Pending').length} of ${activeCandidates.length} candidates` : `${review.purpose === 'supplement' ? review.continuations?.length ?? 0 : review.entries.length} of ${review.source.moves.length} moves`}</p>}
      {usingImported && review?.purpose === 'supplement' && <p className="review-note" aria-label="Continuation coverage">{review.continuations?.length ?? 0} of {source.moves.length} after-move positions retained</p>}
      {review?.status === 'Interrupted' && <p className="review-note">Incomplete: {review.interruption}</p>}
      <div className="play-actions">{running ? <button disabled={saving} onClick={() => void cancel()}><Square size={16} />Cancel analysis</button> : <>
        {review?.status === 'Interrupted' && !mismatch && <button disabled={saving} onClick={() => void start(true)}><RotateCcw size={16} />Retry review</button>}
        <button className="primary" title={usingImported ? 'Add only missing local continuations. Keep imported evaluations, glyphs and annotations unchanged.' : 'Analyze every recorded move with local Stockfish to calculate evaluations, continuations and mistake candidates.'} disabled={saving} onClick={() => void start(false)}>{usingImported ? <GitBranch size={17} /> : <Microscope size={17} />}{usingImported && review?.purpose === 'supplement' ? 'Add missing continuations' : review ? 'Regenerate review' : 'Review game'}</button>
        {usingImported && <button title="Run a full local comparison review. After confirmation and completion, replace the displayed imported analysis; preserve the original annotated PGN." disabled={saving} onClick={() => setReplacementIdentity(captureReviewSource(game).identity)}><Microscope size={17} />Full local review</button>}
      </>}</div>
      {importedEntry && <section className="review-evidence" aria-label="Selected move evidence"><div className="review-evaluation"><h2>{source.moves[cursor - 1]} / {positionFromFen(source.positions[cursor - 1]).turn}</h2><div>{importedEntry.evaluation ? <strong aria-label="Recorded position evaluation">{scoreLabel(importedEntry.evaluation)}</strong> : <strong>Imported evaluation unavailable</strong>}<span>Imported PGN / White</span></div></div>
        <div className="review-assessment" aria-label="Imported move annotations">{importedEntry.glyphs.length > 0 && <strong>{importedEntry.glyphs.join(' ')}</strong>}{importedEntry.comments.map((comment, index) => <p key={index}>{comment}</p>)}</div>
        {continuationPanel}
      </section>}
      {entry && <section className="review-evidence" aria-label="Selected move evidence"><div className="review-evaluation"><h2>{source.moves[cursor - 1]} / {entry.mover}</h2><div><strong aria-label="Recorded position evaluation">{scoreLabel(entry.actualChild.score)}</strong><span>After recorded move / White</span></div></div>
        {isBest && <p className="review-best" aria-label="Best move"><b className="review-glyph review-best-glyph" aria-hidden="true">{'\u2605'}</b> Best move: {source.moves[cursor - 1]} matched Stockfish's first choice in this position, the move that began the best continuation after the previous move.</p>}
        {(!annotation || annotation.glyph) && moveAssessment}
        {continuationPanel}
      </section>}
      {!entry && !usingImported && cursor > 0 && <section className="review-evidence"><div className="review-assessment" aria-label="Move assessment"><strong>{running ? 'Pending analysis' : 'Not analysed'}</strong></div><h3>Best continuation</h3><p className="review-note">{positionFromFen(baseFen!).isEnd() ? 'No continuation: the recorded position is terminal.' : 'Retained continuation unavailable.'}</p></section>}
      <ol ref={movesRef} className="review-moves" aria-label="Reviewed moves"><li><button aria-current={cursor === 0 && !offRecord ? 'step' : undefined} onClick={() => select(0)}>Start</button></li>{source.moves.map((move, index) => {
        const evidence = review?.entries[index]; const assessment = annotations[index]; const fields = source.positions[index].split(' ');
        const supplied = usingImported ? imported?.entries[index] : undefined;
        const label = `${fields[5]}${fields[1] === 'w' ? '.' : '...'} ${move}`;
        const status = usingImported ? supplied?.evaluation ? 'Imported evaluation' : 'No imported evaluation' : assessment ? 'Analysed' : evidence ? 'Evidence unavailable' : running ? 'Pending' : 'Not analysed';
        const value = retainedLabel(index + 1)?.label ?? liveLabel(source.positions[index + 1]);
        return [<li key={index}><PreviewableMove fen={source.positions[index + 1]} label={label} move={lastRecordedMove(source, index + 1)} markings={sourceMarkings?.entries[index]?.markings}><button aria-current={cursor === index + 1 && !offRecord ? 'step' : undefined} onClick={() => select(index + 1)}><span className="review-move-label"><span>{label}</span>{usingImported ? supplied?.glyphs.map((glyph, glyphIndex) => <b key={glyphIndex} className="review-glyph" title={`Imported annotation ${glyph}`} aria-label={`Imported annotation ${glyph}`}>{glyph}</b>) : assessment?.glyph ? <b className="review-glyph" title={assessment.label} aria-label={assessment.label}>{assessment.glyph}</b> : bestMoves[index] && <b className="review-glyph review-best-glyph" title="Best move" aria-label="Best move">{'\u2605'}</b>}</span>{value ? <span className="review-move-eval" title={status}>{value}<span className="sr-only"> / {status}</span></span> : <span>{status}</span>}</button></PreviewableMove></li>, variations(index)];
      })}</ol>
      {selected && selectedNode && <div className="variation-actions" role="group" aria-label="Selected variation">{selected.owner === 'mine'
        ? <><button onClick={deleteHere}><Trash2 size={16} />Delete from here</button><button disabled={isMainline(selectedTree!, selected.id)} onClick={() => persist({ ...myTrees, [cursor]: promoteVariation(selectedTree!, selected.id) })}><ArrowUp size={16} />Promote variation</button></>
        : <p className="review-note">Imported side line / read-only. Moves you play from here are kept as your own line.</p>}</div>}
      <details className="review-analysis-details"><summary>Analysis details</summary>
        {annotation && !annotation.glyph && moveAssessment}
        {usingImported && review && <dl className="game-facts"><div><dt>Local analysis purpose</dt><dd>{review.purpose === 'supplement' ? review.task === 'practice' ? 'Targeted practice preparation' : 'Continuation supplement' : 'Full comparison'}</dd></div><div><dt>Local engine</dt><dd>{review.basis.engineVersion}</dd></div><div><dt>Local effort</dt><dd>{Object.entries(review.basis.limits).map(([key, value]) => `${value} ${key}`).join(', ')}</dd></div></dl>}
        {usingImported ? <dl className="game-facts"><div><dt>Analysis source</dt><dd>Imported PGN annotations</dd></div><div><dt>Supplied engine</dt><dd>{game.headers.Engine || 'Unknown'}</dd></div><div><dt>Supplied depth</dt><dd>{importedEntry?.depth ?? 'Unknown'}</dd></div><div><dt>Score perspective</dt><dd>White / supplied evaluation</dd></div></dl> : <dl className="game-facts"><div><dt>Analysis basis</dt><dd>{review?.basis.engineVersion ?? REVIEW_BASIS.engineVersion}</dd></div><div><dt>Equal child effort</dt><dd>{Object.entries(review?.basis.limits ?? REVIEW_BASIS.limits).map(([key, value]) => `${value} ${key}`).join(', ')} per search</dd></div><div><dt>Protocol</dt><dd>{review?.basis.version ?? REVIEW_BASIS.version}</dd></div><div><dt>Score perspective</dt><dd>White / finite local search</dd></div></dl>}
        {entry && <dl className="review-comparison"><dt>Before recorded move / White</dt><dd>{evidenceLabel(entry.parent)}</dd><dt>After best move / White</dt><dd>{evidenceLabel(entry.bestChild)}</dd><dt>After recorded move / White</dt><dd>{evidenceLabel(entry.actualChild)}</dd></dl>}
      </details>
      <div className="review-side"><label className="field">Mistakes for<select value={side} disabled={running} onChange={event => setSide(event.target.value as 'white' | 'black')}><option value="white">White</option><option value="black">Black</option></select></label><p>{mistakes.length} {side} verified mistakes{!complete && review?.purpose !== 'supplement' ? ' / incomplete' : ''}</p>
        {usingImported && <button title="Locally verify the selected side's imported ? and ?? moves for mistake practice. Keep imported analysis unchanged; only verified eligible positions become trainable." disabled={saving || running} onClick={() => void start(false, false, undefined, 'practice')}><Target size={17} />Prepare mistakes</button>}
        {usingImported && review?.preparation && !mismatch && <><p className="review-note" aria-label="Practice preparation summary">{preparedForSide.length ? `${preparedForSide.filter(candidate => candidate.status === 'Verified eligible').length} verified / ${preparedForSide.length} nominated ${side} positions` : `No imported ? or ?? candidates for ${side}.`}</p><ul aria-label="Practice preparation">{preparedForSide.map(candidate => <li key={candidate.ply}>{candidate.ply + 1}. {source.moves[candidate.ply]} / {candidate.status}</li>)}</ul></>}
        {!mismatch && mistakes.length > 0 && <a className="resume-link" href={mistakePracticeHref(review!, side)}>Practice mistakes</a>}</div>
      <footer className="library-footer"><a href="#/">Games</a><a href="/engine/SOURCE.md" target="_blank" rel="noreferrer">Stockfish 18 / GPL</a></footer>
    </section></MovePreviewProvider>
    {replacementIdentity && <Modal title="Replace displayed imported analysis?" busy={saving} onClose={() => setReplacementIdentity(undefined)}><p>Local Stockfish analysis will replace the displayed imported evaluations and annotations after it completes. Your original PGN, comments, variations and markings will remain preserved.</p><div className="dialog-actions"><button onClick={() => setReplacementIdentity(undefined)}>Cancel</button><button className="primary" onClick={() => { const identity = replacementIdentity; setReplacementIdentity(undefined); void start(false, !!game.computer && game.result !== '*' && !review, identity); }}><Microscope size={17} />Start local review</button></div></Modal>}
    {deleting && <Modal title="Delete review?" busy={saving} onClose={() => setDeleting(false)}>{error && <p className="error" role="alert">{error}</p>}<p>Remove this {review?.status.toLowerCase()} analysis? The source game and past practice results will be kept.</p><div className="dialog-actions"><button disabled={saving} onClick={() => setDeleting(false)}>Cancel</button><button className="danger" disabled={saving} onClick={() => void remove()}><Trash2 size={17} />Delete analysis</button></div></Modal>}
    {promotion && <Modal title="Promote analysis pawn" busy={false} onClose={() => setPromotion('')}><div className="play-actions">{['q', 'r', 'b', 'n'].map((piece, index) => <button key={piece} onClick={() => explore(promotion + piece, true)}>{['Queen', 'Rook', 'Bishop', 'Knight'][index]}</button>)}</div></Modal>}
  </main>;
}