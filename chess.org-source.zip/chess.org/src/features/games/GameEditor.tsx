import { Fragment, useEffect, useRef, useState, type ReactNode } from 'react';
import { ArrowUpToLine, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, FlipVertical2, Minus, Pencil, PenLine, Plus, RotateCcw, Scissors, Star, Trash2 } from 'lucide-react';
import { INITIAL_FEN } from 'chessops/fen';
import { parseSquare } from 'chessops/util';
import { Board } from '../../components/Board';
import { Modal } from '../../components/Modal';
import { MovePreviewProvider, PreviewableMove } from '../../components/MovePreview';
import { PositionEditor } from '../../components/PositionEditor';
import { EventLine, PlayerBar } from '../../components/PlayerBar';
import { addMove, addSan, automaticResult, createTree, deleteFrom, GLYPHS, isMainline, makeMainline, moveLabel, pathTo, promoteVariation, ROOT, treeFromPgn, treeToPgn, type GameTree, type TreeNode } from '../../chess/gameTree';
import type { CommentShape } from 'chessops/pgn';
import { positionFromFen, type GameResult } from '../../chess/pgn';
import type { createLibrary, DomainSnapshot, RetainedGame } from '../../storage/library';

type Side = 'white' | 'black';
type Draft = { tree: GameTree; orientation: Side; tags: Map<string, string>; manualResult: GameResult };
const STANDARD_TAGS = ['Title', 'Event', 'Site', 'Date', 'Round', 'White', 'Black'];
const RESERVED = ['Result', 'SetUp', 'FEN'];
const NO_SHAPES: CommentShape[] = [];
const COLORS: CommentShape['color'][] = ['green', 'red', 'blue', 'yellow'];
type SaveState = 'unsaved' | 'saving' | 'saved' | { error: string };
const message = (error: unknown) => error instanceof Error ? error.message : 'The game could not be saved.';
const legal = (fen: string) => { try { positionFromFen(fen); return true; } catch { return false; } };
function defaultHeaders(): Map<string, string> {
  const today = new Date().toISOString().slice(0, 10);
  return new Map([['Title', `Board game ${today}`], ['Event', '?'], ['Site', '?'], ['Date', today.replaceAll('-', '.')], ['Round', '?'], ['White', '?'], ['Black', '?']]);
}

export function GameEditor({ library, snapshot, onSnapshot, route }: { library: ReturnType<typeof createLibrary>; snapshot: DomainSnapshot; onSnapshot: (snapshot: DomainSnapshot) => void; route: string }) {
  const editId = /^#\/games\/([^/]+)\/edit$/.exec(route)?.[1];
  const record = editId ? snapshot.games.find(game => game.id === decodeURIComponent(editId)) : undefined;
  if (editId && !record) return <main className="play-unavailable"><h1>Game unavailable</h1><p role="alert">This game no longer exists.</p><a href="#/">Games</a></main>;
  if (record && record.source.kind !== 'board') return <main className="play-unavailable"><h1>Game Editor</h1><p role="alert">Only games created on the board can be edited. Imported and computer-played games keep their recorded moves.</p><a href="#/">Games</a></main>;
  return <Editor library={library} onSnapshot={onSnapshot} record={record} />;
}

function Editor({ library, onSnapshot, record }: { library: ReturnType<typeof createLibrary>; onSnapshot: (snapshot: DomainSnapshot) => void; record?: RetainedGame }) {
  const [initial] = useState(() => {
    if (!record) return { tree: createTree(INITIAL_FEN), headers: defaultHeaders(), result: '*' as GameResult };
    const parsed = treeFromPgn(record.pgn);
    return { tree: parsed.tree, headers: parsed.headers, result: record.result === automaticResult(parsed.tree) ? '*' as GameResult : record.result };
  });
  const gameId = useRef(record?.id ?? crypto.randomUUID());
  const created = useRef(!!record);
  const [tags, setTags] = useState(initial.headers);
  const [manualResult, setManualResult] = useState<GameResult>(initial.result);
  const [newTag, setNewTag] = useState({ name: '', value: '' });
  const [renaming, setRenaming] = useState<string>();
  const [tree, setTree] = useState<GameTree>(initial.tree);
  const [orientation, setOrientation] = useState<Side>(record?.source.kind === 'board' ? record.source.orientation : 'white');
  const [selected, setSelected] = useState(ROOT);
  const [setupFen, setSetupFen] = useState(INITIAL_FEN);
  const [collapsed, setCollapsed] = useState<Set<number>>(new Set());
  const [san, setSan] = useState('');
  const [promotion, setPromotion] = useState('');
  const [error, setError] = useState('');
  const [drawMode, setDrawMode] = useState(false);
  const [drawColor, setDrawColor] = useState<CommentShape['color']>('green');
  const [drawFrom, setDrawFrom] = useState<string>();
  const [saveState, setSaveState] = useState<SaveState>(record ? 'saved' : 'unsaved');
  const latest = useRef<Draft>({ tree, orientation, tags, manualResult }); latest.current = { tree, orientation, tags, manualResult };
  const pending = useRef<Draft>();
  const running = useRef(false);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);
  const node = tree.nodes[selected] ?? tree.nodes[ROOT];
  const hasMoves = tree.nodes[ROOT].children.length > 0;
  const setupBlocked = !created.current && !hasMoves && !legal(setupFen);
  const treeRef = useRef<HTMLDivElement>(null);
  useEffect(() => { treeRef.current?.querySelector('[aria-current="step"]')?.scrollIntoView?.({ block: 'nearest' }); }, [selected]);

  async function flush() {
    if (running.current) return;
    running.current = true;
    while (pending.current) {
      const job = pending.current; pending.current = undefined;
      if (alive.current) setSaveState('saving');
      try {
        const pgn = treeToPgn(job.tree, job.tags, automaticResult(job.tree) ?? job.manualResult);
        const next = await library.saveBoardGame(gameId.current, pgn, job.orientation, !created.current);
        if (!created.current) { created.current = true; window.history.replaceState(null, '', `#/games/${gameId.current}/edit`); }
        onSnapshot(next);
        if (alive.current) setSaveState('saved');
      } catch (reason) {
        if (alive.current) setSaveState({ error: message(reason) });
        break;
      }
    }
    running.current = false;
  }
  function save(patch: Partial<Draft>) { pending.current = { ...latest.current, ...patch }; void flush(); }
  function changeTree(next: GameTree, select: number) {
    setTree(next); setSelected(select); setError('');
    if (automaticResult(next) && manualResult !== '*') { setManualResult('*'); save({ tree: next, manualResult: '*' }); }
    else save({ tree: next });
  }
  function changeTags(next: Map<string, string>) { setTags(next); setError(''); save({ tags: next }); }
  function setTag(name: string, value: string) {
    if (value.length > 500 || /[\r\n]/.test(value)) { setError(`${name} must be a single line of at most 500 characters.`); return; }
    changeTags(new Map(tags).set(name, value));
  }
  function addTag() {
    const name = newTag.name.trim();
    if (!/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(name) || RESERVED.includes(name)) { setError('Tag names start with a letter and use letters, digits or underscores; Result, SetUp and FEN are managed by the editor.'); return; }
    if (tags.has(name)) { setError(`${name} already exists.`); return; }
    setNewTag({ name: '', value: '' });
    setTag(name, newTag.value.trim());
  }
  function removeTag(name: string) { const next = new Map(tags); next.delete(name); changeTags(next); }
  function chooseResult(value: GameResult) { setManualResult(value); save({ manualResult: value }); }
  function annotate(id: number, patch: Partial<Pick<TreeNode, 'comment' | 'nag' | 'shapes'>>) {
    const merged = { ...tree.nodes[id], ...patch };
    if (!merged.comment) delete merged.comment;
    if (!merged.nag) delete merged.nag;
    if (!merged.shapes?.length) delete merged.shapes;
    changeTree({ ...tree, nodes: { ...tree.nodes, [id]: merged } }, selected);
  }
  function drawTap(square: string) {
    if (!drawFrom) { setDrawFrom(square); return; }
    const from = parseSquare(drawFrom)!, to = parseSquare(square)!;
    const shapes = node.shapes ?? [];
    const same = shapes.find(shape => shape.from === from && shape.to === to);
    const rest = shapes.filter(shape => shape !== same);
    annotate(node.id, { shapes: same?.color === drawColor ? rest : [...rest, { color: drawColor, from, to }] });
    setDrawFrom(undefined);
  }
  function play(uci: string) {
    try { const added = addMove(tree, node.id, uci); setPromotion(''); if (added.tree === tree) { setSelected(added.id); setError(''); } else changeTree(added.tree, added.id); }
    catch (reason) { setError(message(reason)); }
  }
  function boardMove(uci: string) {
    const from = parseSquare(uci.slice(0, 2));
    if (from !== undefined && positionFromFen(node.fen).board.get(from)?.role === 'pawn' && /[18]$/.test(uci)) setPromotion(uci);
    else play(uci);
  }
  function playSan() {
    try { const added = addSan(tree, node.id, san); setSan(''); if (added.tree === tree) { setSelected(added.id); setError(''); } else changeTree(added.tree, added.id); }
    catch (reason) { setError(message(reason)); }
  }
  function remove() {
    const parent = node.parent;
    const next = deleteFrom(tree, node.id);
    changeTree(next, parent);
  }
  function flip() {
    const next = orientation === 'white' ? 'black' : 'white';
    setOrientation(next);
    if (created.current) save({ orientation: next });
  }
  function changeSetup(fen: string) {
    setSetupFen(fen);
    if (!hasMoves && !created.current && legal(fen)) { setTree(createTree(fen)); setSelected(ROOT); }
  }
  const next = node.children[0];
  const lineEnd = () => { let at = node.id; while (tree.nodes[at].children[0] !== undefined) at = tree.nodes[at].children[0]; return at; };
  const onPath = new Set(pathTo(tree, node.id));
  const toggle = (id: number) => setCollapsed(previous => { const value = new Set(previous); if (value.has(id)) value.delete(id); else value.add(id); return value; });

  const move = (id: number, numbered: boolean) => {
    const item = tree.nodes[id];
    const glyph = item.nag ? GLYPHS[item.nag] ?? '' : '';
    return <Fragment key={id}><PreviewableMove fen={item.fen} label={moveLabel(tree, id, true)} move={item.uci} markings={item.shapes}>
      <button type="button" className="study-move" aria-current={node.id === id ? 'step' : undefined} onClick={() => setSelected(id)}>{moveLabel(tree, id, numbered)}{glyph}</button>
    </PreviewableMove>{item.comment && <p className="study-comment">{item.comment}</p>}</Fragment>;
  };
  const line = (from: number): ReactNode[] => {
    const out: ReactNode[] = [];
    let numbered = true;
    for (let at = from; tree.nodes[at].children.length;) {
      const [main, ...sides] = tree.nodes[at].children;
      out.push(move(main, numbered));
      for (const side of sides) out.push(variation(side));
      numbered = sides.length > 0;
      at = main;
    }
    return out;
  };
  const variation = (id: number): ReactNode => {
    const open = !collapsed.has(id) || onPath.has(id);
    return <div key={`v${id}`} className="study-variation">
      {open ? <>
        {!onPath.has(id) && <button type="button" className="icon study-toggle" title="Collapse variation" aria-label={`Collapse variation ${moveLabel(tree, id, true)}`} onClick={() => toggle(id)}><Minus size={14} /></button>}
        {move(id, true)}{line(id)}
      </> : <button type="button" className="study-collapsed" aria-expanded="false" onClick={() => toggle(id)}><Plus size={14} />{moveLabel(tree, id, true)}</button>}
    </div>;
  };
  const title = tags.get('Title') || `${tags.get('White') ?? '?'} - ${tags.get('Black') ?? '?'}`;
  const automatic = automaticResult(tree);
  const result = automatic ?? manualResult;
  const extraTags = [...tags.keys()].filter(name => !STANDARD_TAGS.includes(name) && !RESERVED.includes(name));
  const tagRecord = Object.fromEntries(tags);
  const status = saveState === 'saving' ? 'Saving...' : saveState === 'saved' ? 'Saved' : saveState === 'unsaved' ? 'Not created yet: the first move creates the game' : `Not saved: ${saveState.error}`;

  return <main className="workspace review-workspace learn-workspace">
    <section className="replay" aria-label="Game editor board">
      <EventLine headers={tagRecord} />
      <PlayerBar headers={tagRecord} result={result} side={orientation === 'white' ? 'black' : 'white'} />
      <div tabIndex={0} className="board-keyboard" aria-label="Editor board" onKeyDown={event => {
        const target = event.key === 'ArrowLeft' ? (node.id === ROOT ? undefined : node.parent) : event.key === 'ArrowRight' ? next : event.key === 'Home' ? ROOT : event.key === 'End' ? lineEnd() : undefined;
        if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) { event.preventDefault(); if (target !== undefined) setSelected(target); }
      }}><Board fen={node.fen} orientation={orientation} lastMove={node.uci || undefined} onMove={setupBlocked || drawMode ? undefined : boardMove} drawing={{ shapes: node.shapes ?? NO_SHAPES, onChange: shapes => annotate(node.id, { shapes }) }} onSelect={drawMode ? drawTap : undefined} /></div>
      <PlayerBar headers={tagRecord} result={result} side={orientation} />
      <div className="replay-toolbar">
        <button className="icon" title="First position" aria-label="First position" disabled={node.id === ROOT} onClick={() => setSelected(ROOT)}><ChevronsLeft /></button>
        <button className="icon" title="Previous move" aria-label="Previous move" disabled={node.id === ROOT} onClick={() => setSelected(node.parent)}><ChevronLeft /></button>
        <button className="icon" title="Next move" aria-label="Next move" disabled={next === undefined} onClick={() => setSelected(next)}><ChevronRight /></button>
        <button className="icon" title="End of line" aria-label="End of line" disabled={next === undefined} onClick={() => setSelected(lineEnd())}><ChevronsRight /></button>
        <button className="icon" title="Flip board" aria-label="Flip board" aria-pressed={orientation === 'black'} onClick={flip}><FlipVertical2 /></button>
        <button className="icon" title="Draw arrows and highlights by tapping squares" aria-label="Draw" aria-pressed={drawMode} onClick={() => { setDrawMode(value => !value); setDrawFrom(undefined); }}><PenLine /></button>
      </div>
      {drawMode && <div className="draw-colors" role="group" aria-label="Drawing colour">{COLORS.map(color => <button key={color} type="button" className={`draw-color draw-${color}`} aria-label={color} title={color} aria-pressed={drawColor === color} onClick={() => setDrawColor(color)} />)}<span className="review-note">{drawFrom ? `From ${drawFrom}: tap the target square, or the same square to highlight it.` : 'Tap a square to start an arrow or highlight.'}</span></div>}
      <p className="review-note draw-hint">Right-click and drag to draw an arrow; right-click a square to highlight it. Shift: red, Alt: blue, Shift+Alt: yellow.</p>
      <form className="san-entry" onSubmit={event => { event.preventDefault(); playSan(); }}><label htmlFor="editor-san">Move (SAN)</label><input id="editor-san" autoComplete="off" spellCheck={false} value={san} disabled={setupBlocked} onChange={event => setSan(event.target.value)} /><button className="icon" title="Play move" aria-label="Play move" disabled={setupBlocked || !san.trim()}><ChevronRight /></button></form>
      <details className="fen"><summary>Position (FEN)</summary><code>{node.fen}</code></details>
    </section>
    <section className="game-panel" aria-label="Game editor">
      <header className="panel-heading"><div><span className="eyebrow">Game Editor</span>{renaming !== undefined
        ? <form className="title-edit" onSubmit={event => { event.preventDefault(); if (renaming.trim() !== (tags.get('Title') ?? '')) setTag('Title', renaming.trim()); setRenaming(undefined); }}>
          <input aria-label="Game title" autoFocus value={renaming} maxLength={500} onChange={event => setRenaming(event.target.value)} onBlur={event => event.currentTarget.form?.requestSubmit()} onKeyDown={event => { if (event.key === 'Escape') setRenaming(undefined); }} />
        </form>
        : <h1><button type="button" className="title-button" title="Rename game" aria-label={`Rename game: ${title}`} onClick={() => setRenaming(tags.get('Title') ?? '')}>{title}<Pencil size={16} aria-hidden="true" /></button></h1>}</div></header>
      <p className={typeof saveState === 'object' ? 'error' : 'review-note'} aria-label="Save status" aria-live="polite">{status}{typeof saveState === 'object' && <> <button type="button" onClick={() => save({})}><RotateCcw size={15} />Retry</button></>}</p>
      {error && <p className="error" role="alert">{error}</p>}
      {!created.current && !hasMoves && <details className="position-setup"><summary>Set up position</summary><PositionEditor fen={setupFen} onChange={changeSetup} fenLabel="Starting FEN" /></details>}
      <details className="position-setup game-tags"><summary>Tags</summary>
        <div className="details-grid">{STANDARD_TAGS.map(name => <label key={name} className="field">{name}<input value={tags.get(name) ?? ''} maxLength={500} onChange={event => setTag(name, event.target.value)} /></label>)}
          <label className="field">Result<select value={result} disabled={!!automatic} title={automatic ? 'Set by the final position of the main line' : undefined} onChange={event => chooseResult(event.target.value as GameResult)}>{(['*', '1-0', '0-1', '1/2-1/2'] as GameResult[]).map(value => <option key={value} value={value}>{value}</option>)}</select></label>
          {extraTags.map(name => <div key={name} className="field extra-tag"><label htmlFor={`tag-${name}`}>{name}</label><div><input id={`tag-${name}`} value={tags.get(name) ?? ''} maxLength={500} onChange={event => setTag(name, event.target.value)} /><button type="button" className="icon" title={`Remove ${name}`} aria-label={`Remove ${name}`} onClick={() => removeTag(name)}><Trash2 size={15} /></button></div></div>)}
        </div>
        <form className="add-tag" onSubmit={event => { event.preventDefault(); addTag(); }}><label className="field">New tag name<input value={newTag.name} placeholder="ECO" onChange={event => setNewTag(value => ({ ...value, name: event.target.value }))} /></label><label className="field">New tag value<input value={newTag.value} onChange={event => setNewTag(value => ({ ...value, value: event.target.value }))} /></label><button type="submit" disabled={!newTag.name.trim()}><Plus size={15} />Add tag</button></form>
      </details>
      <MovePreviewProvider orientation={orientation} resetKey={`${selected}:${tree.next}`}><div ref={treeRef} className="study-tree" aria-label="Game moves">
        <button type="button" className="study-move" aria-current={node.id === ROOT ? 'step' : undefined} onClick={() => setSelected(ROOT)}>Start</button>
        {tree.nodes[ROOT].comment && <p className="study-comment study-intro">{tree.nodes[ROOT].comment}</p>}
        {line(ROOT)}
        <span className="game-tree-result">{result}</span>
        {!hasMoves && <p className="review-note">Play a move on the board or enter it as SAN.</p>}
      </div></MovePreviewProvider>
      <div className="play-actions" aria-label="Selected move actions">
        <button type="button" disabled={node.id === ROOT} onClick={remove}><Scissors size={16} />Delete from here</button>
        <button type="button" disabled={node.id === ROOT || isMainline(tree, node.id)} onClick={() => changeTree(promoteVariation(tree, node.id), node.id)}><ArrowUpToLine size={16} />Promote variation</button>
        <button type="button" disabled={node.id === ROOT || isMainline(tree, node.id)} onClick={() => changeTree(makeMainline(tree, node.id), node.id)}><Star size={16} />Make main line</button>
      </div>
      <div className="glyph-buttons" role="group" aria-label="Move glyph">{Object.entries(GLYPHS).map(([nag, glyph]) => <button key={nag} type="button" aria-pressed={node.nag === Number(nag)} disabled={node.id === ROOT} onClick={() => annotate(node.id, { nag: node.nag === Number(nag) ? undefined : Number(nag) })}>{glyph}</button>)}</div>
      <label className="field">{node.id === ROOT ? 'Comment on the start position' : `Comment after ${moveLabel(tree, node.id, true)}`}<textarea rows={2} value={node.comment ?? ''} onChange={event => annotate(node.id, { comment: event.target.value })} /></label>
      <footer className="library-footer"><a href="#/">Games</a>{created.current && <a href={`#/games/${gameId.current}/review`}>Review game</a>}</footer>
    </section>
    {promotion && <Modal title="Promote pawn" busy={false} onClose={() => setPromotion('')}><div className="play-actions">{['q', 'r', 'b', 'n'].map((piece, index) => <button key={piece} onClick={() => play(promotion + piece)}>{['Queen', 'Rook', 'Bishop', 'Knight'][index]}</button>)}</div></Modal>}
  </main>;
}
