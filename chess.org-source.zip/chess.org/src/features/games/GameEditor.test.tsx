// @vitest-environment jsdom
import { useState } from 'react';
import { act, cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { GameEditor } from './GameEditor';
import { createLibrary, emptySnapshot, type DomainSnapshot } from '../../storage/library';

vi.mock('../../components/Board', () => ({ Board: ({ fen, orientation, onMove, drawing, onSelect }: { fen: string; orientation: string; onMove?: (uci: string) => void; drawing?: { shapes: unknown[]; onChange: (shapes: { color: string; from: number; to: number }[]) => void }; onSelect?: (square: string) => void }) =>
  <div data-testid="editor-board" data-fen={fen} data-orientation={orientation} data-shapes={JSON.stringify(drawing?.shapes ?? [])}><input aria-label="Board move" disabled={!onMove} onChange={event => onMove?.(event.target.value)} />
    <input aria-label="Board tap" disabled={!onSelect} onChange={event => onSelect?.(event.target.value)} /><button onClick={() => drawing?.onChange([{ color: 'red', from: 12, to: 28 }])}>Right-click draw</button></div> }));
afterEach(cleanup);

function setup(failing = false) {
  let durable: DomainSnapshot = emptySnapshot();
  let fail = failing;
  const library = createLibrary({ read: async () => structuredClone(durable), update: async change => { if (fail) throw new Error('Disk full'); durable = change(structuredClone(durable)); } });
  function Harness({ route }: { route: string }) {
    const [snapshot, setSnapshot] = useState(durable);
    return <GameEditor library={library} snapshot={snapshot} onSnapshot={setSnapshot} route={route} />;
  }
  return { library, Harness, durable: () => durable, heal: () => { fail = false; } };
}
const move = async (uci: string) => { await act(async () => { fireEvent.change(screen.getByLabelText('Board move'), { target: { value: uci } }); }); };
const tree = () => within(screen.getByLabelText('Game moves'));

it('creates the game on the first move, saves each change and builds variations', async () => {
  const test = setup();
  render(<test.Harness route="#/games/new" />);
  expect(screen.getByLabelText('Save status').textContent).toContain('Not created yet');
  expect(test.durable().games).toHaveLength(0);
  await move('e2e4');
  expect(screen.getByLabelText('Save status').textContent).toBe('Saved');
  const [game] = test.durable().games;
  expect(game).toMatchObject({ moves: ['e4'], source: { kind: 'board', orientation: 'white' } });
  expect(window.location.hash).toBe(`#/games/${game.id}/edit`);
  await move('e7e5');
  fireEvent.click(screen.getByRole('button', { name: 'Previous move' }));
  await move('c7c5');
  expect(test.durable().games[0].pgn).toContain('1. e4 e5 ( 1... c5 ) *');
  expect(tree().getByRole('button', { name: '1... c5' }).getAttribute('aria-current')).toBe('step');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Make main line' })); });
  expect(test.durable().games[0].moves).toEqual(['e4', 'c5']);
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Delete from here' })); });
  expect(test.durable().games[0].moves).toEqual(['e4', 'e5']);
  expect(tree().getByRole('button', { name: '1. e4' }).getAttribute('aria-current')).toBe('step');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Flip board' })); });
  expect(test.durable().games[0].source).toEqual({ kind: 'board', orientation: 'black' });
  fireEvent.change(screen.getByLabelText('Move (SAN)'), { target: { value: 'Nf6' } });
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Play move' })); });
  expect(test.durable().games[0].pgn).toContain('( 1... Nf6 )');
});

it('starts from a set-up position and blocks moves while it is illegal', async () => {
  const test = setup();
  render(<test.Harness route="#/games/new" />);
  fireEvent.change(screen.getByLabelText('Starting FEN'), { target: { value: '8/8/8/8/8/8/8/K7 w - - 0 1' } });
  expect((screen.getByLabelText('Board move') as HTMLInputElement).disabled).toBe(true);
  fireEvent.change(screen.getByLabelText('Starting FEN'), { target: { value: '7k/8/8/8/8/8/8/K7 w - - 0 1' } });
  await move('a1b2');
  expect(test.durable().games[0]).toMatchObject({ startFen: '7k/8/8/8/8/8/8/K7 w - - 0 1', moves: ['Kb2'] });
});

it('keeps an unsaved change on the board and retries', async () => {
  const test = setup(true);
  render(<test.Harness route="#/games/new" />);
  await move('d2d4');
  expect(screen.getByLabelText('Save status').textContent).toContain('Not saved: Disk full');
  expect(test.durable().games).toHaveLength(0);
  expect(screen.getByTestId('editor-board').getAttribute('data-fen')).toContain('3P4');
  test.heal();
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Retry' })); });
  expect(test.durable().games[0].moves).toEqual(['d4']);
});

it('annotates moves with comments, glyphs, drawn markings and touch drawing', async () => {
  const test = setup();
  render(<test.Harness route="#/games/new" />);
  fireEvent.change(screen.getByLabelText('Comment on the start position'), { target: { value: 'Intro' } });
  await act(async () => {});
  expect(test.durable().games[0].pgn).toContain('{ Intro } *');
  await move('e2e4');
  await act(async () => { fireEvent.change(screen.getByLabelText('Comment after 1. e4'), { target: { value: 'Best by test' } }); });
  await act(async () => { fireEvent.click(within(screen.getByRole('group', { name: 'Move glyph' })).getByRole('button', { name: '!' })); });
  expect(test.durable().games[0].pgn).toContain('1. e4 $1 { Best by test }');
  expect(tree().getByRole('button', { name: '1. e4!' })).toBeTruthy();
  await act(async () => { fireEvent.click(within(screen.getByRole('group', { name: 'Move glyph' })).getByRole('button', { name: '!' })); });
  expect(test.durable().games[0].pgn).not.toContain('$1');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Right-click draw' })); });
  expect(test.durable().games[0].pgn).toContain('[%cal Re2e4]');
  fireEvent.click(screen.getByRole('button', { name: 'Draw' }));
  expect((screen.getByLabelText('Board move') as HTMLInputElement).disabled).toBe(true);
  fireEvent.click(screen.getByRole('button', { name: 'blue' }));
  fireEvent.change(screen.getByLabelText('Board tap'), { target: { value: 'e2' } });
  await act(async () => { fireEvent.change(screen.getByLabelText('Board tap'), { target: { value: 'e4' } }); });
  expect(test.durable().games[0].pgn).toContain('[%cal Be2e4]');
  expect(test.durable().games[0].pgn).not.toContain('Re2e4');
});

it('edits tags and the result, and locks the result when the main line ends in mate', async () => {
  const test = setup();
  render(<test.Harness route="#/games/new" />);
  await act(async () => { fireEvent.change(screen.getByRole('textbox', { name: 'White' }), { target: { value: 'Morphy' } }); });
  expect(test.durable().games[0].headers.White).toBe('Morphy');
  fireEvent.change(screen.getByLabelText('New tag name'), { target: { value: 'ECO' } });
  fireEvent.change(screen.getByLabelText('New tag value'), { target: { value: 'C41' } });
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Add tag' })); });
  expect(test.durable().games[0].headers.ECO).toBe('C41');
  fireEvent.change(screen.getByLabelText('New tag name'), { target: { value: 'FEN' } });
  fireEvent.click(screen.getByRole('button', { name: 'Add tag' }));
  expect(screen.getByRole('alert').textContent).toContain('managed by the editor');
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Remove ECO' })); });
  expect(test.durable().games[0].headers.ECO).toBeUndefined();
  await act(async () => { fireEvent.change(screen.getByLabelText('Result'), { target: { value: '1-0' } }); });
  expect(test.durable().games[0].result).toBe('1-0');
  for (const uci of ['f2f3', 'e7e5', 'g2g4', 'd8h4']) await move(uci);
  expect(test.durable().games[0].result).toBe('0-1');
  expect((screen.getByLabelText('Result') as HTMLSelectElement).disabled).toBe(true);
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Delete from here' })); });
  expect(test.durable().games[0].result).toBe('*');
});

it('renames the game from its heading, including before the first move', async () => {
  const test = setup();
  render(<test.Harness route="#/games/new" />);
  fireEvent.click(screen.getByRole('button', { name: /^Rename game: Board game/ }));
  fireEvent.change(screen.getByLabelText('Game title'), { target: { value: 'Evans Gambit ideas' } });
  fireEvent.keyDown(screen.getByLabelText('Game title'), { key: 'Escape' });
  expect(test.durable().games).toHaveLength(0);
  fireEvent.click(screen.getByRole('button', { name: /^Rename game/ }));
  fireEvent.change(screen.getByLabelText('Game title'), { target: { value: 'Evans Gambit ideas' } });
  await act(async () => { fireEvent.submit(screen.getByLabelText('Game title').closest('form')!); });
  expect(screen.getByRole('button', { name: 'Rename game: Evans Gambit ideas' })).toBeTruthy();
  expect(test.durable().games[0].headers.Title).toBe('Evans Gambit ideas');
});

it('refuses to edit imported games', async () => {
  const test = setup();
  await test.library.importGames([{ headers: {}, startFen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', moves: [], positions: ['rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'], result: '*', pgn: '*' }]);
  const id = test.durable().games[0].id;
  render(<test.Harness route={`#/games/${id}/edit`} />);
  expect(screen.getByRole('alert').textContent).toContain('Only games created on the board');
});
