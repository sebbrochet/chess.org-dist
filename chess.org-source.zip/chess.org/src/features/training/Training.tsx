import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Eye, Lightbulb, RotateCcw } from 'lucide-react';
import { makeSan } from 'chessops/san';
import { parseSquare, parseUci } from 'chessops/util';
import { Board } from '../../components/Board';
import { Modal } from '../../components/Modal';
import { lastRecordedMove, positionFromFen } from '../../chess/pgn';
import { captureReviewSource, eligibleMistakes, legalContinuation } from '../../chess/review';
import { attemptDisplayFen, candidateUci, isAttempt, verifyMistake, type TrainingAttempt } from '../../chess/training';
import { localEngine } from '../../engine/stockfish';
import type { createLibrary, DomainSnapshot } from '../../storage/library';

export function Training({ library, snapshot, onSnapshot, route }: { library: ReturnType<typeof createLibrary>; snapshot: DomainSnapshot; onSnapshot: (value: DomainSnapshot) => void; route: string }) {
  const [path, query] = route.split('?');
  const activity = path.startsWith('#/practice/mistakes') ? 'mistake' : 'guess';
  const gameId = decodeURIComponent(path.split('/')[3] ?? '');
  const params = new URLSearchParams(query);
  const game = snapshot.games.find(record => record.id === gameId);
  const review = snapshot.reviews.find(record => record.gameId === gameId);
  const [side, setSide] = useState<'white' | 'black'>(params.get('side') === 'black' ? 'black' : 'white');
  const [attemptId, setAttemptId] = useState('');
  const [answer, setAnswer] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [hint, setHint] = useState(false);
  const [solutionAttemptId, setSolutionAttemptId] = useState('');
  const [promotion, setPromotion] = useState('');
  const [pendingMove, setPendingMove] = useState<{ attemptId: string; fen: string; move: string }>();
  const active = useRef<AbortController>();
  const lock = useRef(false);
  useEffect(() => () => active.current?.abort(), []);
  const rows = activity === 'mistake' ? snapshot.mistakeAttempts : snapshot.guessMoveAttempts;
  const attempt = rows.find(record => record.id === attemptId && isAttempt(record)) as TrainingAttempt | undefined;
  const currentSource = game && captureReviewSource(game).identity;
  const valid = !!game && (!attempt || attempt.sourceIdentity === currentSource);
  const available = !game ? [] : activity === 'mistake' ? review?.source.identity === currentSource ? eligibleMistakes(review).filter(entry => entry.mover === side).map(entry => entry.ply) : []
    : game.moves.flatMap((_move, index) => positionFromFen(game.positions[index]).turn === side ? [index] : []);
  const nextPly = available.find(ply => ply > (attempt?.ply ?? -1));
  const fen = attempt ? busy && valid && pendingMove?.attemptId === attempt.id ? pendingMove.fen : attemptDisplayFen(attempt) : undefined;
  const title = activity === 'mistake' ? 'Practice Mistakes' : 'Guess the Move';
  const statusText = attempt?.status === 'Success' ? 'Unaided success' : attempt?.status === 'Assisted' ? 'Assisted result' : attempt?.status === 'Incorrect' ? activity === 'guess' ? 'Not the recorded move' : 'Outside the accepted engine result' : 'Your answer';
  const ended = !!attempt && attempt.status !== 'Active';
  const targetMove = attempt ? parseUci(attempt.target) : undefined;
  const targetSan = attempt && targetMove && positionFromFen(attempt.fen).isLegal(targetMove) ? makeSan(positionFromFen(attempt.fen), targetMove) : '';
  const showTarget = ended && valid && !!targetSan && (attempt?.status !== 'Incorrect' || solutionAttemptId === attempt.id);
  let lastMove = game && attempt && valid ? lastRecordedMove(game, attempt.ply) : undefined;
  if (attempt && valid) {
    if (busy && pendingMove?.attemptId === attempt.id) lastMove = pendingMove.move;
    else if ((attempt.status === 'Success' || attempt.status === 'Assisted') && attempt.answers.length) lastMove = attempt.answers.at(-1);
  }

  async function operation(run: () => Promise<DomainSnapshot>) {
    if (lock.current) return;
    lock.current = true; setBusy(true); setError('');
    try { const next = await run(); onSnapshot(next); return next; }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'The exercise could not be saved.'); }
    finally { lock.current = false; setBusy(false); }
  }
  async function start(ply?: number) {
    const expected = activity === 'mistake' && params.has('source') ? { id: params.get('source')!, generation: Number(params.get('generation')) } : undefined;
    const next = await operation(() => library.startAttempt(gameId, activity, side, ply, expected));
    if (next) { setAttemptId((activity === 'mistake' ? next.mistakeAttempts : next.guessMoveAttempts).at(-1)!.id); setAnswer(''); setHint(false); setSolutionAttemptId(''); }
  }
  async function submit(input: string) {
    if (!attempt || busy || lock.current || ended || !valid) return;
    const controller = new AbortController(); active.current?.abort(); active.current = controller;
    try {
      await operation(async () => {
        const move = candidateUci(attempt.fen, input);
        setPendingMove({ attemptId: attempt.id, fen: legalContinuation(attempt.fen, [move])[0].fen, move });
        if (activity === 'mistake') {
          const verified = await verifyMistake(localEngine, attempt, input, controller.signal);
          return library.answerAttempt(attempt.id, verified.answer, verified.correct, verified.evidence, () => !controller.signal.aborted);
        }
        return library.answerAttempt(attempt.id, move, move === attempt.target, undefined, () => !controller.signal.aborted);
      });
    } finally { setPendingMove(undefined); }
  }
  async function assist(reveal: boolean) {
    if (!attempt) return;
    const next = await operation(() => library.assistAttempt(attempt.id, reveal));
    if (next) setHint(!reveal);
  }
  function boardMove(uci: string) {
    if (!fen) return;
    const square = parseSquare(uci.slice(0, 2));
    if (square !== undefined && positionFromFen(fen).board.get(square)?.role === 'pawn' && /[18]$/.test(uci)) setPromotion(uci);
    else void submit(uci);
  }
  if (!gameId || !game) return <main className="play-unavailable"><h1>{title}</h1>{gameId && <p role="alert">The source game is unavailable.</p>}
    <ul className="review-picker">{snapshot.games.map(record => <li key={record.id}><a href={`#/practice/${activity === 'mistake' ? 'mistakes' : 'guess'}/${record.id}`}>{record.headers.Title || `${record.headers.White || 'White'} - ${record.headers.Black || 'Black'}`}</a></li>)}</ul><a href="#/">Games</a></main>;
  function playerName(color: 'White' | 'Black') {
    const name = game!.headers[color]?.trim();
    return name && name !== '?' ? name : color;
  }
  return <main className="workspace review-workspace"><section className="replay" aria-label="Training board">
    <div className="player-line"><strong>{playerName(side === 'white' ? 'Black' : 'White')}</strong></div>
    <Board fen={fen ?? game.startFen} orientation={side} lastMove={lastMove} deferMoveReset onMove={attempt && !busy && !ended && !promotion && valid ? boardMove : undefined} />
    <div className="player-line"><strong>{playerName(side === 'white' ? 'White' : 'Black')}</strong></div>
    {attempt && <form className="san-entry" onSubmit={event => { event.preventDefault(); void submit(answer); }}><label htmlFor="training-san">Your move</label><input id="training-san" value={answer} disabled={busy || ended || !valid} autoComplete="off" onChange={event => setAnswer(event.target.value)} /><button className="icon" title="Submit answer" aria-label="Submit answer" disabled={busy || ended || !answer.trim() || !valid}><ArrowRight /></button></form>}
  </section><section className="game-panel" aria-label="Training exercise"><h1>{title}</h1><h2>{game.headers.Title || `${game.headers.White || 'White'} - ${game.headers.Black || 'Black'}`}</h2>
    {error && <p className="error" role="alert">{error}</p>}{!valid && <p className="error" role="alert">The source changed; return to its current record.</p>}
    {!attempt ? <><label className="field">Practice side<select value={side} disabled={busy} onChange={event => setSide(event.target.value as 'white' | 'black')}><option value="white">White</option><option value="black">Black</option></select></label><p>{available.length} eligible positions</p><button className="primary" disabled={busy || !available.length} onClick={() => void start()}>Start practice</button></>
      : <><p role="status" aria-label="Exercise result">{busy ? 'Checking and saving...' : statusText}</p><p>Position {attempt.ply + 1} / {side}{attempt.assisted ? ' / assistance recorded' : ''}</p>
        {hint && !ended && <p aria-label="Move hint">Move from {attempt.target.slice(0, 2)}.</p>}
        {showTarget && <p aria-label="Target move">Target: {targetSan}</p>}
        <div className="play-actions">{!ended ? <><button disabled={busy || !valid} onClick={() => void assist(false)}><Lightbulb size={17} />Show hint</button><button disabled={busy || !valid} onClick={() => void assist(true)}><Eye size={17} />Reveal answer</button></>
          : <>{attempt.status === 'Incorrect' && !showTarget && <button disabled={busy || !valid || !targetSan} onClick={() => setSolutionAttemptId(attempt.id)}><Eye size={17} />Show solution</button>}<button disabled={busy || !valid} onClick={() => void start(attempt.ply)}><RotateCcw size={17} />Retry position</button><button disabled={busy || nextPly === undefined || !valid} onClick={() => void start(nextPly)}><ArrowRight size={17} />Next position</button></>}</div></>}
    <footer className="library-footer"><a href={`#/games/${gameId}/review`}>Game Review</a><a href="#/progress">Progress</a></footer>
  </section>{promotion && <Modal title="Promote training pawn" busy={busy} onClose={() => setPromotion('')}><div className="play-actions">{['q', 'r', 'b', 'n'].map((piece, index) => <button key={piece} onClick={() => { const move = promotion + piece; setPromotion(''); void submit(move); }}>{['Queen', 'Rook', 'Bishop', 'Knight'][index]}</button>)}</div></Modal>}</main>;
}