import { useState } from 'react';
import { Trash2 } from 'lucide-react';
import { Modal } from '../../components/Modal';
import { isAttempt } from '../../chess/training';
import type { createLibrary, DomainSnapshot } from '../../storage/library';

export function Progress({ library, snapshot, onSnapshot }: { library: ReturnType<typeof createLibrary>; snapshot: DomainSnapshot; onSnapshot: (value: DomainSnapshot) => void }) {
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const groups = [{ name: 'Practice Mistakes', records: snapshot.mistakeAttempts.filter(isAttempt) }, { name: 'Guess the Move', records: snapshot.guessMoveAttempts.filter(isAttempt) }, { name: 'Practice Repertoire', records: snapshot.repertoireAttempts }, { name: 'Puzzles', records: snapshot.puzzleAttempts }];
  async function clear() {
    setBusy(true); setError('');
    try { onSnapshot(await library.clearProgress()); setConfirm(false); } catch (reason) { setError(reason instanceof Error ? reason.message : 'History could not be cleared.'); } finally { setBusy(false); }
  }
  return <main className="progress-workspace"><header className="panel-heading"><h1>Progress</h1><button disabled={busy} onClick={() => setConfirm(true)}><Trash2 size={17} />Clear progress</button></header>
    {error && <p className="error" role="alert">{error}</p>}<section><h2>Games</h2><p>{snapshot.games.length} retained / {snapshot.games.filter(game => game.result !== '*').length} completed / {snapshot.games.filter(game => game.result === '1/2-1/2').length} draws</p></section>
    {groups.map(group => <section key={group.name}><h2>{group.name}</h2><p aria-label={`${group.name} summary`}>{group.records.length} attempts / {group.records.filter(record => record.status === 'Success' && !record.assisted).length} unaided successes / {group.records.filter(record => record.assisted).length} assisted / {group.records.filter(record => record.status === 'Incorrect').length} incorrect or non-target / {group.records.filter(record => record.status === 'Active').length} in progress</p>
      {group.records.length ? <div className="history-table"><table><thead><tr><th>Date</th><th>Source</th><th>Side</th><th>Result</th><th>Assistance</th></tr></thead><tbody>{group.records.map(record => <tr key={record.id}><td>{new Date(record.createdAt).toLocaleString('en')}</td><td>{'gameId' in record ? snapshot.games.find(game => game.id === record.gameId)?.headers.Title || 'Saved game' : 'repertoireId' in record ? snapshot.repertoires.find(book => book.id === record.repertoireId)?.name || 'Repertoire' : snapshot.puzzleCollections.find(collection => collection.id === record.collectionId)?.name || 'Puzzle collection'}</td><td>{record.side}</td><td>{record.status}</td><td>{record.assisted ? 'Assisted' : 'None'}</td></tr>)}</tbody></table></div> : <p>No attempt history.</p>}</section>)}
    {confirm && <Modal title="Clear progress?" busy={busy} onClose={() => setConfirm(false)}><p>Remove exercise history? Games, reviews, and retained source content will be kept.</p>{error && <p className="error" role="alert">{error}</p>}<div className="dialog-actions"><button disabled={busy} onClick={() => setConfirm(false)}>Cancel</button><button className="danger" disabled={busy} onClick={() => void clear()}>Clear attempt history</button></div></Modal>}
  </main>;
}