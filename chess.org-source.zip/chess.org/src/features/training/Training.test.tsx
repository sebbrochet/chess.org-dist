// @vitest-environment jsdom
import React, { useState } from 'react';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { parseGames } from '../../chess/pgn';
import { legalContinuation } from '../../chess/review';
import { createLibrary, emptySnapshot, type DomainSnapshot } from '../../storage/library';
import { Training } from './Training';

vi.mock('../../components/Board', () => ({ Board: ({ fen, onMove, deferMoveReset }: { fen: string; onMove?: (move: string) => void; deferMoveReset?: boolean }) =>
  <div data-testid="training-board" data-fen={fen} data-deferred={String(deferMoveReset)}><button disabled={!onMove} onClick={() => onMove?.('e2e4')}>Board e4</button></div> }));
afterEach(cleanup);

async function fixture(pgn = '1.e4 e5 2.Nf3 *', side: 'white' | 'black' = 'white') {
  let durable = emptySnapshot();
  let barrier: Promise<void> | undefined = undefined;
  let failure = false;
  const library = createLibrary({ read: async () => structuredClone(durable), update: async change => {
    const next = change(structuredClone(durable));
    if (barrier) await barrier;
    if (failure) throw new Error('Quota');
    durable = next;
  } });
  const snapshot = await library.importGames(parseGames(pgn));
  let publish!: (snapshot: DomainSnapshot) => void;
  function Harness() {
    const [current, setCurrent] = useState<DomainSnapshot>(snapshot);
    publish = setCurrent;
    return <Training library={library} snapshot={current} onSnapshot={setCurrent} route={`#/practice/guess/${snapshot.games[0].id}?side=${side}`} />;
  }
  render(<Harness />);
  fireEvent.click(screen.getByRole('button', { name: 'Start practice' }));
  await waitFor(() => expect(screen.getByLabelText('Exercise result').textContent).toBe('Your answer'));
  const original = structuredClone(durable);
  let release!: () => void;
  barrier = new Promise<void>(resolve => { release = resolve; });
  return { original, read: () => structuredClone(durable), release, publish, fail: () => { failure = true; } };
}

it.each(['e4', 'd4'])('keeps %s visible until saving finishes and then keeps or rolls it back', async answer => {
  const test = await fixture();
  const initialFen = test.original.games[0].startFen;
  const playedFen = legalContinuation(initialFen, [answer === 'e4' ? 'e2e4' : 'd2d4'])[0].fen;
  if (answer === 'e4') fireEvent.click(screen.getByRole('button', { name: 'Board e4' }));
  else {
    fireEvent.change(screen.getByLabelText('Your move'), { target: { value: answer } });
    fireEvent.click(screen.getByRole('button', { name: 'Submit answer' }));
  }
  await waitFor(() => expect(screen.getByTestId('training-board').getAttribute('data-fen')).toBe(playedFen));
  expect(screen.getByLabelText('Exercise result').textContent).toBe('Checking and saving...');
  expect(screen.getByTestId('training-board').getAttribute('data-deferred')).toBe('true');
  expect((screen.getByRole('button', { name: 'Board e4' }) as HTMLButtonElement).disabled).toBe(true);
  expect((screen.getByLabelText('Your move') as HTMLInputElement).disabled).toBe(true);
  expect((screen.getByRole('button', { name: 'Reveal answer' }) as HTMLButtonElement).disabled).toBe(true);
  expect(test.read()).toEqual(test.original);
  await act(async () => { test.release(); });
  await waitFor(() => expect(screen.getByLabelText('Exercise result').textContent).toBe(answer === 'e4' ? 'Unaided success' : 'Not the recorded move'));
  expect(screen.getByTestId('training-board').getAttribute('data-fen')).toBe(answer === 'e4' ? playedFen : initialFen);
  expect(test.read().games).toEqual(test.original.games);
});

it('rolls a pending accepted move back on storage failure without awarding success', async () => {
  const test = await fixture();
  test.fail();
  fireEvent.click(screen.getByRole('button', { name: 'Board e4' }));
  await waitFor(() => expect(screen.getByTestId('training-board').getAttribute('data-fen')).toBe(test.original.games[0].positions[1]));
  expect(test.read()).toEqual(test.original);
  await act(async () => { test.release(); });
  await waitFor(() => expect(screen.getByRole('alert').textContent).toContain('Quota'));
  expect(screen.getByTestId('training-board').getAttribute('data-fen')).toBe(test.original.games[0].startFen);
  expect(screen.getByLabelText('Exercise result').textContent).toBe('Your answer');
  expect((screen.getByRole('button', { name: 'Board e4' }) as HTMLButtonElement).disabled).toBe(false);
  expect(test.read()).toEqual(test.original);
});

it.each(['Retry position', 'Next position'])('reveals a wrong answer only on request without writing history, then conceals it on %s', async next => {
  const test = await fixture('[White "Franzine_Echec"]\n[Black "sebbrochet"]\n1.e4 e5 2.Nf3 *');
  fireEvent.change(screen.getByLabelText('Your move'), { target: { value: 'd4' } });
  fireEvent.click(screen.getByRole('button', { name: 'Submit answer' }));
  await act(async () => { test.release(); });
  await waitFor(() => expect(screen.getByLabelText('Exercise result').textContent).toBe('Not the recorded move'));
  expect(screen.queryByLabelText('Target move')).toBeNull();
  const failed = test.read();
  fireEvent.click(screen.getByRole('button', { name: 'Show solution' }));
  expect(screen.getByLabelText('Target move').textContent).toBe('Target: e4');
  expect(test.read()).toEqual(failed);
  expect(screen.getByLabelText('Exercise result').textContent).toBe('Not the recorded move');
  expect(Array.from(screen.getByLabelText('Training board').querySelectorAll('.player-line strong')).map(node => node.textContent)).toEqual(['sebbrochet', 'Franzine_Echec']);
  fireEvent.click(screen.getByRole('button', { name: next }));
  await waitFor(() => expect(screen.getByLabelText('Exercise result').textContent).toBe('Your answer'));
  expect(screen.queryByLabelText('Target move')).toBeNull();
  expect(test.read().guessMoveAttempts[0]).toEqual(failed.guessMoveAttempts[0]);
});

it('uses color fallbacks when player headers are unavailable', async () => {
  await fixture('[White "?"]\n[Black " "]\n1.e4 *');
  expect(Array.from(screen.getByLabelText('Training board').querySelectorAll('.player-line strong')).map(node => node.textContent)).toEqual(['Black', 'White']);
});

it.each(['white', 'black'] as const)('keeps recorded player names associated with colors while practicing %s', async side => {
  await fixture('[White "Franzine_Echec"]\n[Black "sebbrochet"]\n1.e4 e5 *', side);
  expect(Array.from(screen.getByLabelText('Training board').querySelectorAll('.player-line strong')).map(node => node.textContent)).toEqual(side === 'white' ? ['sebbrochet', 'Franzine_Echec'] : ['Franzine_Echec', 'sebbrochet']);
});

it.each(['removed', 'changed', 'target unavailable'])('does not disclose the solution when the source is %s', async condition => {
  const test = await fixture();
  fireEvent.change(screen.getByLabelText('Your move'), { target: { value: 'd4' } });
  fireEvent.click(screen.getByRole('button', { name: 'Submit answer' }));
  await act(async () => { test.release(); });
  await waitFor(() => expect(screen.getByLabelText('Exercise result').textContent).toBe('Not the recorded move'));
  const failed = test.read();
  const unavailable = structuredClone(failed);
  if (condition === 'removed') unavailable.games = [];
  else if (condition === 'changed') unavailable.games[0] = { ...unavailable.games[0], ...parseGames('1.d4 d5 2.Nf3 *')[0] };
  else unavailable.guessMoveAttempts[0].target = 'invalid';
  await act(async () => { test.publish(unavailable); });
  expect(screen.queryByLabelText('Target move')).toBeNull();
  const reveal = screen.queryByRole('button', { name: 'Show solution' }) as HTMLButtonElement | null;
  if (condition === 'removed') expect(reveal).toBeNull(); else expect(reveal?.disabled).toBe(true);
  expect(test.read()).toEqual(failed);
});