// @vitest-environment jsdom
import React, { useState } from 'react';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { Repertoires } from './Repertoires';
import { importRepertoire } from '../../chess/repertoire';
import { createLibrary, emptySnapshot, type DomainSnapshot } from '../../storage/library';

vi.mock('../../components/Board', () => ({ Board: ({ fen, markings }: { fen: string; markings?: { from: number; to: number }[] }) =>
  <div data-testid="board" data-arrows={(markings ?? []).map(shape => `${shape.from}-${shape.to}`).join(',')}>{fen}</div> }));
afterEach(() => { cleanup(); vi.useRealTimers(); });

const book = importRepertoire('1. e4 c6 { Solid. } 2. d4 d5 { Strike the centre. } *', 'Caro', 'black');
function setup(extensions: Record<string, unknown> = {}) {
  let durable: DomainSnapshot = { ...emptySnapshot(), repertoires: [book], extensions };
  const library = createLibrary({ read: async () => structuredClone(durable), update: async change => { durable = change(structuredClone(durable)); } });
  function Harness() {
    const [snapshot, setSnapshot] = useState(durable);
    return <Repertoires library={library} snapshot={snapshot} onSnapshot={setSnapshot} route={`#/practice/repertoire/${book.id}`} />;
  }
  render(<Harness />);
  return { saved: () => durable };
}
async function answer(move: string) {
  fireEvent.change(screen.getByLabelText('Recall move'), { target: { value: move } });
  fireEvent.click(screen.getByRole('button', { name: 'Submit recall' }));
  await waitFor(() => expect(screen.getByLabelText('Recall result').textContent).not.toBe('Saving...'));
}

it('explains a missed recall with target arrows and comments, and waits even with auto-advance on', async () => {
  const store = setup({ practiceAutoAdvance: true });
  fireEvent.click(screen.getByRole('button', { name: 'Start recall' }));
  await waitFor(() => expect(screen.getByLabelText('Recall move')).toBeTruthy());
  expect(screen.queryByText('Solid.')).toBeNull();
  await answer('e5');
  expect(screen.getByLabelText('Recall result').textContent).toBe('Not a selected repertoire move');
  expect(screen.getByLabelText('Recall explanation').textContent).toBe('c6Solid.');
  expect(screen.getByTestId('board').dataset.arrows).toBe('50-42');
  await new Promise(resolve => setTimeout(resolve, 1300));
  expect(store.saved().repertoireAttempts).toHaveLength(1);
});

it('shows no comments after a correct answer and auto-advances only when enabled', async () => {
  const store = setup();
  expect((screen.getByLabelText('Auto-advance after a correct answer') as HTMLInputElement).checked).toBe(false);
  fireEvent.click(screen.getByLabelText('Auto-advance after a correct answer'));
  await waitFor(() => expect(store.saved().extensions.practiceAutoAdvance).toBe(true));
  fireEvent.click(screen.getByRole('button', { name: 'Start recall' }));
  await waitFor(() => expect(screen.getByLabelText('Recall move')).toBeTruthy());
  await answer('c6');
  expect(screen.getByLabelText('Recall result').textContent).toBe('Unaided success');
  expect(screen.queryByLabelText('Recall explanation')).toBeNull();
  expect(screen.getByTestId('board').dataset.arrows).toBe('');
  expect(store.saved().repertoireAttempts).toHaveLength(1);
  await waitFor(() => expect(store.saved().repertoireAttempts).toHaveLength(2), { timeout: 3000 });
  await waitFor(() => expect(screen.getByLabelText('Recall result').textContent).toBe('Your recall move'));
  await answer('d5');
  await act(async () => { await new Promise(resolve => setTimeout(resolve, 1300)); });
  expect(store.saved().repertoireAttempts).toHaveLength(2);
});

it('shows the path while recalling, names the chapter only after the answer and hides the path when switched off', async () => {
  const store = setup();
  fireEvent.click(screen.getByRole('button', { name: 'Start recall' }));
  await waitFor(() => expect(screen.getByLabelText('Recall move')).toBeTruthy());
  expect(screen.getByLabelText('Path to position').textContent).toBe('1. e4');
  expect(screen.queryByLabelText('Recall chapter')).toBeNull();
  await answer('c6');
  expect(screen.getByLabelText('Recall chapter').textContent).toBe('Chapter: Chapter 1');
  fireEvent.click(screen.getByLabelText('Show path to the position'));
  await waitFor(() => expect(store.saved().extensions.practiceShowPath).toBe(false));
  await waitFor(() => expect(screen.queryByLabelText('Path to position')).toBeNull());
});

it('steps through the path read-only, stops at the recall position before answering and previews without moving the board', async () => {
  setup();
  fireEvent.click(screen.getByRole('button', { name: 'Start recall' }));
  await waitFor(() => expect(screen.getByLabelText('Recall move')).toBeTruthy());
  await answer('c6');
  fireEvent.click(screen.getByRole('button', { name: 'Next recall' }));
  await waitFor(() => expect(screen.getByLabelText('Recall result').textContent).toBe('Your recall move'));
  const recallFen = screen.getByTestId('board').textContent;
  expect(screen.getByLabelText('Path to position').textContent).toBe('1. e4c62. d4');
  expect((screen.getByRole('button', { name: 'Next move' }) as HTMLButtonElement).disabled).toBe(true);
  fireEvent.click(screen.getByRole('button', { name: 'c6' }));
  expect(screen.getByTestId('board').textContent).toBe(book.lines[0].positions[2]);
  expect((screen.getByLabelText('Recall move') as HTMLInputElement).disabled).toBe(true);
  expect(screen.getByText('Earlier position')).toBeTruthy();
  fireEvent.click(screen.getByRole('button', { name: 'First position' }));
  expect(screen.getByTestId('board').textContent).toBe(book.lines[0].positions[0]);
  fireEvent.click(screen.getByRole('button', { name: 'Next move' }));
  fireEvent.click(screen.getByRole('button', { name: 'Next move' }));
  fireEvent.click(screen.getByRole('button', { name: 'Next move' }));
  expect(screen.getByTestId('board').textContent).toBe(recallFen);
  expect((screen.getByLabelText('Recall move') as HTMLInputElement).disabled).toBe(false);
  expect(screen.queryByText('Earlier position')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after 1. e4' }));
  expect(screen.getByRole('dialog', { name: 'Position after 1. e4' })).toBeTruthy();
  expect(screen.getByTestId('board').textContent).toBe(recallFen);
});

it('adds the decided move as the last step and lets auto-advance wait while an earlier position is shown', async () => {
  const store = setup({ practiceAutoAdvance: true });
  fireEvent.click(screen.getByRole('button', { name: 'Start recall' }));
  await waitFor(() => expect(screen.getByLabelText('Recall move')).toBeTruthy());
  await answer('c6');
  fireEvent.click(screen.getByRole('button', { name: 'First position' }));
  expect(screen.getByLabelText('Path to position').textContent).toBe('1. e4c6');
  await act(async () => { await new Promise(resolve => setTimeout(resolve, 1300)); });
  expect(store.saved().repertoireAttempts).toHaveLength(1);
  fireEvent.click(screen.getByRole('button', { name: 'Next move' }));
  fireEvent.click(screen.getByRole('button', { name: 'Next move' }));
  expect(screen.getByTestId('board').textContent).toBe(book.lines[0].positions[2]);
  fireEvent.click(screen.getByRole('button', { name: 'Current position' }));
  await waitFor(() => expect(store.saved().repertoireAttempts).toHaveLength(2), { timeout: 3000 });
});

it('does not advance after a correct answer when auto-advance is off', async () => {
  const store = setup();
  fireEvent.click(screen.getByRole('button', { name: 'Start recall' }));
  await waitFor(() => expect(screen.getByLabelText('Recall move')).toBeTruthy());
  await answer('c6');
  await act(async () => { await new Promise(resolve => setTimeout(resolve, 1300)); });
  expect(store.saved().repertoireAttempts).toHaveLength(1);
  expect(screen.getByRole('button', { name: 'Next recall' })).toBeTruthy();
});
