import { useEffect, useRef, useState } from 'react';
import { ArrowRight, BookOpen, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Eye, FilePlus2, Lightbulb, Pencil, RotateCcw, Trash2 } from 'lucide-react';
import { makeSan } from 'chessops/san';
import { parseSquare, parseUci } from 'chessops/util';
import { Board } from '../../components/Board';
import { Modal } from '../../components/Modal';
import { MovePreviewProvider, PreviewableMove } from '../../components/MovePreview';
import { positionFromFen } from '../../chess/pgn';
import { recallDisplay, recallLeadMove, recallPath, recallPositions, type RecallStep } from '../../chess/repertoire';
import { cachedRepertoireChapters, recallExplanations, type RecallExplanation, type StudyChapter } from '../../chess/repertoireStudy';
import { legalContinuation } from '../../chess/review';
import { candidateUci } from '../../chess/training';
import { practiceAutoAdvance, practiceShowPath, type createLibrary, type DomainSnapshot } from '../../storage/library';

export function Repertoires({ library, snapshot, onSnapshot, route }: { library: ReturnType<typeof createLibrary>; snapshot: DomainSnapshot; onSnapshot: (value: DomainSnapshot) => void; route: string }) {
  const practice = route.startsWith('#/practice/repertoire/');
  const [path, query] = route.split('?');
  const [selectedId, setSelectedId] = useState(practice ? decodeURIComponent(path.split('/')[3] ?? '') : snapshot.repertoires[0]?.id ?? '');
  const book = snapshot.repertoires.find(record => record.id === selectedId);
  const [lines, setLines] = useState<string[]>([]);
  const [name, setName] = useState(''); const [source, setSource] = useState(''); const [side, setSide] = useState<'white' | 'black'>('white');
  const [dialog, setDialog] = useState<'import' | 'replace' | 'rename' | 'delete' | null>(null);
  const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [hint, setHint] = useState(false);
  const [attemptId, setAttemptId] = useState(''); const [answer, setAnswer] = useState(''); const [promotion, setPromotion] = useState('');
  const [pending, setPending] = useState<{ attemptId: string; fen: string; move: string }>();
  const [viewStep, setViewStep] = useState<number>();
  const lock = useRef(false);
  const lineIds = book?.lines.map(line => line.id).join(',') ?? '';
  useEffect(() => {
    const requested = new URLSearchParams(query).get('lines')?.split(',');
    setLines(lineIds ? lineIds.split(',').filter(id => !requested || requested.includes(id)) : []);
    setAttemptId(''); setHint(false);
  }, [lineIds, book?.id, book?.generation, query]);
  const attempt = snapshot.repertoireAttempts.find(record => record.id === attemptId);
  const positions = book ? recallPositions(book, lines) : [];
  const cursor = attempt ? positions.findIndex(fen => fen.split(' ').slice(0, 4).join(' ') === attempt.fen.split(' ').slice(0, 4).join(' ')) : -1;
  const ended = !!attempt && attempt.status !== 'Active';
  const chosenSet = new Set(lines);
  const lineMoves = new Map(book?.lines.map(line => [line.id, line.moves.join(' ')]) ?? []);
  const groups: { key: string; name: string; ids: string[] }[] = [];
  if (book) {
    let chapters: StudyChapter[] = [];
    try { chapters = cachedRepertoireChapters(book); } catch { /* ungrouped lines remain selectable */ }
    for (const chapter of chapters) groups.push({ key: `chapter-${chapter.index}`, name: `${chapter.index + 1}. ${chapter.name}`, ids: chapter.lineIds });
    const grouped = new Set(groups.flatMap(group => group.ids));
    const rest = book.lines.filter(line => !grouped.has(line.id)).map(line => line.id);
    if (rest.length) groups.push({ key: 'other', name: chapters.length ? 'Other lines' : 'Lines', ids: rest });
  }
  const shown = attempt ? busy && pending?.attemptId === attempt.id ? { fen: pending.fen, lastMove: pending.move } : recallDisplay(attempt) : undefined;
  const autoAdvance = practiceAutoAdvance(snapshot);
  const showPath = practiceShowPath(snapshot);
  const recallRoute = attempt && book ? recallPath(book, attempt.selectedLines, attempt.fen) : undefined;
  let chapterNames: string[] = [];
  if (attempt && attempt.status !== 'Active' && book && recallRoute) {
    try { const through = new Set(recallRoute.lineIds); chapterNames = cachedRepertoireChapters(book).filter(chapter => chapter.lineIds.some(id => through.has(id))).map(chapter => chapter.name); } catch { /* chapter names are optional context */ }
  }
  const matched = !!attempt && ended && attempt.targets.includes(attempt.answers.at(-1) ?? '');
  const missed = !!attempt && ended && !matched;
  let explanations: RecallExplanation[] = [];
  if (missed && book) { try { explanations = recallExplanations(cachedRepertoireChapters(book), attempt.fen, attempt.targets, attempt.selectedLines); } catch { /* targets remain listed */ } }
  const targetArrows = missed ? attempt!.targets.map(uci => ({ color: 'green' as const, from: parseSquare(uci.slice(0, 2))!, to: parseSquare(uci.slice(2, 4))! })) : undefined;
  const nextPosition = cursor >= 0 ? positions[cursor + 1] : undefined;
  const navSteps: RecallStep[] = recallRoute && showPath ? [...recallRoute.steps] : [];
  const recallIndex = navSteps.length;
  if (attempt && ended && showPath && recallRoute) {
    const decided = matched ? attempt.answers.at(-1)! : attempt.targets[0];
    const position = positionFromFen(attempt.fen);
    const [, turn, , , , fullmove] = attempt.fen.split(' ');
    const san = makeSan(position, parseUci(decided)!);
    navSteps.push({ uci: decided, fen: legalContinuation(attempt.fen, [decided])[0].fen, label: turn === 'w' ? `${fullmove}. ${san}` : recallIndex ? san : `${fullmove}... ${san}` });
  }
  const browsedStep = showPath ? viewStep : undefined;
  const browsing = browsedStep !== undefined;
  const displayIndex = browsedStep ?? (matched ? navSteps.length : recallIndex);
  const stepFen = (index: number) => index === 0 ? recallRoute!.startFen : navSteps[index - 1].fen;
  const goTo = (index: number) => setViewStep(!ended && index >= recallIndex ? undefined : index);
  useEffect(() => { setViewStep(undefined); }, [attempt?.id, showPath]);
  const boardFen = browsedStep !== undefined ? stepFen(browsedStep) : shown?.fen ?? positions[0] ?? book?.lines[0].positions[0] ?? '';
  const lead = browsing || shown?.lastMove || !book ? undefined : recallLeadMove(book, attempt?.selectedLines ?? lines, boardFen);
  useEffect(() => {
    if (!matched || !autoAdvance || !nextPosition || busy || browsing) return;
    const timer = window.setTimeout(() => void start(nextPosition), 1000);
    return () => window.clearTimeout(timer);
    // start() is recreated each render; the attempt id and settings fully identify a pending advance.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attempt?.id, matched, autoAdvance, nextPosition, busy, browsing]);
  async function save(run: () => Promise<DomainSnapshot>) {
    if (lock.current) return; lock.current = true; setBusy(true); setError('');
    try { const next = await run(); onSnapshot(next); return next; } catch (reason) { setError(reason instanceof Error ? reason.message : 'Not saved.'); } finally { lock.current = false; setBusy(false); }
  }
  async function start(fen?: string) {
    if (!book) return;
    const next = await save(() => library.startRecall(book.id, lines, fen));
    if (next) { setAttemptId(next.repertoireAttempts.at(-1)!.id); setAnswer(''); setHint(false); }
  }
  async function action(value: { type: 'answer'; input: string } | { type: 'hint' | 'reveal' }) {
    if (!attempt) return;
    if (value.type === 'answer') {
      try { const move = candidateUci(attempt.fen, value.input); setPending({ attemptId: attempt.id, fen: legalContinuation(attempt.fen, [move])[0].fen, move }); } catch { /* the save reports illegal input */ }
    }
    const next = await save(() => library.recallAction(attempt.id, value));
    setPending(undefined);
    if (next && value.type === 'hint') setHint(true);
  }
  function boardMove(uci: string) {
    if (!attempt) return;
    const square = parseSquare(uci.slice(0, 2));
    if (square !== undefined && positionFromFen(attempt.fen).board.get(square)?.role === 'pawn' && /[18]$/.test(uci)) setPromotion(uci);
    else void action({ type: 'answer', input: uci });
  }
  function open(kind: typeof dialog) { setError(''); setDialog(kind); setName(book?.name ?? ''); setSource(''); setSide(book?.side ?? 'white'); }
  return <main className={practice && book ? 'workspace review-workspace' : 'progress-workspace'}>
    {practice && book && <section className="replay" aria-label="Repertoire practice board"><Board fen={boardFen} orientation={book.side} lastMove={browsedStep !== undefined ? navSteps[browsedStep - 1]?.uci : shown?.lastMove ?? lead?.move} lastMoveFrom={!browsing && attempt && !ended && !attempt.answers.length && lead ? lead.from : undefined} markings={browsing ? undefined : targetArrows} deferMoveReset onMove={attempt && !ended && !busy && !browsing ? boardMove : undefined} />
      {attempt && showPath && recallRoute && (recallRoute.steps.length > 0 || ended) && <div className="replay-toolbar">
        <button className="icon" title="First position" aria-label="First position" disabled={displayIndex === 0} onClick={() => goTo(0)}><ChevronsLeft /></button>
        <button className="icon" title="Previous move" aria-label="Previous move" disabled={displayIndex === 0} onClick={() => goTo(displayIndex - 1)}><ChevronLeft /></button>
        <button className="icon" title="Next move" aria-label="Next move" disabled={!browsing || displayIndex >= navSteps.length} onClick={() => goTo(displayIndex + 1)}><ChevronRight /></button>
        <button className="icon" title="Current position" aria-label="Current position" disabled={!browsing} onClick={() => setViewStep(undefined)}><ChevronsRight /></button>
        {browsing && <output role="status">Earlier position</output>}
      </div>}
      {attempt && <form className="san-entry" onSubmit={event => { event.preventDefault(); void action({ type: 'answer', input: answer }); }}><label htmlFor="recall-san">Recall move</label><input id="recall-san" value={answer} disabled={busy || ended || browsing} onChange={event => setAnswer(event.target.value)} /><button className="icon" title="Submit recall" aria-label="Submit recall" disabled={busy || ended || browsing || !answer.trim()}><ArrowRight /></button></form>}</section>}
    <section className="game-panel"><header className="panel-heading"><h1>{practice ? 'Practice Repertoire' : 'Repertoires'}</h1>{!practice && <button className="primary" disabled={busy} onClick={() => open('import')}><FilePlus2 size={17} />Import repertoire</button>}</header>
      {error && <p className="error" role="alert">{error}</p>}
      {!practice && <ul className="review-picker">{snapshot.repertoires.map(record => <li key={record.id}><button aria-current={book?.id === record.id ? 'true' : undefined} onClick={() => setSelectedId(record.id)}>{record.name} / {record.side} / {record.lines.length} lines</button></li>)}</ul>}
      {!book ? <p>{practice ? 'The selected repertoire is unavailable.' : 'No repertoires retained.'}</p> : <><h2>{book.name}</h2><p>{book.side} / {book.lines.length} imported lines</p>
        {practice && <label className="check-field"><input type="checkbox" checked={autoAdvance} disabled={busy} onChange={event => void save(() => library.changePracticeSettings({ autoAdvance: event.target.checked }))} />Auto-advance after a correct answer</label>}
        {practice && <label className="check-field"><input type="checkbox" checked={showPath} disabled={busy} onChange={event => void save(() => library.changePracticeSettings({ showPath: event.target.checked }))} />Show path to the position</label>}
        {!attempt && <><fieldset disabled={busy}><legend>Selected lines</legend>{groups.map(group => {
          const chosen = group.ids.filter(id => chosenSet.has(id)).length;
          return <div className="line-group" key={group.key}>
            <label><input type="checkbox" disabled={!group.ids.length} checked={!!group.ids.length && chosen === group.ids.length} ref={element => { if (element) element.indeterminate = chosen > 0 && chosen < group.ids.length; }} onChange={event => setLines(previous => event.target.checked ? [...new Set([...previous, ...group.ids])] : previous.filter(id => !group.ids.includes(id)))} />{group.name} ({group.ids.length ? `${chosen}/${group.ids.length} lines` : 'no moves'})</label>
            {group.ids.length > 0 && <details><summary>Show lines</summary>{group.ids.map(id => <label className="preview-row" key={id}><input type="checkbox" checked={chosenSet.has(id)} onChange={event => setLines(previous => event.target.checked ? [...previous, id] : previous.filter(item => item !== id))} />{lineMoves.get(id)}</label>)}</details>}
          </div>;
        })}</fieldset>
          {practice ? <button className="primary" disabled={busy || !positions.length} onClick={() => void start()}>Start recall</button> : <><div className="play-actions"><button onClick={() => open('rename')}><Pencil size={17} />Rename</button><button onClick={() => open('replace')}><RotateCcw size={17} />Replace PGN</button><button className="danger" onClick={() => open('delete')}><Trash2 size={17} />Delete repertoire</button></div><div className="play-actions"><a className="button-link" href={`#/learn/repertoire/${book.id}`}><BookOpen size={16} />Learn</a><a className="resume-link" href={`#/practice/repertoire/${book.id}?lines=${encodeURIComponent(lines.join(','))}`}>Practice selected lines</a></div></>}</>}
        {attempt && showPath && navSteps.length > 0 && <MovePreviewProvider orientation={book.side} resetKey={attempt.id}><ol className="recall-path" aria-label="Path to position">{navSteps.map((step, index) => <li key={index}><PreviewableMove fen={step.fen} label={step.label} move={step.uci}><button type="button" className="study-move" aria-current={displayIndex === index + 1 ? 'step' : undefined} onClick={() => goTo(index + 1)}>{step.label}</button></PreviewableMove></li>)}</ol>{recallRoute!.otherOrders > 0 && <p className="review-note">Also reached via {recallRoute!.otherOrders} other move {recallRoute!.otherOrders === 1 ? 'order' : 'orders'}.</p>}</MovePreviewProvider>}
        {attempt && <><p role="status" aria-label="Recall result">{busy ? 'Saving...' : attempt.status === 'Success' ? 'Unaided success' : attempt.status === 'Assisted' ? 'Assisted result' : attempt.status === 'Incorrect' ? 'Not a selected repertoire move' : 'Your recall move'}</p>
          {hint && !ended && <p aria-label="Recall hint">Move from {attempt.targets[0].slice(0, 2)}.</p>}
          {ended && <p aria-label="Recall targets">Targets: {attempt.targets.map(move => makeSan(positionFromFen(attempt.fen), parseUci(move)!)).join(', ')}</p>}
          {ended && chapterNames.length > 0 && <p className="review-note" aria-label="Recall chapter">Chapter: {chapterNames.join(' / ')}</p>}
          {missed && explanations.some(item => item.comments.length) && <ul className="recall-explanation" aria-label="Recall explanation">{explanations.filter(item => item.comments.length).map(item => <li key={item.uci}><strong>{item.san}</strong>{item.comments.map((text, index) => <p key={index} className="study-comment">{text}</p>)}</li>)}</ul>}
          <div className="play-actions">{!ended ? <><button disabled={busy} onClick={() => void action({ type: 'hint' })}><Lightbulb size={17} />Show hint</button><button disabled={busy} onClick={() => void action({ type: 'reveal' })}><Eye size={17} />Reveal answer</button></> : <><button disabled={busy} onClick={() => void start(attempt.fen)}><RotateCcw size={17} />Repeat position</button><button disabled={busy || !positions[cursor + 1]} onClick={() => void start(positions[cursor + 1])}><ArrowRight size={17} />Next recall</button></>}</div></>}
      </>}
      <footer className="library-footer"><a href="#/repertoires">Repertoires</a><a href="#/progress">Progress</a></footer>
    </section>
    {dialog && <Modal title={dialog === 'import' ? 'Import repertoire' : dialog === 'replace' ? 'Replace repertoire PGN' : dialog === 'rename' ? 'Rename repertoire' : 'Delete repertoire?'} busy={busy} onClose={() => setDialog(null)}><form onSubmit={event => {
      event.preventDefault(); void save(async () => {
        const next = dialog === 'import' ? await library.importRepertoire(source, name, side) : dialog === 'replace' ? await library.replaceRepertoire(book!.id, source, side) : dialog === 'rename' ? await library.renameRepertoire(book!.id, name) : await library.deleteRepertoire(book!.id);
        setDialog(null); if (dialog === 'import') setSelectedId(next.repertoires.at(-1)!.id); return next;
      });
    }}>{error && <p className="error" role="alert">{error}</p>}{(dialog === 'import' || dialog === 'rename') && <label className="field">Repertoire name<input value={name} onChange={event => setName(event.target.value)} required maxLength={200} /></label>}
      {(dialog === 'import' || dialog === 'replace') && <><label className="field">Learned side<select value={side} onChange={event => setSide(event.target.value as 'white' | 'black')}><option value="white">White</option><option value="black">Black</option></select></label><label className="field">Repertoire PGN<textarea value={source} rows={8} onChange={event => setSource(event.target.value)} required /></label><label className="field">PGN file<input type="file" accept=".pgn,.txt" onChange={event => { const file = event.target.files?.[0]; if (file) void file.text().then(setSource).catch(() => setError('Cannot read this file.')); }} /></label></>}
      {dialog === 'delete' && <p>Remove this repertoire and its recall history?</p>}{dialog === 'replace' && <p>Replacement removes previous recall history.</p>}<div className="dialog-actions"><button type="button" disabled={busy} onClick={() => setDialog(null)}>Cancel</button><button className={dialog === 'delete' ? 'danger' : 'primary'} disabled={busy}> {dialog === 'import' ? 'Save repertoire' : dialog === 'replace' ? 'Replace lines' : dialog === 'rename' ? 'Save name' : 'Delete permanently'}</button></div></form></Modal>}
    {promotion && <Modal title="Promote recall pawn" busy={busy} onClose={() => setPromotion('')}><div className="play-actions">{['q', 'r', 'b', 'n'].map((piece, index) => <button key={piece} onClick={() => { const input = promotion + piece; setPromotion(''); void action({ type: 'answer', input }); }}>{['Queen', 'Rook', 'Bishop', 'Knight'][index]}</button>)}</div></Modal>}
  </main>;
}