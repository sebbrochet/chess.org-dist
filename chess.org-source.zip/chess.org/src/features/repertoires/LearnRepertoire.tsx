import { Fragment, useEffect, useRef, useState, type ReactNode } from 'react';
import { ArrowLeft, ArrowRight, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Dumbbell, Minus, Plus } from 'lucide-react';
import { Board } from '../../components/Board';
import { MovePreviewProvider, PreviewableMove } from '../../components/MovePreview';
import { cachedRepertoireChapters, lineEnd, studyPath, type StudyChapter } from '../../chess/repertoireStudy';
import type { DomainSnapshot } from '../../storage/library';

function moveLabel(chapter: StudyChapter, id: number, numbered: boolean): string {
  const node = chapter.nodes[id];
  const [, turn, , , , fullmove] = chapter.nodes[node.parent].fen.split(' ');
  return turn === 'w' ? `${fullmove}. ${node.san}` : numbered ? `${fullmove}... ${node.san}` : node.san;
}

export function LearnRepertoire({ snapshot, route }: { snapshot: DomainSnapshot; route: string }) {
  const book = snapshot.repertoires.find(record => record.id === decodeURIComponent(route.split('?')[0].split('/')[3] ?? ''));
  let chapters: StudyChapter[] | undefined;
  let failure = '';
  try { chapters = book ? cachedRepertoireChapters(book) : undefined; } catch (error) { failure = error instanceof Error ? error.message : 'The repertoire source could not be read.'; }
  const [chapterIndex, setChapterIndex] = useState(0);
  const [selected, setSelected] = useState(0);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());
  const treeRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const tree = treeRef.current;
    const current = tree?.querySelector('[aria-current="step"]');
    if (!tree || !current) return;
    const bounds = tree.getBoundingClientRect(); const row = current.getBoundingClientRect();
    if (row.top < bounds.top) tree.scrollTop -= bounds.top - row.top;
    else if (row.bottom > bounds.bottom) tree.scrollTop += row.bottom - bounds.bottom;
  }, [selected, chapterIndex]);

  if (!book) return <main className="progress-workspace"><h1>Repertoire unavailable</h1><p>This opening collection no longer exists.</p><a href="#/repertoires">Repertoires</a></main>;
  if (!chapters) return <main className="progress-workspace"><h1>{book.name}</h1><p className="error" role="alert">{failure}</p><a href="#/repertoires">Repertoires</a></main>;
  const chapter = chapters[Math.min(chapterIndex, chapters.length - 1)];
  const node = chapter.nodes[selected] ?? chapter.nodes[0];
  const onPath = new Set(studyPath(chapter, node.id));
  const openChapter = (index: number) => { setChapterIndex(index); setSelected(0); setExpanded(new Set()); };
  const toggle = (id: number) => setExpanded(previous => { const next = new Set(previous); if (next.has(id)) next.delete(id); else next.add(id); return next; });

  const move = (id: number, numbered: boolean) => {
    const item = chapter.nodes[id];
    return <Fragment key={id}>
      {item.before.map((text, index) => <p key={`b${index}`} className="study-comment">{text}</p>)}
      <PreviewableMove fen={item.fen} label={moveLabel(chapter, id, true)} move={item.uci} markings={item.shapes}><button type="button" className="study-move" aria-current={node.id === id ? 'step' : undefined} onClick={() => setSelected(id)}>{moveLabel(chapter, id, numbered)}</button></PreviewableMove>
      {item.comments.map((text, index) => <p key={`c${index}`} className="study-comment">{text}</p>)}
    </Fragment>;
  };
  const line = (from: number): ReactNode[] => {
    const out: ReactNode[] = [];
    let at = from; let numbered = true;
    while (chapter.nodes[at].children.length) {
      const [main, ...sides] = chapter.nodes[at].children;
      out.push(move(main, numbered));
      numbered = chapter.nodes[main].comments.length > 0 || sides.length > 0;
      for (const side of sides) out.push(variation(side));
      at = main;
    }
    return out;
  };
  const variation = (id: number): ReactNode => {
    const open = expanded.has(id) || onPath.has(id);
    const count = chapter.nodes[id].lineIds.length;
    return <div key={`v${id}`} className="study-variation">
      {open ? <>
        {!onPath.has(id) && <button type="button" className="icon study-toggle" title="Collapse variation" aria-label={`Collapse variation ${moveLabel(chapter, id, true)}`} onClick={() => toggle(id)}><Minus size={14} /></button>}
        {move(id, true)}{line(id)}
      </> : <button type="button" className="study-collapsed" aria-expanded="false" onClick={() => toggle(id)}><Plus size={14} />{moveLabel(chapter, id, true)} ({count} {count === 1 ? 'line' : 'lines'})</button>}
    </div>;
  };
  const practiceHref = node.lineIds.length ? `#/practice/repertoire/${book.id}?lines=${encodeURIComponent(node.lineIds.join(','))}` : undefined;

  return <main className="workspace review-workspace learn-workspace">
    <section className="replay" aria-label="Learn board">
      <Board fen={node.fen} orientation={book.side} lastMove={node.uci || undefined} markings={node.id === 0 ? chapter.introShapes : node.shapes} />
      <div className="replay-toolbar">
        <button className="icon" title="First position" aria-label="First position" disabled={node.id === 0} onClick={() => setSelected(0)}><ChevronsLeft /></button>
        <button className="icon" title="Previous move" aria-label="Previous move" disabled={node.id === 0} onClick={() => setSelected(node.parent)}><ChevronLeft /></button>
        <button className="icon" title="Next move" aria-label="Next move" disabled={!node.children.length} onClick={() => setSelected(node.children[0])}><ChevronRight /></button>
        <button className="icon" title="End of line" aria-label="End of line" disabled={!node.children.length} onClick={() => setSelected(lineEnd(chapter, node.id))}><ChevronsRight /></button>
      </div>
    </section>
    <section className="game-panel" aria-label="Learn repertoire">
      <header className="panel-heading"><div><span className="eyebrow">Learn / {book.side}</span><h1>{book.name}</h1></div></header>
      <ol className="study-chapters" aria-label="Chapters">{chapters.map(item => <li key={item.index}><button type="button" aria-current={item.index === chapter.index ? 'true' : undefined} onClick={() => openChapter(item.index)}>{item.name}</button></li>)}</ol>
      <h2 className="study-chapter-title">{chapter.index + 1}. {chapter.name}</h2>
      <div className="play-actions">
        <button type="button" disabled={chapter.index === 0} onClick={() => openChapter(chapter.index - 1)}><ArrowLeft size={16} />Previous chapter</button>
        <button type="button" disabled={chapter.index === chapters.length - 1} onClick={() => openChapter(chapter.index + 1)}>Next chapter<ArrowRight size={16} /></button>
        {practiceHref ? <a className="button-link" href={practiceHref}><Dumbbell size={16} />Practice from here</a> : <button type="button" disabled><Dumbbell size={16} />Practice from here</button>}
      </div>
      <MovePreviewProvider orientation={book.side} resetKey={`${chapter.index}`}><div ref={treeRef} className="study-tree" aria-label="Chapter moves">
        {chapter.intro.map((text, index) => <p key={index} className="study-comment study-intro">{text}</p>)}
        <button type="button" className="study-move" aria-current={node.id === 0 ? 'step' : undefined} onClick={() => setSelected(0)}>Start</button>
        {line(0)}
        {chapter.nodes.length === 1 && <p className="review-note">This chapter has no moves.</p>}
      </div></MovePreviewProvider>
      <footer className="library-footer"><a href="#/repertoires">Repertoires</a><a href="#/progress">Progress</a></footer>
    </section>
  </main>;
}
