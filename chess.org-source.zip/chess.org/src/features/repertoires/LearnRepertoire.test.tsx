// @vitest-environment jsdom
import React from 'react';
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { LearnRepertoire } from './LearnRepertoire';
import { importRepertoire } from '../../chess/repertoire';
import { emptySnapshot } from '../../storage/library';

vi.mock('../../components/Board', () => ({ Board: ({ fen, orientation, markings }: { fen: string; orientation: string; markings?: unknown[] }) =>
  <div data-testid="board" data-orientation={orientation} data-markings={markings?.length ?? 0}>{fen}</div> }));
afterEach(cleanup);

const SOURCE = `[ChapterName "Introduction"]

{ Read me first. } *

[ChapterName "Main line"]

1. e4 { Center. [%cal Ge2e4] } c6 (1... e5 { Symmetric } 2. Nf3) 2. d4 d5 *
`;
const book = importRepertoire(SOURCE, 'Course', 'black');
const snapshot = { ...emptySnapshot(), repertoires: [book] };

it('lists chapters in order, reads comments and markings, and navigates without recording anything', () => {
  render(<LearnRepertoire snapshot={snapshot} route={`#/learn/repertoire/${book.id}`} />);
  const chapters = within(screen.getByRole('list', { name: 'Chapters' })).getAllByRole('button').map(button => button.textContent);
  expect(chapters).toEqual(['Introduction', 'Main line']);
  expect(screen.getByText('Read me first.')).toBeTruthy();
  expect(screen.getByText('This chapter has no moves.')).toBeTruthy();
  expect((screen.getByRole('button', { name: 'Practice from here' }) as HTMLButtonElement).disabled).toBe(true);
  fireEvent.click(screen.getByRole('button', { name: /Next chapter/ }));
  expect(screen.getByTestId('board').dataset.orientation).toBe('black');
  fireEvent.click(screen.getByRole('button', { name: 'Next move' }));
  expect(screen.getByTestId('board').textContent).toContain('4P3');
  expect(screen.getByTestId('board').dataset.markings).toBe('1');
  expect(screen.getByText('Center.')).toBeTruthy();
  expect(screen.queryByText('Symmetric')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: /1\.\.\. e5 \(1 line\)/ }));
  expect(screen.getByText('Symmetric')).toBeTruthy();
  fireEvent.click(screen.getByRole('button', { name: '1... e5' }));
  const practice = screen.getByRole('link', { name: 'Practice from here' });
  const lines = decodeURIComponent(practice.getAttribute('href')!.split('lines=')[1]).split(',');
  expect(lines.map(id => book.lines.find(line => line.id === id)!.moves.join(' '))).toEqual(['e4 e5 Nf3']);
  fireEvent.click(screen.getByRole('button', { name: 'End of line' }));
  expect(screen.getByTestId('board').textContent).toContain('5N2');
  fireEvent.click(screen.getByRole('button', { name: 'First position' }));
  expect(decodeURIComponent(screen.getByRole('link', { name: 'Practice from here' }).getAttribute('href')!.split('lines=')[1]).split(',')).toHaveLength(2);
  const before = screen.getByTestId('board').textContent;
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after 1. e4' }));
  expect(screen.getByRole('dialog', { name: 'Position after 1. e4' })).toBeTruthy();
  expect(screen.getByTestId('board').textContent).toBe(before);
  expect(snapshot.repertoireAttempts).toEqual([]);
});

it('reports an unavailable repertoire without stale chapters', () => {
  render(<LearnRepertoire snapshot={emptySnapshot()} route="#/learn/repertoire/missing" />);
  expect(screen.getByRole('heading', { name: 'Repertoire unavailable' })).toBeTruthy();
  expect(screen.queryByRole('list', { name: 'Chapters' })).toBeNull();
});
