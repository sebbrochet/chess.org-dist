// @vitest-environment jsdom
import React, { useState } from 'react';
import { act, cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { afterEach, beforeAll, expect, it, vi } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { PlayComputer, evaluationLabel } from './PlayComputer';
import { newComputerGame, transitionGame, type ComputerGame, type ComputerOptions, type PlayAids } from '../../chess/play';
import { positionFromFen } from '../../chess/pgn';
import { REVIEW_BASIS } from '../../chess/review';
import { createLibrary, emptySnapshot, type DomainSnapshot } from '../../storage/library';
import { ENGINE_VERSION, type AnalysisRequest, type AnalysisResult, type EngineScore, type LocalEngine } from '../../engine/stockfish';
import { makeUci } from 'chessops/util';

vi.mock('../../components/Board', () => ({ Board: ({ fen, previewMove, moveGlyph, onMove }: { fen: string; previewMove?: string; moveGlyph?: { text: string }; onMove?: unknown }) =>
  <div data-testid="board" data-preview={previewMove ?? ''} data-glyph={moveGlyph?.text ?? ''} data-interactive={String(!!onMove)}>{fen}</div> }));
beforeAll(() => {
  HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
  HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); };
});
afterEach(cleanup);
const options: ComputerOptions = { side: 'white', level: 2, takebacks: true, time: null };
function memoryLibrary(initial: DomainSnapshot) {
  let saved = structuredClone(initial);
  let failed = false;
  const library = createLibrary({ read: async () => structuredClone(saved), update: async change => {
    const next = change(structuredClone(saved));
    if (failed) throw new Error('Storage quota exceeded');
    saved = next;
  } });
  return { library, fail: () => { failed = true; }, saved: () => saved };
}
function Harness({ library, initial, engine }: { library: ReturnType<typeof createLibrary>; initial: DomainSnapshot; engine: LocalEngine }) {
  const [snapshot, setSnapshot] = useState(initial);
  return <PlayComputer library={library} snapshot={snapshot} onSnapshot={setSnapshot} gameId={initial.games[0]?.id} selectedFen={INITIAL_FEN} engine={engine} />;
}
const idleEngine = (): LocalEngine => ({ analyze: vi.fn().mockRejectedValue(new Error('Engine assets unavailable')), cancelAll: vi.fn() });

it('offers explicit review after completion without automatically invoking analysis or changing final state', () => {
  const created = newComputerGame(INITIAL_FEN, options, 0);
  const game = transitionGame(created, { type: 'resign' }, 1);
  const initial = { ...emptySnapshot(), games: [game] }; const store = memoryLibrary(initial);
  const engine = idleEngine(); const onReview = vi.fn();
  render(<PlayComputer library={store.library} snapshot={initial} onSnapshot={vi.fn()} gameId={game.id} selectedFen={INITIAL_FEN} engine={engine} onReview={onReview} />);
  expect(engine.analyze).not.toHaveBeenCalled(); expect(onReview).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('button', { name: 'Review game' }));
  expect(onReview).toHaveBeenCalledExactlyOnceWith(game.id);
  expect(store.saved()).toEqual(initial);
});

it.each(['white', 'black'] as const)('labels the %s player as You and keeps labels correct when flipped', async side => {
  const fen = side === 'white' ? INITIAL_FEN : INITIAL_FEN.replace(' w ', ' b ');
  const game = newComputerGame(fen, { ...options, side }, Date.now());
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  render(<Harness library={store.library} initial={initial} engine={idleEngine()} />);
  await waitFor(() => expect((screen.getByLabelText('Move (SAN)') as HTMLInputElement).disabled).toBe(false));
  const labels = () => Array.from(screen.getByRole('region', { name: 'Computer game board' }).querySelectorAll('.player-line strong'), element => element.textContent);
  expect(labels()).toEqual(['Computer', 'You']);
  fireEvent.click(screen.getByRole('button', { name: 'Flip board' }));
  expect(labels()).toEqual(['You', 'Computer']);
  expect(store.saved().games[0].headers).toEqual(game.headers);
});

it('omits clocks and cadence details for an untimed game', async () => {
  const game = newComputerGame(INITIAL_FEN, options, Date.now());
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  render(<Harness library={store.library} initial={initial} engine={idleEngine()} />);
  await waitFor(() => expect((screen.getByLabelText('Move (SAN)') as HTMLInputElement).disabled).toBe(false));
  expect(screen.queryByText('Untimed')).toBeNull();
  expect(screen.queryByText('Time control')).toBeNull();
  expect(screen.queryByLabelText('White clock')).toBeNull();
  expect(screen.queryByLabelText('Black clock')).toBeNull();
});

it('keeps both clocks and cadence details for a timed game', async () => {
  const game = newComputerGame(INITIAL_FEN, { ...options, time: { initialMs: 600000, incrementMs: 2000 } }, Date.now());
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  render(<Harness library={store.library} initial={initial} engine={idleEngine()} />);
  await waitFor(() => expect((screen.getByLabelText('Move (SAN)') as HTMLInputElement).disabled).toBe(false));
  expect(screen.getByLabelText('White clock').textContent).toMatch(/^\d+:\d{2}$/);
  expect(screen.getByLabelText('Black clock').textContent).toBe('10:00');
  expect(screen.getByText('10 min + 2 s')).toBeTruthy();
});

it('does not create a retained game when the actual-engine availability check fails', async () => {
  const store = memoryLibrary(emptySnapshot());
  render(<Harness library={store.library} initial={emptySnapshot()} engine={idleEngine()} />);
  fireEvent.click(screen.getByRole('button', { name: 'Start game' }));
  await waitFor(() => expect(screen.getByRole('alert').textContent).toContain('Engine assets unavailable'));
  expect(store.saved().games).toHaveLength(0);
});

it('shows rejected move persistence and keeps the last saved board and clocks', async () => {
  const game = newComputerGame(INITIAL_FEN, options, Date.now());
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  render(<Harness library={store.library} initial={initial} engine={idleEngine()} />);
  await waitFor(() => expect((screen.getByLabelText('Move (SAN)') as HTMLInputElement).disabled).toBe(false));
  store.fail();
  fireEvent.change(screen.getByLabelText('Move (SAN)'), { target: { value: 'e4' } });
  fireEvent.click(screen.getByRole('button', { name: 'Play move' }));
  await waitFor(() => expect(screen.getByRole('alert').textContent).toContain('Not saved: Storage quota exceeded'));
  expect(store.saved().games[0].moves).toEqual([]);
  expect(store.saved().games[0].computer?.clock).toBeNull();
  expect(screen.getByTestId('board').textContent).toBe(INITIAL_FEN);
});

it('rejects a late engine reply after takeback and after navigation unmount', async () => {
  const start = newComputerGame(INITIAL_FEN, options, Date.now());
  const game = transitionGame(start, { type: 'move', move: 'e4', actor: 'player' }, Date.now());
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  let resolve: ((result: AnalysisResult) => void) | undefined;
  let request: AnalysisRequest | undefined;
  let signal: AbortSignal | undefined;
  const engine: LocalEngine = { cancelAll: vi.fn(), analyze: vi.fn((next, abort) => {
    request = next; signal = abort;
    return new Promise<AnalysisResult>(done => { resolve = done; });
  }) };
  const view = render(<Harness library={store.library} initial={initial} engine={engine} />);
  await waitFor(() => expect(engine.analyze).toHaveBeenCalledOnce());
  fireEvent.click(screen.getByRole('button', { name: 'Take back' }));
  await waitFor(() => expect(store.saved().games[0].moves).toEqual([]));
  expect(signal?.aborted).toBe(true);
  await act(async () => { resolve?.({ ...request!, bestmove: 'e7e5', jobId: 'stale', engineVersion: 'stockfish-18.0.7-lite-single', depth: 8, nodes: 100, pv: [] }); });
  expect(store.saved().games[0].moves).toEqual([]);
  view.unmount();
  const secondStore = memoryLibrary(initial);
  const second = render(<Harness library={secondStore.library} initial={initial} engine={engine} />);
  await waitFor(() => expect(engine.analyze).toHaveBeenCalledTimes(2));
  const before = structuredClone(secondStore.saved());
  second.unmount();
  expect(signal?.aborted).toBe(true);
  await act(async () => { resolve?.({ ...request!, bestmove: 'e7e5', jobId: 'after-nav', engineVersion: 'stockfish-18.0.7-lite-single', depth: 8, nodes: 100, pv: [] }); });
  expect(secondStore.saved()).toEqual(before);
});

it('reports engine failure without fabricating a reply and retains the player move', async () => {
  const game = transitionGame(newComputerGame(INITIAL_FEN, options, Date.now()), { type: 'move', move: 'e4', actor: 'player' }, Date.now());
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  render(<Harness library={store.library} initial={initial} engine={idleEngine()} />);
  await waitFor(() => expect(screen.getByRole('alert').textContent).toContain('Play interrupted: Engine assets unavailable'));
  expect(store.saved().games[0].moves).toEqual(['e4']);
  expect(screen.getByRole('button', { name: 'Retry saved position' })).toBeTruthy();
});

const cp = (value: number): EngineScore => ({ kind: 'cp', value, perspective: 'white' });
function firstLegal(fen: string): string {
  for (const [from, dests] of positionFromFen(fen).allDests()) for (const to of dests) return makeUci({ from, to });
  throw new Error('No legal move.');
}
function aidEngine(score: (fen: string) => EngineScore, play?: (request: AnalysisRequest) => Promise<AnalysisResult>): LocalEngine {
  return { cancelAll: vi.fn(), analyze: vi.fn(async (request: AnalysisRequest): Promise<AnalysisResult> => {
    if (request.purpose === 'play') return play ? play(request) : new Promise<AnalysisResult>(() => {});
    const best = firstLegal(request.fen);
    return { ...request, jobId: crypto.randomUUID(), engineVersion: ENGINE_VERSION, bestmove: best, score: score(request.fen), depth: 10, nodes: REVIEW_BASIS.limits.nodes, pv: [best] };
  }) };
}
const replies = (bestmove: string) => async (request: AnalysisRequest): Promise<AnalysisResult> => ({ ...request, jobId: crypto.randomUUID(), engineVersion: ENGINE_VERSION, bestmove, depth: 5, nodes: 10, pv: [] });
function played(moves: [string, 'player' | 'engine'][], aids?: PlayAids, side: 'white' | 'black' = 'white'): ComputerGame {
  return moves.reduce((game, [move, actor]) => transitionGame(game, { type: 'move', move, actor }, Date.now()), newComputerGame(INITIAL_FEN, { ...options, side }, Date.now(), aids));
}
const sanEnabled = () => !(screen.getByLabelText('Move (SAN)') as HTMLInputElement).disabled;

it('formats evaluations from White\'s point of view with signed mates and terminal results', () => {
  const search = (score: EngineScore) => ({ kind: 'search', fen: INITIAL_FEN, score, result: {} as AnalysisResult }) as const;
  expect(evaluationLabel(search(cp(50)))).toBe('+0.5');
  expect(evaluationLabel(search(cp(-125)))).toBe('-1.3');
  expect(evaluationLabel(search({ kind: 'mate', value: 3, perspective: 'white', winner: 'white' }))).toBe('#3');
  expect(evaluationLabel(search({ kind: 'mate', value: -2, perspective: 'white', winner: 'black' }))).toBe('#-2');
  expect(evaluationLabel({ kind: 'terminal', fen: INITIAL_FEN, score: { kind: 'mate', value: 0, perspective: 'white', winner: 'black' }, reason: 'checkmate' })).toBe('0-1');
  expect(evaluationLabel({ kind: 'terminal', fen: INITIAL_FEN, score: cp(0), reason: 'draw' })).toBe('1/2-1/2');
});

it('navigates earlier positions read-only and resumes play only at the current position', async () => {
  const game = played([['e4', 'player'], ['e5', 'engine']]);
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  render(<Harness library={store.library} initial={initial} engine={idleEngine()} />);
  await waitFor(() => expect(sanEnabled()).toBe(true));
  fireEvent.click(screen.getByRole('button', { name: 'First position' }));
  expect(screen.getByTestId('board').textContent).toBe(game.positions[0]);
  expect(screen.getByTestId('board').dataset.interactive).toBe('false');
  expect(sanEnabled()).toBe(false);
  expect(screen.getByRole('status').textContent).toBe('Viewing start of 2');
  fireEvent.click(screen.getByRole('button', { name: 'Next move' }));
  expect(screen.getByTestId('board').textContent).toBe(game.positions[1]);
  fireEvent.click(within(screen.getByRole('list', { name: 'Saved moves' })).getByRole('button', { name: 'e5' }));
  expect(screen.getByTestId('board').textContent).toBe(game.positions[2]);
  expect(sanEnabled()).toBe(true);
  fireEvent.click(screen.getByRole('button', { name: 'Previous move' }));
  expect(sanEnabled()).toBe(false);
  fireEvent.click(screen.getByRole('button', { name: 'Current position' }));
  expect(screen.getByTestId('board').textContent).toBe(game.positions[2]);
  expect(screen.getByTestId('board').dataset.interactive).toBe('true');
  expect(store.saved().games[0].moves).toEqual(['e4', 'e5']);
});

it('returns to the current position when Stockfish replies', async () => {
  const game = played([['e4', 'player'], ['e5', 'engine']]);
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  render(<Harness library={store.library} initial={initial} engine={aidEngine(() => cp(0), replies('b8c6'))} />);
  await waitFor(() => expect(sanEnabled()).toBe(true));
  fireEvent.change(screen.getByLabelText('Move (SAN)'), { target: { value: 'Nf3' } });
  fireEvent.click(screen.getByRole('button', { name: 'Play move' }));
  await waitFor(() => expect(store.saved().games[0].moves).toEqual(['e4', 'e5', 'Nf3', 'Nc6']));
  await waitFor(() => expect(screen.getByTestId('board').textContent).toBe(store.saved().games[0].positions[4]));
});

it('shows each side\'s captured pieces and the displayed position\'s material advantage', async () => {
  const game = played([['e4', 'player'], ['d5', 'engine'], ['exd5', 'player']]);
  const initial = { ...emptySnapshot(), games: [game] };
  render(<Harness library={memoryLibrary(initial).library} initial={initial} engine={aidEngine(() => cp(0))} />);
  expect(screen.getByLabelText('Captured by white: pawn; white ahead by 1')).toBeTruthy();
  expect(screen.getByLabelText('Captured by black: none')).toBeTruthy();
  fireEvent.click(screen.getByRole('button', { name: 'First position' }));
  expect(screen.getByLabelText('Captured by white: none')).toBeTruthy();
});

it('resolves Random and retains the chosen play aids when starting a game', async () => {
  const random = vi.spyOn(Math, 'random').mockReturnValue(0.75);
  try {
    const store = memoryLibrary(emptySnapshot());
    render(<Harness library={store.library} initial={emptySnapshot()} engine={aidEngine(() => cp(0), replies('e2e4'))} />);
    fireEvent.change(screen.getByLabelText('Your side'), { target: { value: 'random' } });
    fireEvent.click(screen.getByLabelText('Evaluation bar'));
    fireEvent.click(screen.getByLabelText('Move assessments'));
    fireEvent.click(screen.getByRole('button', { name: 'Start game' }));
    await waitFor(() => expect(store.saved().games).toHaveLength(1));
    expect(store.saved().games[0].computer?.options.side).toBe('black');
    expect(store.saved().games[0].computer?.aids).toEqual({ evaluation: true, bestMove: false, assessments: true });
  } finally { random.mockRestore(); }
});

it('shows the evaluation bar and the best-move arrow on the player\'s turn from full-strength analysis', async () => {
  const game = played([], { evaluation: true, bestMove: true, assessments: false });
  const initial = { ...emptySnapshot(), games: [game] };
  const engine = aidEngine(() => cp(50));
  render(<Harness library={memoryLibrary(initial).library} initial={initial} engine={engine} />);
  expect(await screen.findByRole('img', { name: 'Evaluation +0.5' })).toBeTruthy();
  await waitFor(() => expect(screen.getByTestId('board').dataset.preview).toBe(firstLegal(INITIAL_FEN)));
  const requests = vi.mocked(engine.analyze).mock.calls.map(([request]) => request);
  expect(requests.every(request => request.purpose === 'analysis' && request.level === undefined && JSON.stringify(request.limits) === JSON.stringify(REVIEW_BASIS.limits))).toBe(true);
});

it('assesses moves played in this session for both sides and leaves earlier moves unmarked', async () => {
  const game = played([['e4', 'player'], ['e5', 'engine']], { evaluation: false, bestMove: false, assessments: true });
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  const afterNf3 = transitionGame(game, { type: 'move', move: 'Nf3', actor: 'player' }, Date.now()).positions[3];
  render(<Harness library={store.library} initial={initial} engine={aidEngine(fen => cp(fen === afterNf3 ? -300 : 0), replies('b8c6'))} />);
  await waitFor(() => expect(sanEnabled()).toBe(true));
  fireEvent.change(screen.getByLabelText('Move (SAN)'), { target: { value: 'Nf3' } });
  fireEvent.click(screen.getByRole('button', { name: 'Play move' }));
  const list = screen.getByRole('list', { name: 'Saved moves' });
  expect(await within(list).findByLabelText('Blunder')).toBeTruthy();
  await waitFor(() => expect(within(list).queryByLabelText('Assessment pending')).toBeNull());
  expect(within(list).getByRole('button', { name: /^Nf3/ }).textContent).toContain('??');
  expect(within(list).getByRole('button', { name: 'e4' })).toBeTruthy();
  expect(within(list).getByRole('button', { name: 'Nc6' })).toBeTruthy();
  expect(screen.getByTestId('board').dataset.glyph).toBe('');
  fireEvent.click(within(list).getByRole('button', { name: /^Nf3/ }));
  expect(screen.getByTestId('board').dataset.glyph).toBe('??');
  expect(store.saved().games[0].computer?.aids).toEqual({ evaluation: false, bestMove: false, assessments: true });
});

it('changes play aids during Stockfish\'s turn without interrupting its reply', async () => {
  const game = played([['e4', 'player']]);
  const initial = { ...emptySnapshot(), games: [game] };
  const store = memoryLibrary(initial);
  let signal: AbortSignal | undefined;
  const engine: LocalEngine = { cancelAll: vi.fn(), analyze: vi.fn((_request, abort) => { signal = abort; return new Promise<AnalysisResult>(() => {}); }) };
  render(<Harness library={store.library} initial={initial} engine={engine} />);
  await waitFor(() => expect(engine.analyze).toHaveBeenCalledOnce());
  fireEvent.click(screen.getByLabelText('Evaluation bar'));
  await waitFor(() => expect(store.saved().games[0].computer?.aids).toEqual({ evaluation: true, bestMove: false, assessments: false }));
  await waitFor(() => expect((screen.getByLabelText('Evaluation bar') as HTMLInputElement).checked).toBe(true));
  expect(signal?.aborted).toBe(false);
  expect(engine.analyze).toHaveBeenCalledOnce();
  expect(store.saved().games[0].moves).toEqual(['e4']);
});

it('marks a failed aid evaluation unavailable without blocking play', async () => {
  const game = played([], { evaluation: true, bestMove: true, assessments: false });
  const initial = { ...emptySnapshot(), games: [game] };
  render(<Harness library={memoryLibrary(initial).library} initial={initial} engine={idleEngine()} />);
  expect(await screen.findByRole('img', { name: 'Evaluation Unavailable' })).toBeTruthy();
  expect(sanEnabled()).toBe(true);
  expect(screen.queryByRole('alert')).toBeNull();
  expect(screen.getByTestId('board').dataset.preview).toBe('');
  expect(screen.getByLabelText('Best-move arrow unavailable').textContent).toBe('Unavailable');
  expect(screen.getByLabelText('Evaluation bar unavailable')).toBeTruthy();
  expect(screen.queryByLabelText('Move assessments pending')).toBeNull();
});