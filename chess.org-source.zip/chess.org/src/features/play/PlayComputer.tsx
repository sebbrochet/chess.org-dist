import { createElement, useEffect, useRef, useState, type FormEvent } from 'react';
import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Flag, FlipVertical2, Microscope, Plus, RotateCcw, Undo2 } from 'lucide-react';
import { INITIAL_FEN } from 'chessops/fen';
import { parseSan } from 'chessops/san';
import { castlingSide } from 'chessops/chess';
import { kingCastlesTo, makeUci, parseSquare } from 'chessops/util';
import type { Color } from 'chessops/types';
import { Board } from '../../components/Board';
import { Modal } from '../../components/Modal';
import { PositionEditor } from '../../components/PositionEditor';
import { lastRecordedMove, positionFromFen } from '../../chess/pgn';
import { capturedMaterial } from '../../chess/material';
import { analyzeReviewPosition, annotateMove, legalContinuation, type Evidence, type MoveAnnotation } from '../../chess/review';
import { canTakeBack, clockAt, currentFen, isComputerGame, NO_PLAY_AIDS, playAids, resolveSide, type ComputerGame, type PlayAids, type PlayCommand } from '../../chess/play';
import { localEngine, type EngineScore, type LocalEngine } from '../../engine/stockfish';
import type { createLibrary, DomainSnapshot } from '../../storage/library';

const message = (error: unknown) => error instanceof Error ? error.message : 'Operation failed.';
const legalFen = (fen: string) => { try { positionFromFen(fen); return true; } catch { return false; } };
export function engineHistory(game: ComputerGame): { startFen: string; moves: string[] } {
  const position = positionFromFen(game.startFen);
  const moves = game.moves.map(san => {
    const move = parseSan(position, san)!;
    const castle = castlingSide(position, move);
    const uci = castle && 'from' in move ? makeUci({ from: move.from, to: kingCastlesTo(position.turn, castle) }) : makeUci(move);
    position.play(move);
    return uci;
  });
  return { startFen: game.startFen, moves };
}
const formatClock = (ms: number) => `${Math.floor(Math.ceil(ms / 1000) / 60)}:${String(Math.ceil(ms / 1000) % 60).padStart(2, '0')}`;
const AID_LABELS: [keyof PlayAids, string][] = [['evaluation', 'Evaluation bar'], ['bestMove', 'Best-move arrow'], ['assessments', 'Move assessments']];
type AidResult = Evidence | 'unavailable';
type Assessment = MoveAnnotation | 'unavailable';
const moveKey = (game: ComputerGame, ply: number) => `${ply}:${game.positions[ply + 1]}`;

export function scoreLabel(score: EngineScore): string {
  return score.kind === 'mate' ? `#${score.winner === 'white' ? '' : '-'}${Math.abs(score.value)}` : `${score.value >= 0 ? '+' : ''}${(score.value / 100).toFixed(1)}`;
}
export function evaluationLabel(evidence: Evidence): string {
  if (evidence.kind === 'terminal') return evidence.reason === 'draw' ? '1/2-1/2' : evidence.score.kind === 'mate' && evidence.score.winner === 'white' ? '1-0' : '0-1';
  return scoreLabel(evidence.score);
}
function EvaluationBar({ result, bottom }: { result?: AidResult; bottom: Color }) {
  const score = result && result !== 'unavailable' ? result.score : undefined;
  const white = !score ? 50 : score.kind === 'mate' ? score.winner === 'white' ? 100 : 0 : 100 / (1 + Math.exp(-0.00368208 * score.value));
  const label = result === 'unavailable' ? 'Unavailable' : result ? evaluationLabel(result) : 'Pending';
  return <div className="eval-bar" data-bottom={bottom} role="img" aria-label={`Evaluation ${label}`} title={`Evaluation (White's point of view): ${label}`}>
    <div className="eval-bar-white" style={{ height: `${white}%` }} />
    <span className="eval-bar-label" data-leader={score ? (white >= 50 ? 'white' : 'black') : undefined}>{result === 'unavailable' ? '!' : result ? evaluationLabel(result) : '...'}</span>
  </div>;
}
function CapturedPieces({ side, pieces, advantage }: { side: Color; pieces: string[]; advantage?: number }) {
  const victim = side === 'white' ? 'black' : 'white';
  return <div className="captured-pieces cg-wrap" aria-label={`Captured by ${side}: ${pieces.length ? pieces.join(', ') : 'none'}${advantage ? `; ${side} ahead by ${advantage}` : ''}`}>
    {pieces.map((role, index) => createElement('piece', { key: index, className: `${role} ${victim}` }))}{advantage ? <span className="material-advantage">+{advantage}</span> : null}
  </div>;
}

export function PlayComputer({ library, snapshot, onSnapshot, gameId, selectedFen, onReview, engine = localEngine }: {
  library: ReturnType<typeof createLibrary>; snapshot: DomainSnapshot; onSnapshot: (snapshot: DomainSnapshot) => void;
  gameId?: string; selectedFen: string; onReview?: (gameId: string) => void; engine?: LocalEngine;
}) {
  const record = snapshot.games.find(game => game.id === gameId);
  const game = record && isComputerGame(record) ? record : undefined;
  const [side, setSide] = useState<Color | 'random'>('white');
  const [setupAids, setSetupAids] = useState<PlayAids>(NO_PLAY_AIDS);
  const [level, setLevel] = useState(4);
  const [takebacks, setTakebacks] = useState(false);
  const [timed, setTimed] = useState(false);
  const [minutes, setMinutes] = useState(10);
  const [increment, setIncrement] = useState(0);
  const [source, setSource] = useState('standard');
  const [customFen, setCustomFen] = useState('');
  const [san, setSan] = useState('');
  const [intended, setIntended] = useState('');
  const [promotion, setPromotion] = useState('');
  const [confirmResign, setConfirmResign] = useState(false);
  const [flipped, setFlipped] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [resumed, setResumed] = useState(false);
  const [retry, setRetry] = useState(0);
  const [now, setNow] = useState(Date.now);
  const [visible, setVisible] = useState(!document.hidden);
  const [viewPly, setViewPly] = useState<number>();
  const [evaluations, setEvaluations] = useState<Record<string, AidResult>>({});
  const [assessments, setAssessments] = useState<Record<string, Assessment>>({});
  const [assessFrom, setAssessFrom] = useState(0);
  const [aidError, setAidError] = useState('');
  const alive = useRef(true);
  const lock = useRef(false);
  const job = useRef<AbortController>();
  const movesRef = useRef<HTMLOListElement>(null);
  const gameRef = useRef(game);
  gameRef.current = game;
  const aids = game ? playAids(game) : NO_PLAY_AIDS;
  const playKey = game ? `${game.id}:${game.computer.version}:${game.result}` : '';
  const moveCount = game?.moves.length ?? 0;

  useEffect(() => {
    alive.current = true;
    const visibility = () => { job.current?.abort(); setVisible(!document.hidden); setResumed(false); setNow(Date.now()); };
    const hide = () => job.current?.abort();
    document.addEventListener('visibilitychange', visibility);
    window.addEventListener('pagehide', hide);
    const timer = window.setInterval(() => setNow(Date.now()), 200);
    return () => { alive.current = false; job.current?.abort(); clearInterval(timer); document.removeEventListener('visibilitychange', visibility); window.removeEventListener('pagehide', hide); };
  }, []);

  useEffect(() => {
    const saved = gameRef.current;
    if (!saved || saved.result !== '*' || !visible) return;
    let active = true;
    setResumed(false); setBusy(true); lock.current = true;
    library.play(saved.id, { version: saved.computer.version, fen: currentFen(saved) }, { type: 'reconcile' }, Date.now(), () => active && alive.current).then(next => {
      if (active) { onSnapshot(next); setResumed(true); setError(''); }
    }).catch(reason => { if (active) setError(`Not saved: ${message(reason)}`); })
      .finally(() => { if (active) { lock.current = false; setBusy(false); } });
    return () => { active = false; };
  }, [gameId, library, onSnapshot, retry, visible]);

  useEffect(() => {
    const game = gameRef.current;
    if (!game || game.result !== '*' || !resumed || !visible || error || positionFromFen(currentFen(game)).turn === game.computer.options.side) return;
    const controller = new AbortController();
    job.current = controller;
    setThinking(true);
    engine.analyze({ gameId: game.id, generation: game.computer.version, fen: currentFen(game), purpose: 'play',
      limits: { movetime: 300 + game.computer.options.level * 40 }, level: game.computer.options.level, history: engineHistory(game),
    }, controller.signal).then(async result => {
      if (controller.signal.aborted || !alive.current) return;
      if (lock.current) throw new Error('Another save is pending. Retry from the saved position.');
      lock.current = true; setBusy(true);
      try {
        const next = await library.play(game.id, { version: result.generation, fen: result.fen }, { type: 'move', move: result.bestmove, actor: 'engine' }, Date.now(), () => !controller.signal.aborted && alive.current);
        if (!controller.signal.aborted && alive.current) onSnapshot(next);
      } finally { lock.current = false; if (alive.current) setBusy(false); }
    }).catch(reason => {
      if (!controller.signal.aborted && alive.current) setError(`Play interrupted: ${message(reason)}`);
    }).finally(() => { if (alive.current && !controller.signal.aborted) setThinking(false); });
    return () => { controller.abort(); setThinking(false); };
  }, [playKey, resumed, visible, error, engine, library, onSnapshot]);

  useEffect(() => { setEvaluations({}); setAssessments({}); setAssessFrom(gameRef.current?.moves.length ?? 0); setAidError(''); }, [gameId]);
  useEffect(() => { if (aids.assessments) setAssessFrom(gameRef.current?.moves.length ?? 0); }, [aids.assessments]);
  useEffect(() => { setViewPly(undefined); setAssessFrom(from => Math.min(from, moveCount)); }, [moveCount, gameId]);

  const displayedPly = game ? Math.min(viewPly ?? game.moves.length, game.moves.length) : 0;
  const atCurrent = !game || displayedPly === game.moves.length;
  const displayedFen = game ? game.positions[displayedPly] : '';
  const playerTurn = !!game && positionFromFen(currentFen(game)).turn === game.computer.options.side;
  const aidsMayRun = !!game && visible && (game.result !== '*' || (resumed && playerTurn));
  useEffect(() => {
    const game = gameRef.current;
    if (!game || !aidsMayRun || !(aids.evaluation || aids.bestMove || aids.assessments)) return;
    const controller = new AbortController();
    const cache = new Map<string, Evidence>();
    const evaluate = async (fen: string) => {
      const known = cache.get(fen);
      if (known) return known;
      const evidence = await analyzeReviewPosition(engine, fen, game.id, game.computer.version, controller.signal);
      cache.set(fen, evidence);
      return evidence;
    };
    void (async () => {
      const wanted = aids.evaluation ? [displayedFen] : [];
      if (aids.bestMove && game.result === '*') wanted.push(currentFen(game));
      for (const fen of new Set(wanted)) {
        if (evaluations[fen]) continue;
        try { const evidence = await evaluate(fen); if (!controller.signal.aborted) setEvaluations(known => ({ ...known, [fen]: evidence })); }
        catch { if (controller.signal.aborted) return; setEvaluations(known => ({ ...known, [fen]: 'unavailable' })); }
      }
      if (!aids.assessments) return;
      for (let ply = assessFrom; ply < game.moves.length; ply++) {
        const key = moveKey(game, ply);
        if (assessments[key]) continue;
        try {
          const parent = await evaluate(game.positions[ply]);
          if (parent.kind !== 'search') throw new Error('Recorded move follows a terminal position.');
          const bestFen = legalContinuation(game.positions[ply], [parent.result.bestmove])[0].fen;
          const bestChild = await evaluate(bestFen);
          const actualChild = bestFen === game.positions[ply + 1] ? bestChild : await evaluate(game.positions[ply + 1]);
          const annotation = annotateMove(bestChild.score, actualChild.score, positionFromFen(game.positions[ply]).turn);
          if (!controller.signal.aborted) setAssessments(known => ({ ...known, [key]: annotation }));
        } catch { if (controller.signal.aborted) return; setAssessments(known => ({ ...known, [key]: 'unavailable' })); }
      }
    })();
    return () => controller.abort();
    // Results already held in state are skipped by key; re-running on their arrival would restart finished work.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playKey, aidsMayRun, aids.evaluation, aids.bestMove, aids.assessments, displayedFen, assessFrom, engine]);

  useEffect(() => {
    const list = movesRef.current;
    const selected = list?.querySelector('[aria-current="step"]')?.closest('li');
    if (!list || !selected) return;
    const bounds = list.getBoundingClientRect();
    const row = selected.getBoundingClientRect();
    const top = bounds.top + list.clientTop;
    const bottom = top + list.clientHeight;
    if (row.top < top) list.scrollTop -= top - row.top;
    else if (row.bottom > bottom) list.scrollTop += row.bottom - bottom;
  }, [displayedPly, moveCount]);

  async function changeAids(next: PlayAids) {
    if (!game) return;
    setAidError('');
    try { const saved = await library.changePlayAids(game.id, next); if (alive.current) onSnapshot(saved); }
    catch (reason) { if (alive.current) setAidError(`Play aids not saved: ${message(reason)}`); }
  }

  const clock = game ? clockAt(game, now) : null;
  const expired = !!clock?.running && clock[clock.running] <= 0;
  useEffect(() => {
    if (expired && resumed && !busy && !error) { job.current?.abort(); setRetry(value => value + 1); }
  }, [expired, resumed, busy, error]);

  async function command(command: PlayCommand) {
    if (!game || lock.current) return;
    job.current?.abort(); setThinking(false);
    lock.current = true; setBusy(true); setError('');
    try {
      const next = await library.play(game.id, { version: game.computer.version, fen: currentFen(game) }, command, Date.now(), () => alive.current);
      if (alive.current) { onSnapshot(next); setSan(''); setIntended(''); setPromotion(''); setConfirmResign(false); }
    } catch (reason) { if (alive.current) setError(`Not saved: ${message(reason)}`); }
    finally { lock.current = false; if (alive.current) setBusy(false); }
  }
  async function start(event: FormEvent) {
    event.preventDefault();
    if (lock.current) return;
    lock.current = true; setBusy(true); setError('');
    const controller = new AbortController(); job.current = controller;
    try {
      const fen = source === 'standard' ? INITIAL_FEN : source === 'selected' ? selectedFen : customFen;
      positionFromFen(fen);
      await engine.analyze({ gameId: 'availability-check', generation: 0, fen: INITIAL_FEN, limits: { nodes: 1 }, purpose: 'play' }, controller.signal);
      if (!alive.current || controller.signal.aborted) return;
      const next = await library.startComputer(fen, { side: resolveSide(side), level, takebacks, time: timed ? { initialMs: minutes * 60000, incrementMs: increment * 1000 } : null }, Date.now(), setupAids);
      if (alive.current) { onSnapshot(next); window.location.hash = `/play/${next.games.at(-1)!.id}`; }
    } catch (reason) { if (alive.current) setError(`Cannot start: ${message(reason)}`); }
    finally { lock.current = false; if (alive.current) setBusy(false); }
  }
  function boardMove(uci: string) {
    if (!game) return;
    const position = positionFromFen(currentFen(game));
    const from = parseSquare(uci.slice(0, 2));
    if (from !== undefined && position.board.get(from)?.role === 'pawn' && /[18]$/.test(uci)) setPromotion(uci);
    else void command({ type: 'move', move: uci, actor: 'player' });
  }

  if (gameId && !game) return <main className="play-unavailable"><h1>Game unavailable for computer play</h1><a href="#/">Games</a></main>;
  const fen = game ? displayedFen : source === 'selected' ? selectedFen : source === 'fen' && legalFen(customFen) ? customFen : INITIAL_FEN;
  const orientation: Color = game ? game.computer.options.side : side === 'black' ? 'black' : 'white';
  const bottom: Color = flipped ? (orientation === 'white' ? 'black' : 'white') : orientation;
  const top: Color = bottom === 'white' ? 'black' : 'white';
  const playerLabel = (color: Color) => color === orientation ? 'You' : 'Computer';
  const canMove = !!game && atCurrent && game.result === '*' && resumed && visible && !busy && !error && !expired && playerTurn;
  const summary = game?.computer;
  const material = game ? capturedMaterial(game.startFen, game.moves, displayedPly) : undefined;
  const assessmentAt = (ply: number): Assessment | 'pending' | undefined => game && aids.assessments && ply >= assessFrom ? assessments[moveKey(game, ply)] ?? 'pending' : undefined;
  const shown = displayedPly > 0 ? assessmentAt(displayedPly - 1) : undefined;
  const moveGlyph = typeof shown === 'object' && shown.glyph ? { text: shown.glyph, label: shown.label } : undefined;
  const current = game ? evaluations[currentFen(game)] : undefined;
  const bestMove = game && aids.bestMove && atCurrent && game.result === '*' && playerTurn && typeof current === 'object' && current.kind === 'search' ? current.result.bestmove : undefined;
  const sideLine = (color: Color) => <div className="player-line"><strong>{playerLabel(color)}</strong>
    {material && <CapturedPieces side={color} pieces={material.captured[color]} advantage={material.advantage?.side === color ? material.advantage.points : undefined} />}
    {clock && <output aria-label={`${color === 'white' ? 'White' : 'Black'} clock`} className="clock">{formatClock(clock[color])}</output>}</div>;
  const aidToggles = (value: PlayAids, onChange: (next: PlayAids) => void, state?: (key: keyof PlayAids) => string | undefined) => <fieldset className="play-aids"><legend>Play aids</legend>
    {AID_LABELS.map(([key, label]) => { const status = value[key] ? state?.(key) : undefined; return <div key={key} className="aid-row"><label className="check-field"><input type="checkbox" checked={value[key]} onChange={event => onChange({ ...value, [key]: event.target.checked })} />{label}</label>{status && <span className="aid-state" aria-label={`${label} ${status.toLowerCase()}`}>{status}</span>}</div>; })}</fieldset>;
  const aidState = (key: keyof PlayAids) => {
    const result = key === 'evaluation' ? evaluations[displayedFen] : key === 'bestMove' && atCurrent && playerTurn && game?.result === '*' ? current : 'n/a';
    if (key === 'assessments') return game && game.moves.slice(assessFrom).some((_, offset) => !assessments[moveKey(game, assessFrom + offset)]) ? 'Pending' : undefined;
    return result === 'unavailable' ? 'Unavailable' : result === undefined ? 'Pending' : undefined;
  };
  return <main className="workspace play-workspace" aria-busy={busy}>
    <section className="replay" aria-label="Computer game board">
      {sideLine(top)}
      <div className="board-with-eval" data-eval={game && aids.evaluation ? 'shown' : undefined}>
        {game && aids.evaluation && <EvaluationBar result={evaluations[displayedFen]} bottom={bottom} />}
        <Board fen={fen} orientation={bottom} lastMove={game ? lastRecordedMove(game, displayedPly) : undefined} previewMove={bestMove} moveGlyph={moveGlyph} onMove={canMove ? boardMove : undefined} />
      </div>
      {sideLine(bottom)}
      <div className="replay-toolbar">
        {game && <>
          <button className="icon" title="First position" aria-label="First position" disabled={displayedPly === 0} onClick={() => setViewPly(0)}><ChevronsLeft size={19} /></button>
          <button className="icon" title="Previous move" aria-label="Previous move" disabled={displayedPly === 0} onClick={() => setViewPly(displayedPly - 1)}><ChevronLeft size={19} /></button>
          <button className="icon" title="Next move" aria-label="Next move" disabled={atCurrent} onClick={() => setViewPly(displayedPly + 1)}><ChevronRight size={19} /></button>
          <button className="icon" title="Current position" aria-label="Current position" disabled={atCurrent} onClick={() => setViewPly(undefined)}><ChevronsRight size={19} /></button>
        </>}
        <button className="icon" title="Flip board" aria-label="Flip board" onClick={() => setFlipped(value => !value)}><FlipVertical2 size={19} /></button>
        <output role="status">{busy ? 'Saving...' : thinking ? 'Stockfish thinking...' : game && !atCurrent ? `Viewing ${displayedPly ? `move ${displayedPly}` : 'start'} of ${game.moves.length}` : game?.result !== '*' && game ? `${game.result}: ${summary?.reason}` : game ? canMove ? 'Your turn' : 'Saved position' : 'New computer game'}</output>
      </div>
      {game && <form className="san-entry" onSubmit={event => { event.preventDefault(); void command({ type: 'move', move: san, actor: 'player' }); }}><label htmlFor="play-san">Move (SAN)</label><input id="play-san" autoComplete="off" value={san} disabled={!canMove} onChange={event => setSan(event.target.value)} /><button className="icon" title="Play move" aria-label="Play move" type="submit" disabled={!canMove || !san.trim()}><ChevronRight /></button></form>}
      <details className="fen"><summary>Position (FEN)</summary><code>{fen}</code></details>
    </section>
    <section className="game-panel" aria-label={game ? 'Live game' : 'New game setup'}>
      <header className="panel-heading"><h1>Play Computer</h1>{game?.result === '*' && <a className="new-game-link" href="#/play"><Plus size={16} />New game</a>}</header>
      {error && <><p className="error" role="alert">{error}</p>{game && game.result === '*' && <button onClick={async () => {
        try { const latest = await library.load(); onSnapshot(latest); setError(''); setRetry(value => value + 1); }
        catch (reason) { setError(`Library unavailable: ${message(reason)}`); }
      }}><RotateCcw size={16} />Retry saved position</button>}</>}
      {!game ? <form onSubmit={event => void start(event)} className="play-setup">
        <fieldset disabled={busy}><legend>New game</legend>
          <label className="field">Starting position<select value={source} onChange={event => { setSource(event.target.value); if (event.target.value === 'fen' && !customFen) setCustomFen(legalFen(selectedFen) ? selectedFen : INITIAL_FEN); }}><option value="standard">Standard start</option><option value="selected">Selected game position</option><option value="fen">Set up position</option></select></label>
          {source === 'fen' && <PositionEditor fen={customFen} onChange={setCustomFen} fenLabel="Starting FEN" disabled={busy} />}
          <label className="field">Your side<select value={side} onChange={event => setSide(event.target.value as Color | 'random')}><option value="white">White</option><option value="black">Black</option><option value="random">Random</option></select></label>
          <label className="field">Stockfish level<select value={level} onChange={event => setLevel(Number(event.target.value))}>{Array.from({ length: 21 }, (_, index) => <option key={index} value={index}>{index}</option>)}</select></label>
          <label className="check-field"><input type="checkbox" checked={timed} onChange={event => setTimed(event.target.checked)} />Timed game</label>
          {timed && <div className="details-grid"><label className="field">Initial minutes<input type="number" min="0.1" max="1440" step="0.1" required value={minutes} onChange={event => setMinutes(Number(event.target.value))} /></label><label className="field">Increment seconds<input type="number" min="0" max="600" step="1" required value={increment} onChange={event => setIncrement(Number(event.target.value))} /></label></div>}
          <label className="check-field"><input type="checkbox" checked={takebacks} onChange={event => setTakebacks(event.target.checked)} />Allow takebacks</label>
          {aidToggles(setupAids, setSetupAids)}
          <button type="submit" className="primary"><ChevronRight size={17} />{busy ? 'Checking engine and saving...' : 'Start game'}</button>
        </fieldset>
      </form> : <>
        <dl className="game-facts"><div><dt>Your side</dt><dd>{summary!.options.side}</dd></div><div><dt>Stockfish level</dt><dd>{summary!.options.level}</dd></div><div><dt>Takebacks</dt><dd>{summary!.options.takebacks ? 'Enabled' : 'Disabled'} / {summary!.takebacksUsed} used</dd></div>{summary!.options.time && <div><dt>Time control</dt><dd>{`${summary!.options.time.initialMs / 60000} min + ${summary!.options.time.incrementMs / 1000} s`}</dd></div>}</dl>
        <ol ref={movesRef} className="live-moves" aria-label="Saved moves">{game.moves.map((move, index) => {
          const fields = game.positions[index].split(' ');
          const assessment = assessmentAt(index);
          return <li key={index} data-number={`${fields[5]}${fields[1] === 'w' ? '.' : '...'}`}><button aria-current={displayedPly === index + 1 ? 'step' : undefined} onClick={() => setViewPly(index + 1)}>{move}
            {typeof assessment === 'object' ? assessment.glyph && <b className="review-glyph" title={assessment.label} aria-label={assessment.label}>{assessment.glyph}</b>
              : assessment && <span className="assessment-state" title={`Assessment ${assessment}`} aria-label={`Assessment ${assessment}`}>{assessment === 'pending' ? '...' : '!'}</span>}</button></li>;
        })}</ol>
        {game.result === '*' && aidToggles(aids, next => void changeAids(next), aidState)}
        {aidError && <p className="error" role="alert">{aidError}</p>}
        {game.result === '*' && <>
          <div className="play-actions"><button title="Take back move" disabled={busy || !resumed || !canTakeBack(game) || expired} onClick={() => void command({ type: 'takeback' })}><Undo2 size={17} />Take back</button><button disabled={busy || !resumed} onClick={() => setConfirmResign(true)}><Flag size={17} />Resign</button></div>
          <form onSubmit={event => { event.preventDefault(); void command({ type: 'claim', intended }); }}><label className="field">Intended move for draw claim<input autoComplete="off" value={intended} disabled={!canMove} onChange={event => setIntended(event.target.value)} /></label><button disabled={!canMove} type="submit"><Flag size={16} />Claim draw</button></form>
        </>}
        {game.result !== '*' && <div className="post-game-actions"><p className="completed-result">{game.result} / {summary?.reason}</p><div className="play-actions"><button type="button" className="primary" onClick={() => { if (onReview) onReview(game.id); else window.location.hash = `/games/${game.id}/review`; }}><Microscope size={17} />Review game</button><a className="resume-link" href="#/play"><Plus size={16} />New game</a></div></div>}
      </>}
      <footer className="library-footer"><a href="#/">Games</a><a href="/engine/SOURCE.md" target="_blank" rel="noreferrer">Stockfish 18 / GPL</a></footer>
    </section>
    {promotion && <Modal title="Promote pawn" busy={busy} onClose={() => setPromotion('')}><div className="play-actions">{(['q', 'r', 'b', 'n'] as const).map((piece, index) => <button key={piece} disabled={busy} onClick={() => void command({ type: 'move', move: promotion + piece, actor: 'player' })}>{['Queen', 'Rook', 'Bishop', 'Knight'][index]}</button>)}</div></Modal>}
    {confirmResign && <Modal title="Resign game?" busy={busy} onClose={() => setConfirmResign(false)}><div className="dialog-actions"><button onClick={() => setConfirmResign(false)}>Cancel</button><button className="danger" disabled={busy} onClick={() => void command({ type: 'resign' })}><Flag size={17} />Resign game</button></div></Modal>}
  </main>;
}