// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { lastRecordedMove, parseGames } from '../chess/pgn';
import { moveSoundsEnabled, playMoveSound, setMoveSoundsEnabled, soundedMove } from './moveSound';

const audios: { src: string; currentTime: number; play: ReturnType<typeof vi.fn> }[] = [];
beforeEach(() => {
  localStorage.clear(); setMoveSoundsEnabled(true);
  vi.stubGlobal('Audio', class {
    src: string; currentTime = 4; play = vi.fn().mockResolvedValue(undefined);
    constructor(src: string) { this.src = src; audios.push(this); }
  });
});
afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); });

it('uses the baseline move/capture clips, resets playback and persists mute', () => {
  playMoveSound('e4');
  expect(audios.find(audio => audio.src.endsWith('/move.mp3'))?.play).toHaveBeenCalledOnce();
  playMoveSound('Bxf7+');
  expect(audios.find(audio => audio.src.endsWith('/capture.mp3'))?.play).toHaveBeenCalledOnce();
  expect(audios.every(audio => audio.currentTime === 0)).toBe(true);
  setMoveSoundsEnabled(false);
  expect(moveSoundsEnabled()).toBe(false);
  expect(localStorage.getItem('chess.org:move-sounds')).toBe('false');
  playMoveSound('d4');
  expect(audios.find(audio => audio.src.endsWith('/move.mp3'))?.play).toHaveBeenCalledOnce();
  setMoveSoundsEnabled(true);
  audios.find(audio => audio.src.endsWith('/move.mp3'))!.play.mockRejectedValueOnce(new Error('Autoplay blocked'));
  expect(() => playMoveSound('d4')).not.toThrow();
});

it('recognizes displayed legal moves but not flips, rollback or unrelated position changes', () => {
  const game = parseGames('1.e4 e5 *')[0];
  expect(soundedMove(game.positions[0], game.positions[1], 'e2e4')).toBe('e4');
  expect(soundedMove(game.positions[1], game.positions[0], 'e2e4')).toBeUndefined();
  expect(soundedMove(game.positions[1], game.positions[1], 'e2e4')).toBeUndefined();
  expect(soundedMove(game.positions[0], game.positions[2], 'e7e5')).toBeUndefined();
  expect(soundedMove(game.positions[0], game.positions[1])).toBeUndefined();
});

it.each([
  ['1.e4 d5 2.exd5 *', 'exd5'],
  ['1.e4 a6 2.e5 d5 3.exd6 *', 'exd6'],
  ['[FEN "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1"]\n1.O-O *', 'O-O'],
  ['[FEN "7k/P7/8/8/8/8/4K3/8 w - - 0 1"]\n1.a8=N *', 'a8=N'],
])('identifies the correct SAN sound classification for %s', (pgn, san) => {
  const game = parseGames(pgn)[0];
  expect(soundedMove(game.positions.at(-2)!, game.positions.at(-1)!, lastRecordedMove(game))).toBe(san);
});

it('keeps the mute preference usable when browser storage is unavailable', () => {
  vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => { throw new Error('Blocked'); });
  vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new Error('Blocked'); });
  expect(() => setMoveSoundsEnabled(false)).not.toThrow();
  expect(moveSoundsEnabled()).toBe(false);
  setMoveSoundsEnabled(true);
  expect(moveSoundsEnabled()).toBe(true);
});