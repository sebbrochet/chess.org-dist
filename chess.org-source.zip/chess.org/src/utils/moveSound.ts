import { makeFen } from 'chessops/fen';
import { makeSanAndPlay } from 'chessops/san';
import { parseUci } from 'chessops/util';
import { positionFromFen } from '../chess/pgn';

const BASE = import.meta.env.BASE_URL || '/';
let moveAudio: HTMLAudioElement | undefined;
let captureAudio: HTMLAudioElement | undefined;
let enabled = true;

export function moveSoundsEnabled(): boolean {
  try { const value = localStorage.getItem('chess.org:move-sounds'); return value === null ? enabled : value !== 'false'; }
  catch { return enabled; }
}

export function setMoveSoundsEnabled(value: boolean): void {
  enabled = value;
  try { localStorage.setItem('chess.org:move-sounds', String(value)); } catch { return; }
}

export function playMoveSound(san: string): void {
  if (!moveSoundsEnabled() || typeof Audio === 'undefined') return;
  try {
    moveAudio ??= new Audio(`${BASE}sounds/move.mp3`);
    captureAudio ??= new Audio(`${BASE}sounds/capture.mp3`);
    const audio = san.includes('x') ? captureAudio : moveAudio;
    audio.currentTime = 0;
    void audio.play().catch(() => {});
  } catch { return; }
}

export function soundedMove(previousFen: string, fen: string, uci?: string): string | undefined {
  if (!uci || previousFen === fen) return;
  const position = positionFromFen(previousFen);
  const move = parseUci(uci);
  if (!move || !position.isLegal(move)) return;
  const san = makeSanAndPlay(position, move);
  return makeFen(position.toSetup()) === fen ? san : undefined;
}