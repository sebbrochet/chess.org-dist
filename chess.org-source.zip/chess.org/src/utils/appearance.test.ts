// @vitest-environment jsdom
import { afterEach, expect, it, vi } from 'vitest';
import { applyAppearance, readAppearance, saveAppearance } from './appearance';

afterEach(() => { localStorage.clear(); vi.restoreAllMocks(); });

it('defaults safely and retains valid board/piece choices', () => {
  expect(readAppearance()).toEqual({ board: 'system', pieces: 'cburnett' });
  saveAppearance({ board: 'blue', pieces: 'merida' });
  expect(readAppearance()).toEqual({ board: 'blue', pieces: 'merida' });
  localStorage.setItem('chess.org:appearance', '{invalid');
  expect(readAppearance()).toEqual({ board: 'system', pieces: 'cburnett' });
  localStorage.setItem('chess.org:appearance', JSON.stringify({ board: 'unknown', pieces: 'unknown' }));
  expect(readAppearance()).toEqual({ board: 'system', pieces: 'cburnett' });
});

it('applies board-only variables and piece choice without touching application theme', () => {
  document.documentElement.dataset.theme = 'dark';
  applyAppearance({ board: 'green', pieces: 'merida' });
  expect(document.documentElement.style.getPropertyValue('--cp-board-light')).toBe('#ffffdd');
  expect(document.documentElement.dataset.pieceStyle).toBe('merida');
  expect(document.documentElement.dataset.theme).toBe('dark');
  applyAppearance({ board: 'system', pieces: 'cburnett' });
  expect(document.documentElement.style.getPropertyValue('--cp-board-dark')).toBe('var(--cp-border-strong)');
});

it('does not fail when browser preference storage is blocked', () => {
  vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => { throw new Error('Blocked'); });
  vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new Error('Blocked'); });
  expect(readAppearance()).toEqual({ board: 'system', pieces: 'cburnett' });
  expect(() => saveAppearance({ board: 'brown', pieces: 'merida' })).not.toThrow();
});

it.each(['letter', 'mono'] as const)('persists and applies %s images for every piece role and color', pieces => {
  saveAppearance({ board: 'blue', pieces });
  expect(readAppearance()).toEqual({ board: 'blue', pieces });
  applyAppearance(readAppearance());
  for (const color of ['w', 'b']) for (const role of ['K', 'Q', 'R', 'B', 'N', 'P']) {
    expect(document.documentElement.style.getPropertyValue(`--cp-piece-${color}${role}`)).toBe(`url("/pieces/${pieces}/${pieces === 'mono' ? '' : color}${role}.svg")`);
  }
});