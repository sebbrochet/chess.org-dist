export const BOARD_THEMES = [
  { id: 'system', label: 'System', light: 'var(--cp-surface-soft)', dark: 'var(--cp-border-strong)' },
  { id: 'brown', label: 'Brown', light: '#f0d9b5', dark: '#b58863' },
  { id: 'blue', label: 'Blue', light: '#dee3e6', dark: '#8ca2ad' },
  { id: 'green', label: 'Green', light: '#ffffdd', dark: '#86a666' },
  { id: 'purple', label: 'Purple', light: '#e8daf0', dark: '#9070a0' },
  { id: 'grey', label: 'Grey', light: '#ececec', dark: '#c1c18e' },
] as const;
export const PIECE_STYLES = [{ id: 'cburnett', label: 'Cburnett' }, { id: 'merida', label: 'Merida' }, { id: 'letter', label: 'Letter' }, { id: 'mono', label: 'Mono' }] as const;
export type Appearance = { board: typeof BOARD_THEMES[number]['id']; pieces: typeof PIECE_STYLES[number]['id'] };
const DEFAULT: Appearance = { board: 'system', pieces: 'cburnett' };

export function readAppearance(): Appearance {
  try {
    const value = JSON.parse(localStorage.getItem('chess.org:appearance') ?? '{}');
    return {
      board: BOARD_THEMES.some(theme => theme.id === value?.board) ? value.board : DEFAULT.board,
      pieces: PIECE_STYLES.some(style => style.id === value?.pieces) ? value.pieces : DEFAULT.pieces,
    };
  } catch { return { ...DEFAULT }; }
}

export function saveAppearance(value: Appearance): void {
  try { localStorage.setItem('chess.org:appearance', JSON.stringify(value)); } catch { return; }
}

export function applyAppearance(value: Appearance): void {
  const theme = BOARD_THEMES.find(theme => theme.id === value.board) ?? BOARD_THEMES[0];
  document.documentElement.style.setProperty('--cp-board-light', theme.light);
  document.documentElement.style.setProperty('--cp-board-dark', theme.dark);
  document.documentElement.dataset.pieceStyle = value.pieces;
  for (const color of ['w', 'b']) for (const role of ['K', 'Q', 'R', 'B', 'N', 'P']) {
    document.documentElement.style.setProperty(`--cp-piece-${color}${role}`, `url("/pieces/${value.pieces}/${value.pieces === 'mono' ? '' : color}${role}.svg")`);
  }
}