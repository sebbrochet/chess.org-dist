import 'fake-indexeddb/auto';
import { clear } from 'idb-keyval';
import { beforeEach, describe, expect, it } from 'vitest';
import { createLibrary, emptySnapshot } from './library';
import { fetchPublicGames, normalizeLichess } from '../providers/chessServices';
import { exportGames, parseGames } from '../chess/pgn';
import { exportBackup, parseBackup } from './backup';

describe('public-game retention', () => {
  beforeEach(async () => { await clear(); });
  it('deduplicates within and across imports by provider identity, not headers', async () => {
    const library = createLibrary(); const records = normalizeLichess('[GameId "AbCd1234"]\n1.e4 *');
    await library.importPublicGames([...records, ...records]);
    const next = await library.importPublicGames(records);
    expect(next.games).toHaveLength(1);
    expect(next.games[0].source).toEqual({ kind: 'online', provider: 'lichess', originalId: 'AbCd1234' });
    const separate = await library.importPublicGames([{ ...records[0], provider: 'chess.com', originalId: 'https://www.chess.com/game/live/1' }]);
    expect(separate.games).toHaveLength(2);
    expect(separate.games[0].moves).toEqual(records[0].game.moves);
  });
  it('preserves both providers metadata through durable load, PGN export and full backup', async () => {
    const library = createLibrary();
    const lichess = normalizeLichess('[GameId "AbCd1234"]\n[Event "rated rapid game"]\n[UTCDate "2026.11.06"]\n[UTCTime "12:34:56"]\n[TimeControl "600+5"]\n1.e4 1-0');
    const fetcher: typeof fetch = async url => new Response(JSON.stringify(String(url).endsWith('/archives') ? { archives: ['https://api.chess.com/pub/player/player/games/2026/11'] } : { games: [{ rules: 'chess', url: 'https://www.chess.com/game/live/123', pgn: '1.d4 0-1', time_class: 'rapid', time_control: '900+10', end_time: Date.parse('2026-11-06T12:34:56Z') / 1000 }] }));
    const chesscom = await fetchPublicGames('chess.com', 'Player', '', '', fetcher, undefined, 'rapid');
    await library.importPublicGames([...lichess, ...chesscom.games]);
    const loaded = await library.load();
    expect(loaded.games[0].headers).toMatchObject({ UTCDate: '2026.11.06', UTCTime: '12:34:56', TimeClass: 'rapid', TimeControl: '600+5' });
    expect(loaded.games[1].headers).toMatchObject({ EndUTCDate: '2026.11.06', EndUTCTime: '12:34:56', TimeClass: 'rapid', TimeControl: '900+10' });
    expect(parseGames(exportGames(loaded.games)).map(game => game.headers)).toEqual(loaded.games.map(game => game.headers));
    expect(parseBackup(exportBackup(loaded))).toEqual(loaded);
  });
  it('keeps prior content intact on quota failure and validates provenance', async () => {
    let durable = emptySnapshot(); let fail = false;
    const library = createLibrary({ read: async () => structuredClone(durable), update: async change => { const next = change(structuredClone(durable)); if (fail) throw new Error('Quota'); durable = next; } });
    const records = normalizeLichess('[GameId "AbCd1234"]\n1.e4 *');
    await library.importPublicGames(records); const before = structuredClone(durable); fail = true;
    await expect(library.importPublicGames(records)).rejects.toThrow('Quota');
    expect(durable).toEqual(before);
  });
});