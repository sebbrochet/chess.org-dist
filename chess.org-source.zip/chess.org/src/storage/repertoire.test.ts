import 'fake-indexeddb/auto';
import { clear } from 'idb-keyval';
import { beforeEach, describe, expect, it } from 'vitest';
import { createLibrary, emptySnapshot, migrateSnapshot } from './library';

describe('durable repertoire lifecycle', () => {
  beforeEach(async () => { await clear(); });
  it('preserves history on rename and removes it on validated replacement', async () => {
    const library = createLibrary();
    const book = (await library.importRepertoire('1.e4 (1.d4 d5) e5 *', 'Lines', 'white')).repertoires[0];
    const attempt = (await library.startRecall(book.id, book.lines.map(line => line.id))).repertoireAttempts[0];
    const answered = await library.recallAction(attempt.id, { type: 'answer', input: 'd4' });
    expect(answered.repertoireAttempts[0].status).toBe('Success');
    expect((await library.renameRepertoire(book.id, 'Renamed')).repertoireAttempts).toHaveLength(1);
    const before = await library.load();
    await expect(library.replaceRepertoire(book.id, '1.e5 *', 'white')).rejects.toThrow();
    expect(await library.load()).toEqual(before);
    const replaced = await library.replaceRepertoire(book.id, '1.c4 e5 *', 'white');
    expect(replaced.repertoireAttempts).toHaveLength(0);
    expect(replaced.repertoires[0]).toMatchObject({ name: 'Renamed', generation: 2 });
    await expect(library.recallAction(attempt.id, { type: 'answer', input: 'e4' })).rejects.toThrow('unavailable');
  });
  it('retains assistance before feedback and clears only attempt history', async () => {
    const library = createLibrary();
    const book = (await library.importRepertoire('1.e4 e5 *', 'Recall', 'white')).repertoires[0];
    const attempt = (await library.startRecall(book.id, [book.lines[0].id])).repertoireAttempts[0];
    await library.recallAction(attempt.id, { type: 'hint' });
    expect((await library.recallAction(attempt.id, { type: 'answer', input: 'e4' })).repertoireAttempts[0]).toMatchObject({ assisted: true, status: 'Assisted' });
    const cleared = await library.clearProgress();
    expect(cleared.repertoireAttempts).toHaveLength(0);
    expect(cleared.repertoires[0]).toEqual(book);
    expect((await library.deleteRepertoire(book.id)).repertoires).toEqual([]);
  });
  it('migrates version two without losing existing unrelated content', () => {
    const previous = { ...emptySnapshot(), schemaVersion: 2, extensions: { keep: 'value' } };
    const next = migrateSnapshot(previous);
    expect(next.schemaVersion).toBe(emptySnapshot().schemaVersion);
    expect(next.repertoires).toEqual([]);
    expect(next.extensions).toEqual({ keep: 'value' });
  });
});