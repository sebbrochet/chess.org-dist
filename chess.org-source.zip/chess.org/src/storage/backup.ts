import { z } from 'zod';
import { parseGames, positionFromFen } from '../chess/pgn';
import { captureReviewSource, hasCompleteCoverage, hasValidPrefix, legalContinuation } from '../chess/review';
import { acceptsCandidate, candidateUci, type TrainingAttempt } from '../chess/training';
import { createRecall, importRepertoire } from '../chess/repertoire';
import { answerPuzzle, newPuzzleAttempt, validatePuzzle } from '../chess/puzzles';
import { validBranches, type LineMove } from '../chess/analysisLines';
import { emptySnapshot, migrateSnapshot, type DomainSnapshot } from './library';

export const MAX_BACKUP_SIZE = 100000000;
const text = z.string().max(2000000), id = z.string().min(1).max(200), side = z.enum(['white', 'black']);
const finite = z.number().finite(), nonnegative = finite.nonnegative();
const date = z.string().refine(value => Number.isFinite(Date.parse(value)), 'Invalid date');
const result = z.enum(['*', '1-0', '0-1', '1/2-1/2']);
const status = z.enum(['Active', 'Success', 'Assisted', 'Incorrect']);
const source = z.discriminatedUnion('kind', [z.object({ kind: z.literal('pgn') }).strict(), z.object({ kind: z.literal('computer') }).strict(), z.object({ kind: z.literal('online'), provider: z.enum(['lichess', 'chess.com']), originalId: id }).strict(), z.object({ kind: z.literal('board'), orientation: z.enum(['white', 'black']), copiedFrom: text.optional() }).strict()]);
const game = z.object({ id, createdAt: date, source, headers: z.record(z.string(), text), startFen: text, positions: z.array(text).min(1).max(10000), moves: z.array(text).max(10000), result, pgn: text,
  computer: z.object({ options: z.object({ side, level: z.number().int().min(0).max(20), takebacks: z.boolean(), time: z.object({ initialMs: finite.positive(), incrementMs: nonnegative }).strict().nullable() }).strict(), version: z.number().int().nonnegative(), takebacksUsed: z.number().int().nonnegative(), clock: z.object({ white: nonnegative, black: nonnegative, running: side.nullable(), at: nonnegative }).strict().nullable(), reason: text.optional(), aids: z.object({ evaluation: z.boolean(), bestMove: z.boolean(), assessments: z.boolean() }).strict().optional() }).strict().optional() }).strict();
const reviewSource = z.object({ identity: text, startFen: text, moves: z.array(text).max(10000), positions: z.array(text).max(10001) }).strict();
const basis = z.object({ version: text, engineVersion: text, limits: z.union([z.object({ nodes: finite.positive().int() }).strict(), z.object({ depth: finite.positive().int() }).strict(), z.object({ movetime: finite.positive().int() }).strict()]) }).strict();
const review = z.object({ id, gameId: id, generation: z.number().int().nonnegative(), status: z.enum(['Analysing', 'Complete', 'Interrupted']), source: reviewSource, basis, entries: z.array(z.unknown()).max(10000), createdAt: date, updatedAt: date, interruption: text.optional() }).passthrough();
const training = z.object({ id, gameId: id, activity: z.enum(['mistake', 'guess']), sourceIdentity: text, ply: z.number().int().nonnegative(), side, fen: text, target: text,
  assisted: z.boolean(), status, answers: z.array(text).max(1000), createdAt: date, updatedAt: date, evidence: z.object({ entry: z.unknown(), basis, candidate: z.unknown().optional() }).strict().optional() }).strict();
const repertoire = z.object({ id, name: z.string().min(1).max(200), side, generation: z.number().int().positive(), source: text, lines: z.array(z.object({ id, moves: z.array(text).min(1).max(10000), positions: z.array(text).min(2).max(10001) }).strict()).min(1).max(2000), createdAt: date }).strict();
const recall = z.object({ id, repertoireId: id, generation: z.number().int().positive(), selectedLines: z.array(id).min(1).max(2000), side, fen: text, targets: z.array(text).min(1).max(256), answers: z.array(text).max(1000), assisted: z.boolean(), status, createdAt: date }).strict();
const collection = z.object({ id, name: text, source: text, puzzleIds: z.array(id).max(100000), retainedAt: date }).strict();
const puzzle = z.object({ id, collectionId: id, fen: text, solutions: z.array(z.array(text).min(1).max(100)).min(1).max(200), themes: z.array(text).max(100), rating: nonnegative.optional() }).strict();
const puzzleAttempt = z.object({ id, puzzleId: id, collectionId: id, side, fen: text, remaining: z.array(z.array(text).max(100)).max(200), answers: z.array(text).max(100), assisted: z.boolean(), status, createdAt: date }).strict();
const lineMove: z.ZodType<LineMove> = z.lazy(() => z.object({ uci: z.string().min(4).max(5), children: z.array(lineMove).max(256) }).strict());
const analysisLines = z.object({ id, gameId: id, branches: z.array(z.object({ ply: z.number().int().nonnegative(), fen: text, moves: z.array(lineMove).min(1).max(256) }).strict()).min(1).max(10000) }).strict();
const snapshotSchema = z.object({ schemaVersion: z.literal(4), revision: z.number().int().nonnegative(), games: z.array(game).max(50000), reviews: z.array(review).max(50000),
  mistakeAttempts: z.array(training).max(100000), guessMoveAttempts: z.array(training).max(100000), repertoires: z.array(repertoire).max(10000), repertoireAttempts: z.array(recall).max(100000),
  puzzleCollections: z.array(collection).max(10000), puzzles: z.array(puzzle).max(100000), puzzleAttempts: z.array(puzzleAttempt).max(100000), analysisLines: z.array(analysisLines).max(50000), extensions: z.record(z.string(), z.unknown()) }).strict();
const envelope = z.object({ format: z.literal('chess.org-backup'), version: z.literal(1), exportedAt: date, data: z.unknown() }).strict();
const equal = (left: unknown, right: unknown) => JSON.stringify(left) === JSON.stringify(right);
function insist(condition: unknown, message: string): asserts condition { if (!condition) throw new Error(`Invalid backup: ${message}`); }
function legalSnapshot(startFen: string, moves: string[], positions: string[]) {
  insist(positions.length === moves.length + 1 && positions[0] === startFen, 'recorded position coverage');
  let fen = startFen; positionFromFen(fen);
  for (let index = 0; index < moves.length; index++) { const next = legalContinuation(fen, [candidateUci(fen, moves[index])])[0].fen; insist(next === positions[index + 1], 'illegal or mismatched move history'); fen = next; }
}
function assistance(record: { assisted: boolean; status: string }) {
  insist(!(record.assisted && record.status === 'Success') && !(record.status === 'Assisted' && !record.assisted), 'assisted result credited as unaided');
}
function validateTraining(attempt: TrainingAttempt, snapshot: DomainSnapshot) {
  insist(snapshot.games.some(game => game.id === attempt.gameId), 'missing attempt source game');
  const parsed = JSON.parse(attempt.sourceIdentity) as unknown;
  insist(Array.isArray(parsed) && parsed.length === 3 && typeof parsed[0] === 'string' && Array.isArray(parsed[1]) && Array.isArray(parsed[2]), 'invalid historical snapshot');
  const source = reviewSource.parse({ identity: attempt.sourceIdentity, startFen: parsed[0], moves: parsed[1], positions: parsed[2] });
  legalSnapshot(source.startFen, source.moves, source.positions);
  insist(attempt.ply < source.moves.length && source.positions[attempt.ply] === attempt.fen && positionFromFen(attempt.fen).turn === attempt.side, 'attempt position mismatch');
  candidateUci(attempt.fen, attempt.target);
  for (const answer of attempt.answers) candidateUci(attempt.fen, answer);
  assistance(attempt);
  insist(attempt.answers.length <= 1, 'historical exercise has multiple terminal answers');
  insist(attempt.status !== 'Active' || !attempt.answers.length, 'active attempt has completed answers');
  if (attempt.activity === 'guess') {
    insist(attempt.target === candidateUci(attempt.fen, source.moves[attempt.ply]), 'recorded target mismatch');
    if (attempt.answers.length) insist(attempt.status === 'Incorrect' ? attempt.answers[0] !== attempt.target : attempt.answers[0] === attempt.target, 'recorded prediction result mismatch');
    if (attempt.status === 'Success') insist(attempt.answers.at(-1) === attempt.target, 'incorrect target credited as success');
  } else {
    insist(attempt.evidence, 'missing mistake evidence');
    const entry = attempt.evidence.entry;
    insist(entry && entry.ply === attempt.ply && entry.parent.fen === attempt.fen && entry.best === attempt.target && entry.judgment.mistake, 'mistake target mismatch');
    const historicalSource = captureReviewSource({ startFen: attempt.fen, moves: [source.moves[attempt.ply]], positions: source.positions.slice(attempt.ply, attempt.ply + 2) });
    const generation = Math.max(1, ...[entry.parent, entry.bestChild, entry.actualChild].map(evidence => evidence.kind === 'search' ? evidence.result.generation : 1));
    const evidenceReview = { id: 'historical', gameId: attempt.gameId, generation, source: historicalSource, basis: attempt.evidence.basis, entries: [{ ...entry, ply: 0 }], status: 'Complete' as const, createdAt: attempt.createdAt, updatedAt: attempt.updatedAt };
    insist(hasCompleteCoverage(evidenceReview), 'historical mistake evidence is inconsistent');
    for (const evidence of [entry.parent, entry.bestChild, entry.actualChild, ...(attempt.evidence.candidate ? [attempt.evidence.candidate] : [])]) {
      positionFromFen(evidence.fen); insist(evidence.score && Number.isFinite(evidence.score.value) && ['cp', 'mate'].includes(evidence.score.kind), 'invalid historical evaluation');
      if (evidence.kind === 'search') insist(evidence.result.fen === evidence.fen && equal(evidence.result.score, evidence.score) && equal(evidence.result.limits, evidenceReview.basis.limits), 'mismatched historical evidence');
    }
    if (attempt.status === 'Success') {
      const evidence = attempt.evidence.candidate; const answer = attempt.answers.at(-1);
      insist(evidence && answer && legalContinuation(attempt.fen, [answer])[0].fen === evidence.fen && acceptsCandidate(entry.bestChild.score, evidence.score, attempt.side) === true, 'unsupported mistake success');
    }
  }
}

export function validateBackupData(value: unknown): DomainSnapshot {
  const snapshot = snapshotSchema.parse(migrateSnapshot(value)) as unknown as DomainSnapshot;
  for (const records of [snapshot.games, snapshot.reviews, snapshot.mistakeAttempts, snapshot.guessMoveAttempts, snapshot.repertoires, snapshot.repertoireAttempts, snapshot.puzzleCollections, snapshot.puzzles, snapshot.puzzleAttempts, snapshot.analysisLines]) insist(new Set(records.map(record => record.id)).size === records.length, 'duplicate record identity');
  insist(new Set(snapshot.analysisLines.map(record => record.gameId)).size === snapshot.analysisLines.length, 'duplicate analysis lines for a game');
  for (const record of snapshot.analysisLines) {
    const game = snapshot.games.find(game => game.id === record.gameId);
    insist(game, 'missing analysis lines source game');
    let valid = false; try { valid = equal(validBranches(game, record.branches), record.branches); } catch { valid = false; }
    insist(valid, 'invalid analysis lines');
  }
  insist(snapshot.extensions.practiceAutoAdvance === undefined || typeof snapshot.extensions.practiceAutoAdvance === 'boolean', 'invalid practice settings');
  insist(snapshot.extensions.practiceShowPath === undefined || typeof snapshot.extensions.practiceShowPath === 'boolean', 'invalid practice settings');
  insist(snapshot.extensions.reviewLiveEngine === undefined || typeof snapshot.extensions.reviewLiveEngine === 'boolean', 'invalid review settings');
  for (const game of snapshot.games) {
    const parsed = parseGames(game.pgn); insist(parsed.length === 1 && equal(parsed[0].moves, game.moves) && equal(parsed[0].positions, game.positions) && parsed[0].result === game.result && parsed[0].startFen === game.startFen && equal(parsed[0].headers, game.headers), 'saved PGN and game disagree');
    insist((game.source.kind === 'computer') === !!game.computer, 'computer options/source mismatch');
    if (game.computer) { const state = game.computer; insist(!!state.options.time === !!state.clock, 'clock/control mismatch'); if (state.clock) insist(state.clock.running === (game.result === '*' ? positionFromFen(game.positions.at(-1)!).turn : null), 'clock running side mismatch'); }
  }
  for (const review of snapshot.reviews) {
    insist(snapshot.games.some(game => game.id === review.gameId), 'missing review source');
    legalSnapshot(review.source.startFen, review.source.moves, review.source.positions);
    insist(hasValidPrefix(review) && (review.status !== 'Complete' || hasCompleteCoverage(review)), 'incomplete or inconsistent review evidence');
  }
  for (const attempt of snapshot.mistakeAttempts) { insist(attempt.activity === 'mistake', 'wrong attempt family'); validateTraining(attempt as TrainingAttempt, snapshot); }
  for (const attempt of snapshot.guessMoveAttempts) { insist(attempt.activity === 'guess', 'wrong attempt family'); validateTraining(attempt as TrainingAttempt, snapshot); }
  for (const book of snapshot.repertoires) { insist(new Set(book.lines.map(line => line.id)).size === book.lines.length, 'duplicate repertoire lines'); insist(equal(importRepertoire(book.source, book.name, book.side).lines, book.lines), 'repertoire lines disagree with imported source'); for (const line of book.lines) legalSnapshot(line.positions[0], line.moves, line.positions); }
  for (const attempt of snapshot.repertoireAttempts) {
    const book = snapshot.repertoires.find(book => book.id === attempt.repertoireId); insist(book && book.generation === attempt.generation && book.side === attempt.side, 'missing or replaced repertoire source');
    const expected = createRecall(book, attempt.selectedLines, attempt.fen); insist(equal(expected.targets, attempt.targets), 'repertoire targets mismatch'); assistance(attempt);
    for (const answer of attempt.answers) candidateUci(attempt.fen, answer);
    insist(attempt.answers.length <= 1 && (attempt.status !== 'Active' || !attempt.answers.length), 'invalid recall answer lifecycle');
    if (attempt.answers.length) insist(attempt.status === 'Incorrect' ? !attempt.targets.includes(attempt.answers[0]) : attempt.targets.includes(attempt.answers[0]), 'recall outcome mismatch');
    if (attempt.status === 'Success') insist(attempt.targets.includes(attempt.answers.at(-1)!), 'non-target recall success');
  }
  for (const puzzle of snapshot.puzzles) { const checked = validatePuzzle(puzzle); insist(equal(checked, puzzle) && snapshot.puzzleCollections.some(collection => collection.id === puzzle.collectionId && collection.puzzleIds.includes(puzzle.id)), 'puzzle source/content mismatch'); }
  for (const collection of snapshot.puzzleCollections) insist(equal([...collection.puzzleIds].sort(), snapshot.puzzles.filter(puzzle => puzzle.collectionId === collection.id).map(puzzle => puzzle.id).sort()), 'collection membership mismatch');
  for (const attempt of snapshot.puzzleAttempts) {
    const puzzle = snapshot.puzzles.find(puzzle => puzzle.id === attempt.puzzleId); insist(puzzle && puzzle.collectionId === attempt.collectionId, 'missing puzzle source'); assistance(attempt);
    let expected = { ...newPuzzleAttempt(puzzle), assisted: attempt.assisted };
    for (const answer of attempt.answers) expected = answerPuzzle(expected, answer);
    insist(expected.fen === attempt.fen && equal(expected.remaining, attempt.remaining) && expected.side === attempt.side, 'puzzle sequence mismatch');
    insist(expected.status === attempt.status || (expected.status === 'Active' && attempt.status === 'Assisted' && attempt.assisted), 'invalid puzzle result');
  }
  return snapshot;
}
export function exportBackup(snapshot: DomainSnapshot): string {
  const data = validateBackupData(snapshot);
  return JSON.stringify({ format: 'chess.org-backup', version: 1, exportedAt: new Date().toISOString(), data }, null, 2);
}
export function parseBackup(text: string): DomainSnapshot {
  if (text.length > MAX_BACKUP_SIZE) throw new Error('Backup exceeds the supported 100 MB size.');
  const parsed = envelope.parse(JSON.parse(text)); return validateBackupData(parsed.data);
}
export function prepareRestoration(candidate: DomainSnapshot, existing: DomainSnapshot): DomainSnapshot {
  const next = validateBackupData(candidate);
  for (const game of next.games) if (game.computer) game.computer.version = Math.max(game.computer.version, existing.games.find(record => record.id === game.id)?.computer?.version ?? 0) + 1;
  for (const review of next.reviews) {
    review.generation = Math.max(review.generation, existing.reviews.find(record => record.id === review.id)?.generation ?? 0) + 1;
    if (review.status === 'Analysing') { review.status = 'Interrupted'; review.interruption = 'Active analysis was restored incomplete. Retry to continue.'; }
  }
  next.schemaVersion = emptySnapshot().schemaVersion;
  return next;
}