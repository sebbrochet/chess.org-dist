import { describe, expect, it } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { createLibrary, emptySnapshot, type DomainSnapshot } from './library';
import { exportBackup, parseBackup } from './backup';
import { addMove, createTree, ROOT, treeToPgn } from '../chess/gameTree';
import { captureReviewSource } from '../chess/review';
import { parseGames } from '../chess/pgn';

function memoryLibrary() {
  let durable: DomainSnapshot = emptySnapshot();
  return { library: createLibrary({ read: async () => structuredClone(durable), update: async change => { durable = change(structuredClone(durable)); } }), current: () => durable };
}

describe('board-created games', () => {
  it('creates on first save, updates in place, survives backup and refuses other sources', async () => {
    const { library, current } = memoryLibrary();
    const first = addMove(createTree(INITIAL_FEN), ROOT, 'e2e4');
    await library.saveBoardGame('board-1', treeToPgn(first.tree, new Map([['Title', 'Mine']]), '*'), 'black', true);
    expect(current().games[0]).toMatchObject({ id: 'board-1', moves: ['e4'], source: { kind: 'board', orientation: 'black' }, headers: { Title: 'Mine' } });
    const identity = captureReviewSource(current().games[0]).identity;
    const second = addMove(first.tree, first.id, 'c7c5');
    await library.saveBoardGame('board-1', treeToPgn(second.tree, new Map([['Title', 'Mine']]), '*'), 'white', false);
    expect(current().games).toHaveLength(1);
    expect(current().games[0].moves).toEqual(['e4', 'c5']);
    expect(captureReviewSource(current().games[0]).identity).not.toBe(identity);
    expect(parseBackup(exportBackup(current())).games[0].source).toEqual({ kind: 'board', orientation: 'white' });
    await expect(library.saveBoardGame('missing', treeToPgn(second.tree, new Map(), '*'), 'white', false)).rejects.toThrow('no longer exists');
    await library.importGames([{ headers: {}, startFen: INITIAL_FEN, moves: [], positions: [INITIAL_FEN], result: '*', pgn: '*' }]);
    const imported = current().games[1].id;
    await expect(library.saveBoardGame(imported, treeToPgn(second.tree, new Map(), '*'), 'white', false)).rejects.toThrow('Only games created on the board');
  });

  it('copies any game to an editable game without touching the original', async () => {
    const { library, current } = memoryLibrary();
    await library.importGames(parseGames('[White "Carlsen"]\n[Black "Caruana"]\n[Result "1-0"]\n\n1. e4 { [%eval 0.3] Main } (1. d4 d5) e5 2. Nf3 $1 { [%cal Gf3e5] } 1-0'));
    const original = structuredClone(current().games[0]);
    await library.copyToEditable(original.id, 'copy-1');
    const copy = current().games.find(game => game.id === 'copy-1')!;
    expect(current().games.find(game => game.id === original.id)).toEqual(original);
    expect(copy).toMatchObject({ result: '1-0', moves: ['e4', 'e5', 'Nf3'], source: { kind: 'board', orientation: 'white', copiedFrom: 'Carlsen - Caruana' } });
    expect(copy.headers.Title).toBe('Copy of Carlsen - Caruana');
    expect(copy.pgn).toContain('1. e4 { Main } ( 1. d4 d5 ) 1... e5 2. Nf3 $1 { [%cal Gf3e5] } 1-0');
    expect(copy.pgn).not.toContain('%eval');
    expect(parseBackup(exportBackup(current())).games).toHaveLength(2);
    await expect(library.copyToEditable('missing')).rejects.toThrow('no longer exists');
  });
});
