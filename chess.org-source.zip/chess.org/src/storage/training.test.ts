import 'fake-indexeddb/auto';
import { clear } from 'idb-keyval';
import { beforeEach, describe, expect, it } from 'vitest';
import { parseGames } from '../chess/pgn';
import { createLibrary, emptySnapshot } from './library';
import { isAttempt } from '../chess/training';

describe('durable exercise boundaries', () => {
  beforeEach(async () => { await clear(); });
  it('assistance cannot later turn into unaided credit, and historical outcomes are immutable', async () => {
    const library = createLibrary();
    const game = (await library.importGames(parseGames('1.e4 e5 *'))).games[0];
    const record = (await library.startAttempt(game.id, 'guess', 'white')).guessMoveAttempts[0];
    await library.assistAttempt(record.id, false);
    const next = await library.answerAttempt(record.id, 'e2e4', true);
    expect(next.guessMoveAttempts[0]).toMatchObject({ assisted: true, status: 'Assisted', answers: ['e2e4'] });
    await expect(library.answerAttempt(record.id, 'e2e4', true)).rejects.toThrow('ended');
    await expect(library.assistAttempt(record.id, false)).rejects.toThrow('active');
    expect((await library.load()).games[0]).toEqual(game);
  });
  it('retains failed assistance as unassisted without disclosing a successful mutation', async () => {
    let durable = emptySnapshot(); let fail = false;
    const library = createLibrary({ read: async () => structuredClone(durable), update: async change => {
      const next = change(structuredClone(durable)); if (fail) throw new Error('Quota'); durable = next;
    } });
    const game = (await library.importGames(parseGames('1.e4 *'))).games[0];
    const attempt = (await library.startAttempt(game.id, 'guess', 'white')).guessMoveAttempts[0];
    fail = true;
    await expect(library.assistAttempt(attempt.id, true)).rejects.toThrow('Quota');
    expect(durable.guessMoveAttempts[0]).toMatchObject({ status: 'Active', assisted: false });
  });
  it('rejects late answers and assistance after source deletion without recreating history', async () => {
    const library = createLibrary();
    const game = (await library.importGames(parseGames('1.e4 *'))).games[0];
    const attempt = (await library.startAttempt(game.id, 'guess', 'white')).guessMoveAttempts[0];
    await library.deleteGame(game.id);
    await expect(library.answerAttempt(attempt.id, 'e2e4', true)).rejects.toThrow('no longer exists');
    await expect(library.assistAttempt(attempt.id, false)).rejects.toThrow('no longer exists');
    expect((await library.load()).guessMoveAttempts).toEqual([]);
  });
  it('creates independent retries and clearing preserves sources', async () => {
    const library = createLibrary();
    const game = (await library.importGames(parseGames('1.e4 *'))).games[0];
    const attempt = (await library.startAttempt(game.id, 'guess', 'white')).guessMoveAttempts[0];
    await library.answerAttempt(attempt.id, 'd2d4', false);
    const repeated = await library.startAttempt(game.id, 'guess', 'white');
    expect(repeated.guessMoveAttempts.filter(isAttempt).map(record => record.status)).toEqual(['Incorrect', 'Active']);
    expect(new Set(repeated.guessMoveAttempts.map(record => record.id)).size).toBe(2);
    const cleared = await library.clearProgress();
    expect(cleared.guessMoveAttempts).toEqual([]);
    expect(cleared.games[0]).toEqual(game);
  });
});