import { get, update } from 'idb-keyval';
import { editDetails, importedGameAnalysis, parseGames, positionFromFen, type GameDetails, type ParsedGame } from '../chess/pgn';
import { changePlayAids, currentFen, newComputerGame, transitionGame, type ComputerOptions, type ComputerState, type PlayAids, type PlayCommand } from '../chess/play';
import { captureReviewSource, hasCompleteCoverage, hasValidPrefix, REVIEW_BASIS, type MoveEvidence, type PreparedCandidate, type Review, type ReviewBasis } from '../chess/review';
import { isAttempt, newAttempt, type TrainingAttempt } from '../chess/training';
import type { Evidence } from '../chess/review';
import { createRecall, importRepertoire as parseRepertoire, type RecallAttempt, type Repertoire } from '../chess/repertoire';
import { candidateUci } from '../chess/training';
import { automaticResult, treeFromPgn, treeToPgn } from '../chess/gameTree';
import { mergeIntoTree, validBranches, type AnalysisBranch, type AnalysisLines } from '../chess/analysisLines';
import { answerPuzzle, bundledPuzzles, newPuzzleAttempt, validatePuzzle, type Puzzle, type PuzzleAttempt, type PuzzleCollection, type PuzzleSet } from '../chess/puzzles';
import type { PublicGame } from '../providers/chessServices';

export interface RetainedGame extends ParsedGame {
  id: string;
  createdAt: string;
  source: { kind: 'pgn' } | { kind: 'computer' } | { kind: 'online'; provider: 'lichess' | 'chess.com'; originalId: string } | { kind: 'board'; orientation: 'white' | 'black'; copiedFrom?: string };
  computer?: ComputerState;
}
export interface GameDependent {
  id: string;
  gameId: string;
  [field: string]: unknown;
}
export interface DomainSnapshot {
  schemaVersion: 4;
  revision: number;
  games: RetainedGame[];
  reviews: Review[];
  mistakeAttempts: GameDependent[];
  guessMoveAttempts: GameDependent[];
  repertoires: Repertoire[];
  repertoireAttempts: RecallAttempt[];
  puzzleCollections: PuzzleCollection[];
  puzzles: Puzzle[];
  puzzleAttempts: PuzzleAttempt[];
  analysisLines: AnalysisLines[];
  extensions: Record<string, unknown>;
}
export const SNAPSHOT_KEY = 'chess.org:domain';
export const practiceAutoAdvance = (snapshot: DomainSnapshot) => snapshot.extensions.practiceAutoAdvance === true;
export const practiceShowPath = (snapshot: DomainSnapshot) => snapshot.extensions.practiceShowPath !== false;
export const reviewLiveEngine = (snapshot: DomainSnapshot) => snapshot.extensions.reviewLiveEngine === true;
export const emptySnapshot = (): DomainSnapshot => ({
  schemaVersion: 4, revision: 0, games: [], reviews: [], mistakeAttempts: [], guessMoveAttempts: [], repertoires: [], repertoireAttempts: [], puzzleCollections: [], puzzles: [], puzzleAttempts: [], analysisLines: [], extensions: {},
});

export function migrateSnapshot(value: unknown): DomainSnapshot {
  if (value === undefined) return emptySnapshot();
  const snapshot = value as DomainSnapshot;
  if (!snapshot || ![1, 2, 3, 4].includes(snapshot.schemaVersion)) throw new Error('Unsupported local data version. Existing data has not been changed.');
  if (!Number.isInteger(snapshot.revision) || !Array.isArray(snapshot.games) ||
    !Array.isArray(snapshot.reviews) || !Array.isArray(snapshot.mistakeAttempts) ||
    !Array.isArray(snapshot.guessMoveAttempts) || !snapshot.extensions) throw new Error('Local data is damaged. Existing data has not been changed.');
  const next = structuredClone(snapshot);
  if ((value as { schemaVersion: number }).schemaVersion === 1) {
    next.reviews = snapshot.reviews.map(record => {
      const game = snapshot.games.find(game => game.id === record.gameId);
      if (!game) throw new Error('Local review source is missing. Existing data has not been changed.');
      return { ...record, id: record.id, gameId: record.gameId, generation: 0, status: 'Interrupted', source: captureReviewSource(game),
        basis: structuredClone(REVIEW_BASIS), entries: [], createdAt: game.createdAt, updatedAt: new Date().toISOString(), interruption: 'Legacy review requires engine analysis.' };
    });
  }
  next.schemaVersion = 4;
  if ((value as { schemaVersion: number }).schemaVersion < 3) { next.repertoires = []; next.repertoireAttempts = []; }
  if (!Array.isArray(next.repertoires) || !Array.isArray(next.repertoireAttempts)) throw new Error('Local repertoire data is damaged.');
  if ((value as { schemaVersion: number }).schemaVersion < 4) { next.puzzleCollections = []; next.puzzles = []; next.puzzleAttempts = []; }
  if (!Array.isArray(next.puzzleCollections) || !Array.isArray(next.puzzles) || !Array.isArray(next.puzzleAttempts)) throw new Error('Local puzzle data is damaged.');
  if (next.analysisLines === undefined) next.analysisLines = [];
  if (!Array.isArray(next.analysisLines)) throw new Error('Local analysis lines are damaged.');
  return next;
}

export interface SnapshotDriver {
  read(): Promise<unknown>;
  update(change: (current: unknown) => DomainSnapshot): Promise<void>;
}
const indexedDbDriver: SnapshotDriver = {
  read: () => get(SNAPSHOT_KEY),
  update: change => update(SNAPSHOT_KEY, change),
};

export function removeGame(snapshot: DomainSnapshot, gameId: string): DomainSnapshot {
  return {
    ...snapshot,
    games: snapshot.games.filter(game => game.id !== gameId),
    reviews: snapshot.reviews.filter(record => record.gameId !== gameId),
    mistakeAttempts: snapshot.mistakeAttempts.filter(record => record.gameId !== gameId),
    guessMoveAttempts: snapshot.guessMoveAttempts.filter(record => record.gameId !== gameId),
    analysisLines: snapshot.analysisLines.filter(record => record.gameId !== gameId),
  };
}

export function createLibrary(driver: SnapshotDriver = indexedDbDriver) {
  let queue: Promise<unknown> = Promise.resolve();
  function mutate(change: (snapshot: DomainSnapshot) => DomainSnapshot): Promise<DomainSnapshot> {
    const operation = queue.then(async () => {
      let committed: DomainSnapshot | undefined;
      await driver.update(current => {
        const previous = migrateSnapshot(current);
        committed = { ...change(previous), schemaVersion: 4, revision: previous.revision + 1 };
        return committed;
      });
      if (!committed) throw new Error('Storage did not complete the transaction.');
      return structuredClone(committed);
    });
    queue = operation.catch(() => undefined);
    return operation;
  }
  function currentReview(snapshot: DomainSnapshot, id: string, generation: number, identity: string, isCurrent: () => boolean): Review {
    if (!isCurrent()) throw new DOMException('Review cancelled.', 'AbortError');
    const review = snapshot.reviews.find(record => record.id === id);
    if (!review || review.generation !== generation || review.status !== 'Analysing' || review.source.identity !== identity) throw new Error('Review no longer active. Late result ignored.');
    const game = snapshot.games.find(record => record.id === review.gameId);
    if (!game || captureReviewSource(game).identity !== identity) throw new Error('Review source snapshot changed. Regenerate from the saved game.');
    return review;
  }
  function prepareReview(snapshot: DomainSnapshot, gameId: string, basis: ReviewBasis, isCurrent: () => boolean): DomainSnapshot {
    if (!isCurrent()) throw new DOMException('Review cancelled.', 'AbortError');
    const game = snapshot.games.find(record => record.id === gameId);
    if (!game) throw new Error('This game no longer exists.');
    const previous = snapshot.reviews.find(record => record.gameId === gameId);
    const now = new Date().toISOString();
    const review: Review = { id: previous?.id ?? crypto.randomUUID(), gameId, generation: (previous?.generation ?? 0) + 1,
      source: captureReviewSource(game), basis: structuredClone(basis), entries: [], status: 'Analysing', createdAt: previous?.createdAt ?? now, updatedAt: now };
    return { ...snapshot, reviews: [...snapshot.reviews.filter(record => record.gameId !== gameId), review] };
  }
  return {
    load: async () => {
      const snapshot = migrateSnapshot(await driver.read());
      return snapshot.reviews.some(review => review.status === 'Analysing') ? mutate(latest => ({ ...latest, reviews: latest.reviews.map(review => review.status === 'Analysing'
        ? { ...review, status: 'Interrupted' as const, updatedAt: new Date().toISOString(), interruption: 'App closed or analysis was interrupted. Retry to continue.' } : review) })) : snapshot;
    },
    mutate,
    restoreData: async (candidate: DomainSnapshot) => {
      const { prepareRestoration } = await import('./backup');
      return mutate(snapshot => prepareRestoration(candidate, snapshot));
    },
    importPublicGames: (records: PublicGame[]) => mutate(snapshot => {
      const identities = new Set(snapshot.games.flatMap(game => game.source.kind === 'online' ? [`${game.source.provider}:${game.source.originalId}`] : []));
      const added: RetainedGame[] = [];
      for (const record of records) {
        const key = `${record.provider}:${record.originalId}`;
        if (identities.has(key)) continue;
        if (!record.originalId || !['lichess', 'chess.com'].includes(record.provider)) throw new Error('Invalid public-game provenance.');
        identities.add(key);
        added.push({ ...structuredClone(record.game), id: crypto.randomUUID(), createdAt: new Date().toISOString(), source: { kind: 'online', provider: record.provider, originalId: record.originalId } });
      }
      return { ...snapshot, games: [...snapshot.games, ...added] };
    }),
    changePracticeSettings: (settings: { autoAdvance?: boolean; showPath?: boolean }) => mutate(snapshot => {
      const values = Object.entries(settings);
      if (!values.length || values.some(([key, value]) => !['autoAdvance', 'showPath'].includes(key) || typeof value !== 'boolean')) throw new Error('Invalid practice settings.');
      return { ...snapshot, extensions: { ...snapshot.extensions,
        ...(settings.autoAdvance !== undefined ? { practiceAutoAdvance: settings.autoAdvance } : {}),
        ...(settings.showPath !== undefined ? { practiceShowPath: settings.showPath } : {}) } };
    }),
    changeReviewSettings: (settings: { liveEngine: boolean }) => mutate(snapshot => {
      if (typeof settings.liveEngine !== 'boolean') throw new Error('Invalid review settings.');
      return { ...snapshot, extensions: { ...snapshot.extensions, reviewLiveEngine: settings.liveEngine } };
    }),
    initializePuzzles: () => mutate(snapshot => {
      if (snapshot.extensions.bundledPuzzlesInitialized) return snapshot;
      const set = bundledPuzzles();
      return { ...snapshot, puzzleCollections: [...snapshot.puzzleCollections, set.collection], puzzles: [...snapshot.puzzles, ...set.puzzles], extensions: { ...snapshot.extensions, bundledPuzzlesInitialized: true } };
    }),
    retainPuzzleSet: async (set: PuzzleSet) => {
      const puzzles = set.puzzles.map(validatePuzzle);
      if (puzzles.some(puzzle => puzzle.collectionId !== set.collection.id) || new Set(puzzles.map(puzzle => puzzle.id)).size !== puzzles.length || JSON.stringify(puzzles.map(puzzle => puzzle.id).sort()) !== JSON.stringify([...set.collection.puzzleIds].sort())) throw new Error('Puzzle collection membership is invalid.');
      return mutate(snapshot => snapshot.puzzleCollections.some(record => record.id === set.collection.id) ? snapshot : ({ ...snapshot,
        puzzleCollections: [...snapshot.puzzleCollections, structuredClone(set.collection)], puzzles: [...snapshot.puzzles, ...puzzles] }));
    },
    removePuzzleCollection: (id: string) => mutate(snapshot => ({ ...snapshot, puzzleCollections: snapshot.puzzleCollections.filter(record => record.id !== id),
      puzzles: snapshot.puzzles.filter(record => record.collectionId !== id), puzzleAttempts: snapshot.puzzleAttempts.filter(record => record.collectionId !== id) })),
    startPuzzle: (id: string) => mutate(snapshot => {
      const puzzle = snapshot.puzzles.find(record => record.id === id);
      if (!puzzle) throw new Error('Puzzle is no longer retained.');
      return { ...snapshot, puzzleAttempts: [...snapshot.puzzleAttempts, newPuzzleAttempt(puzzle)] };
    }),
    puzzleAction: (id: string, action: { type: 'answer'; input: string } | { type: 'hint' | 'reveal' }) => mutate(snapshot => {
      const attempt = snapshot.puzzleAttempts.find(record => record.id === id);
      if (!attempt || attempt.status !== 'Active' || !snapshot.puzzles.some(record => record.id === attempt.puzzleId)) throw new Error('The active puzzle or its source is unavailable.');
      const next = action.type === 'answer' ? answerPuzzle(attempt, action.input) : { ...attempt, assisted: true, status: action.type === 'reveal' ? 'Assisted' as const : 'Active' as const };
      return { ...snapshot, puzzleAttempts: snapshot.puzzleAttempts.map(record => record.id === id ? next : record) };
    }),
    importRepertoire: async (source: string, name: string, side: 'white' | 'black') => {
      const repertoire = parseRepertoire(source, name, side);
      return mutate(snapshot => ({ ...snapshot, repertoires: [...snapshot.repertoires, repertoire] }));
    },
    renameRepertoire: (id: string, name: string) => mutate(snapshot => {
      if (!name.trim() || name.trim().length > 200) throw new Error('Supply a repertoire name.');
      if (!snapshot.repertoires.some(record => record.id === id)) throw new Error('Repertoire no longer exists.');
      return { ...snapshot, repertoires: snapshot.repertoires.map(record => record.id === id ? { ...record, name: name.trim() } : record) };
    }),
    replaceRepertoire: async (id: string, source: string, side: 'white' | 'black') => {
      const parsed = parseRepertoire(source, 'Replacement', side);
      return mutate(snapshot => {
        const previous = snapshot.repertoires.find(record => record.id === id);
        if (!previous) throw new Error('Repertoire no longer exists.');
        return { ...snapshot, repertoires: snapshot.repertoires.map(record => record.id === id ? { ...parsed, id, name: previous.name, createdAt: previous.createdAt, generation: previous.generation + 1 } : record), repertoireAttempts: snapshot.repertoireAttempts.filter(record => record.repertoireId !== id) };
      });
    },
    deleteRepertoire: (id: string) => mutate(snapshot => ({ ...snapshot, repertoires: snapshot.repertoires.filter(record => record.id !== id), repertoireAttempts: snapshot.repertoireAttempts.filter(record => record.repertoireId !== id) })),
    startRecall: (id: string, selected: string[], fen?: string) => mutate(snapshot => {
      const book = snapshot.repertoires.find(record => record.id === id);
      if (!book) throw new Error('Repertoire no longer exists.');
      return { ...snapshot, repertoireAttempts: [...snapshot.repertoireAttempts, createRecall(book, selected, fen)] };
    }),
    recallAction: (id: string, action: { type: 'answer'; input: string } | { type: 'hint' | 'reveal' }) => mutate(snapshot => {
      const attempt = snapshot.repertoireAttempts.find(record => record.id === id);
      const book = snapshot.repertoires.find(record => record.id === attempt?.repertoireId);
      if (!attempt || !book || attempt.generation !== book.generation || attempt.status !== 'Active') throw new Error('The active exercise or its source is unavailable.');
      let next: RecallAttempt;
      if (action.type === 'answer') {
        const answer = candidateUci(attempt.fen, action.input);
        next = { ...attempt, answers: [...attempt.answers, answer], status: attempt.targets.includes(answer) ? attempt.assisted ? 'Assisted' : 'Success' : 'Incorrect' };
      } else next = { ...attempt, assisted: true, status: action.type === 'reveal' ? 'Assisted' : 'Active' };
      return { ...snapshot, repertoireAttempts: snapshot.repertoireAttempts.map(record => record.id === id ? next : record) };
    }),
    startAttempt: (gameId: string, activity: TrainingAttempt['activity'], side: TrainingAttempt['side'], ply?: number, expectedReview?: { id: string; generation: number }) => mutate(snapshot => {
      const game = snapshot.games.find(record => record.id === gameId);
      if (!game) throw new Error('This source game no longer exists.');
      const review = snapshot.reviews.find(record => record.gameId === gameId);
      if (activity === 'mistake' && expectedReview && (review?.id !== expectedReview.id || review.generation !== expectedReview.generation)) throw new Error('The selected review changed. Return to the current review.');
      const attempt = newAttempt(game, activity, side, ply, review);
      const field = activity === 'mistake' ? 'mistakeAttempts' : 'guessMoveAttempts';
      return { ...snapshot, [field]: [...snapshot[field], attempt] };
    }),
    assistAttempt: (id: string, reveal: boolean) => mutate(snapshot => {
      const assist = (record: GameDependent) => {
        if (record.id !== id || !isAttempt(record)) return record;
        if (record.status !== 'Active') throw new Error('Only an active exercise can receive assistance.');
        const game = snapshot.games.find(game => game.id === record.gameId);
        if (!game || captureReviewSource(game).identity !== record.sourceIdentity) throw new Error('The exercise source is unavailable or changed.');
        return { ...record, assisted: true, status: reveal ? 'Assisted' as const : record.status, updatedAt: new Date().toISOString() };
      };
      if (![...snapshot.mistakeAttempts, ...snapshot.guessMoveAttempts].some(record => record.id === id)) throw new Error('This exercise no longer exists.');
      return { ...snapshot, mistakeAttempts: snapshot.mistakeAttempts.map(assist), guessMoveAttempts: snapshot.guessMoveAttempts.map(assist) };
    }),
    answerAttempt: (id: string, answer: string, correct: boolean, evidence?: Evidence, isCurrent: () => boolean = () => true) => mutate(snapshot => {
      if (!isCurrent()) throw new DOMException('Exercise cancelled.', 'AbortError');
      let found = false;
      const finish = (record: GameDependent) => {
        if (record.id !== id || !isAttempt(record)) return record;
        found = true;
        const game = snapshot.games.find(game => game.id === record.gameId);
        if (record.status !== 'Active' || !game || captureReviewSource(game).identity !== record.sourceIdentity) throw new Error('This exercise ended or its source changed.');
        if (record.activity === 'mistake' && !evidence) throw new Error('Engine evidence is required before scoring.');
        return { ...record, answers: [...record.answers, answer], status: correct ? record.assisted ? 'Assisted' as const : 'Success' as const : 'Incorrect' as const,
          updatedAt: new Date().toISOString(), ...(record.evidence && evidence ? { evidence: { ...record.evidence, candidate: structuredClone(evidence) } } : {}) };
      };
      const next = { ...snapshot, mistakeAttempts: snapshot.mistakeAttempts.map(finish), guessMoveAttempts: snapshot.guessMoveAttempts.map(finish) };
      if (!found) throw new Error('This exercise no longer exists.');
      return next;
    }),
    clearProgress: () => mutate(snapshot => ({ ...snapshot, mistakeAttempts: [], guessMoveAttempts: [],
      ...('repertoireAttempts' in snapshot ? { repertoireAttempts: [] } : {}), ...('puzzleAttempts' in snapshot ? { puzzleAttempts: [] } : {}) })),
    beginSupplement: (gameId: string, task: 'continuations' | 'practice', side: 'white' | 'black', isCurrent: () => boolean = () => true) => mutate(snapshot => {
      if (!isCurrent()) throw new DOMException('Review cancelled.', 'AbortError');
      const game = snapshot.games.find(record => record.id === gameId);
      if (!game) throw new Error('This game no longer exists.');
      const imported = importedGameAnalysis(game);
      if (!imported) throw new Error('No matching imported annotations are available.');
      const source = captureReviewSource(game);
      const previous = snapshot.reviews.find(record => record.gameId === gameId);
      if (previous?.status === 'Analysing') throw new Error('Local work is already running. Stop it before changing the requested task.');
      const compatible = previous && previous.source.identity === source.identity && JSON.stringify(previous.basis) === JSON.stringify(REVIEW_BASIS) && hasValidPrefix(previous);
      if (previous?.purpose === 'supplement' && previous.source.identity === source.identity && !compatible) throw new Error('Saved supplemental evidence is incompatible. Remove local analysis before restarting.');
      if (compatible && previous.purpose !== 'supplement' && previous.status === 'Complete') throw new Error('Full comparison results are already available.');
      const candidates = compatible && previous.purpose === 'supplement' ? structuredClone(previous.preparation?.candidates ?? []) : [];
      if (task === 'practice') imported.entries.forEach((entry, ply) => {
        if (positionFromFen(source.positions[ply]).turn !== side || !entry.glyphs.some(glyph => glyph === '?' || glyph === '??')) return;
        const found = candidates.find(candidate => candidate.ply === ply);
        if (found) { if (found.status === 'Unverifiable') { found.status = 'Pending'; found.error = undefined; } return; }
        const retained = compatible && previous.purpose !== 'supplement' ? previous.entries[ply] : undefined;
        candidates.push(retained ? { ply, status: retained.judgment.mistake ? 'Verified eligible' : 'Rejected', evidence: structuredClone(retained) } : { ply, status: 'Pending' });
      });
      const now = new Date().toISOString();
      const continuations = !compatible ? [] : previous.purpose === 'supplement' ? structuredClone(previous.continuations ?? [])
        : previous.entries.filter(entry => entry.actualChild.kind === 'terminal' || entry.actualChild.result.pv.length > 0).map(entry => ({ ply: entry.ply, evidence: structuredClone(entry.actualChild) }));
      const review: Review = { id: previous?.id ?? crypto.randomUUID(), gameId, generation: (previous?.generation ?? 0) + 1, status: 'Analysing', source, basis: structuredClone(REVIEW_BASIS), entries: [],
        purpose: 'supplement', task, continuations,
        ...(task === 'practice' || (compatible && previous.preparation) ? { preparation: { side: task === 'practice' ? side : previous!.preparation!.side, candidates } } : {}), createdAt: previous?.createdAt ?? now, updatedAt: now };
      if (!hasValidPrefix(review)) throw new Error('Supplement evidence is incompatible with its source.');
      return { ...snapshot, reviews: [...snapshot.reviews.filter(record => record.gameId !== gameId), review] };
    }),
    retainContinuation: (id: string, generation: number, identity: string, ply: number, evidence: Evidence, isCurrent: () => boolean = () => true) => mutate(snapshot => {
      const review = currentReview(snapshot, id, generation, identity, isCurrent);
      if (review.purpose !== 'supplement' || review.task !== 'continuations' || review.continuations?.some(line => line.ply === ply) || (evidence.kind === 'search' && evidence.result.generation !== generation)) throw new Error('Continuation work changed.');
      const next = { ...review, continuations: [...(review.continuations ?? []), { ply, evidence: structuredClone(evidence) }], updatedAt: new Date().toISOString() };
      if (!hasValidPrefix(next)) throw new Error('Invalid continuation evidence.');
      return { ...snapshot, reviews: snapshot.reviews.map(record => record.id === id ? next : record) };
    }),
    retainPreparation: (id: string, generation: number, identity: string, candidate: PreparedCandidate, isCurrent: () => boolean = () => true) => mutate(snapshot => {
      const review = currentReview(snapshot, id, generation, identity, isCurrent);
      const previous = review.preparation?.candidates.find(record => record.ply === candidate.ply);
      if (review.purpose !== 'supplement' || review.task !== 'practice' || previous?.status !== 'Pending' || positionFromFen(review.source.positions[candidate.ply]).turn !== review.preparation?.side) throw new Error('Preparation work changed.');
      if (candidate.evidence && [candidate.evidence.parent, candidate.evidence.bestChild, candidate.evidence.actualChild].some(evidence => evidence.kind === 'search' && evidence.result.generation !== generation)) throw new Error('Stale preparation evidence.');
      const next = { ...review, preparation: { ...review.preparation!, candidates: review.preparation!.candidates.map(record => record.ply === candidate.ply ? structuredClone(candidate) : record) }, updatedAt: new Date().toISOString() };
      if (!hasValidPrefix(next)) throw new Error('Invalid preparation evidence.');
      return { ...snapshot, reviews: snapshot.reviews.map(record => record.id === id ? next : record) };
    }),
    beginReview: (gameId: string, basis: ReviewBasis = REVIEW_BASIS, isCurrent: () => boolean = () => true, expectedSource?: string) => mutate(snapshot => {
      const game = snapshot.games.find(record => record.id === gameId);
      if (expectedSource && (!game || captureReviewSource(game).identity !== expectedSource)) throw new Error('Review source changed. Confirm replacement again.');
      return prepareReview(snapshot, gameId, basis, isCurrent);
    }),
    beginFirstReview: async (gameId: string, basis: ReviewBasis = REVIEW_BASIS, isCurrent: () => boolean = () => true, expectedSource?: string) => {
      let started = false;
      const snapshot = await mutate(current => {
        if (!isCurrent()) throw new DOMException('Review cancelled.', 'AbortError');
        const game = current.games.find(record => record.id === gameId);
        if (!game?.computer || game.result === '*') throw new Error('Post-game review requires a completed computer game.');
        if (expectedSource && captureReviewSource(game).identity !== expectedSource) throw new Error('Review source changed. Confirm replacement again.');
        if (current.reviews.some(record => record.gameId === gameId)) return current;
        const next = prepareReview(current, gameId, basis, isCurrent); started = true; return next;
      });
      return { snapshot, started };
    },
    retryReview: (id: string, isCurrent: () => boolean = () => true) => mutate(snapshot => {
      const review = snapshot.reviews.find(record => record.id === id);
      const game = snapshot.games.find(record => record.id === review?.gameId);
      if (!isCurrent()) throw new DOMException('Review cancelled.', 'AbortError');
      if (!review || !game || review.status !== 'Interrupted' || captureReviewSource(game).identity !== review.source.identity || !hasValidPrefix(review)) throw new Error('Review source or evidence changed. Regenerate from the saved game.');
      return { ...snapshot, reviews: snapshot.reviews.map(record => record.id === id ? { ...record, generation: record.generation + 1, status: 'Analysing' as const, interruption: undefined, updatedAt: new Date().toISOString() } : record) };
    }),
    appendReview: (id: string, generation: number, identity: string, entry: MoveEvidence, isCurrent: () => boolean = () => true) => mutate(snapshot => {
      const review = currentReview(snapshot, id, generation, identity, isCurrent);
      if (entry.ply !== review.entries.length) throw new Error('Review coverage must be sequential and exhaustive.');
      if ([entry.parent, entry.bestChild, entry.actualChild].some(evidence => evidence.kind === 'search' && evidence.result.generation !== generation)) throw new Error('Stale review evidence generation.');
      const next = { ...review, entries: [...review.entries, structuredClone(entry)], updatedAt: new Date().toISOString() };
      if (!hasValidPrefix(next)) throw new Error('Review evidence does not match its saved snapshot and analysis basis.');
      return { ...snapshot, reviews: snapshot.reviews.map(record => record.id === id ? next : record) };
    }),
    completeReview: (id: string, generation: number, identity: string, isCurrent: () => boolean = () => true) => mutate(snapshot => {
      const review = currentReview(snapshot, id, generation, identity, isCurrent);
      if (!hasCompleteCoverage(review)) throw new Error('Review is incomplete. Every recorded move requires evidence.');
      return { ...snapshot, reviews: snapshot.reviews.map(record => record.id === id ? { ...record, status: 'Complete' as const, updatedAt: new Date().toISOString() } : record) };
    }),
    interruptReview: (id: string, generation: number, reason: string) => mutate(snapshot => ({ ...snapshot, reviews: snapshot.reviews.map(record => record.id === id && record.generation === generation && record.status === 'Analysing'
      ? { ...record, status: 'Interrupted' as const, interruption: reason, updatedAt: new Date().toISOString() } : record) })),
    deleteReview: (id: string) => mutate(snapshot => ({ ...snapshot, reviews: snapshot.reviews.filter(record => record.id !== id) })),
    importGames: (games: ParsedGame[]) => mutate(snapshot => ({
      ...snapshot,
      games: [...snapshot.games, ...games.map(game => ({
        ...structuredClone(game), id: crypto.randomUUID(), createdAt: new Date().toISOString(), source: { kind: 'pgn' as const },
      }))],
    })),
    startComputer: (fen: string, options: ComputerOptions, now = Date.now(), aids?: PlayAids) => mutate(snapshot => ({
      ...snapshot, games: [...snapshot.games, newComputerGame(fen, options, now, aids)],
    })),
    changePlayAids: (id: string, aids: PlayAids) => mutate(snapshot => {
      const game = snapshot.games.find(record => record.id === id);
      if (!game) throw new Error('This game no longer exists.');
      const next = changePlayAids(game, aids);
      return { ...snapshot, games: snapshot.games.map(record => record.id === id ? next : record) };
    }),
    play: (id: string, expected: { version: number; fen: string }, command: PlayCommand, now = Date.now(), isCurrent: () => boolean = () => true) => mutate(snapshot => {
      if (!isCurrent()) throw new DOMException('Play operation cancelled.', 'AbortError');
      const game = snapshot.games.find(record => record.id === id);
      if (!game) throw new Error('This game no longer exists.');
      if (game.computer?.version !== expected.version || currentFen(game) !== expected.fen) throw new Error('The saved game changed. Reopen it before continuing.');
      const next = transitionGame(game, command, now);
      return { ...snapshot, games: snapshot.games.map(record => record.id === id ? next : record) };
    }),
    editGame: (id: string, details: GameDetails) => mutate(snapshot => {
      if (!snapshot.games.some(game => game.id === id)) throw new Error('This game no longer exists.');
      return { ...snapshot, games: snapshot.games.map(game => game.id === id ? { ...game, ...editDetails(game, details) } : game) };
    }),
    copyToEditable: (id: string, newId: string = crypto.randomUUID()) => mutate(snapshot => {
      const original = snapshot.games.find(game => game.id === id);
      if (!original) throw new Error('This game no longer exists.');
      const { tree: recorded, headers } = treeFromPgn(original.pgn);
      const tree = mergeIntoTree(recorded, snapshot.analysisLines.find(record => record.gameId === id)?.branches ?? []);
      const title = original.headers.Title || `${original.headers.White || '?'} - ${original.headers.Black || '?'}`;
      headers.set('Title', `Copy of ${title}`);
      const [parsed] = parseGames(treeToPgn(tree, headers, automaticResult(tree) ?? original.result));
      const orientation = original.source.kind === 'board' ? original.source.orientation : original.computer?.options.side ?? 'white';
      const copy: RetainedGame = { ...parsed, id: newId, createdAt: new Date().toISOString(), source: { kind: 'board', orientation, copiedFrom: title } };
      return { ...snapshot, games: [...snapshot.games, copy] };
    }),
    deleteGame: (id: string) => mutate(snapshot => removeGame(snapshot, id)),
    saveAnalysisLines: (gameId: string, branches: AnalysisBranch[]) => mutate(snapshot => {
      const game = snapshot.games.find(record => record.id === gameId);
      if (!game) throw new Error('This game no longer exists.');
      const valid = validBranches(game, branches);
      const others = snapshot.analysisLines.filter(record => record.gameId !== gameId);
      const previous = snapshot.analysisLines.find(record => record.gameId === gameId);
      return { ...snapshot, analysisLines: valid.length ? [...others, { id: previous?.id ?? crypto.randomUUID(), gameId, branches: valid }] : others };
    }),
    saveBoardGame: (id: string, pgn: string, orientation: 'white' | 'black', create: boolean) => {
      const parsed = parseGames(pgn);
      if (parsed.length !== 1) throw new Error('A board game must be a single game.');
      return mutate(snapshot => {
        const existing = snapshot.games.find(game => game.id === id);
        if (existing && existing.source.kind !== 'board') throw new Error('Only games created on the board can be edited.');
        if (!existing && !create) throw new Error('This game no longer exists.');
        const game: RetainedGame = { ...structuredClone(parsed[0]), id, createdAt: existing?.createdAt ?? new Date().toISOString(), source: { kind: 'board', orientation, ...(existing?.source.kind === 'board' && existing.source.copiedFrom ? { copiedFrom: existing.source.copiedFrom } : {}) } };
        const kept = snapshot.analysisLines.flatMap(record => {
          if (record.gameId !== id) return [record];
          const branches = record.branches.filter(branch => { try { return validBranches(game, [branch]).length > 0; } catch { return false; } });
          return branches.length ? [{ ...record, branches }] : [];
        });
        return { ...snapshot, analysisLines: kept, games: existing ? snapshot.games.map(record => record.id === id ? game : record) : [...snapshot.games, game] };
      });
    },
  };
}