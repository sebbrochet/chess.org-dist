import 'fake-indexeddb/auto';
import { clear, get } from 'idb-keyval';
import { beforeEach, describe, expect, it } from 'vitest';
import { parseGames } from '../chess/pgn';
import { captureReviewSource, REVIEW_BASIS } from '../chess/review';
import { INITIAL_FEN } from 'chessops/fen';
import { currentFen, type ComputerOptions } from '../chess/play';
import { createLibrary, emptySnapshot, migrateSnapshot, SNAPSHOT_KEY, type DomainSnapshot, type SnapshotDriver } from './library';

const games = () => parseGames('1.e4 e5 *');

describe('durable library', () => {
  beforeEach(async () => { await clear(); });
  it('rejects stale imported-analysis confirmation inside the latest transaction snapshot', async () => {
    const library = createLibrary();
    const game = (await library.importGames(parseGames('1.e4 { [%eval 0.25] } *'))).games[0];
    const confirmed = captureReviewSource(game).identity;
    const changed = await library.mutate(snapshot => ({ ...snapshot, games: snapshot.games.map(record => ({ ...record, ...parseGames('1.d4 { [%eval 0.15] } *')[0] })) }));
    await expect(library.beginReview(game.id, REVIEW_BASIS, () => true, confirmed)).rejects.toThrow('Confirm replacement again');
    expect(await library.load()).toEqual(changed);
  });
  it('starts empty and retains separate identities on repeated local imports', async () => {
    const library = createLibrary();
    expect((await library.load()).games).toEqual([]);
    await library.importGames(games());
    const next = await library.importGames(games());
    expect(new Set(next.games.map(game => game.id)).size).toBe(2);
    expect(await createLibrary().load()).toEqual(next);
  });
  it('uses the latest transaction snapshot across concurrent library instances', async () => {
    await Promise.all([createLibrary().importGames(games()), createLibrary().importGames(games())]);
    const stored = await createLibrary().load();
    expect(stored.games).toHaveLength(2);
    expect(stored.revision).toBe(2);
  });
  it('commits edits and cascades atomically without removing unrelated records', async () => {
    const library = createLibrary();
    const imported = await library.importGames([...games(), ...games()]);
    const [first, second] = imported.games;
    await library.mutate(snapshot => ({ ...snapshot,
      reviews: migrateSnapshot({ ...snapshot, schemaVersion: 1, reviews: [{ id: 'review', gameId: first.id }] }).reviews,
      mistakeAttempts: [{ id: 'mistake', gameId: first.id }],
      guessMoveAttempts: [{ id: 'keep', gameId: second.id }],
      extensions: { future: ['preserved'] },
    }));
    const edited = await library.editGame(first.id, { White: 'Updated' });
    expect(edited.games[0].moves).toEqual(first.moves);
    expect(edited.games[0].source).toEqual(first.source);
    const deleted = await library.deleteGame(first.id);
    expect(deleted.reviews).toEqual([]);
    expect(deleted.mistakeAttempts).toEqual([]);
    expect(deleted.guessMoveAttempts).toHaveLength(1);
    expect(deleted.extensions).toEqual({ future: ['preserved'] });
    expect(await get(SNAPSHOT_KEY)).toEqual(deleted);
  });
  it('does not expose failed writes, and the serialized queue recovers', async () => {
    let durable = emptySnapshot();
    let fail = true;
    let release: (() => void) | undefined;
    const driver: SnapshotDriver = {
      read: async () => structuredClone(durable),
      update: async change => {
        const candidate = change(structuredClone(durable));
        if (fail) throw new Error('Quota exceeded');
        await new Promise<void>(resolve => { release = resolve; });
        durable = candidate;
      },
    };
    const library = createLibrary(driver);
    await expect(library.importGames(games())).rejects.toThrow('Quota');
    expect((await library.load()).games).toHaveLength(0);
    fail = false;
    const saving = library.importGames(games());
    await Promise.resolve();
    expect(durable.games).toHaveLength(0);
    release?.();
    await saving;
    expect(durable.games).toHaveLength(1);
  });
  it('preserves existing data when parsing or mutations fail', async () => {
    const library = createLibrary();
    const before = await library.importGames(games());
    expect(() => parseGames('1.e4 e5 *\n\n1.e5 *')).toThrow();
    await expect(library.mutate(() => { throw new Error('rejected'); })).rejects.toThrow();
    expect(await library.load()).toEqual(before);
  });
  it('rejects unsupported snapshots instead of overwriting them', () => {
    expect(() => migrateSnapshot({ schemaVersion: 99 })).toThrow('version');
    expect(migrateSnapshot(undefined)).toEqual(emptySnapshot());
    const invalid = { ...emptySnapshot(), games: null } as unknown as DomainSnapshot;
    expect(() => migrateSnapshot(invalid)).toThrow('damaged');
  });
  const options: ComputerOptions = { side: 'white', level: 2, takebacks: true, time: null };
  it('creates post-game first analysis once across concurrent libraries and preserves existing analysis', async () => {
    const library = createLibrary();
    const started = await library.startComputer(INITIAL_FEN, options, 0);
    const game = started.games[0];
    await expect(library.beginFirstReview(game.id)).rejects.toThrow('completed computer game');
    await library.play(game.id, { version: game.computer!.version, fen: currentFen(game) }, { type: 'resign' }, 1);
    await expect(library.beginFirstReview(game.id, REVIEW_BASIS, () => true, 'stale-confirmed-source')).rejects.toThrow('Confirm replacement again');
    const results = await Promise.all([library.beginFirstReview(game.id), createLibrary().beginFirstReview(game.id)]);
    expect(results.filter(result => result.started)).toHaveLength(1);
    const retained = (await library.load()).reviews[0];
    const reopened = await library.beginFirstReview(game.id);
    expect(reopened.started).toBe(false);
    expect(reopened.snapshot.reviews).toEqual([retained]);
    expect(reopened.snapshot.games[0].result).toBe('0-1');
  });
  it('atomically saves moves and clocks and preserves creation choices through descriptive edits', async () => {
    const library = createLibrary();
    const started = (await library.startComputer(INITIAL_FEN, options, 0)).games[0];
    const next = await library.play(started.id, { version: 0, fen: currentFen(started) }, { type: 'move', move: 'e4', actor: 'player' }, 1);
    const edited = await library.editGame(started.id, { Title: 'My game' });
    expect(edited.games[0].computer).toEqual(next.games[0].computer);
    expect(edited.games[0].computer?.options).toEqual(options);
    expect((await createLibrary().load()).games[0].moves).toEqual(['e4']);
  });
  it('retains changed play aids without changing play version, moves or creation choices', async () => {
    const library = createLibrary();
    const started = (await library.startComputer(INITIAL_FEN, options, 0, { evaluation: true, bestMove: false, assessments: false })).games[0];
    expect(started.computer?.aids).toEqual({ evaluation: true, bestMove: false, assessments: false });
    const changed = (await library.changePlayAids(started.id, { evaluation: false, bestMove: true, assessments: true })).games[0];
    expect(changed.computer?.aids).toEqual({ evaluation: false, bestMove: true, assessments: true });
    expect(changed.computer?.version).toBe(started.computer?.version);
    expect(changed.computer?.options).toEqual(options);
    expect((await createLibrary().load()).games[0].computer?.aids).toEqual({ evaluation: false, bestMove: true, assessments: true });
    await expect(library.changePlayAids('missing', { evaluation: false, bestMove: false, assessments: false })).rejects.toThrow('no longer exists');
  });
  it('rejects stale move/takeback/resignation/deletion generations and navigation-cancelled replies', async () => {
    const library = createLibrary();
    const original = (await library.startComputer(INITIAL_FEN, options, 0)).games[0];
    const initial = { version: 0, fen: currentFen(original) };
    const moved = (await library.play(original.id, initial, { type: 'move', move: 'e4', actor: 'player' }, 0)).games[0];
    const reply = { version: moved.computer!.version, fen: currentFen(moved) };
    await expect(library.play(original.id, initial, { type: 'move', move: 'd4', actor: 'player' }, 0)).rejects.toThrow('changed');
    await expect(library.play(original.id, reply, { type: 'move', move: 'e5', actor: 'engine' }, 0, () => false)).rejects.toMatchObject({ name: 'AbortError' });
    const taken = (await library.play(original.id, reply, { type: 'takeback' }, 0)).games[0];
    await expect(library.play(original.id, reply, { type: 'move', move: 'e5', actor: 'engine' }, 0)).rejects.toThrow('changed');
    const resigned = (await library.play(original.id, { version: taken.computer!.version, fen: currentFen(taken) }, { type: 'resign' }, 0)).games[0];
    await expect(library.play(original.id, { version: resigned.computer!.version, fen: currentFen(resigned) }, { type: 'move', move: 'e4', actor: 'player' }, 0)).rejects.toThrow('unfinished');
    await library.deleteGame(original.id);
    await expect(library.play(original.id, reply, { type: 'move', move: 'e5', actor: 'engine' }, 0)).rejects.toThrow('no longer exists');
  });
  it('keeps the previous saved move and clocks when a computer-game write fails', async () => {
    let durable = emptySnapshot();
    let fail = false;
    const library = createLibrary({ read: async () => structuredClone(durable), update: async change => {
      const next = change(structuredClone(durable));
      if (fail) throw new Error('Quota');
      durable = next;
    } });
    const original = (await library.startComputer(INITIAL_FEN, { ...options, time: { initialMs: 10000, incrementMs: 1000 } }, 0)).games[0];
    fail = true;
    await expect(library.play(original.id, { version: 0, fen: currentFen(original) }, { type: 'move', move: 'e4', actor: 'player' }, 1000)).rejects.toThrow('Quota');
    expect((await library.load()).games[0]).toEqual(original);
    fail = false;
    const resumed = (await library.play(original.id, { version: 0, fen: currentFen(original) }, { type: 'reconcile' }, 10000)).games[0];
    expect(resumed.result).toBe('0-1');
  });
});