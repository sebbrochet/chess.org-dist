import 'fake-indexeddb/auto';
import { clear } from 'idb-keyval';
import { beforeEach, describe, expect, it } from 'vitest';
import { createLibrary, emptySnapshot } from './library';
import { bundledPuzzles } from '../chess/puzzles';

describe('puzzle retention and results', () => {
  beforeEach(async () => { await clear(); });
  it('initializes once and does not reinstall explicitly removed starters', async () => {
    const library = createLibrary(); await library.initializePuzzles();
    expect((await library.initializePuzzles()).puzzles).toHaveLength(3);
    const removed = await library.removePuzzleCollection('chess-org-starter');
    expect(removed.puzzles).toHaveLength(0);
    expect((await createLibrary().initializePuzzles()).puzzles).toHaveLength(0);
  });
  it('removes collection attempts and rejects late results without touching unrelated data', async () => {
    const library = createLibrary(); const initialized = await library.initializePuzzles();
    const puzzle = initialized.puzzles[0]; const attempt = (await library.startPuzzle(puzzle.id)).puzzleAttempts[0];
    await library.puzzleAction(attempt.id, { type: 'hint' });
    const answered = await library.puzzleAction(attempt.id, { type: 'answer', input: puzzle.solutions[0][0] });
    expect(answered.puzzleAttempts[0]).toMatchObject({ status: 'Assisted', assisted: true });
    expect((await library.removePuzzleCollection(puzzle.collectionId)).puzzleAttempts).toHaveLength(0);
    await expect(library.puzzleAction(attempt.id, { type: 'reveal' })).rejects.toThrow('unavailable');
  });
  it('preserves complete prior content when new retention fails', async () => {
    let durable = emptySnapshot(); let fail = false;
    const library = createLibrary({ read: async () => structuredClone(durable), update: async change => { const next = change(structuredClone(durable)); if (fail) throw new Error('Quota'); durable = next; } });
    await library.initializePuzzles(); const before = structuredClone(durable);
    fail = true;
    await expect(library.retainPuzzleSet(bundledPuzzles())).rejects.toThrow('Quota');
    expect(durable).toEqual(before);
  });
});