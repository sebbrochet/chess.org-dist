import { parseGames, positionFromFen, type ParsedGame } from '../chess/pgn';
import { legalContinuation } from '../chess/review';
import { makePgn, PgnParser, type Game, type PgnNodeData } from 'chessops/pgn';
import type { EngineScore } from '../engine/stockfish';

export type GameProvider = 'lichess' | 'chess.com';
export type Cadence = 'all' | 'ultraBullet' | 'bullet' | 'blitz' | 'rapid' | 'classical' | 'correspondence' | 'daily';
const CADENCE_LABELS: Record<Cadence, string> = { all: 'All', ultraBullet: 'UltraBullet', bullet: 'Bullet', blitz: 'Blitz', rapid: 'Rapid', classical: 'Classical', correspondence: 'Correspondence', daily: 'Daily' };
export function cadenceOptions(provider: GameProvider): { value: Cadence; label: string }[] {
  const values: Cadence[] = provider === 'lichess' ? ['all', 'ultraBullet', 'bullet', 'blitz', 'rapid', 'classical', 'correspondence'] : ['all', 'bullet', 'blitz', 'rapid', 'daily'];
  return values.map(value => ({ value, label: CADENCE_LABELS[value] }));
}
export interface PublicGame { game: ParsedGame; provider: GameProvider; originalId: string }
export interface OpeningInfo { name: string; eco?: string }
export interface OpeningMove { uci: string; san: string; white: number; draws: number; black: number; total: number; opening?: OpeningInfo }
export interface OpeningSample { white: number; draws: number; black: number; total: number; moves: OpeningMove[]; source: string; ratingSystem: string; ratings: string; speeds: string; fen: string; opening?: OpeningInfo }
const MAX_RESPONSE = 8000000;
async function responseText(url: string, fetcher: typeof fetch, signal?: AbortSignal, missingResponse?: string): Promise<string> {
  const response = await fetcher(url, { signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(20000)]) : AbortSignal.timeout(20000), credentials: 'omit' });
  if (response.status === 404 && missingResponse !== undefined) return missingResponse;
  if (!response.ok) throw new Error(response.status === 429 ? 'Provider rate limit reached. Retry later; retained content is unchanged.' : `Provider unavailable (${response.status}). Retained content is unchanged.`);
  if (Number(response.headers.get('content-length')) > MAX_RESPONSE) throw new Error('Provider response exceeds the supported size. Select a smaller date range.');
  const text = await response.text(); if (text.length > MAX_RESPONSE) throw new Error('Provider response is too large.'); return text;
}
export function usernameInput(value: string): string {
  const user = value.trim(); if (!/^[a-zA-Z0-9_-]{1,30}$/.test(user)) throw new Error('Supply a valid public username.'); return user;
}
function cadenceFromHeaders(game: ParsedGame, provider: GameProvider): Cadence | undefined {
  const category = game.headers.TimeClass || (provider === 'lichess' ? /\b(ultrabullet|bullet|blitz|rapid|classical|correspondence)\b/i.exec(game.headers.Event ?? '')?.[1] : undefined);
  return cadenceOptions(provider).find(option => option.value !== 'all' && option.value.toLowerCase() === category?.toLowerCase())?.value;
}
function withProviderHeaders(game: ParsedGame, headers: Record<string, string>): ParsedGame {
  if (!Object.keys(headers).length) return game;
  const parsed: Game<PgnNodeData>[] = [];
  new PgnParser(value => parsed.push(value)).parse(game.pgn);
  for (const [key, value] of Object.entries(headers)) parsed[0].headers.set(key, value);
  return { ...game, headers: Object.fromEntries(parsed[0].headers), pgn: makePgn(parsed[0]) };
}
function validDate(value?: string): string | undefined {
  if (!value || !/^\d{4}[.-]\d{2}[.-]\d{2}$/.test(value)) return;
  const iso = value.replaceAll('.', '-');
  const parsed = new Date(`${iso}T00:00:00Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === iso ? iso : undefined;
}
function validTime(value?: string): string | undefined {
  return value && /^(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d$/.test(value) ? value : undefined;
}
export function publicGameDetails(record: PublicGame): { date: string; cadence: string; timeControl: string } {
  const headers = record.game.headers;
  const utcDate = validDate(headers.UTCDate), sourceDate = validDate(headers.Date), endDate = validDate(headers.EndUTCDate);
  const utcTime = validTime(headers.UTCTime), sourceTime = validTime(headers.Time);
  const ended = !utcDate && !sourceDate && !utcTime && !sourceTime && !!endDate;
  const date = utcDate || sourceDate || (ended ? endDate : undefined);
  const time = ended ? validTime(headers.EndUTCTime) : utcTime || sourceTime;
  const timezone = ended || utcTime ? 'UTC' : headers.TimeZone || 'timezone unknown';
  const completionTime = validTime(headers.EndUTCTime);
  const completion = !ended && !time && endDate && completionTime ? `; Ended ${endDate} / ${completionTime} (UTC)` : '';
  const category = cadenceFromHeaders(record.game, record.provider);
  const control = headers.TimeControl;
  let timeControl = 'Time control unknown';
  if (control === '-') timeControl = 'Untimed';
  else if (control && control !== '?') {
    const live = /^(\d+)(?:\+(\d+))?$/.exec(control);
    const daily = /^1\/(\d+)$/.exec(control);
    if (live && Number(live[1]) > 0 && Number.isSafeInteger(Number(live[1])) && Number.isSafeInteger(Number(live[2] ?? 0))) {
      const seconds = Number(live[1]), increment = Number(live[2] ?? 0);
      timeControl = `${seconds % 60 === 0 ? `${seconds / 60} min` : `${seconds} sec`}${increment ? ` + ${increment} sec` : ''}`;
    } else if (daily && Number(daily[1]) > 0 && Number(daily[1]) % 86400 === 0) {
      const days = Number(daily[1]) / 86400;
      timeControl = `${days} ${days === 1 ? 'day' : 'days'}/move`;
    } else timeControl = control;
  }
  return { date: `${ended ? 'Ended ' : ''}${date || 'Date unknown'} / ${time ? `${time} (${timezone})` : 'Time unknown'}${completion}`, cadence: category ? CADENCE_LABELS[category] : 'Cadence unknown', timeControl };
}
export function normalizeLichess(source: string): PublicGame[] {
  if (!source.trim()) return [];
  return parseGames(source).map(game => {
    const id = game.headers.GameId || /^https:\/\/lichess\.org\/(?:game\/)?([a-zA-Z0-9]{8})(?:[a-zA-Z0-9]{4})?(?:[/?#]|$)/.exec(game.headers.Site ?? '')?.[1];
    if (!id || !/^[a-zA-Z0-9]{8}$/.test(id)) throw new Error('The provider did not supply a valid original game identity.');
    const cadence = cadenceFromHeaders(game, 'lichess');
    return { game: withProviderHeaders(game, cadence ? { TimeClass: cadence } : {}), originalId: id, provider: 'lichess' };
  });
}
export async function fetchPublicGames(provider: GameProvider, username: string, month = '', before = '', fetcher: typeof fetch = fetch, signal?: AbortSignal, cadence: Cadence = 'all'): Promise<{ games: PublicGame[]; archives: string[] }> {
  const user = usernameInput(username);
  if (!cadenceOptions(provider).some(option => option.value === cadence)) throw new Error('Select a cadence supported by this provider.');
  if (provider === 'lichess') {
    const query = new URLSearchParams({ max: '20', moves: 'true', tags: 'true', clocks: 'false', evals: 'false', opening: 'false' });
    if (cadence !== 'all') query.set('perfType', cadence);
    if (before) { const date = Date.parse(before); if (!Number.isFinite(date)) throw new Error('Supply a valid before date.'); query.set('until', String(date)); }
    return { games: normalizeLichess(await responseText(`https://lichess.org/api/games/user/${encodeURIComponent(user)}?${query}`, fetcher, signal, '')).filter(record => cadence === 'all' || cadenceFromHeaders(record.game, provider) === cadence), archives: [] };
  }
  if (provider !== 'chess.com') throw new Error('Unknown provider.');
  const list = JSON.parse(await responseText(`https://api.chess.com/pub/player/${encodeURIComponent(user.toLowerCase())}/games/archives`, fetcher, signal, JSON.stringify({ archives: [] }))) as { archives?: unknown };
  if (!Array.isArray(list.archives) || list.archives.some(value => typeof value !== 'string')) throw new Error('Invalid public archive response.');
  const prefix = `https://api.chess.com/pub/player/${user.toLowerCase()}/games/`;
  const archives = (list.archives as string[]).map(url => {
    if (!url.toLowerCase().startsWith(prefix) || !/^\d{4}\/\d{2}$/.test(url.slice(prefix.length))) throw new Error('Untrusted archive URL.');
    return url.slice(prefix.length);
  });
  const chosen = month || archives.at(-1);
  if (!chosen) return { games: [], archives };
  if (!archives.includes(chosen)) throw new Error('Select one of this user\'s published archive months.');
  const data = JSON.parse(await responseText(`${prefix}${chosen}`, fetcher, signal)) as { games?: unknown };
  if (!Array.isArray(data.games)) throw new Error('Invalid monthly game response.');
  const games: PublicGame[] = [];
  for (const raw of data.games) {
    if (!raw || typeof raw !== 'object') throw new Error('Invalid provider game record.');
    const record = raw as { rules?: unknown; pgn?: unknown; url?: unknown; time_class?: unknown; time_control?: unknown; end_time?: unknown };
    if (record.rules !== 'chess') continue;
    if (typeof record.pgn !== 'string' || typeof record.url !== 'string' || !/^https:\/\/www\.chess\.com\/game\/(live|daily)\/\d+$/.test(record.url)) throw new Error('Provider record lacks a valid original identity or PGN.');
    const parsed = parseGames(record.pgn);
    if (parsed.length !== 1) throw new Error('Provider record contains an unexpected game count.');
    const headers: Record<string, string> = {};
    if (typeof record.time_class === 'string' && cadenceOptions(provider).some(option => option.value !== 'all' && option.value === record.time_class)) headers.TimeClass = record.time_class;
    if (typeof record.time_control === 'string' && record.time_control.length <= 100 && !Array.from(record.time_control).some(character => character.charCodeAt(0) < 32)) headers.TimeControl = record.time_control;
    if (typeof record.end_time === 'number' && Number.isSafeInteger(record.end_time) && record.end_time >= 0 && record.end_time < 253402300800) {
      const ended = new Date(record.end_time * 1000).toISOString();
      headers.EndUTCDate = ended.slice(0, 10).replaceAll('-', '.'); headers.EndUTCTime = ended.slice(11, 19);
    }
    const game = withProviderHeaders(parsed[0], headers);
    if (cadence === 'all' || cadenceFromHeaders(game, provider) === cadence) games.push({ game, provider, originalId: record.url });
  }
  return { games, archives };
}
const count = (value: unknown) => { if (!Number.isSafeInteger(value) || Number(value) < 0) throw new Error('Invalid statistics count.'); return Number(value); };
function openingInfo(value: unknown): OpeningInfo | undefined {
  if (!value || typeof value !== 'object') return;
  const info = value as { name?: unknown; eco?: unknown };
  if (typeof info.name !== 'string' || !info.name.trim() || info.name.length > 500 || Array.from(info.name).some(character => character.charCodeAt(0) < 32 || character.charCodeAt(0) === 127)) return;
  return { name: info.name.trim(), eco: typeof info.eco === 'string' && /^[A-E]\d{2}$/.test(info.eco) ? info.eco : undefined };
}
export function openingSample(value: unknown, fen: string, ratings: string, speeds: string): OpeningSample {
  positionFromFen(fen);
  const raw = value as { white?: unknown; draws?: unknown; black?: unknown; moves?: unknown; opening?: unknown };
  if (!raw || !Array.isArray(raw.moves)) throw new Error('Invalid explorer response.');
  const white = count(raw.white), draws = count(raw.draws), black = count(raw.black);
  const moves = raw.moves.map(item => {
    const move = item as { uci?: unknown; white?: unknown; draws?: unknown; black?: unknown; opening?: unknown };
    if (!move || typeof move.uci !== 'string') throw new Error('Invalid explorer move.');
    const legal = legalContinuation(fen, [move.uci])[0]; const white = count(move.white), draws = count(move.draws), black = count(move.black);
    return { uci: move.uci, san: legal.san, white, draws, black, total: white + draws + black, opening: openingInfo(move.opening) };
  });
  if (new Set(moves.map(move => move.uci)).size !== moves.length || moves.some(move => move.total > white + draws + black)) throw new Error('Inconsistent explorer sample.');
  return { white, draws, black, total: white + draws + black, moves, fen, ratings, speeds, source: 'Lichess opening explorer', ratingSystem: 'Lichess ratings, not FIDE', opening: openingInfo(raw.opening) };
}
export type OpeningFailure = 'authentication' | 'rate-limit' | 'network' | 'provider';
export class OpeningServiceError extends Error {
  constructor(public readonly kind: OpeningFailure, message: string) { super(message); }
}
export function openingToken(value: string): string {
  const token = value.trim();
  if (!token || token.length > 1024 || !/^[-a-zA-Z0-9._~+/]+=*$/.test(token)) throw new Error('Supply a valid Lichess token.');
  return token;
}
export interface CloudLine { uci: string; score: EngineScore }
// Sent without credentials: the cloud evaluation service accepts anonymous requests.
export async function fetchCloudEvaluation(fen: string, fetcher: typeof fetch = fetch, signal?: AbortSignal): Promise<CloudLine[]> {
  positionFromFen(fen);
  const query = new URLSearchParams({ fen, multiPv: '5' });
  const response = await fetcher(`https://lichess.org/api/cloud-eval?${query}`, { credentials: 'omit', redirect: 'error', signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(10000)]) : AbortSignal.timeout(10000) });
  if (response.status === 404) return [];
  if (!response.ok) throw new Error(`Lichess cloud evaluation unavailable (${response.status}).`);
  const text = await response.text();
  if (text.length > MAX_RESPONSE) throw new Error('Lichess cloud evaluation is too large.');
  const raw = JSON.parse(text) as { pvs?: unknown };
  if (!Array.isArray(raw.pvs)) throw new Error('Invalid cloud evaluation.');
  return raw.pvs.flatMap(item => {
    const pv = item as { moves?: unknown; cp?: unknown; mate?: unknown };
    const uci = typeof pv.moves === 'string' ? pv.moves.split(' ')[0] : '';
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(uci)) return [];
    const score: EngineScore | undefined = Number.isSafeInteger(pv.mate) && pv.mate !== 0 ? { kind: 'mate', value: Number(pv.mate), perspective: 'white', winner: Number(pv.mate) > 0 ? 'white' : 'black' }
      : Number.isSafeInteger(pv.cp) ? { kind: 'cp', value: Number(pv.cp), perspective: 'white' } : undefined;
    return score ? [{ uci, score }] : [];
  });
}
export async function fetchOpenings(fen: string, ratings: string, speeds: string, fetcher: typeof fetch = fetch, signal?: AbortSignal, token?: string): Promise<OpeningSample> {
  positionFromFen(fen);
  if (!/^(0|1000|1200|1400|1600|1800|2000|2200|2500)(,(0|1000|1200|1400|1600|1800|2000|2200|2500))*$/.test(ratings) || !/^(rapid|classical|blitz|bullet|ultraBullet|correspondence)(,(rapid|classical|blitz|bullet|ultraBullet|correspondence))*$/.test(speeds)) throw new Error('Select supported Lichess rating bands and speeds.');
  const query = new URLSearchParams({ variant: 'standard', fen, ratings, speeds, moves: '20' });
  const headers = token === undefined ? undefined : { Authorization: `Bearer ${openingToken(token)}` };
  let response: Response;
  try {
    response = await fetcher(`https://explorer.lichess.ovh/lichess?${query}`, { headers, credentials: 'omit', redirect: 'error', cache: 'no-store', signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(20000)]) : AbortSignal.timeout(20000) });
  } catch {
    throw new OpeningServiceError('network', 'Lichess network unavailable. Check your connection and retry.');
  }
  if (response.status === 401 || response.status === 403) throw new OpeningServiceError('authentication', `Lichess authentication refused (${response.status}). Configure a valid token.`);
  if (response.status === 429) throw new OpeningServiceError('rate-limit', 'Lichess rate limit reached. Retry later.');
  if (!response.ok) throw new OpeningServiceError('provider', `Lichess provider unavailable (${response.status}).`);
  if (Number(response.headers.get('content-length')) > MAX_RESPONSE) throw new OpeningServiceError('provider', 'Lichess response exceeds the supported size.');
  let text: string;
  try { text = await response.text(); }
  catch { throw new OpeningServiceError('network', 'Lichess response could not be retrieved. Retry later.'); }
  if (text.length > MAX_RESPONSE) throw new OpeningServiceError('provider', 'Lichess response exceeds the supported size.');
  try { return openingSample(JSON.parse(text), fen, ratings, speeds); }
  catch { throw new OpeningServiceError('provider', 'Lichess returned invalid opening statistics.'); }
}