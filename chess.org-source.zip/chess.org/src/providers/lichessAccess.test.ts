// @vitest-environment jsdom
import { afterEach, expect, it, vi } from 'vitest';
import { createLichessAccess, LICHESS_ACCESS_KEY } from './lichessAccess';

afterEach(() => { localStorage.clear(); vi.restoreAllMocks(); });

it('keeps session access only in memory and exposes no token in the UI snapshot', () => {
  const access = createLichessAccess();
  expect(access.getSnapshot()).toBeUndefined();
  access.configure('lip_session_fixture', false, access.beginValidation());
  expect(access.getToken()).toBe('lip_session_fixture');
  expect(access.getSnapshot()).toEqual({ retention: 'session', status: 'Accepted' });
  expect(localStorage.getItem(LICHESS_ACCESS_KEY)).toBeNull();
  expect(createLichessAccess().getToken()).toBeUndefined();
  expect(JSON.stringify(access.getSnapshot())).not.toContain('lip_session_fixture');
});

it('retains explicitly remembered access and clears it when switching to session-only', () => {
  const access = createLichessAccess();
  access.configure('lip_device_fixture', true, access.beginValidation());
  expect(createLichessAccess().getSnapshot()).toEqual({ retention: 'device', status: 'Not checked' });
  expect(createLichessAccess().getToken()).toBe('lip_device_fixture');
  access.configure('lip_new_fixture', false, access.beginValidation());
  expect(localStorage.getItem(LICHESS_ACCESS_KEY)).toBeNull();
  expect(createLichessAccess().getToken()).toBeUndefined();
});

it('removes active and remembered access and rejects late or cancelled validation', () => {
  const access = createLichessAccess();
  access.configure('lip_device_fixture', true, access.beginValidation());
  const pending = access.beginValidation();
  access.remove();
  expect(access.configure('lip_late_fixture', true, pending)).toBe(false);
  expect(access.getToken()).toBeUndefined();
  expect(localStorage.getItem(LICHESS_ACCESS_KEY)).toBeNull();
  const cancelled = access.beginValidation(); access.cancelValidation();
  expect(access.configure('lip_cancelled_fixture', false, cancelled)).toBe(false);
});

it('preserves existing access on invalid input and device-storage failure', () => {
  const access = createLichessAccess();
  access.configure('lip_working_fixture', false, access.beginValidation());
  expect(() => access.configure('bad\nheader', true, access.beginValidation())).toThrow('valid Lichess token');
  vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new Error('secret details'); });
  expect(() => access.configure('lip_candidate_fixture', true, access.beginValidation())).toThrow('Existing access is unchanged');
  expect(access.getToken()).toBe('lip_working_fixture');
});

it('ignores invalid remembered data and stale status replies', () => {
  localStorage.setItem(LICHESS_ACCESS_KEY, 'bad\nheader');
  const access = createLichessAccess();
  expect(access.getToken()).toBeUndefined();
  access.configure('lip_current_fixture', false, access.beginValidation());
  access.recordStatus('lip_old_fixture', 'Authentication refused');
  expect(access.getSnapshot()?.status).toBe('Accepted');
  access.recordStatus('lip_current_fixture', 'Rate limited');
  expect(access.getSnapshot()?.status).toBe('Rate limited');
});

it('supports session use when storage is blocked and reports incomplete device removal', () => {
  vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => { throw new Error('Blocked'); });
  const access = createLichessAccess();
  access.configure('lip_session_fixture', false, access.beginValidation());
  vi.spyOn(Storage.prototype, 'removeItem').mockImplementation(() => { throw new Error('Blocked'); });
  expect(() => access.remove()).toThrow('remembered access could not be cleared');
  expect(access.getToken()).toBeUndefined();
});