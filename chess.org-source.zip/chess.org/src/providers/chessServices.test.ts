import { describe, expect, it, vi } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { cadenceOptions, fetchCloudEvaluation, fetchOpenings, fetchPublicGames, normalizeLichess, openingSample, publicGameDetails, usernameInput } from './chessServices';
import { parseGames } from '../chess/pgn';

describe('public provider boundaries', () => {
  it('requests Lichess cadence before the result limit and preserves its date scope', async () => {
    const source = '[Site "https://lichess.org/AbCd1234"]\n[Event "Rated rapid game"]\n[UTCDate "2026.11.06"]\n[UTCTime "12:34:56"]\n[TimeControl "600+5"]\n1.e4 *';
    const fetcher = vi.fn<typeof fetch>().mockResolvedValue(new Response(source));
    const result = await fetchPublicGames('lichess', 'Player', '', '2026-11-07', fetcher, undefined, 'rapid');
    const query = new URL(String(fetcher.mock.calls[0][0])).searchParams;
    expect(query.get('perfType')).toBe('rapid'); expect(query.get('until')).toBe(String(Date.parse('2026-11-07')));
    expect(publicGameDetails(result.games[0])).toEqual({ date: '2026-11-06 / 12:34:56 (UTC)', cadence: 'Rapid', timeControl: '10 min + 5 sec' });
    expect(parseGames(result.games[0].game.pgn)[0].headers.TimeClass).toBe('rapid');
  });
  it('filters a chess.com month by supplied category and retains exact metadata in PGN', async () => {
    const records = ['rapid', 'blitz', 'daily'].map((time_class, index) => ({ rules: 'chess', url: `https://www.chess.com/game/live/${index}`, pgn: '1.e4 *', time_class, time_control: time_class === 'daily' ? '1/259200' : '900+10', end_time: 1793968496 }));
    const fetcher = vi.fn<typeof fetch>().mockImplementation(async url => new Response(JSON.stringify(String(url).endsWith('/archives') ? { archives: ['https://api.chess.com/pub/player/player/games/2026/11'] } : { games: records })));
    const result = await fetchPublicGames('chess.com', 'Player', '2026/11', '', fetcher, undefined, 'rapid');
    expect(result.games).toHaveLength(1); expect(result.games[0].originalId).toBe(records[0].url);
    const details = publicGameDetails(result.games[0]);
    expect(details).toMatchObject({ cadence: 'Rapid', timeControl: '15 min + 10 sec' }); expect(details.date).toContain('Ended '); expect(details.date).toContain('(UTC)');
    expect(parseGames(result.games[0].game.pgn)[0].headers).toMatchObject({ TimeClass: 'rapid', TimeControl: '900+10', EndUTCTime: expect.any(String) });
    const all = await fetchPublicGames('chess.com', 'Player', '', '', fetcher);
    expect(all.games).toHaveLength(3); expect(publicGameDetails(all.games[2]).timeControl).toBe('3 days/move');
  });
  it('keeps missing and invalid metadata unknown without fabricating midnight or cadence', () => {
    const missing = normalizeLichess('[Site "https://lichess.org/AbCd1234"]\n[Date "2026.11.06"]\n1.e4 *')[0];
    expect(publicGameDetails(missing)).toEqual({ date: '2026-11-06 / Time unknown', cadence: 'Cadence unknown', timeControl: 'Time control unknown' });
    const invalid = normalizeLichess('[Site "https://lichess.org/AbCd1234"]\n[UTCDate "2026.02.30"]\n[UTCTime "25:00:00"]\n[TimeControl "-"]\n1.e4 *')[0];
    expect(publicGameDetails(invalid)).toEqual({ date: 'Date unknown / Time unknown', cadence: 'Cadence unknown', timeControl: 'Untimed' });
    expect(cadenceOptions('chess.com').map(option => option.value)).not.toContain('classical');
  });
  it('preserves a known time even when the date or timezone is unavailable', () => {
    const utc = normalizeLichess('[Site "https://lichess.org/AbCd1234"]\n[UTCTime "12:34:56"]\n1.e4 *')[0];
    expect(publicGameDetails(utc).date).toBe('Date unknown / 12:34:56 (UTC)');
    const local = normalizeLichess('[Site "https://lichess.org/AbCd1234"]\n[Date "2026.11.06"]\n[Time "12:34:56"]\n1.e4 *')[0];
    expect(publicGameDetails(local).date).toBe('2026-11-06 / 12:34:56 (timezone unknown)');
    const ended = normalizeLichess('[Site "https://lichess.org/AbCd1234"]\n[Date "2026.11.05"]\n[EndUTCDate "2026.11.06"]\n[EndUTCTime "12:34:56"]\n1.e4 *')[0];
    expect(publicGameDetails(ended).date).toBe('2026-11-05 / Time unknown; Ended 2026-11-06 / 12:34:56 (UTC)');
  });
  it('distinguishes successful no-matches and validates provider-specific categories', async () => {
    const fetcher = vi.fn<typeof fetch>().mockImplementation(async () => new Response('[Site "https://lichess.org/AbCd1234"]\n[Event "Rated blitz game"]\n1.e4 *'));
    expect((await fetchPublicGames('lichess', 'Player', '', '', fetcher, undefined, 'rapid')).games).toEqual([]);
    await expect(fetchPublicGames('chess.com', 'Player', '', '', fetcher, undefined, 'classical')).rejects.toThrow('supported');
    fetcher.mockClear(); await fetchPublicGames('lichess', 'Player', '', '', fetcher);
    expect(new URL(String(fetcher.mock.calls[0][0])).searchParams.has('perfType')).toBe(false);
  });
  it('returns empty for unknown users without swallowing a missing published archive', async () => {
    const missingUser = vi.fn<typeof fetch>().mockImplementation(async () => new Response('', { status: 404 }));
    await expect(fetchPublicGames('lichess', 'Unknown', '', '', missingUser, undefined, 'rapid')).resolves.toEqual({ games: [], archives: [] });
    await expect(fetchPublicGames('chess.com', 'Unknown', '', '', missingUser, undefined, 'rapid')).resolves.toEqual({ games: [], archives: [] });
    const missingMonth = vi.fn<typeof fetch>().mockResolvedValueOnce(new Response(JSON.stringify({ archives: ['https://api.chess.com/pub/player/player/games/2026/11'] }))).mockResolvedValueOnce(new Response('', { status: 404 }));
    await expect(fetchPublicGames('chess.com', 'Player', '', '', missingMonth)).rejects.toThrow('404');
    await expect(fetchPublicGames('chess.com', 'Player', '', '', vi.fn<typeof fetch>().mockResolvedValue(new Response('')))).rejects.toThrow();
  });
  it('preserves provider identity and rejects untrusted input', () => {
    const games = normalizeLichess('[Site "https://lichess.org/game/AbCd1234"]\n1.e4 *');
    expect(games[0]).toMatchObject({ provider: 'lichess', originalId: 'AbCd1234' });
    expect(usernameInput(' club_player ')).toBe('club_player');
    expect(() => usernameInput('../private')).toThrow();
  });
  it('follows only the selected user archive, skipping unsupported variants', async () => {
    const fetcher = vi.fn<typeof fetch>().mockResolvedValueOnce(new Response(JSON.stringify({ archives: ['https://api.chess.com/pub/player/player/games/2026/10'] })))
      .mockResolvedValueOnce(new Response(JSON.stringify({ games: [{ rules: 'chess', url: 'https://www.chess.com/game/live/123', pgn: '1.e4 e5 *' }, { rules: 'chess960' }] })));
    const result = await fetchPublicGames('chess.com', 'Player', '', '', fetcher);
    expect(result.games).toHaveLength(1); expect(result.games[0].originalId).toBe('https://www.chess.com/game/live/123');
    expect(fetcher.mock.calls[0][1]?.credentials).toBe('omit');
  });
  it('distinguishes unavailable/rate-limited explorers from zero samples', async () => {
    await expect(fetchOpenings(INITIAL_FEN, '1400,1600', 'rapid,classical', vi.fn().mockResolvedValue(new Response('', { status: 401 })))).rejects.toThrow('401');
    await expect(fetchPublicGames('lichess', 'Player', '', '', vi.fn().mockResolvedValue(new Response('', { status: 429 })))).rejects.toThrow('rate limit');
    expect(openingSample({ white: 0, draws: 0, black: 0, moves: [] }, INITIAL_FEN, '1400', 'rapid').total).toBe(0);
  });
  it('reads anonymous cloud evaluations from White\'s point of view and treats a missing one as empty', async () => {
    const fetcher = vi.fn<typeof fetch>().mockResolvedValue(new Response(JSON.stringify({ depth: 40, pvs: [{ moves: 'e2e4 e7e5', cp: 18 }, { moves: 'f2f3 e7e5', mate: -3 }, { moves: 'bad', cp: 1 }, { moves: 'd2d4 d7d5' }] })));
    expect(await fetchCloudEvaluation(INITIAL_FEN, fetcher)).toEqual([
      { uci: 'e2e4', score: { kind: 'cp', value: 18, perspective: 'white' } },
      { uci: 'f2f3', score: { kind: 'mate', value: -3, perspective: 'white', winner: 'black' } },
    ]);
    const url = new URL(String(fetcher.mock.calls[0][0]));
    expect(url.origin + url.pathname).toBe('https://lichess.org/api/cloud-eval');
    expect(url.searchParams.get('multiPv')).toBe('5');
    expect(fetcher.mock.calls[0][1]).toMatchObject({ credentials: 'omit' });
    expect(fetcher.mock.calls[0][1]?.headers).toBeUndefined();
    expect(await fetchCloudEvaluation(INITIAL_FEN, vi.fn<typeof fetch>().mockResolvedValue(new Response('', { status: 404 })))).toEqual([]);
    await expect(fetchCloudEvaluation(INITIAL_FEN, vi.fn<typeof fetch>().mockResolvedValue(new Response('', { status: 429 })))).rejects.toThrow('429');
  });
  it('confines an opening token to a non-redirecting, uncached explorer request', async () => {
    const token = 'lip_fixture_secret';
    const fetcher = vi.fn<typeof fetch>().mockImplementation(async () => new Response(JSON.stringify({ white: 0, draws: 0, black: 0, moves: [] })));
    await fetchOpenings(INITIAL_FEN, '1400', 'rapid', fetcher, undefined, ` ${token} `);
    expect(new URL(String(fetcher.mock.calls[0][0])).origin).toBe('https://explorer.lichess.ovh');
    expect(String(fetcher.mock.calls[0][0])).not.toContain(token);
    expect(fetcher.mock.calls[0][1]).toMatchObject({ headers: { Authorization: `Bearer ${token}` }, credentials: 'omit', redirect: 'error', cache: 'no-store' });
    fetcher.mockClear();
    await fetchOpenings(INITIAL_FEN, '1400', 'rapid', fetcher);
    expect(fetcher.mock.calls[0][1]?.headers).toBeUndefined();
  });
  it('rejects malformed tokens before sending and never exposes transport errors or response bodies', async () => {
    const fetcher = vi.fn<typeof fetch>();
    await expect(fetchOpenings(INITIAL_FEN, '1400', 'rapid', fetcher, undefined, 'bad\r\nheader')).rejects.toThrow('valid Lichess token');
    expect(fetcher).not.toHaveBeenCalled();
    fetcher.mockRejectedValue(new Error('lip_fixture_secret'));
    await expect(fetchOpenings(INITIAL_FEN, '1400', 'rapid', fetcher, undefined, 'lip_fixture_secret')).rejects.toMatchObject({ kind: 'network', message: 'Lichess network unavailable. Check your connection and retry.' });
    fetcher.mockResolvedValue(new Response('lip_fixture_secret', { status: 403 }));
    await expect(fetchOpenings(INITIAL_FEN, '1400', 'rapid', fetcher)).rejects.toMatchObject({ kind: 'authentication' });
    fetcher.mockResolvedValue(new Response('lip_fixture_secret'));
    await expect(fetchOpenings(INITIAL_FEN, '1400', 'rapid', fetcher)).rejects.toMatchObject({ kind: 'provider', message: 'Lichess returned invalid opening statistics.' });
    fetcher.mockResolvedValue(new Response('', { status: 429 }));
    await expect(fetchOpenings(INITIAL_FEN, '1400', 'rapid', fetcher)).rejects.toMatchObject({ kind: 'rate-limit' });
  });
  it('checks legal move counts and computes totals without relabelling online ratings', () => {
    const result = openingSample({ white: 10, draws: 5, black: 5, moves: [{ uci: 'e2e4', white: 6, draws: 3, black: 1 }] }, INITIAL_FEN, '1400', 'rapid');
    expect(result.moves[0]).toMatchObject({ san: 'e4', total: 10 }); expect(result.total).toBe(20);
    expect(result.ratingSystem).toContain('not FIDE');
    expect(() => openingSample({ white: 1, draws: 0, black: 0, moves: [{ uci: 'a1a8', white: 1, draws: 0, black: 0 }] }, INITIAL_FEN, '1400', 'rapid')).toThrow();
  });
  it('preserves independent current/candidate opening names and never invents missing metadata', () => {
    const result = openingSample({ white: 10, draws: 5, black: 5, opening: { eco: 'A00', name: ' Starting Position ' }, moves: [
      { uci: 'e2e4', white: 6, draws: 3, black: 1, opening: { eco: 'B00', name: "King's Pawn Game" } },
      { uci: 'd2d4', white: 2, draws: 1, black: 1, opening: null },
      { uci: 'g1f3', white: 1, draws: 1, black: 1, opening: { eco: 'bad', name: 'Zukertort Opening' } },
      { uci: 'c2c4', white: 1, draws: 0, black: 1, opening: { eco: 'A10', name: 'bad\nname' } },
    ] }, INITIAL_FEN, '1400', 'rapid');
    expect(result.opening).toEqual({ eco: 'A00', name: 'Starting Position' });
    expect(result.moves[0].opening).toEqual({ eco: 'B00', name: "King's Pawn Game" });
    expect(result.moves[1].opening).toBeUndefined();
    expect(result.moves[2].opening).toEqual({ eco: undefined, name: 'Zukertort Opening' });
    expect(result.moves[3].opening).toBeUndefined();
    expect(openingSample({ white: 0, draws: 0, black: 0, moves: [] }, INITIAL_FEN, '1400', 'rapid').opening).toBeUndefined();
  });
});