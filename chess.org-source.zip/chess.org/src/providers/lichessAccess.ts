import { openingToken } from './chessServices';

export const LICHESS_ACCESS_KEY = 'chess.org:lichess-access';
export type AccessStatus = 'Not checked' | 'Accepted' | 'Authentication refused' | 'Rate limited' | 'Network unavailable' | 'Provider unavailable';
export interface AccessSnapshot { retention: 'session' | 'device'; status: AccessStatus }
type AccessStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;

function browserStorage(): AccessStorage | undefined {
  try { return globalThis.localStorage; } catch { return undefined; }
}

export function createLichessAccess(storage: AccessStorage | undefined = browserStorage()) {
  let token: string | undefined;
  let snapshot: AccessSnapshot | undefined;
  let generation = 0;
  const listeners = new Set<() => void>();
  try {
    const remembered = storage?.getItem(LICHESS_ACCESS_KEY);
    if (remembered) { token = openingToken(remembered); snapshot = { retention: 'device', status: 'Not checked' }; }
  } catch { token = undefined; }
  function notify() { for (const listener of listeners) listener(); }
  return {
    getToken: () => token,
    getSnapshot: () => snapshot,
    subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; },
    beginValidation() { return ++generation; },
    cancelValidation() { generation++; },
    configure(value: string, remember: boolean, expectedGeneration: number): boolean {
      if (generation !== expectedGeneration) return false;
      const next = openingToken(value);
      try {
        if (remember) {
          if (!storage) throw new Error();
          storage.setItem(LICHESS_ACCESS_KEY, next);
        } else storage?.removeItem(LICHESS_ACCESS_KEY);
      } catch { throw new Error('Device storage unavailable. Existing access is unchanged.'); }
      token = next; snapshot = { retention: remember ? 'device' : 'session', status: 'Accepted' };
      notify(); return true;
    },
    recordStatus(expectedToken: string | undefined, status: AccessStatus) {
      if (!token || token !== expectedToken || !snapshot) return;
      snapshot = { ...snapshot, status }; notify();
    },
    remove() {
      generation++; token = undefined; snapshot = undefined; notify();
      try { storage?.removeItem(LICHESS_ACCESS_KEY); }
      catch { throw new Error('Active access removed, but remembered access could not be cleared. Retry removal when device storage is available.'); }
    },
  };
}

export const lichessAccess = createLichessAccess();