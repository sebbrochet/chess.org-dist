import { createElement, type CSSProperties } from 'react';
import { BOARD_THEMES, PIECE_STYLES, type Appearance } from '../utils/appearance';

export function AppearancePanel({ value, onChange }: { value: Appearance; onChange(value: Appearance): void }) {
  return <>
    <fieldset className="appearance-field"><legend>Board theme</legend><div className="appearance-options">{BOARD_THEMES.map(theme =>
      <button key={theme.id} type="button" className="appearance-choice" aria-label={`${theme.label} board`} aria-pressed={value.board === theme.id} title={theme.label} onClick={() => onChange({ ...value, board: theme.id })}>
        <span className="board-swatch" style={{ '--cp-board-light': theme.light, '--cp-board-dark': theme.dark } as CSSProperties} aria-hidden="true" /><span>{theme.label}</span>
      </button>)}</div></fieldset>
    <fieldset className="appearance-field"><legend>Piece style</legend><div className="appearance-options">{PIECE_STYLES.map(style =>
      <button key={style.id} type="button" className="appearance-choice" aria-label={`${style.label} pieces`} aria-pressed={value.pieces === style.id} title={style.label} onClick={() => onChange({ ...value, pieces: style.id })}>
        {style.id === 'cburnett' ? <span className="cg-wrap appearance-preview" aria-hidden="true">{createElement('piece', { className: 'white knight' })}</span> : <img className={`appearance-preview ${style.id === 'mono' ? 'mono-preview' : ''}`} src={`/pieces/${style.id}/${style.id === 'mono' ? 'N' : 'wN'}.svg`} alt="" />}<span>{style.label}</span>
      </button>)}</div></fieldset>
  </>;
}