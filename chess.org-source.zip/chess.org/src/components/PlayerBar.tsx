import type { ReactNode } from 'react';
import type { GameResult } from '../chess/pgn';

type Side = 'white' | 'black';
const known = (value: string | undefined) => { const text = value?.trim(); return text && !/^[?.\s-]*$/.test(text) ? text : undefined; };

export function sideScore(result: GameResult, side: Side): string | undefined {
  if (result === '1/2-1/2') return '½';
  if (result === '1-0') return side === 'white' ? '1' : '0';
  if (result === '0-1') return side === 'white' ? '0' : '1';
}

export function PlayerBar({ headers, side, result, children }: { headers: Readonly<Record<string, string>>; side: Side; result: GameResult; children?: ReactNode }) {
  const prefix = side === 'white' ? 'White' : 'Black';
  const name = known(headers[prefix]) ?? prefix;
  const team = known(headers[`${prefix}Team`]);
  const title = known(headers[`${prefix}Title`]);
  const elo = known(headers[`${prefix}Elo`]);
  const score = sideScore(result, side);
  return <div className="player-line player-bar" data-side={side} aria-label={[prefix, score && `score ${score}`, team, title, name, elo && `rating ${elo}`].filter(Boolean).join(', ')}>
    {score && <span className="player-score" data-score={score}>{score}</span>}
    {team && <span className="player-team">{team}</span>}
    {title && <span className="player-title">{title}</span>}
    <strong>{name}</strong>
    {elo && <span className="player-elo">{elo}</span>}
    {children && <span className="player-extra">{children}</span>}
  </div>;
}

export function EventLine({ headers }: { headers: Readonly<Record<string, string>> }) {
  const date = known(headers.Date)?.split('.').filter(part => !/^\?+$/.test(part)).join('.');
  const parts = [known(headers.Event), known(headers.Site), date && known(date)].filter(Boolean);
  return parts.length ? <p className="event-line" aria-label="Event">{parts.join(' · ')}</p> : null;
}
