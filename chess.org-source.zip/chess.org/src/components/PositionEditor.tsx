import { createElement, useEffect, useId, useRef, useState } from 'react';
import { Chessground } from 'chessground';
import type { Api } from 'chessground/api';
import { makeBoardFen } from 'chessops/fen';
import type { Color, Piece, Role } from 'chessops/types';
import { parseSquare } from 'chessops/util';
import { Eraser, Move } from 'lucide-react';
import { CASTLING_ROOKS, castlingAllowed, clearedSetup, hasCastling, movePiece, placePiece, readSetup, setCastling, setTurn, setupFen, setupProblem, STARTING_SETUP_FEN } from '../chess/positionSetup';

const ROLES: Role[] = ['king', 'queen', 'rook', 'bishop', 'knight', 'pawn'];
const EMPTY_FEN = '8/8/8/8/8/8/8/8 w - - 0 1';
type Tool = Piece | 'eraser' | 'move';

export function PositionEditor({ fen, onChange, fenLabel = 'FEN', fenField = true, disabled = false }: { fen: string; onChange: (fen: string) => void; fenLabel?: string; fenField?: boolean; disabled?: boolean }) {
  const lastReadable = useRef(readSetup(fen) ?? readSetup(EMPTY_FEN)!);
  const parsed = readSetup(fen);
  if (parsed) lastReadable.current = parsed;
  const setup = lastReadable.current;
  const [tool, setTool] = useState<Tool>('move');
  const turnName = useId(); const fenId = useId();
  const latest = useRef({ setup, tool, onChange, disabled }); latest.current = { setup, tool, onChange, disabled };
  const element = useRef<HTMLDivElement>(null); const ground = useRef<Api>();
  const placement = makeBoardFen(setup.board);
  useEffect(() => {
    ground.current = Chessground(element.current!, {
      fen: placement, coordinates: false, autoCastle: false, animation: { enabled: false }, highlight: { lastMove: false, check: false },
      movable: { free: true, color: 'both', dests: new Map() }, draggable: { enabled: true }, selectable: { enabled: true }, drawable: { enabled: false },
      events: {
        select: key => {
          const { setup: current, tool: active, onChange: emit, disabled: locked } = latest.current;
          if (locked || active === 'move') return;
          emit(setupFen(placePiece(current, parseSquare(key)!, active === 'eraser' ? undefined : active)));
        },
        move: (from, to) => {
          const { setup: current, onChange: emit, disabled: locked } = latest.current;
          if (!locked) emit(setupFen(movePiece(current, parseSquare(from)!, parseSquare(to)!)));
        },
      },
    });
    return () => { ground.current?.destroy(); ground.current = undefined; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const moving = tool === 'move' && !disabled;
  useEffect(() => {
    ground.current?.selectSquare(null);
    ground.current?.set({ movable: { free: moving, color: moving ? 'both' : undefined }, draggable: { enabled: moving }, selectable: { enabled: moving } });
  }, [moving]);
  useEffect(() => { ground.current?.set({ fen: placement }); }, [placement]);
  const problem = parsed ? setupProblem(parsed) : 'This FEN cannot be read; the editor shows the last readable position.';
  const toolButton = (item: Tool, label: string) => {
    const active = tool === item || (typeof tool === 'object' && typeof item === 'object' && tool.role === item.role && tool.color === item.color);
    return <button key={label} type="button" className="palette-button" aria-label={label} title={label} aria-pressed={active} disabled={disabled} onClick={() => setTool(item)}>
      {item === 'eraser' ? <Eraser size={18} /> : item === 'move' ? <Move size={18} /> : <span className="captured-pieces cg-wrap palette-piece">{createElement('piece', { className: `${item.role} ${item.color}` })}</span>}
    </button>;
  };
  return <div className="position-editor">
    <div className="position-editor-board board-frame mini-board-frame" aria-label={`Position editor board. ${problem ?? 'Legal position.'}`} data-fen={setupFen(setup)}><div className="cg-wrap" ref={element} /></div>
    <div className="position-editor-controls">
      <div className="palette" role="group" aria-label="Piece to place">
        {(['white', 'black'] as Color[]).map(color => <div key={color} className="palette-row">{ROLES.map(role => toolButton({ role, color }, `${color} ${role}`))}</div>)}
        <div className="palette-row">{toolButton('move', 'Move pieces')}{toolButton('eraser', 'Eraser')}</div>
      </div>
      <fieldset className="position-editor-options" disabled={disabled}><legend>Side to move</legend>
        {(['white', 'black'] as Color[]).map(color => <label key={color} className="check-field"><input type="radio" name={turnName} checked={setup.turn === color} onChange={() => onChange(setupFen(setTurn(setup, color)))} />{color === 'white' ? 'White' : 'Black'}</label>)}
      </fieldset>
      <fieldset className="position-editor-options" disabled={disabled}><legend>Castling</legend>
        {CASTLING_ROOKS.map(({ rook, label }) => <label key={rook} className="check-field"><input type="checkbox" checked={hasCastling(setup, rook)} disabled={!castlingAllowed(setup, rook)} onChange={event => onChange(setupFen(setCastling(setup, rook, event.target.checked)))} />{label}</label>)}
      </fieldset>
      <div className="play-actions">
        <button type="button" disabled={disabled} onClick={() => onChange(STARTING_SETUP_FEN)}>Starting position</button>
        <button type="button" disabled={disabled} onClick={() => onChange(setupFen(clearedSetup(setup)))}>Clear board</button>
      </div>
    </div>
    {fenField && <div className="field position-editor-fen"><label htmlFor={fenId}>{fenLabel}</label><textarea id={fenId} rows={2} value={fen} spellCheck={false} disabled={disabled} onChange={event => onChange(event.target.value)} /></div>}
    <p className={problem ? 'error' : 'position-editor-valid'} aria-live="polite" aria-label="Position check">{problem ?? 'Legal position.'}</p>
  </div>;
}
