// @vitest-environment jsdom
import React from 'react';
import { cleanup, render } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import type { Config } from 'chessground/config';
import { parseGames } from '../chess/pgn';
import { Board } from './Board';

const ground = vi.hoisted(() => ({ set: vi.fn(), destroy: vi.fn(), cancelMove: vi.fn(), create: vi.fn() }));
const sound = vi.hoisted(() => ({ play: vi.fn() }));
vi.mock('../utils/moveSound', async importOriginal => ({ ...await importOriginal<typeof import('../utils/moveSound')>(), playMoveSound: sound.play }));
vi.mock('chessground', () => ({ Chessground: ground.create }));
beforeEach(() => {
  vi.clearAllMocks();
  ground.create.mockReturnValue({ set: ground.set, destroy: ground.destroy, cancelMove: ground.cancelMove });
});
afterEach(cleanup);
it('displays and clears supplied arrows and marked squares without changing board ownership', () => {
  const view = render(<Board fen={INITIAL_FEN} orientation="white" markings={[{ from: 12, to: 28, color: 'green' }, { from: 27, to: 27, color: 'red' }]} />);
  expect(ground.set).toHaveBeenCalledWith({ drawable: { enabled: false, autoShapes: [{ orig: 'e2', dest: 'e4', brush: 'green' }, { orig: 'd4', brush: 'red' }] } });
  ground.set.mockClear(); view.rerender(<Board fen={INITIAL_FEN} orientation="black" />);
  expect(ground.set).toHaveBeenCalledWith({ drawable: { enabled: false, autoShapes: [] } });
  expect(ground.create).toHaveBeenCalledOnce(); expect(sound.play).not.toHaveBeenCalled();
});

it('anchors a move glyph to the destination through flips and clears it without changing the board instance or sound', () => {
  ground.create.mockImplementationOnce((element: HTMLElement) => {
    const surface = document.createElement('cg-container'); element.append(surface);
    vi.spyOn(surface, 'getBoundingClientRect').mockReturnValue({ width: 320, height: 320 } as DOMRect);
    return { set: ground.set, destroy: ground.destroy, cancelMove: ground.cancelMove };
  });
  const fen = parseGames('1.e4 *')[0].positions[1];
  const view = render(<Board fen={fen} orientation="white" lastMove="e2e4" moveGlyph={{ text: '??', label: 'Blunder' }} />);
  const badge = () => view.container.querySelector<HTMLElement>('.board-move-glyph');
  expect(badge()?.dataset.square).toBe('e4');
  expect(view.container.querySelector<HTMLElement>('.board-glyph-layer')?.style.width).toBe('320px');
  expect(view.container.querySelector<HTMLElement>('.board-glyph-layer')?.style.height).toBe('320px');
  expect(badge()?.style.left).toBe('calc(62.5% - 2px)'); expect(badge()?.style.top).toBe('calc(50% + 2px)');
  expect(view.container.querySelector('[role="img"]')?.getAttribute('aria-label')).toContain('Blunder ?? on e4');
  view.rerender(<Board fen={fen} orientation="black" lastMove="e2e4" moveGlyph={{ text: '??', label: 'Blunder' }} />);
  expect(badge()?.dataset.square).toBe('e4');
  expect(badge()?.style.left).toBe('calc(50% - 2px)'); expect(badge()?.style.top).toBe('calc(37.5% + 2px)');
  view.rerender(<Board fen={fen} orientation="black" lastMove="e2e4" />);
  expect(badge()).toBeNull();
  view.rerender(<Board fen={fen} orientation="black" moveGlyph={{ text: '?', label: 'Mistake' }} />);
  expect(badge()).toBeNull();
  expect(ground.create).toHaveBeenCalledOnce(); expect(sound.play).not.toHaveBeenCalled();
});

it('keeps the same instance while turns and save states toggle input', () => {
  const positions = parseGames('1.e4 e5 2.Nf3 *')[0].positions;
  const onMove = vi.fn();
  const view = render(<Board fen={positions[1]} orientation="white" onMove={onMove} />);
  expect(ground.create).toHaveBeenCalledOnce();
  expect(ground.create.mock.calls[0][1]).toMatchObject({ fen: positions[1], orientation: 'white', viewOnly: false });
  view.rerender(<Board fen={positions[1]} orientation="white" />);
  expect(ground.set).toHaveBeenLastCalledWith(expect.objectContaining({ draggable: { enabled: false }, selectable: { enabled: false }, movable: expect.objectContaining({ color: undefined, dests: new Map() }) }));
  view.rerender(<Board fen={positions[2]} orientation="white" onMove={onMove} />);
  expect(ground.set).toHaveBeenLastCalledWith(expect.objectContaining({ fen: positions[2], draggable: { enabled: true }, movable: expect.objectContaining({ color: 'white' }) }));
  view.rerender(<Board fen={positions[3]} orientation="black" />);
  expect(ground.create).toHaveBeenCalledOnce();
  expect(ground.destroy).not.toHaveBeenCalled();
  view.unmount();
  expect(ground.destroy).toHaveBeenCalledOnce();
});

it('restores the authoritative position without animating a temporary user move', () => {
  const first = vi.fn(); const latest = vi.fn();
  const view = render(<Board fen={INITIAL_FEN} orientation="white" onMove={first} />);
  const config = ground.set.mock.calls.at(-1)![0] as Config;
  const after = config.movable!.events!.after!;
  view.rerender(<Board fen={INITIAL_FEN} orientation="white" onMove={latest} />);
  ground.set.mockClear();
  after('e2', 'e4', { premove: false });
  expect(ground.set.mock.calls).toEqual([
    [{ fen: INITIAL_FEN, lastMove: undefined, animation: { enabled: false } }],
    [{ animation: { enabled: true } }],
  ]);
  expect(latest).toHaveBeenCalledWith('e2e4');
  expect(first).not.toHaveBeenCalled();
});

it('leaves a submitted move visible when its owner defers rollback', () => {
  const onMove = vi.fn();
  const view = render(<Board fen={INITIAL_FEN} orientation="white" onMove={onMove} deferMoveReset />);
  const config = ground.set.mock.calls.at(-1)![0] as Config;
  ground.set.mockClear();
  config.movable!.events!.after!('e2', 'e4', { premove: false });
  expect(onMove).toHaveBeenCalledWith('e2e4');
  expect(ground.set).not.toHaveBeenCalled();
  view.rerender(<Board fen={parseGames('1.e4 *')[0].positions[1]} orientation="white" deferMoveReset />);
  expect(ground.set).toHaveBeenLastCalledWith(expect.objectContaining({ fen: parseGames('1.e4 *')[0].positions[1], movable: expect.objectContaining({ color: undefined }) }));
  expect(ground.create).toHaveBeenCalledOnce();
});

it('updates and clears last-move highlights without recreating the board or resetting unchanged input', () => {
  const onMove = vi.fn();
  const positions = parseGames('1.e4 e5 *')[0].positions;
  const view = render(<Board fen={positions[1]} orientation="white" onMove={onMove} lastMove="e2e4" />);
  expect(ground.set).toHaveBeenLastCalledWith(expect.objectContaining({ lastMove: ['e2', 'e4'], movable: expect.objectContaining({ showDests: true }) }));
  expect(ground.create.mock.calls[0][1]).toMatchObject({ highlight: { lastMove: true, check: true } });
  const updates = ground.set.mock.calls.length;
  view.rerender(<Board fen={positions[1]} orientation="white" onMove={onMove} lastMove="e2e4" />);
  expect(ground.set).toHaveBeenCalledTimes(updates);
  view.rerender(<Board fen={positions[2]} orientation="black" lastMove="e7e5" />);
  expect(ground.set).toHaveBeenLastCalledWith(expect.objectContaining({ lastMove: ['e7', 'e5'], movable: expect.objectContaining({ showDests: false }) }));
  view.rerender(<Board fen={INITIAL_FEN} orientation="black" />);
  expect(ground.set).toHaveBeenLastCalledWith(expect.objectContaining({ lastMove: undefined }));
  expect(ground.create).toHaveBeenCalledOnce();
});

it('sounds a displayed move once but not initial loading, flipping, input changes or rollback', () => {
  const positions = parseGames('1.e4 e5 *')[0].positions;
  const view = render(<Board fen={positions[0]} orientation="white" />);
  expect(sound.play).not.toHaveBeenCalled();
  view.rerender(<Board fen={positions[1]} orientation="white" lastMove="e2e4" />);
  expect(sound.play).toHaveBeenCalledExactlyOnceWith('e4');
  view.rerender(<Board fen={positions[1]} orientation="black" lastMove="e2e4" onMove={vi.fn()} />);
  expect(sound.play).toHaveBeenCalledTimes(1);
  view.rerender(<Board fen={positions[0]} orientation="black" />);
  expect(sound.play).toHaveBeenCalledTimes(1);
});

it('sounds a move reached by a jump only when its start position is stated', () => {
  const positions = parseGames('1.e4 e5 2.Nf3 Nc6 *')[0].positions;
  const view = render(<Board fen={positions[1]} orientation="black" lastMove="e2e4" />);
  view.rerender(<Board fen={positions[3]} orientation="black" lastMove="g1f3" />);
  expect(sound.play).not.toHaveBeenCalled();
  view.rerender(<Board fen={positions[1]} orientation="black" lastMove="e2e4" />);
  view.rerender(<Board fen={positions[3]} orientation="black" lastMove="g1f3" lastMoveFrom={positions[2]} />);
  expect(sound.play).toHaveBeenCalledExactlyOnceWith('Nf3');
  view.rerender(<Board fen={positions[3]} orientation="black" lastMove="g1f3" lastMoveFrom={positions[2]} onMove={vi.fn()} />);
  expect(sound.play).toHaveBeenCalledTimes(1);
});

it('shows and clears a read-only preview arrow without changing position, instance or sound', () => {
  const view = render(<Board fen={INITIAL_FEN} orientation="white" />);
  ground.set.mockClear();
  view.rerender(<Board fen={INITIAL_FEN} orientation="white" previewMove="e2e4" />);
  expect(ground.set).toHaveBeenCalledExactlyOnceWith({ drawable: { enabled: false, autoShapes: [{ orig: 'e2', dest: 'e4', brush: 'blue' }] } });
  expect(ground.create.mock.calls[0][1].drawable).toMatchObject({ enabled: false, visible: true });
  expect(ground.create).toHaveBeenCalledOnce();
  expect(sound.play).not.toHaveBeenCalled();
  ground.set.mockClear();
  view.rerender(<Board fen={INITIAL_FEN} orientation="white" />);
  expect(ground.set).toHaveBeenCalledExactlyOnceWith({ drawable: { enabled: false, autoShapes: [] } });
  expect(sound.play).not.toHaveBeenCalled();
});