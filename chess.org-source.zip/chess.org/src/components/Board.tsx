import { useEffect, useRef } from 'react';
import { Chessground } from 'chessground';
import type { Api } from 'chessground/api';
import type { Key } from 'chessground/types';
import type { CommentShape } from 'chessops/pgn';
import { makeSquare, parseSquare } from 'chessops/util';
import { chessgroundDests } from 'chessops/compat';
import { positionFromFen } from '../chess/pgn';
import { playMoveSound, soundedMove } from '../utils/moveSound';
import 'chessground/assets/chessground.base.css';
import 'chessground/assets/chessground.cburnett.css';

const moveSquares = (move?: string): Key[] | undefined => move && /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move) ? [move.slice(0, 2) as Key, move.slice(2, 4) as Key] : undefined;
const toShapes = (shapes: readonly CommentShape[]) => shapes.map(shape => ({ orig: makeSquare(shape.from) as Key, ...(shape.to !== shape.from ? { dest: makeSquare(shape.to) as Key } : {}), brush: shape.color }));

export function Board({ fen, orientation, onMove, deferMoveReset = false, lastMove, lastMoveFrom, previewMove, moveGlyph, markings, drawing, onSelect }: { fen: string; orientation: 'white' | 'black'; onMove?: (uci: string) => void; deferMoveReset?: boolean; lastMove?: string; lastMoveFrom?: string; previewMove?: string; moveGlyph?: { text: string; label: string }; markings?: readonly CommentShape[]; drawing?: { shapes: readonly CommentShape[]; onChange: (shapes: CommentShape[]) => void }; onSelect?: (square: string) => void }) {
  const element = useRef<HTMLDivElement>(null);
  const glyphLayer = useRef<HTMLDivElement>(null);
  const board = useRef<Api>();
  const callback = useRef(onMove);
  const positionRef = useRef({ fen, orientation });
  const lastMoveRef = useRef(lastMove);
  const previousSoundFen = useRef(fen);
  callback.current = onMove;
  const drawingRef = useRef(drawing); drawingRef.current = drawing;
  const selectRef = useRef(onSelect); selectRef.current = onSelect;
  lastMoveRef.current = lastMove;
  positionRef.current = { fen, orientation };
  const interactive = !!onMove;
  useEffect(() => {
    if (!element.current) return;
    board.current = Chessground(element.current, {
      ...positionRef.current,
      viewOnly: false, coordinates: true, animation: { enabled: true, duration: 160 },
      highlight: { lastMove: true, check: true }, lastMove: moveSquares(lastMoveRef.current),
      movable: { free: false, color: undefined, dests: new Map() },
      premovable: { enabled: false }, draggable: { enabled: false }, selectable: { enabled: false },
      drawable: { enabled: false, visible: true, eraseOnClick: false, onChange: shapes => drawingRef.current?.onChange(shapes.flatMap(shape => {
        const from = parseSquare(shape.orig), to = shape.dest ? parseSquare(shape.dest) : from;
        return from !== undefined && to !== undefined && ['green', 'red', 'yellow', 'blue'].includes(shape.brush ?? '') ? [{ color: shape.brush as CommentShape['color'], from, to }] : [];
      })) },
      events: { select: key => selectRef.current?.(key) },
    });
    return () => { board.current?.destroy(); board.current = undefined; };
  }, []);
  const drawingEnabled = !!drawing;
  useEffect(() => {
    const squares = moveSquares(previewMove);
    const autoShapes = toShapes(markings ?? []);
    board.current?.set({ drawable: { enabled: drawingEnabled, autoShapes: [...autoShapes, ...(squares ? [{ orig: squares[0], dest: squares[1], brush: 'blue' }] : [])] } });
  }, [previewMove, markings, drawingEnabled]);
  useEffect(() => {
    const position = positionFromFen(fen);
    if (!interactive) board.current?.cancelMove();
    board.current?.set({ fen, orientation, lastMove: moveSquares(lastMove), turnColor: position.turn, check: position.isCheck(),
      draggable: { enabled: interactive }, selectable: { enabled: interactive },
      movable: { free: false, color: interactive ? position.turn : undefined, showDests: interactive, dests: interactive ? chessgroundDests(position) : new Map(),
        events: { after: (from, to) => {
          if (!deferMoveReset) {
            board.current?.set({ fen: positionRef.current.fen, lastMove: moveSquares(lastMoveRef.current), animation: { enabled: false } });
            board.current?.set({ animation: { enabled: true } });
          }
          callback.current?.(`${from}${to}`);
        } } },
    });
  }, [fen, orientation, interactive, deferMoveReset, lastMove]);
  useEffect(() => {
    // Chessground clears user shapes whenever a fen is set, so this runs after the position effect.
    if (!drawingEnabled) return;
    board.current?.set({ drawable: { enabled: true } });
    board.current?.setShapes(toShapes(drawing?.shapes ?? []));
  }, [drawingEnabled, drawing?.shapes, fen]);
  useEffect(() => {
    // lastMoveFrom lets a jump to a new position still sound the move that reached it.
    const san = previousSoundFen.current === fen ? undefined : soundedMove(lastMoveFrom ?? previousSoundFen.current, fen, lastMove);
    previousSoundFen.current = fen;
    if (san) playMoveSound(san);
  }, [fen, lastMove, lastMoveFrom]);
  const destination = moveSquares(lastMove)?.[1];
  useEffect(() => {
    const layer = glyphLayer.current;
    const surface = element.current?.querySelector('cg-container');
    if (!layer || !surface) return;
    const sync = () => {
      const bounds = surface.getBoundingClientRect();
      layer.style.width = `${bounds.width}px`; layer.style.height = `${bounds.height}px`;
    };
    sync();
    if (typeof ResizeObserver === 'undefined') return;
    const observer = new ResizeObserver(sync); observer.observe(surface);
    return () => observer.disconnect();
  }, [destination, moveGlyph?.text, orientation]);
  const file = destination ? destination.charCodeAt(0) - 97 : 0;
  const rank = destination ? Number(destination[1]) - 1 : 0;
  const glyphPosition = { left: `calc(${((orientation === 'white' ? file : 7 - file) + 1) * 12.5}% - 2px)`, top: `calc(${(orientation === 'white' ? 7 - rank : rank) * 12.5}% + 2px)` };
  return <div className="board-frame" role="img" aria-label={`Chessboard, ${orientation} at bottom. Position: ${fen}${moveGlyph && destination ? `. ${moveGlyph.label} ${moveGlyph.text} on ${destination}` : ''}`} data-fen={fen}>
    <div ref={element} className="cg-wrap" aria-hidden="true" />
    {moveGlyph && destination && <div ref={glyphLayer} className="board-glyph-layer" aria-hidden="true"><span className="board-move-glyph" data-glyph={moveGlyph.text} data-square={destination} title={`${moveGlyph.label} ${moveGlyph.text}`} style={glyphPosition}>{moveGlyph.text}</span></div>}
  </div>;
}