import { createContext, useContext, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Chessground } from 'chessground';
import type { Api } from 'chessground/api';
import type { Key } from 'chessground/types';
import { makeSquare, parseUci } from 'chessops/util';
import type { CommentShape } from 'chessops/pgn';
import { Eye, X } from 'lucide-react';

interface Preview { fen: string; move?: string; markings?: readonly CommentShape[]; label: string; anchor: HTMLElement; pinned: boolean }
interface PreviewContext { show(preview: Preview): void; hide(anchor: HTMLElement | null): void; dismiss(): void }
const context = createContext<PreviewContext | undefined>(undefined);

export function previewPlacement(anchor: { left: number; top: number; bottom: number }, size: { width: number; height: number }, viewport: { width: number; height: number }) {
  const gap = 8;
  const top = anchor.bottom + gap + size.height <= viewport.height - gap ? anchor.bottom + gap : anchor.top - size.height - gap;
  return { left: Math.max(gap, Math.min(anchor.left, viewport.width - size.width - gap)), top: Math.max(gap, Math.min(top, viewport.height - size.height - gap)) };
}

function MiniBoard({ fen, orientation, move, markings }: { fen: string; orientation: 'white' | 'black'; move?: string; markings?: readonly CommentShape[] }) {
  const element = useRef<HTMLDivElement>(null); const ground = useRef<Api>();
  const latest = useRef({ fen, orientation }); latest.current = { fen, orientation };
  useEffect(() => {
    ground.current = Chessground(element.current!, { ...latest.current, coordinates: false, viewOnly: true, animation: { enabled: false }, movable: { free: false, color: undefined }, draggable: { enabled: false }, selectable: { enabled: false }, drawable: { enabled: false, visible: true } });
    return () => { ground.current?.destroy(); ground.current = undefined; };
  }, []);
  useEffect(() => { ground.current?.set({ fen, orientation }); }, [fen, orientation]);
  useEffect(() => {
    const parsed = move ? parseUci(move) : undefined;
    const shapes = (markings ?? []).map(shape => ({ orig: makeSquare(shape.from) as Key, ...(shape.from !== shape.to ? { dest: makeSquare(shape.to) as Key } : {}), brush: shape.color }));
    const played = parsed && 'from' in parsed ? [makeSquare(parsed.from) as Key, makeSquare(parsed.to) as Key] : undefined;
    ground.current?.set({ lastMove: played, drawable: { autoShapes: [...shapes, ...(played ? [{ orig: played[0], dest: played[1], brush: 'blue' }] : [])] } });
  }, [move, fen, orientation, markings]);
  return <div className="board-frame mini-board-frame" data-fen={fen} data-orientation={orientation}><div className="cg-wrap" ref={element} /></div>;
}

export function MovePreviewProvider({ children, orientation, resetKey }: { children: ReactNode; orientation: 'white' | 'black'; resetKey?: string }) {
  const [preview, setPreview] = useState<Preview>();
  useEffect(() => { setPreview(undefined); }, [resetKey]);
  const popup = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ left: 8, top: 8 });
  const width = Math.max(1, Math.min(240, window.innerWidth - 16, window.innerHeight - 80));
  useLayoutEffect(() => {
    if (!preview || !popup.current) return;
    const bounds = popup.current.getBoundingClientRect();
    setPosition(previewPlacement(preview.anchor.getBoundingClientRect(), bounds, { width: window.innerWidth, height: window.innerHeight }));
  }, [preview, orientation]);
  useEffect(() => {
    if (!preview) return;
    const clear = () => setPreview(undefined);
    const scroll = (event: Event) => {
      const insidePopup = event.target instanceof Node && popup.current?.contains(event.target);
      if (!insidePopup && !preview.pinned && !preview.anchor.contains(document.activeElement)) clear();
    };
    const key = (event: KeyboardEvent) => { if (event.key === 'Escape') clear(); };
    const outside = (event: PointerEvent) => { if (!preview.anchor.contains(event.target as Node) && !popup.current?.contains(event.target as Node)) clear(); };
    const wheel = (event: WheelEvent) => { if (!(event.target instanceof Node && popup.current?.contains(event.target))) clear(); };
    window.addEventListener('resize', clear); window.addEventListener('scroll', scroll, true);
    window.addEventListener('wheel', wheel, { passive: true });
    document.addEventListener('keydown', key); document.addEventListener('pointerdown', outside);
    return () => { window.removeEventListener('resize', clear); window.removeEventListener('scroll', scroll, true); window.removeEventListener('wheel', wheel); document.removeEventListener('keydown', key); document.removeEventListener('pointerdown', outside); };
  }, [preview]);
  return <context.Provider value={{ show: setPreview, hide: anchor => setPreview(value => value?.anchor === anchor && !value.pinned ? undefined : value), dismiss: () => setPreview(undefined) }}>
    {children}
    {preview && createPortal(<div className="move-miniboard-popup" role="dialog" aria-label={`Position after ${preview.label}`} ref={popup} style={{ ...position, width, maxHeight: Math.max(1, window.innerHeight - 16) }}>
      <header><strong>{preview.label}</strong><button type="button" className="icon" title="Dismiss move preview" aria-label="Dismiss move preview" onClick={() => setPreview(undefined)}><X size={16} /></button></header>
      <MiniBoard fen={preview.fen} orientation={orientation} move={preview.move} markings={preview.markings} />
    </div>, document.body)}
  </context.Provider>;
}

export function PreviewableMove({ children, fen, label, move, markings }: { children: ReactNode; fen: string; label: string; move?: string; markings?: readonly CommentShape[] }) {
  const preview = useContext(context)!; const anchor = useRef<HTMLDivElement>(null);
  const show = (pinned = false) => preview.show({ fen, move, markings, label, anchor: anchor.current!, pinned });
  return <div className="move-preview-item" ref={anchor}
    onClick={event => { if (event.target instanceof Element && event.target.closest('button') === event.currentTarget.firstElementChild) preview.dismiss(); }}
    onPointerEnter={event => { if (event.pointerType !== 'touch') show(); }}
    onPointerLeave={event => { if (!event.currentTarget.contains(document.activeElement)) preview.hide(anchor.current); }}
    onFocus={() => show()}
    onBlur={event => { if (!event.currentTarget.contains(event.relatedTarget as Node | null)) preview.hide(anchor.current); }}>
    {children}<button type="button" className="move-preview-toggle" title={`Preview position after ${label}`} aria-label={`Preview position after ${label}`} onClick={() => show(true)}><Eye size={15} /></button>
  </div>;
}