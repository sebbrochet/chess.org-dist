// @vitest-environment jsdom
import { useState } from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, expect, it } from 'vitest';
import { PositionEditor } from './PositionEditor';

afterEach(cleanup);
function Harness({ initial }: { initial: string }) {
  const [fen, setFen] = useState(initial);
  return <><PositionEditor fen={fen} onChange={setFen} fenLabel="Starting FEN" /><output data-testid="fen">{fen}</output></>;
}
const fen = () => screen.getByTestId('fen').textContent;
const check = () => screen.getByLabelText('Position check').textContent;

it('keeps the FEN field, side to move, castling and presets in step', () => {
  render(<Harness initial="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" />);
  expect(screen.getByRole('button', { name: 'Move pieces' }).getAttribute('aria-pressed')).toBe('true');
  expect(check()).toBe('Legal position.');
  fireEvent.click(screen.getByLabelText('Black'));
  expect(fen()).toBe('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b KQkq - 0 1');
  fireEvent.click(screen.getByLabelText('White O-O'));
  expect(fen()).toBe('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b Qkq - 0 1');
  fireEvent.click(screen.getByRole('button', { name: 'Clear board' }));
  expect(fen()).toBe('8/8/8/8/8/8/8/8 b - - 0 1');
  expect(check()).toBe('The board is empty.');
  expect((screen.getByLabelText('Black O-O-O') as HTMLInputElement).disabled).toBe(true);
  fireEvent.change(screen.getByLabelText('Starting FEN'), { target: { value: 'k7/8/8/8/8/8/8/K7 w - - 0 1' } });
  expect(screen.getByLabelText(/^Position editor board/).getAttribute('data-fen')).toBe('k7/8/8/8/8/8/8/K7 w - - 0 1');
  expect(check()).toBe('Legal position.');
  fireEvent.change(screen.getByLabelText('Starting FEN'), { target: { value: 'k7/8/8' } });
  expect(check()).toContain('cannot be read');
  expect(screen.getByLabelText(/^Position editor board/).getAttribute('data-fen')).toBe('k7/8/8/8/8/8/8/K7 w - - 0 1');
  fireEvent.click(screen.getByRole('button', { name: 'Starting position' }));
  expect(fen()).toBe('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  fireEvent.click(screen.getByRole('button', { name: 'black queen' }));
  expect(screen.getByRole('button', { name: 'black queen' }).getAttribute('aria-pressed')).toBe('true');
  expect(screen.getByRole('button', { name: 'white pawn' }).getAttribute('aria-pressed')).toBe('false');
  expect(screen.getByRole('button', { name: 'Move pieces' }).getAttribute('aria-pressed')).toBe('false');
});
