import { useEffect, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';

export function Modal({ title, children, busy, onClose }: { title: string; children: ReactNode; busy: boolean; onClose(): void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const element = dialog.current!;
    element.showModal();
    return () => element.close();
  }, []);
  return <dialog ref={dialog} aria-labelledby="dialog-title" onCancel={event => {
    event.preventDefault();
    if (!busy) onClose();
  }}>
    <header className="dialog-heading"><h2 id="dialog-title">{title}</h2>
      <button type="button" className="icon" title="Close dialog" aria-label="Close dialog" disabled={busy} onClick={onClose}><X size={20} /></button>
    </header>
    {children}
  </dialog>;
}