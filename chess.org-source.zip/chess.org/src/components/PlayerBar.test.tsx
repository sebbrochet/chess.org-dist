// @vitest-environment jsdom
import { cleanup, render, screen } from '@testing-library/react';
import { afterEach, expect, it } from 'vitest';
import { EventLine, PlayerBar, sideScore } from './PlayerBar';

afterEach(cleanup);
const headers = { White: 'Sébastien Brochet', WhiteElo: '1486', WhiteTeam: 'CEB77', Black: 'Robert Mas', BlackElo: '1399', BlackTitle: 'FM', BlackTeam: 'Thorigny Sur Marne', Event: 'Interclubs', Site: '?', Date: '2026.11.??' };

it('shows result, team, title, name and rating, leaving out unknown values', () => {
  render(<><PlayerBar headers={headers} side="black" result="0-1" /><PlayerBar headers={headers} side="white" result="0-1">extra</PlayerBar></>);
  const [black, white] = Array.from(document.querySelectorAll('.player-bar'));
  expect(black.textContent).toBe('1Thorigny Sur MarneFMRobert Mas1399');
  expect(black.getAttribute('aria-label')).toBe('Black, score 1, Thorigny Sur Marne, FM, Robert Mas, rating 1399');
  expect(white.textContent).toBe('0CEB77Sébastien Brochet1486extra');
  cleanup();
  render(<PlayerBar headers={{ White: '?' }} side="white" result="*" />);
  expect(document.querySelector('.player-bar')!.textContent).toBe('White');
  expect([sideScore('1/2-1/2', 'white'), sideScore('*', 'black'), sideScore('1-0', 'black')]).toEqual(['½', undefined, '0']);
});

it('joins event, site and date and drops unknown parts', () => {
  render(<EventLine headers={headers} />);
  expect(screen.getByLabelText('Event').textContent).toBe('Interclubs · 2026.11');
  cleanup();
  const { container } = render(<EventLine headers={{ Event: '?', Date: '????.??.??' }} />);
  expect(container.textContent).toBe('');
});
