// @vitest-environment jsdom
import React from 'react';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { lastRecordedMove, parseGames } from '../chess/pgn';
import { MovePreviewProvider, PreviewableMove, previewPlacement } from './MovePreview';

afterEach(cleanup);
const after = parseGames('1.e4 *')[0].positions[1];
function view(orientation: 'white' | 'black' = 'white', source = 'one') {
  return <MovePreviewProvider orientation={orientation} key={source}><div data-testid="scroll-panel"><PreviewableMove fen={after} label="1. e4"><button>Replay e4</button></PreviewableMove></div></MovePreviewProvider>;
}

it('previews local after-move positions outside the list and never selects the move', () => {
  const selected = vi.fn();
  render(<MovePreviewProvider orientation="black"><div data-testid="scroll-panel"><PreviewableMove fen={after} label="1. e4"><button onClick={selected}>Replay e4</button></PreviewableMove></div></MovePreviewProvider>);
  fireEvent.pointerEnter(screen.getByRole('button', { name: 'Replay e4' }).parentElement!);
  const popup = screen.getByRole('dialog', { name: 'Position after 1. e4' });
  expect(screen.getByTestId('scroll-panel').contains(popup)).toBe(false);
  expect(popup.querySelector('.mini-board-frame')?.getAttribute('data-fen')).toBe(after);
  expect(popup.querySelector('cg-board')).toBeTruthy();
  expect(popup.querySelector('.orientation-black')).toBeTruthy();
  expect(selected).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('button', { name: 'Dismiss move preview' }));
  expect(screen.queryByRole('dialog')).toBeNull();
  expect(document.querySelector('.move-miniboard-popup')).toBeNull();
});

it('supports focus and pinned touch controls, Escape, source changes and orientation updates', () => {
  const mounted = render(view());
  fireEvent.focus(screen.getByRole('button', { name: 'Replay e4' }));
  expect(screen.getByRole('dialog')).toBeTruthy();
  const mini = screen.getByRole('dialog').querySelector('.mini-board-frame');
  mounted.rerender(view('black'));
  expect(screen.getByRole('dialog').querySelector('.mini-board-frame')).toBe(mini);
  expect(screen.getByRole('dialog').querySelector('.orientation-black')).toBeTruthy();
  fireEvent.keyDown(document, { key: 'Escape' });
  expect(screen.queryByRole('dialog')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after 1. e4' }));
  fireEvent.pointerLeave(screen.getByRole('button', { name: 'Replay e4' }).parentElement!);
  fireEvent.scroll(window);
  expect(screen.getByRole('dialog')).toBeTruthy();
  fireEvent.wheel(document.body);
  expect(screen.queryByRole('dialog')).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after 1. e4' }));
  mounted.rerender(view('black', 'two'));
  expect(screen.queryByRole('dialog')).toBeNull();
  expect(INITIAL_FEN).not.toBe(after);
});

it('clamps popup placement above bottom-edge anchors and inside narrow viewports', () => {
  expect(previewPlacement({ left: 900, top: 650, bottom: 690 }, { width: 240, height: 280 }, { width: 1000, height: 700 })).toEqual({ left: 752, top: 362 });
  expect(previewPlacement({ left: -10, top: 2, bottom: 20 }, { width: 240, height: 280 }, { width: 320, height: 400 })).toEqual({ left: 8, top: 28 });
});

it.each([
  ['1.e4 *', 'e2e4'],
  ['[SetUp "1"]\n[FEN "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1"]\n1.O-O *', 'e1g1'],
  ['[SetUp "1"]\n[FEN "7k/P7/8/8/8/8/8/7K w - - 0 1"]\n1.a8=Q+ *', 'a7a8q'],
])('shows a start-to-end arrow on the after-move board: %s', async (pgn, expected) => {
  const game = parseGames(pgn)[0]; const move = lastRecordedMove(game, 1);
  expect(move).toBe(expected);
  render(<MovePreviewProvider orientation="white"><PreviewableMove fen={game.positions[1]} label={game.moves[0]} move={move}><button>Move</button></PreviewableMove></MovePreviewProvider>);
  fireEvent.click(screen.getByRole('button', { name: `Preview position after ${game.moves[0]}` }));
  const popup = screen.getByRole('dialog');
  expect(popup.querySelector('.mini-board-frame')?.getAttribute('data-fen')).toBe(game.positions[1]);
  await waitFor(() => expect(popup.querySelectorAll('.cg-shapes line')).toHaveLength(1));
});

it('dismisses the popup when selecting the main move while the eye control remains preview-only', () => {
  const selected = vi.fn();
  render(<MovePreviewProvider orientation="white"><PreviewableMove fen={after} label="1. e4"><button onClick={selected}>Replay e4</button></PreviewableMove></MovePreviewProvider>);
  fireEvent.click(screen.getByRole('button', { name: 'Preview position after 1. e4' }));
  expect(screen.getByRole('dialog')).toBeTruthy();
  expect(selected).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('button', { name: 'Replay e4' }));
  expect(screen.queryByRole('dialog')).toBeNull();
  expect(selected).toHaveBeenCalledOnce();
});