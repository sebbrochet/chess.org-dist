import { describe, expect, it, vi } from 'vitest';
import { INITIAL_FEN } from 'chessops/fen';
import { createEngine, parseEngineInfo, type AnalysisRequest, type EngineWorker } from './stockfish';

class WorkerDouble implements EngineWorker {
  onmessage: EngineWorker['onmessage'] = null;
  onerror: EngineWorker['onerror'] = null;
  commands: string[] = [];
  terminated = false;
  postMessage(command: string) { this.commands.push(command); }
  terminate() { this.terminated = true; }
  emit(data: string) { this.onmessage?.({ data } as MessageEvent); }
}
const request: AnalysisRequest = { gameId: 'game', generation: 1, fen: INITIAL_FEN, limits: { depth: 8 }, purpose: 'analysis' };
function boot(worker: WorkerDouble) { worker.emit('uciok'); worker.emit('readyok'); }
describe('serialized engine protocol', () => {
  it('includes the worker bootstrap subphase when startup never reaches UCI', async () => {
    vi.useFakeTimers();
    try {
      const engine = createEngine(() => Object.assign(new WorkerDouble(), { startupStatus: () => 'waiting for worker script acknowledgement' }));
      const pending = engine.analyze(request);
      const failure = expect(pending).rejects.toThrow('worker produced no output; waiting for worker script acknowledgement');
      await vi.advanceTimersByTimeAsync(30000);
      await failure;
    } finally { vi.useRealTimers(); }
  });
  it('evicts a warm idle worker that reports an error before another job', async () => {
    const workers: WorkerDouble[] = [];
    const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
    const first = engine.analyze({ ...request, purpose: 'play' });
    boot(workers[0]); workers[0].emit('bestmove e2e4'); await first;
    workers[0].onerror?.({} as ErrorEvent);
    expect(workers[0].terminated).toBe(true);
    const second = engine.analyze({ ...request, purpose: 'play', generation: 2 });
    boot(workers[1]); workers[1].emit('bestmove d2d4');
    expect((await second).generation).toBe(2);
    expect(workers).toHaveLength(2);
    engine.cancelAll();
  });
  it('reuses successful play workers behind readiness barriers and resets state for different games', async () => {
    const workers: WorkerDouble[] = [];
    const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
    const first = engine.analyze({ ...request, purpose: 'play', level: 2 });
    boot(workers[0]); workers[0].emit('bestmove e2e4');
    await first;
    expect(workers[0].terminated).toBe(false);
    const nextFen = INITIAL_FEN.replace(' w ', ' b ');
    const second = engine.analyze({ ...request, purpose: 'play', generation: 2, fen: nextFen, level: 4 });
    expect(workers).toHaveLength(1);
    expect(workers[0].commands.slice(-4)).toEqual(['stop', 'setoption name Skill Level value 4', 'setoption name Hash value 16', 'isready']);
    workers[0].emit('info depth 12 score cp 999 nodes 99 pv e2e4');
    workers[0].emit('bestmove a2a4');
    workers[0].emit('readyok');
    workers[0].emit('info depth 8 score cp 30 nodes 400 pv e7e5');
    workers[0].emit('bestmove e7e5');
    expect(await second).toMatchObject({ generation: 2, fen: nextFen, bestmove: 'e7e5', depth: 8, score: { value: -30 } });
    const third = engine.analyze({ ...request, gameId: 'another-game', purpose: 'play', level: 8 });
    expect(workers[0].commands).toContain('ucinewgame');
    workers[0].emit('readyok'); workers[0].emit('bestmove d2d4');
    expect((await third).gameId).toBe('another-game');
    expect(workers).toHaveLength(1);
    engine.cancelAll(); expect(workers[0].terminated).toBe(true);
  });
  it('keeps analysis workers isolated while preserving a warm play worker', async () => {
    const workers: WorkerDouble[] = [];
    const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
    const play = engine.analyze({ ...request, purpose: 'play' });
    boot(workers[0]); workers[0].emit('bestmove e2e4'); await play;
    const analysis = engine.analyze(request);
    boot(workers[1]); workers[1].emit('bestmove d2d4'); await analysis;
    expect(workers[1].terminated).toBe(true);
    const resumed = engine.analyze({ ...request, purpose: 'play', generation: 2 });
    workers[0].emit('readyok'); workers[0].emit('bestmove d2d4');
    expect((await resumed).generation).toBe(2);
    expect(workers).toHaveLength(2);
    engine.cancelAll();
  });
  it('retires a cancelled reused worker and ignores its late callback', async () => {
    const workers: WorkerDouble[] = [];
    const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
    const first = engine.analyze({ ...request, purpose: 'play' });
    boot(workers[0]); workers[0].emit('bestmove e2e4'); await first;
    const controller = new AbortController();
    const second = engine.analyze({ ...request, purpose: 'play', generation: 2 }, controller.signal);
    const rejection = expect(second).rejects.toMatchObject({ name: 'AbortError' });
    const late = workers[0].onmessage!;
    controller.abort(); await rejection;
    expect(workers[0].terminated).toBe(true);
    const next = engine.analyze({ ...request, purpose: 'play', generation: 3 });
    late({ data: 'readyok\nbestmove a2a4' } as MessageEvent);
    boot(workers[1]); workers[1].emit('bestmove d2d4');
    expect((await next).generation).toBe(3);
    engine.cancelAll();
  });
  it.each([undefined, 'Stockfish 18 Lite WASM'])('reports whether a stalled startup emitted bootstrap output: %s', async output => {
    vi.useFakeTimers();
    try {
      const workers: WorkerDouble[] = [];
      const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
      const pending = engine.analyze(request);
      const failure = expect(pending).rejects.toThrow(output ? `last worker output: ${output}` : 'worker produced no output');
      await vi.advanceTimersByTimeAsync(10000);
      if (output) workers[1].emit(output);
      await vi.advanceTimersByTimeAsync(20000);
      await failure;
      expect(workers).toHaveLength(2);
      expect(workers.every(worker => worker.terminated)).toBe(true);
    } finally { vi.useRealTimers(); }
  });
  it.each(['startup', 'setup', 'search'] as const)('identifies the %s timeout and terminates the stalled worker without publishing partial evidence', async phase => {
    vi.useFakeTimers();
    try {
      const workers: WorkerDouble[] = [];
      const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
      const pending = engine.analyze(request);
      const failure = expect(pending).rejects.toThrow(phase === 'startup' ? 'startup timed out waiting for uciok' : phase === 'setup' ? 'setup timed out waiting for readyok' : 'search timed out after depth 8 and 900 reported nodes');
      if (phase !== 'startup') workers[0].emit('uciok');
      if (phase === 'search') {
        workers[0].emit('readyok');
        workers[0].emit('info depth 8 score cp 30 nodes 400 pv e2e4');
        workers[0].emit('info depth 9 score cp 40 upperbound nodes 900 pv d2d4');
      }
      await vi.advanceTimersByTimeAsync(30000);
      await failure;
      expect(workers[0].terminated).toBe(true);
      expect(workers).toHaveLength(phase === 'startup' ? 2 : 1);
      const retry = engine.analyze(request);
      boot(workers.at(-1)!); workers.at(-1)!.emit('bestmove e2e4');
      expect((await retry).bestmove).toBe('e2e4');
    } finally { vi.useRealTimers(); }
  });
  it('restarts an unresponsive startup once, ignores its late output and completes with the original request', async () => {
    vi.useFakeTimers();
    try {
      const workers: WorkerDouble[] = [];
      const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
      const pending = engine.analyze({ ...request, purpose: 'play', level: 10, limits: { movetime: 700 } });
      const late = workers[0].onmessage!;
      await vi.advanceTimersByTimeAsync(10000);
      expect(workers).toHaveLength(2);
      expect(workers[0].terminated).toBe(true);
      late({ data: 'uciok\nreadyok\nbestmove a2a4' } as MessageEvent);
      boot(workers[1]);
      expect(workers[1].commands).toContain('setoption name Skill Level value 10');
      expect(workers[1].commands.at(-1)).toBe('go movetime 700');
      workers[1].emit('bestmove e2e4');
      expect(await pending).toMatchObject({ bestmove: 'e2e4', level: 10, limits: { movetime: 700 }, generation: 1 });
    } finally { vi.useRealTimers(); }
  });
  it('never extends the original deadline or restarts a search that has begun', async () => {
    vi.useFakeTimers();
    try {
      const workers: WorkerDouble[] = [];
      const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
      const pending = engine.analyze(request);
      const failure = expect(pending).rejects.toThrow('search timed out');
      await vi.advanceTimersByTimeAsync(10000);
      boot(workers[1]);
      await vi.advanceTimersByTimeAsync(19999);
      expect(workers[1].terminated).toBe(false);
      await vi.advanceTimersByTimeAsync(1);
      await failure;
      expect(workers[1].terminated).toBe(true);
      expect(workers).toHaveLength(2);
    } finally { vi.useRealTimers(); }
  });
  it('cancels recovered startups without creating another worker', async () => {
    vi.useFakeTimers();
    try {
      const workers: WorkerDouble[] = [];
      const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
      const controller = new AbortController();
      const pending = engine.analyze(request, controller.signal);
      const failure = expect(pending).rejects.toMatchObject({ name: 'AbortError' });
      await vi.advanceTimersByTimeAsync(10000);
      controller.abort();
      await failure;
      await vi.advanceTimersByTimeAsync(30000);
      expect(workers).toHaveLength(2);
      expect(workers.every(worker => worker.terminated)).toBe(true);
    } finally { vi.useRealTimers(); }
  });
  it('preserves live-play priority after background startup recovery', async () => {
    vi.useFakeTimers();
    try {
      const workers: WorkerDouble[] = [];
      const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
      const background = engine.analyze(request);
      const cancelled = expect(background).rejects.toMatchObject({ name: 'AbortError' });
      await vi.advanceTimersByTimeAsync(10000);
      const play = engine.analyze({ ...request, purpose: 'play', limits: { movetime: 300 } });
      await cancelled;
      expect(workers[1].terminated).toBe(true);
      boot(workers[2]); workers[2].emit('bestmove e2e4');
      expect((await play).purpose).toBe('play');
      await vi.advanceTimersByTimeAsync(30000);
      expect(workers).toHaveLength(3);
    } finally { vi.useRealTimers(); }
  });
  it('normalizes cp and mate to White, rejecting bound and secondary scores', () => {
    const black = INITIAL_FEN.replace(' w ', ' b ');
    expect(parseEngineInfo('info depth 9 score cp 125 nodes 42 pv e2e4', black)?.score).toEqual({ kind: 'cp', value: -125, perspective: 'white' });
    expect(parseEngineInfo('info depth 9 score mate -3 pv e2e4', black)?.score).toEqual({ kind: 'mate', value: 3, perspective: 'white', winner: 'white' });
    expect(parseEngineInfo('info depth 0 score mate 0', black)?.score).toMatchObject({ kind: 'mate', winner: 'white' });
    expect(parseEngineInfo('info score cp 20 lowerbound', black)).toBeUndefined();
    expect(parseEngineInfo('info depth 12 score cp 56 upperbound nodes 12005 pv d2d4', black)).toEqual({ searchedNodes: 12005 });
    expect(parseEngineInfo('info multipv 2 score cp 20', black)).toBeUndefined();
  });
  it('serializes jobs, preserves limits and completes only on bestmove', async () => {
    const workers: WorkerDouble[] = [];
    const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
    const first = engine.analyze(request);
    const second = engine.analyze({ ...request, generation: 2 });
    expect(workers).toHaveLength(1);
    boot(workers[0]);
    expect(workers[0].commands.at(-1)).toBe('go depth 8');
    workers[0].emit('info depth 8 score cp 30 nodes 400 pv e2e4 e7e5');
    workers[0].emit('info depth 9 score cp 50 upperbound nodes 900 pv d2d4');
    workers[0].emit('bestmove e2e4');
    expect(await first).toMatchObject({ bestmove: 'e2e4', depth: 8, nodes: 400, searchedNodes: 900, limits: { depth: 8 }, score: { kind: 'cp', value: 30, perspective: 'white' }, pv: ['e2e4', 'e7e5'] });
    expect(workers).toHaveLength(2);
    boot(workers[1]); workers[1].emit('bestmove d2d4');
    expect((await second).generation).toBe(2);
  });
  it('terminates cancelled workers and rejects late output, queued jobs and worker errors', async () => {
    const workers: WorkerDouble[] = [];
    const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
    const controller = new AbortController();
    const cancelled = engine.analyze(request, controller.signal);
    const rejected = expect(cancelled).rejects.toMatchObject({ name: 'AbortError' });
    const lateListener = workers[0].onmessage!;
    controller.abort();
    await rejected;
    expect(workers[0].terminated).toBe(true);
    const next = engine.analyze({ ...request, generation: 2 });
    lateListener({ data: 'bestmove a2a4' } as MessageEvent);
    boot(workers[1]); workers[1].emit('bestmove d2d4');
    expect((await next).bestmove).toBe('d2d4');
    const failed = engine.analyze(request);
    const failure = expect(failed).rejects.toThrow('worker failed');
    workers[2].onerror?.({} as ErrorEvent);
    await failure;
    const active = engine.analyze(request);
    const pending = engine.analyze(request);
    const checks = [expect(active).rejects.toMatchObject({ name: 'AbortError' }), expect(pending).rejects.toMatchObject({ name: 'AbortError' })];
    engine.cancelAll();
    await Promise.all(checks);
  });
  it('gives live play priority and preempts background analysis', async () => {
    const workers: WorkerDouble[] = [];
    const engine = createEngine(() => { const worker = new WorkerDouble(); workers.push(worker); return worker; });
    const background = engine.analyze(request);
    const cancelled = expect(background).rejects.toMatchObject({ name: 'AbortError' });
    const play = engine.analyze({ ...request, purpose: 'play', level: 2, limits: { movetime: 300 } });
    await cancelled;
    boot(workers[1]); workers[1].emit('bestmove e2e4');
    expect((await play).purpose).toBe('play');
  });
});