import type { EngineWorker } from './stockfish';

const ASSETS = [
  { url: '/engine/stockfish-18-lite-single.js', bytes: 20670, hash: '2278005057f381491f1c9bb3e44c9f5920b3a00bef9759e33cc6582769a1f1fe', type: 'application/javascript' },
  { url: '/engine/stockfish-18-lite-single.wasm', bytes: 7295411, hash: 'a8fbc05ec6920b56d7485826dcb02c5ffd2826bcbf751cf973046f237a9096f1', type: 'application/wasm' },
];

const WORKER_READY = 'chess.org:stockfish-worker-ready';
const BOOTSTRAP = `self.postMessage('${WORKER_READY}');\n`;

export function createStockfishWorkerFactory(fetcher: typeof fetch = fetch, spawn: (url: string) => EngineWorker = url => new Worker(url)) {
  let resources: Promise<string[]> | undefined;
  function load(): Promise<string[]> {
    if (!resources) {
      resources = Promise.all(ASSETS.map(async asset => {
        const response = await fetcher(asset.url, { credentials: 'omit', signal: AbortSignal.timeout(15000) });
        if (!response.ok) throw new Error(`Stockfish asset unavailable (${response.status}): ${asset.url}`);
        const bytes = await response.arrayBuffer();
        const digest = await crypto.subtle.digest('SHA-256', bytes);
        const hash = Array.from(new Uint8Array(digest), value => value.toString(16).padStart(2, '0')).join('');
        if (bytes.byteLength !== asset.bytes || hash !== asset.hash) throw new Error(`Stockfish asset integrity check failed: ${asset.url}`);
        return new Blob(asset.type === 'application/javascript' ? [bytes, '\n', BOOTSTRAP] : [bytes], { type: asset.type });
      })).then(blobs => blobs.map(blob => URL.createObjectURL(blob))).catch(error => { resources = undefined; throw error; });
    }
    return resources;
  }
  return (): EngineWorker => {
    let worker: EngineWorker | undefined;
    let ready = false;
    let startup = 'loading verified engine assets';
    let closed = false;
    const commands: string[] = [];
    const proxy: EngineWorker = {
      onmessage: null, onerror: null,
      startupStatus: () => startup,
      postMessage(command) { if (closed) return; if (worker && ready) worker.postMessage(command); else commands.push(command); },
      terminate() { closed = true; startup = 'terminated'; commands.length = 0; if (worker) { worker.onmessage = null; worker.onerror = null; worker.terminate(); } },
    };
    void load().then(([script, wasm]) => {
      if (closed) return;
      startup = 'waiting for worker script acknowledgement';
      worker = spawn(`${script}#${encodeURIComponent(wasm)},stockfish`);
      worker.onmessage = event => {
        if (closed) return;
        if (event.data === WORKER_READY) {
          if (ready) return;
          ready = true;
          startup = 'worker script acknowledged; waiting for Stockfish output';
          for (const command of commands.splice(0)) worker!.postMessage(command);
          return;
        }
        if (String(event.data).trim()) startup = 'Stockfish output received';
        proxy.onmessage?.(event);
      };
      worker.onerror = event => { if (!closed) proxy.onerror?.(event); };
    }).catch(error => {
      if (!closed) proxy.onerror?.({ message: error instanceof Error ? error.message : 'Stockfish assets could not be loaded.' } as ErrorEvent);
    });
    return proxy;
  };
}