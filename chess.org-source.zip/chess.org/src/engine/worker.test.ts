import { readFileSync } from 'node:fs';
import { expect, it, vi } from 'vitest';
import { createStockfishWorkerFactory } from './worker';
import type { EngineWorker } from './stockfish';

class WorkerDouble implements EngineWorker {
  constructor(readonly url = '') {}
  onmessage: EngineWorker['onmessage'] = null;
  onerror: EngineWorker['onerror'] = null;
  commands: string[] = [];
  terminated = false;
  postMessage(command: string) { this.commands.push(command); }
  terminate() { this.terminated = true; }
}
const assetResponse = (url: string) => new Response(new Uint8Array(readFileSync(new URL(`../../public${url}`, import.meta.url))));

it('verifies and caches unchanged assets while creating fresh workers and flushing queued commands', async () => {
  const fetcher = vi.fn<typeof fetch>().mockImplementation(async url => assetResponse(String(url)));
  const workers: WorkerDouble[] = [];
  const spawn = vi.fn((url: string) => { const worker = new WorkerDouble(url); workers.push(worker); return worker; });
  const create = createStockfishWorkerFactory(fetcher, spawn);
  const first = create(); first.postMessage('uci');
  expect(first.startupStatus?.()).toBe('loading verified engine assets');
  const received = vi.fn(); first.onmessage = received;
  await vi.waitFor(() => expect(workers).toHaveLength(1));
  expect(first.startupStatus?.()).toBe('waiting for worker script acknowledgement');
  expect(workers[0].commands).toEqual([]);
  workers[0].onmessage?.({ data: 'chess.org:stockfish-worker-ready' } as MessageEvent);
  expect(first.startupStatus?.()).toBe('worker script acknowledged; waiting for Stockfish output');
  expect(workers[0].commands).toEqual(['uci']);
  expect(received).not.toHaveBeenCalled();
  expect(spawn.mock.calls[0][0]).toMatch(/^blob:.*#blob%3A.*?,stockfish$/);
  workers[0].onmessage?.({ data: 'uciok' } as MessageEvent);
  expect(first.startupStatus?.()).toBe('Stockfish output received');
  expect(received).toHaveBeenCalledWith(expect.objectContaining({ data: 'uciok' }));
  first.terminate(); expect(workers[0].terminated).toBe(true);
  const second = create(); second.postMessage('uci');
  await vi.waitFor(() => expect(workers).toHaveLength(2));
  workers[1].onmessage?.({ data: 'chess.org:stockfish-worker-ready' } as MessageEvent);
  expect(fetcher).toHaveBeenCalledTimes(2);
  expect(workers[1].commands).toEqual(['uci']);
  second.terminate();
});

it('does not start a worker after cancellation during asset loading', async () => {
  const fetcher = vi.fn<typeof fetch>().mockImplementation(async url => assetResponse(String(url)));
  const spawn = vi.fn((url: string) => new WorkerDouble(url));
  const create = createStockfishWorkerFactory(fetcher, spawn);
  const cancelled = create(); cancelled.postMessage('uci'); cancelled.terminate();
  const active = create(); active.postMessage('isready');
  await vi.waitFor(() => expect(spawn).toHaveBeenCalledOnce());
  spawn.mock.results[0].value.onmessage?.({ data: 'chess.org:stockfish-worker-ready' } as MessageEvent);
  expect(spawn.mock.results[0].value.commands).toEqual(['isready']);
  active.terminate();
});

it('does not flush cancelled or duplicate readiness and forwards only engine protocol', async () => {
  const workers: WorkerDouble[] = [];
  const create = createStockfishWorkerFactory(vi.fn<typeof fetch>().mockImplementation(async url => assetResponse(String(url))), url => { const worker = new WorkerDouble(url); workers.push(worker); return worker; });
  const first = create(); first.postMessage('uci');
  await vi.waitFor(() => expect(workers).toHaveLength(1));
  const late = workers[0].onmessage!; first.terminate();
  late({ data: 'chess.org:stockfish-worker-ready' } as MessageEvent);
  expect(workers[0].commands).toEqual([]);
  const next = create(); next.postMessage('uci');
  await vi.waitFor(() => expect(workers).toHaveLength(2));
  workers[1].onmessage?.({ data: 'chess.org:stockfish-worker-ready' } as MessageEvent);
  workers[1].onmessage?.({ data: 'chess.org:stockfish-worker-ready' } as MessageEvent);
  next.postMessage('isready');
  expect(workers[1].commands).toEqual(['uci', 'isready']);
  next.terminate();
});

it('rejects bad assets before execution and permits a clean later retry', async () => {
  let corrupt = true;
  const fetcher = vi.fn<typeof fetch>().mockImplementation(async url => corrupt ? new Response('not Stockfish') : assetResponse(String(url)));
  const spawn = vi.fn((url: string) => new WorkerDouble(url));
  const create = createStockfishWorkerFactory(fetcher, spawn);
  const failed = create(); const error = vi.fn(); failed.onerror = error; failed.postMessage('uci');
  await vi.waitFor(() => expect(error).toHaveBeenCalled());
  expect(error.mock.calls[0][0].message).toContain('integrity');
  expect(spawn).not.toHaveBeenCalled();
  failed.terminate(); corrupt = false;
  const retry = create(); retry.postMessage('uci');
  await vi.waitFor(() => expect(spawn).toHaveBeenCalledOnce());
  expect(fetcher).toHaveBeenCalledTimes(4);
  retry.terminate();
});

it('reports failed downloads without creating a worker', async () => {
  const fetcher = vi.fn<typeof fetch>().mockResolvedValue(new Response('', { status: 503 }));
  const spawn = vi.fn((url: string) => new WorkerDouble(url));
  const worker = createStockfishWorkerFactory(fetcher, spawn)(); const error = vi.fn(); worker.onerror = error;
  await vi.waitFor(() => expect(error).toHaveBeenCalled());
  expect(error.mock.calls[0][0].message).toContain('503'); expect(spawn).not.toHaveBeenCalled();
  worker.terminate();
});