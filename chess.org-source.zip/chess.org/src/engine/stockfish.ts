import { positionFromFen } from '../chess/pgn';
import { createStockfishWorkerFactory } from './worker';

export const ENGINE_VERSION = 'stockfish-18.0.7-lite-single';
export const ENGINE_URL = '/engine/stockfish-18-lite-single.js';
export type EngineLimits = { depth: number } | { nodes: number } | { movetime: number };
export type EngineScore = { kind: 'cp'; value: number; perspective: 'white' }
  | { kind: 'mate'; value: number; perspective: 'white'; winner: 'white' | 'black' };
export interface AnalysisRequest {
  gameId: string;
  generation: number;
  fen: string;
  limits: EngineLimits;
  purpose: 'play' | 'analysis';
  level?: number;
  history?: { startFen: string; moves: string[] };
}
export interface AnalysisResult extends AnalysisRequest {
  jobId: string;
  engineVersion: typeof ENGINE_VERSION;
  bestmove: string;
  score?: EngineScore;
  depth: number;
  nodes: number;
  searchedNodes?: number;
  pv: string[];
}
export interface EngineWorker {
  onmessage: ((event: MessageEvent) => void) | null;
  onerror: ((event: ErrorEvent) => void) | null;
  postMessage(command: string): void;
  terminate(): void;
  startupStatus?(): string;
}
export function parseEngineInfo(line: string, fen: string): Partial<Pick<AnalysisResult, 'score' | 'depth' | 'nodes' | 'searchedNodes' | 'pv'>> | undefined {
  if (!line.startsWith('info ') || /\bmultipv\s+(?!1\b)\d+/.test(line)) return;
  const score = /\bscore (cp|mate) (-?\d+)/.exec(line);
  const depth = /\bdepth (\d+)/.exec(line);
  const nodes = /\bnodes (\d+)/.exec(line);
  if (/\b(?:upperbound|lowerbound)\b/.test(line)) return nodes ? { searchedNodes: Number(nodes[1]) } : undefined;
  const pv = /\bpv (.+)$/.exec(line);
  const turn = fen.split(' ')[1] === 'b' ? 'black' : 'white';
  const value = score ? Number(score[2]) * (turn === 'black' ? -1 : 1) : 0;
  const evaluation: EngineScore | undefined = !score ? undefined : score[1] === 'cp'
    ? { kind: 'cp', value, perspective: 'white' }
    : { kind: 'mate', value, perspective: 'white', winner: Number(score[2]) > 0 ? turn : turn === 'white' ? 'black' : 'white' };
  return {
    ...(evaluation ? { score: evaluation } : {}),
    ...(depth ? { depth: Number(depth[1]) } : {}), ...(nodes ? { nodes: Number(nodes[1]), searchedNodes: Number(nodes[1]) } : {}),
    ...(pv ? { pv: pv[1].trim().split(/\s+/) } : {}),
  };
}
const cancelled = () => new DOMException('Engine job cancelled.', 'AbortError');
interface Job {
  request: AnalysisRequest;
  signal?: AbortSignal;
  resolve: (value: AnalysisResult) => void;
  reject: (error: Error) => void;
  cleanup: () => void;
  deadline?: number;
  startupRetried?: boolean;
}

const defaultWorkerFactory = createStockfishWorkerFactory();

export function createEngine(factory: () => EngineWorker = defaultWorkerFactory) {
  const queue: Job[] = [];
  let active: { job: Job; cancel: () => void } | undefined;
  let warmPlay: { worker: EngineWorker; gameId: string } | undefined;
  function pump() {
    if (active) return;
    const job = queue.shift();
    if (!job) return;
    job.cleanup();
    if (job.signal?.aborted) { job.reject(cancelled()); pump(); return; }
    job.deadline ??= performance.now() + 30000;
    const cached = job.request.purpose === 'play' ? warmPlay : undefined;
    if (cached) warmPlay = undefined;
    let worker: EngineWorker;
    try { worker = cached?.worker ?? factory(); }
    catch (error) { job.reject(error instanceof Error ? error : new Error('Engine unavailable.')); pump(); return; }
    let settled = false;
    let started = false;
    let phase: 'startup' | 'setup' | 'search' = cached ? 'setup' : 'startup';
    let lastOutput = '';
    const result: AnalysisResult = { ...job.request, jobId: crypto.randomUUID(), engineVersion: ENGINE_VERSION, bestmove: '', depth: 0, nodes: 0, pv: [] };
    let startupTimer: ReturnType<typeof setTimeout> | undefined;
    const finish = (error?: Error, restart = false) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      clearTimeout(startupTimer);
      job.signal?.removeEventListener('abort', abort);
      worker.onmessage = null;
      worker.onerror = null;
      if (!error && !restart && job.request.purpose === 'play') {
        warmPlay = { worker, gameId: job.request.gameId };
        worker.onerror = () => {
          if (warmPlay?.worker === worker) { worker.terminate(); warmPlay = undefined; }
        };
      } else worker.terminate();
      active = undefined;
      if (restart) queue.unshift(job);
      else if (error) job.reject(error); else job.resolve(result);
      pump();
    };
    const abort = () => finish(cancelled());
    const timer = setTimeout(() => {
      const detail = phase === 'startup' ? `startup timed out waiting for uciok (${lastOutput ? `last worker output: ${lastOutput}` : 'worker produced no output'}${worker.startupStatus ? `; ${worker.startupStatus()}` : ''})`
        : phase === 'setup' ? 'setup timed out waiting for readyok'
        : `search timed out after depth ${result.depth} and ${result.searchedNodes ?? result.nodes} reported nodes`;
      finish(new Error(`Stockfish ${detail}. No result was saved. Retry the engine.`));
    }, Math.max(0, job.deadline - performance.now()));
    active = { job, cancel: abort };
    job.signal?.addEventListener('abort', abort, { once: true });
    if (!cached && !job.startupRetried) startupTimer = setTimeout(() => {
      if (phase === 'startup' && !settled && !job.signal?.aborted && performance.now() < job.deadline!) {
        job.startupRetried = true;
        finish(undefined, true);
      }
    }, 10000);
    const configure = () => {
      phase = 'setup';
      if (cached && cached.gameId !== job.request.gameId) worker.postMessage('ucinewgame');
      worker.postMessage(`setoption name Skill Level value ${job.request.level ?? 20}`);
      worker.postMessage('setoption name Hash value 16');
      worker.postMessage('isready');
    };
    worker.onerror = event => finish(new Error(`Stockfish worker failed${event.message ? `: ${event.message}.` : '.'} The last saved position is unchanged.`));
    worker.onmessage = event => {
      if (settled) return;
      for (const line of String(event.data).split('\n')) {
        if (line.trim()) lastOutput = line.trim().slice(0, 180);
        if (line === 'uciok') {
          clearTimeout(startupTimer);
          if (!cached) configure();
        } else if (line === 'readyok' && !started) {
          started = true;
          phase = 'search';
          const history = job.request.history;
          worker.postMessage(history ? `position fen ${history.startFen} moves ${history.moves.join(' ')}` : `position fen ${job.request.fen}`);
          const [limit, value] = Object.entries(job.request.limits)[0];
          worker.postMessage(`go ${limit} ${value}`);
        } else if (started && line.startsWith('info ')) Object.assign(result, parseEngineInfo(line, result.fen));
        else if (started && line.startsWith('bestmove ')) {
          result.bestmove = line.split(/\s+/)[1];
          finish();
        }
      }
    };
    if (cached) { worker.postMessage('stop'); configure(); }
    else worker.postMessage('uci');
  }
  return {
    analyze(request: AnalysisRequest, signal?: AbortSignal): Promise<AnalysisResult> {
      try {
        positionFromFen(request.fen);
        const limits = Object.entries(request.limits);
        if (limits.length !== 1 || !['depth', 'nodes', 'movetime'].includes(limits[0][0]) ||
          !Number.isSafeInteger(limits[0][1]) || limits[0][1] <= 0) throw new Error('Supply one positive integer search limit.');
        if (request.level !== undefined && (!Number.isInteger(request.level) || request.level < 0 || request.level > 20)) throw new Error('Invalid Stockfish level.');
      } catch (error) { return Promise.reject(error); }
      if (signal?.aborted) return Promise.reject(cancelled());
      return new Promise((resolve, reject) => {
        const job: Job = { request: structuredClone(request), signal, resolve, reject, cleanup: () => signal?.removeEventListener('abort', abort) };
        const abort = () => {
          const index = queue.indexOf(job);
          if (index >= 0) { queue.splice(index, 1); job.cleanup(); reject(cancelled()); }
        };
        signal?.addEventListener('abort', abort, { once: true });
        if (request.purpose === 'play') {
          const index = queue.findIndex(candidate => candidate.request.purpose !== 'play');
          queue.splice(index < 0 ? queue.length : index, 0, job);
          if (active?.job.request.purpose === 'analysis') active.cancel();
        } else queue.push(job);
        pump();
      });
    },
    cancelAll() {
      for (const job of queue.splice(0)) { job.cleanup(); job.reject(cancelled()); }
      active?.cancel();
      if (warmPlay) { warmPlay.worker.terminate(); warmPlay = undefined; }
    },
  };
}
export type LocalEngine = ReturnType<typeof createEngine>;
export const localEngine = createEngine();
if (import.meta.hot) import.meta.hot.dispose(() => localEngine.cancelAll());