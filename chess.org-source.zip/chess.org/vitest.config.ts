import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: { pool: 'vmForks', maxWorkers: 1, include: ['src/**/*.test.{ts,tsx}'] },
});