import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { buildServiceWorker } from './src/app/serviceWorker';

function publicAssets(directory: string, prefix = ''): string[] {
  return readdirSync(directory, { withFileTypes: true }).flatMap(entry => entry.isDirectory()
    ? publicAssets(resolve(directory, entry.name), `${prefix}/${entry.name}`) : [`${prefix}/${entry.name}`]);
}
export default defineConfig({
  plugins: [react(), {
    name: 'offline-shell',
    generateBundle(_options, bundle) {
      const retained = publicAssets(resolve('public'));
      const assets = ['/', ...retained, ...Object.keys(bundle).map(file => `/${file}`)];
      const hash = createHash('sha256').update(Object.values(bundle).map(file => file.type === 'chunk' ? file.code : String(file.source)).join(''));
      for (const file of retained.sort()) hash.update(file).update(readFileSync(resolve('public', file.slice(1))));
      const version = hash.digest('hex').slice(0, 12);
      this.emitFile({ type: 'asset', fileName: 'sw.js', source: buildServiceWorker(assets, version) });
    },
  }],
  server: { host: true, allowedHosts: true, strictPort: false },
});